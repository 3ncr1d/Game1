extends Node2D
class_name BackgroundAnimation
## Renders subtle 2D pixel-art environmental animations for the isometric fantasy village at dusk:
## - Warm flickering light in homestead cottage windows
## - Gentle drifting twilight fog bands
## - Falling dusk leaves

@export var enable_particles: bool = true
@export var reduced_motion: bool = false

var _time: float = 0.0
var _leaves: Array[Dictionary] = []
var _fog_bands: Array[Dictionary] = []
var _window_lights: Array[Vector2] = [
	Vector2(1180, 560),
	Vector2(1235, 578),
	Vector2(1390, 520),
	Vector2(1485, 625),
]

func _ready() -> void:
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	var leaf_colors: Array[Color] = [
		Color("#9c6b3b"),
		Color("#b88446"),
		Color("#7d5233"),
		Color("#6b7d57"),
	]
	for i in range(18):
		_leaves.append({
			"pos": Vector2(fmod(i * 117.0, 1920.0), fmod(i * 83.0, 1080.0)),
			"vel": Vector2(-24.0 - (i % 3) * 6.0, 28.0 + (i % 4) * 5.0),
			"phase": float(i) * 0.65,
			"color": leaf_colors[i % leaf_colors.size()],
		})

	_fog_bands = [
		{"x": 120.0, "y": 520.0, "w": 520.0, "h": 28.0, "speed": 12.0, "alpha": 0.14},
		{"x": 860.0, "y": 585.0, "w": 640.0, "h": 34.0, "speed": 9.0, "alpha": 0.16},
		{"x": 420.0, "y": 780.0, "w": 590.0, "h": 36.0, "speed": 14.0, "alpha": 0.12},
	]

func _process(delta: float) -> void:
	var step := delta * (0.2 if reduced_motion else 1.0)
	_time += step
	var viewport_size := get_viewport_rect().size

	for fog in _fog_bands:
		fog["x"] += fog["speed"] * step
		if fog["x"] > viewport_size.x + 80.0:
			fog["x"] = -fog["w"] - 40.0

	if enable_particles:
		for leaf in _leaves:
			var pos: Vector2 = leaf["pos"]
			var vel: Vector2 = leaf["vel"]
			pos.x += (vel.x + sin(_time * 1.8 + leaf["phase"]) * 10.0) * step
			pos.y += vel.y * step
			if pos.x < -16.0:
				pos.x = viewport_size.x + 12.0
			if pos.y > viewport_size.y + 16.0:
				pos.y = -12.0
				pos.x = fmod(pos.x + 340.0, viewport_size.x)
			leaf["pos"] = pos

	queue_redraw()

func _draw() -> void:
	# 1. Warm flickering cottage window glow
	for idx in range(_window_lights.size()):
		var pt: Vector2 = _window_lights[idx]
		var flicker := 0.5 + 0.5 * sin(_time * 2.8 + float(idx) * 1.3)
		var glow_alpha := lerpf(0.10, 0.20, flicker)
		draw_rect(Rect2(pt - Vector2(18, 18), Vector2(36, 36)), Color(0.91, 0.66, 0.30, glow_alpha))
		draw_rect(Rect2(pt - Vector2(6, 8), Vector2(12, 16)), Color("#E2B05A"))

	# 2. Gentle drifting twilight fog bands
	for fog in _fog_bands:
		var col := Color(0.69, 0.74, 0.70, fog["alpha"])
		draw_rect(Rect2(fog["x"], fog["y"], fog["w"], fog["h"]), col)

	# 3. Falling pixel-art dusk leaves
	if enable_particles:
		for leaf in _leaves:
			var pos: Vector2 = leaf["pos"]
			var c: Color = leaf["color"]
			draw_rect(Rect2(pos.round(), Vector2(6, 4)), c)
