extends Control
class_name MainMenu
## Clean, minimalist, atmospheric Main Menu for a 2D isometric fantasy RPG (Godot 4).
## Strictly adheres to the restrained fantasy color palette and left-center asymmetrical layout
## without displaying any game title, character portraits, or HUD clutter.

const SAVE_DIR := "user://saves/"
const CHARACTER_CREATION_SCENE := "res://scenes/ui/CharacterCreation.tscn"
const GAME_WORLD_SCENE := "res://scenes/world/IsometricWorld.tscn"

# Restrained Fantasy Color Palette
const COLOR_BG_OVERLAY := Color("#111613C8")      # Dark charcoal with slight green undertones
const COLOR_TEXT_PRIMARY := Color("#F2ECE1")      # Warm ivory
const COLOR_TEXT_SECONDARY := Color("#B5AC9A")    # Muted beige
const COLOR_SELECTED := Color("#E2B05A")          # Soft golden amber
const COLOR_HOVER := Color("#7E9C82")             # Muted sage green
const COLOR_BORDER := Color("#5A4B38")            # Subtle dark bronze

@onready var background: TextureRect = $Background
@onready var background_animation: Node2D = $BackgroundAnimation
@onready var dark_overlay: ColorRect = $DarkOverlay
@onready var main_layout: Control = $MainLayout
@onready var menu_buttons: VBoxContainer = $MainLayout/MenuButtons
@onready var continue_button: Button = $MainLayout/MenuButtons/ContinueButton
@onready var new_adventure_button: Button = $MainLayout/MenuButtons/NewAdventureButton
@onready var load_game_button: Button = $MainLayout/MenuButtons/LoadGameButton
@onready var settings_button: Button = $MainLayout/MenuButtons/SettingsButton
@onready var credits_button: Button = $MainLayout/MenuButtons/CreditsButton
@onready var exit_button: Button = $MainLayout/MenuButtons/ExitButton
@onready var version_label: Label = $VersionLabel
@onready var confirmation_dialog: ConfirmationDialog = $ConfirmationDialog

var _no_save_notice_label: Label
var _most_recent_save_path: String = ""
var _buttons: Array[Button] = []

func _ready() -> void:
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	dark_overlay.color = COLOR_BG_OVERLAY
	version_label.modulate = COLOR_TEXT_SECONDARY

	_buttons = [
		continue_button,
		new_adventure_button,
		load_game_button,
		settings_button,
		credits_button,
		exit_button,
	]

	_setup_button_styles()
	_check_most_recent_save()
	_setup_focus_neighbours()
	_connect_signals()
	_play_sequential_fade_in()

func _setup_button_styles() -> void:
	for btn in _buttons:
		btn.alignment = HORIZONTAL_ALIGNMENT_LEFT
		btn.custom_minimum_size = Vector2(260, 38)
		btn.mouse_filter = Control.MOUSE_FILTER_STOP
		btn.focus_mode = Control.FOCUS_ALL

		var normal_box := StyleBoxFlat.new()
		normal_box.bg_color = Color(0.067, 0.086, 0.075, 0.32)
		normal_box.border_width_bottom = 1
		normal_box.border_color = Color(COLOR_BORDER, 0.30)
		normal_box.content_margin_left = 14.0
		normal_box.content_margin_right = 14.0
		normal_box.content_margin_top = 8.0
		normal_box.content_margin_bottom = 8.0

		var hover_box := normal_box.duplicate() as StyleBoxFlat
		hover_box.bg_color = Color(0.078, 0.106, 0.090, 0.72)
		hover_box.border_width_left = 2
		hover_box.border_color = COLOR_HOVER

		var focus_box := normal_box.duplicate() as StyleBoxFlat
		focus_box.bg_color = Color(0.078, 0.106, 0.090, 0.78)
		focus_box.border_width_left = 2
		focus_box.border_color = COLOR_SELECTED

		var disabled_box := normal_box.duplicate() as StyleBoxFlat
		disabled_box.bg_color = Color(0.067, 0.086, 0.075, 0.18)

		btn.add_theme_stylebox_override("normal", normal_box)
		btn.add_theme_stylebox_override("hover", hover_box)
		btn.add_theme_stylebox_override("focus", focus_box)
		btn.add_theme_stylebox_override("pressed", focus_box)
		btn.add_theme_stylebox_override("disabled", disabled_box)

		btn.add_theme_color_override("font_color", COLOR_TEXT_PRIMARY)
		btn.add_theme_color_override("font_hover_color", COLOR_TEXT_PRIMARY)
		btn.add_theme_color_override("font_focus_color", COLOR_SELECTED)
		btn.add_theme_color_override("font_pressed_color", COLOR_SELECTED)
		btn.add_theme_color_override("font_disabled_color", Color(COLOR_TEXT_SECONDARY, 0.38))

func _check_most_recent_save() -> void:
	_most_recent_save_path = _find_latest_save_file()
	if _most_recent_save_path.is_empty():
		continue_button.disabled = true
		continue_button.focus_mode = Control.FOCUS_NONE
		if _no_save_notice_label == null:
			_no_save_notice_label = Label.new()
			_no_save_notice_label.name = "NoSaveNoticeLabel"
			_no_save_notice_label.text = "No saved adventure exists."
			_no_save_notice_label.add_theme_color_override("font_color", COLOR_TEXT_SECONDARY)
			_no_save_notice_label.add_theme_font_size_override("font_size", 12)
			menu_buttons.add_child(_no_save_notice_label)
			menu_buttons.move_child(_no_save_notice_label, 1)
		new_adventure_button.grab_focus()
	else:
		continue_button.disabled = false
		continue_button.focus_mode = Control.FOCUS_ALL
		if _no_save_notice_label != null:
			_no_save_notice_label.visible = false
		continue_button.grab_focus()

func _find_latest_save_file() -> String:
	var dir := DirAccess.open(SAVE_DIR)
	if dir == null:
		return ""
	var latest_file := ""
	var latest_time := 0
	dir.list_dir_begin()
	var file_name := dir.get_next()
	while file_name != "":
		if not dir.current_is_dir() and file_name.ends_with(".sav"):
			var full_path := SAVE_DIR + file_name
			var mod_time := FileAccess.get_modified_time(full_path)
			if mod_time > latest_time:
				latest_time = mod_time
				latest_file = full_path
		file_name = dir.get_next()
	dir.list_dir_end()
	return latest_file

func _setup_focus_neighbours() -> void:
	var focusable: Array[Button] = []
	for btn in _buttons:
		if not btn.disabled:
			focusable.append(btn)
	for i in range(focusable.size()):
		var prev_btn := focusable[(i - 1 + focusable.size()) % focusable.size()]
		var next_btn := focusable[(i + 1) % focusable.size()]
		focusable[i].focus_neighbor_top = prev_btn.get_path()
		focusable[i].focus_neighbor_bottom = next_btn.get_path()

func _connect_signals() -> void:
	continue_button.pressed.connect(_on_continue_pressed)
	new_adventure_button.pressed.connect(_on_new_adventure_pressed)
	load_game_button.pressed.connect(_on_load_game_pressed)
	settings_button.pressed.connect(_on_settings_pressed)
	credits_button.pressed.connect(_on_credits_pressed)
	exit_button.pressed.connect(_on_exit_pressed)

	confirmation_dialog.title = ""
	confirmation_dialog.dialog_text = "Are you sure you want to leave?"
	confirmation_dialog.ok_button_text = "Confirm"
	confirmation_dialog.cancel_button_text = "Cancel"
	confirmation_dialog.confirmed.connect(_on_exit_confirmed)

	for btn in _buttons:
		btn.mouse_entered.connect(func() -> void:
			if not btn.disabled:
				btn.grab_focus()
				var tw := create_tween()
				tw.tween_property(btn, "position:x", 4.0, 0.12)
		)
		btn.mouse_exited.connect(func() -> void:
			var tw := create_tween()
			tw.tween_property(btn, "position:x", 0.0, 0.12)
		)

func _play_sequential_fade_in() -> void:
	for i in range(_buttons.size()):
		var btn := _buttons[i]
		btn.modulate.a = 0.0
		var tw := create_tween()
		tw.tween_interval(float(i) * 0.045)
		tw.tween_property(btn, "modulate:a", 1.0, 0.20)

func _fade_and_change_scene(scene_path: String) -> void:
	var tw := create_tween()
	tw.tween_property(self, "modulate", Color.BLACK, 0.22)
	tw.tween_callback(func() -> void:
		if ResourceLoader.exists(scene_path):
			get_tree().change_scene_to_file(scene_path)
	)

func _on_continue_pressed() -> void:
	if _most_recent_save_path.is_empty():
		return
	_fade_and_change_scene(GAME_WORLD_SCENE)

func _on_new_adventure_pressed() -> void:
	# Character creation happens before entering the game world
	_fade_and_change_scene(CHARACTER_CREATION_SCENE)

func _on_load_game_pressed() -> void:
	_open_sub_panel("LoadGamePanel")

func _on_settings_pressed() -> void:
	_open_sub_panel("SettingsPanel")

func _on_credits_pressed() -> void:
	_open_sub_panel("CreditsPanel")

func _on_exit_pressed() -> void:
	confirmation_dialog.popup_centered()

func _on_exit_confirmed() -> void:
	get_tree().quit()

func _open_sub_panel(panel_name: String) -> void:
	if has_node(panel_name):
		var panel := get_node(panel_name) as Control
		panel.visible = true
