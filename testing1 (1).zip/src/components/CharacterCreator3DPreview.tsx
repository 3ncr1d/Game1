import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { CharacterRaceId, CharacterSubclassId } from '../game/rules';
import {
  ArchetypeClassId,
  CharacterDetailedAppearance,
} from '../game/characterCreationData';

interface CharacterCreator3DPreviewProps {
  raceId: CharacterRaceId;
  archetypeClass: ArchetypeClassId;
  subclassId?: CharacterSubclassId;
  appearance: CharacterDetailedAppearance;
  framingMode: 'full_body' | 'face';
  className?: string;
}

export const CharacterCreator3DPreview: React.FC<CharacterCreator3DPreviewProps> = ({
  raceId,
  archetypeClass,
  subclassId,
  appearance,
  framingMode,
  className = '',
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Orbit state
  const orbitAngleY = useRef<number>(0.2); // Current yaw
  const targetAngleY = useRef<number>(0.2);
  const orbitAngleX = useRef<number>(0.05); // Current pitch
  const targetAngleX = useRef<number>(0.05);
  const orbitDistance = useRef<number>(framingMode === 'face' ? 1.35 : 3.2);
  const targetDistance = useRef<number>(framingMode === 'face' ? 1.35 : 3.2);
  const targetLookAtY = useRef<number>(framingMode === 'face' ? 1.62 : 1.0);
  const currentLookAtY = useRef<number>(framingMode === 'face' ? 1.62 : 1.0);

  const isDragging = useRef<boolean>(false);
  const lastMousePos = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  // Update target framing when framingMode prop changes
  useEffect(() => {
    if (framingMode === 'face') {
      targetDistance.current = 1.35;
      targetLookAtY.current = 1.62;
    } else {
      targetDistance.current = 3.2;
      targetLookAtY.current = 1.0;
    }
  }, [framingMode]);

  // Handle Preset View Angles
  const setTargetYaw = useCallback((yaw: number) => {
    targetAngleY.current = yaw;
  }, []);

  const stepRotate = useCallback((delta: number) => {
    targetAngleY.current += delta;
  }, []);

  const zoomCamera = useCallback((delta: number) => {
    targetDistance.current = Math.max(0.9, Math.min(4.8, targetDistance.current + delta));
  }, []);

  const resetCamera = useCallback(() => {
    targetAngleY.current = 0.2;
    targetAngleX.current = 0.05;
    if (framingMode === 'face') {
      targetDistance.current = 1.35;
      targetLookAtY.current = 1.62;
    } else {
      targetDistance.current = 3.2;
      targetLookAtY.current = 1.0;
    }
  }, [framingMode]);

  // Main Three.js Scene Setup & Re-renders
  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    let isDisposed = false;
    let animationFrameId = 0;

    // Renderer
    const renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      alpha: true,
      powerPreference: 'high-performance',
    });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2.0));
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFShadowMap;

    // Scene
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x111613, 0.12);

    // Camera
    const camera = new THREE.PerspectiveCamera(
      36,
      container.clientWidth / Math.max(container.clientHeight, 1),
      0.1,
      25
    );

    // Lighting (Studio 3-Point Lighting for Character Creation)
    const keyLight = new THREE.DirectionalLight(0xfff5e6, 1.85);
    keyLight.position.set(2.8, 3.8, 3.2);
    keyLight.castShadow = true;
    keyLight.shadow.mapSize.width = 1024;
    keyLight.shadow.mapSize.height = 1024;
    keyLight.shadow.bias = -0.0005;
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0x88b0d8, 1.4);
    rimLight.position.set(-2.6, 2.5, -2.8);
    scene.add(rimLight);

    const fillLight = new THREE.DirectionalLight(0x4a5568, 0.8);
    fillLight.position.set(-2.5, 1.5, 2.5);
    scene.add(fillLight);

    const ambientLight = new THREE.AmbientLight(0x1a2024, 0.7);
    scene.add(ambientLight);

    const overheadPoint = new THREE.PointLight(0xe2b05a, 0.45, 4.0);
    overheadPoint.position.set(0, 2.6, 0.4);
    scene.add(overheadPoint);

    // =========================================================================
    // PEDESTAL & SANCTUM PLINTH
    // =========================================================================
    const pedestalGroup = new THREE.Group();
    scene.add(pedestalGroup);

    // Base Stone Plinth
    const plinthGeo = new THREE.CylinderGeometry(1.25, 1.35, 0.22, 36);
    const plinthMat = new THREE.MeshStandardMaterial({
      color: 0x181e19,
      roughness: 0.85,
      metalness: 0.15,
    });
    const plinth = new THREE.Mesh(plinthGeo, plinthMat);
    plinth.position.y = -0.11;
    plinth.receiveShadow = true;
    pedestalGroup.add(plinth);

    // Outer Stone Step
    const stepGeo = new THREE.CylinderGeometry(1.48, 1.56, 0.1, 36);
    const stepMat = new THREE.MeshStandardMaterial({
      color: 0x111613,
      roughness: 0.9,
      metalness: 0.1,
    });
    const step = new THREE.Mesh(stepGeo, stepMat);
    step.position.y = -0.22;
    step.receiveShadow = true;
    pedestalGroup.add(step);

    // Glowing Concentric Runic Ring
    const runeRingGeo = new THREE.RingGeometry(0.85, 1.15, 48);
    const specColor =
      subclassId === 'dawn_warden'
        ? 0xf59e0b
        : subclassId === 'vengeance_knight'
        ? 0xb91c1c
        : subclassId === 'crimson_savant'
        ? 0xdc2626
        : subclassId === 'rift_chronomancer'
        ? 0xa855f7
        : subclassId === 'briar_stalker'
        ? 0x16a34a
        : subclassId === 'ironbough_sentinel'
        ? 0x15803d
        : null;

    const runeColor =
      specColor ??
      (raceId === 'tiefling'
        ? 0xb85349
        : raceId === 'wood_kin'
        ? 0x7e9c82
        : raceId === 'half_elf'
        ? 0xc7ccd1
        : 0xe2b05a);
    const runeMat = new THREE.MeshBasicMaterial({
      color: runeColor,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.45,
    });
    const runeRing = new THREE.Mesh(runeRingGeo, runeMat);
    runeRing.rotation.x = -Math.PI / 2;
    runeRing.position.y = 0.005;
    pedestalGroup.add(runeRing);

    // Inner Accent Ring
    const innerRingGeo = new THREE.RingGeometry(0.35, 0.45, 36);
    const innerRingMat = new THREE.MeshBasicMaterial({
      color: specColor ?? 0xe2b05a,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.35,
    });
    const innerRing = new THREE.Mesh(innerRingGeo, innerRingMat);
    innerRing.rotation.x = -Math.PI / 2;
    innerRing.position.y = 0.006;
    pedestalGroup.add(innerRing);

    // Floating Dust / Starlight Particle Cloud
    const particleCount = 75;
    const particleGeo = new THREE.BufferGeometry();
    const particlePositions = new Float32Array(particleCount * 3);
    for (let i = 0; i < particleCount; i++) {
      particlePositions[i * 3] = (Math.random() - 0.5) * 2.8;
      particlePositions[i * 3 + 1] = Math.random() * 2.6;
      particlePositions[i * 3 + 2] = (Math.random() - 0.5) * 2.8;
    }
    particleGeo.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));
    const particleMat = new THREE.PointsMaterial({
      color: runeColor,
      size: 0.035,
      transparent: true,
      opacity: 0.5,
    });
    const particleCloud = new THREE.Points(particleGeo, particleMat);
    scene.add(particleCloud);

    // =========================================================================
    // DYNAMIC 3D CHARACTER COMPOSITE MESH
    // =========================================================================
    const characterRoot = new THREE.Group();
    scene.add(characterRoot);

    // Morphable scales from appearance
    const bodyHeight = appearance.height || 1.0;
    const shoulderWidth = appearance.shoulderWidth || 1.0;
    const chestScale = appearance.chest || 1.0;
    const waistScale = appearance.waist || 1.0;
    const armThickness = appearance.armThickness || 1.0;
    const legThickness = appearance.legThickness || 1.0;

    characterRoot.scale.set(shoulderWidth, bodyHeight, (chestScale + waistScale) / 2);

    // Colors & Materials
    const skinColorHex = appearance.skinToneHex || '#e8cbb8';
    const skinMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color(skinColorHex),
      roughness: 0.65,
      metalness: 0.08,
    });

    const hairColorHex = appearance.hairPrimaryColor || '#d8d0c5';
    const hairMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color(hairColorHex),
      roughness: 0.55,
      metalness: 0.15,
    });

    // Class Equipment Palettes
    const isWarrior = archetypeClass === 'warrior';
    const isMage = archetypeClass === 'mage';
    const isRogue = archetypeClass === 'rogue';
    const isPaladin = archetypeClass === 'paladin';
    const isRanger = archetypeClass === 'ranger';

    const armorColor = isWarrior
      ? 0x334155
      : isMage
      ? 0x272036
      : isRogue
      ? 0x242728
      : isPaladin
      ? 0x475569
      : 0x2d3a28;

    const trimColor = isWarrior
      ? 0xb45309
      : isMage
      ? 0x9333ea
      : isRogue
      ? 0x78716c
      : isPaladin
      ? 0xe2b05a
      : 0x84cc16;

    const cloakColor = isWarrior
      ? 0x7f1d1d
      : isMage
      ? 0x4c1d95
      : isRogue
      ? 0x1e293b
      : isPaladin
      ? 0x1e3a8a
      : 0x14532d;

    const metalMat = new THREE.MeshStandardMaterial({
      color: armorColor,
      roughness: 0.4,
      metalness: 0.75,
    });

    const trimMat = new THREE.MeshStandardMaterial({
      color: trimColor,
      roughness: 0.45,
      metalness: 0.6,
    });

    const clothMat = new THREE.MeshStandardMaterial({
      color: cloakColor,
      roughness: 0.85,
      metalness: 0.05,
      side: THREE.DoubleSide,
    });

    const darkLeatherMat = new THREE.MeshStandardMaterial({
      color: 0x1f2421,
      roughness: 0.7,
      metalness: 0.2,
    });

    // 1. Lower Body: Boots & Greaves
    const bootGeo = new THREE.CylinderGeometry(
      0.11 * legThickness,
      0.13 * legThickness,
      0.55,
      16
    );
    const leftBoot = new THREE.Mesh(bootGeo, darkLeatherMat);
    leftBoot.position.set(-0.19 * shoulderWidth, 0.28, 0);
    leftBoot.castShadow = true;
    characterRoot.add(leftBoot);

    const rightBoot = new THREE.Mesh(bootGeo, darkLeatherMat);
    rightBoot.position.set(0.19 * shoulderWidth, 0.28, 0);
    rightBoot.castShadow = true;
    characterRoot.add(rightBoot);

    // Upper Leg / Trousers
    const legGeo = new THREE.CylinderGeometry(
      0.12 * legThickness,
      0.11 * legThickness,
      0.5,
      16
    );
    const leftLeg = new THREE.Mesh(legGeo, metalMat);
    leftLeg.position.set(-0.19 * shoulderWidth, 0.74, 0);
    leftLeg.castShadow = true;
    characterRoot.add(leftLeg);

    const rightLeg = new THREE.Mesh(legGeo, metalMat);
    rightLeg.position.set(0.19 * shoulderWidth, 0.74, 0);
    rightLeg.castShadow = true;
    characterRoot.add(rightLeg);

    // 2. Torso Cuirass / Robes
    const torsoPoints: THREE.Vector2[] = [
      new THREE.Vector2(0.14 * waistScale, 0.0),
      new THREE.Vector2(0.19 * waistScale, 0.2),
      new THREE.Vector2(0.24 * chestScale, 0.45),
      new THREE.Vector2(0.27 * shoulderWidth, 0.68),
      new THREE.Vector2(0.18, 0.72),
      new THREE.Vector2(0.08, 0.76),
    ];
    const torsoGeo = new THREE.LatheGeometry(torsoPoints, 20);
    const torso = new THREE.Mesh(torsoGeo, isMage ? clothMat : metalMat);
    torso.position.y = 0.95;
    torso.castShadow = true;
    torso.receiveShadow = true;
    characterRoot.add(torso);

    // Chestplate Trim Insignia
    const chestPlateGeo = new THREE.BoxGeometry(
      0.28 * chestScale,
      0.24,
      0.18 * chestScale
    );
    const chestPlate = new THREE.Mesh(chestPlateGeo, trimMat);
    chestPlate.position.set(0, 1.36, 0.08);
    chestPlate.castShadow = true;
    characterRoot.add(chestPlate);

    // Belt & Buckle
    const beltGeo = new THREE.CylinderGeometry(
      0.22 * waistScale,
      0.23 * waistScale,
      0.08,
      20
    );
    const belt = new THREE.Mesh(beltGeo, darkLeatherMat);
    belt.position.y = 1.0;
    characterRoot.add(belt);

    const buckleGeo = new THREE.BoxGeometry(0.08, 0.07, 0.04);
    const buckle = new THREE.Mesh(buckleGeo, trimMat);
    buckle.position.set(0, 1.0, 0.22 * waistScale);
    characterRoot.add(buckle);

    // 3. Pauldrons (Shoulder Armor)
    const pauldronGeo = new THREE.SphereGeometry(
      0.15 * shoulderWidth,
      12,
      12,
      0,
      Math.PI * 2,
      0,
      Math.PI * 0.65
    );
    const leftPauldron = new THREE.Mesh(pauldronGeo, metalMat);
    leftPauldron.position.set(-0.35 * shoulderWidth, 1.58, 0);
    leftPauldron.rotation.z = 0.35;
    leftPauldron.castShadow = true;
    characterRoot.add(leftPauldron);

    const rightPauldron = new THREE.Mesh(pauldronGeo, metalMat);
    rightPauldron.position.set(0.35 * shoulderWidth, 1.58, 0);
    rightPauldron.rotation.z = -0.35;
    rightPauldron.castShadow = true;
    characterRoot.add(rightPauldron);

    // 4. Arms & Gauntlets
    const armGeo = new THREE.CylinderGeometry(
      0.075 * armThickness,
      0.07 * armThickness,
      0.62,
      14
    );
    const leftArm = new THREE.Mesh(armGeo, darkLeatherMat);
    leftArm.position.set(-0.35 * shoulderWidth, 1.25, 0);
    leftArm.rotation.z = 0.08;
    leftArm.castShadow = true;
    characterRoot.add(leftArm);

    const rightArm = new THREE.Mesh(armGeo, darkLeatherMat);
    rightArm.position.set(0.35 * shoulderWidth, 1.25, 0);
    rightArm.rotation.z = -0.08;
    rightArm.castShadow = true;
    characterRoot.add(rightArm);

    // Hands
    const handGeo = new THREE.SphereGeometry(0.065, 10, 10);
    const leftHand = new THREE.Mesh(handGeo, skinMat);
    leftHand.position.set(-0.38 * shoulderWidth, 0.9, 0);
    characterRoot.add(leftHand);

    const rightHand = new THREE.Mesh(handGeo, skinMat);
    rightHand.position.set(0.38 * shoulderWidth, 0.9, 0);
    characterRoot.add(rightHand);

    // 5. Head Group (Morphable facial geometry)
    const headGroup = new THREE.Group();
    headGroup.position.set(0, 1.76, 0);
    characterRoot.add(headGroup);

    // Neck
    const neckGeo = new THREE.CylinderGeometry(0.085, 0.1, 0.14, 16);
    const neck = new THREE.Mesh(neckGeo, skinMat);
    neck.position.y = -0.08;
    headGroup.add(neck);

    // Head base (Spherical Cranium with facial scaling)
    const faceW = appearance.faceWidth || 1.0;
    const faceL = appearance.faceLength || 1.0;
    const jawW = appearance.jawWidth || 1.0;
    const jawS = appearance.jawShape ?? 0.5;

    const craniumGeo = new THREE.SphereGeometry(0.14, 24, 20);
    const cranium = new THREE.Mesh(craniumGeo, skinMat);
    cranium.scale.set(faceW, faceL, 1.02);
    cranium.castShadow = true;
    headGroup.add(cranium);

    // Jaw / Chin Box
    const jawGeo = new THREE.BoxGeometry(
      0.16 * jawW * faceW,
      0.11 * faceL,
      0.15
    );
    const jaw = new THREE.Mesh(jawGeo, skinMat);
    jaw.position.set(0, -0.08 * faceL, 0.035);
    jaw.rotation.x = 0.18 + jawS * 0.12;
    headGroup.add(jaw);

    // Nose
    const noseGeo = new THREE.ConeGeometry(0.026 * (appearance.noseWidth || 1.0), 0.07 * (appearance.noseLength || 1.0), 8);
    const nose = new THREE.Mesh(noseGeo, skinMat);
    nose.position.set(0, -0.01, 0.145);
    nose.rotation.x = -Math.PI / 2.3;
    headGroup.add(nose);

    // Eyes
    const eyeColorHex = appearance.eyeColorHex || '#e2b05a';
    const eyeMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color(eyeColorHex),
      emissive: new THREE.Color(eyeColorHex),
      emissiveIntensity: raceId === 'half_elf' || raceId === 'tiefling' ? 0.45 : 0.15,
      roughness: 0.2,
      metalness: 0.1,
    });
    const eyeGeo = new THREE.SphereGeometry(0.02 * (appearance.eyeSize || 1.0), 10, 10);

    const eyeSpacing = 0.052 * (appearance.eyeSpacing || 1.0);
    const leftEye = new THREE.Mesh(eyeGeo, eyeMat);
    leftEye.position.set(-eyeSpacing, 0.025, 0.125);
    headGroup.add(leftEye);

    const rightEye = new THREE.Mesh(eyeGeo, eyeMat);
    rightEye.position.set(eyeSpacing, 0.025, 0.125);
    headGroup.add(rightEye);

    // Eyebrows
    const browMat = new THREE.MeshStandardMaterial({ color: new THREE.Color(hairColorHex), roughness: 0.8 });
    const browGeo = new THREE.BoxGeometry(0.055, 0.012 * (appearance.browThickness || 1.0), 0.015);

    const leftBrow = new THREE.Mesh(browGeo, browMat);
    leftBrow.position.set(-eyeSpacing, 0.05, 0.13);
    leftBrow.rotation.z = -0.08 - (appearance.browAngle || 0) * 0.15;
    headGroup.add(leftBrow);

    const rightBrow = new THREE.Mesh(browGeo, browMat);
    rightBrow.position.set(eyeSpacing, 0.05, 0.13);
    rightBrow.rotation.z = 0.08 + (appearance.browAngle || 0) * 0.15;
    headGroup.add(rightBrow);

    // Lips
    const lipMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color(skinColorHex).lerp(new THREE.Color(0x994d50), 0.35),
      roughness: 0.5,
    });
    const lipGeo = new THREE.BoxGeometry(0.06 * (appearance.mouthWidth || 1.0), 0.018 * (appearance.lipThickness || 1.0), 0.02);
    const lips = new THREE.Mesh(lipGeo, lipMat);
    lips.position.set(0, -0.07, 0.13);
    headGroup.add(lips);

    // 6. Race-Specific Anatomical Features
    if (raceId === 'half_elf') {
      // Elven Pointed Ears
      const earGeo = new THREE.ConeGeometry(0.035 * (appearance.earSize || 1.0), 0.14, 8);
      const leftEar = new THREE.Mesh(earGeo, skinMat);
      leftEar.position.set(-0.16 * faceW, 0.02, -0.02);
      leftEar.rotation.set(-0.2, 0.2, 1.15);
      headGroup.add(leftEar);

      const rightEar = new THREE.Mesh(earGeo, skinMat);
      rightEar.position.set(0.16 * faceW, 0.02, -0.02);
      rightEar.rotation.set(-0.2, -0.2, -1.15);
      headGroup.add(rightEar);
    } else if (raceId === 'wood_kin') {
      // Long swept-back Sylvan ears
      const earGeo = new THREE.ConeGeometry(0.04, 0.18, 8);
      const leftEar = new THREE.Mesh(earGeo, skinMat);
      leftEar.position.set(-0.16 * faceW, 0.01, -0.04);
      leftEar.rotation.set(-0.35, 0.3, 1.25);
      headGroup.add(leftEar);

      const rightEar = new THREE.Mesh(earGeo, skinMat);
      rightEar.position.set(0.16 * faceW, 0.01, -0.04);
      rightEar.rotation.set(-0.35, -0.3, -1.25);
      headGroup.add(rightEar);

      // Subtle Antler Buds on brow
      const antlerMat = new THREE.MeshStandardMaterial({ color: 0x5a4132, roughness: 0.8 });
      const antlerGeo = new THREE.CylinderGeometry(0.012, 0.02, 0.14, 6);
      const leftAntler = new THREE.Mesh(antlerGeo, antlerMat);
      leftAntler.position.set(-0.08, 0.15, 0.06);
      leftAntler.rotation.set(-0.4, 0.2, -0.4);
      headGroup.add(leftAntler);

      const rightAntler = new THREE.Mesh(antlerGeo, antlerMat);
      rightAntler.position.set(0.08, 0.15, 0.06);
      rightAntler.rotation.set(-0.4, -0.2, 0.4);
      headGroup.add(rightAntler);
    } else if (raceId === 'tiefling') {
      // Tiefling Tail (Lower back)
      const tailCurve = new THREE.CatmullRomCurve3([
        new THREE.Vector3(0, 0.95, -0.15),
        new THREE.Vector3(0.08, 0.7, -0.32),
        new THREE.Vector3(-0.06, 0.4, -0.42),
        new THREE.Vector3(0.12, 0.18, -0.48),
        new THREE.Vector3(0.2, 0.08, -0.4),
      ]);
      const tailGeo = new THREE.TubeGeometry(tailCurve, 24, 0.026, 8, false);
      const tail = new THREE.Mesh(tailGeo, skinMat);
      tail.castShadow = true;
      characterRoot.add(tail);

      // Tail Arrow Tip
      const arrowGeo = new THREE.ConeGeometry(0.04, 0.09, 8);
      const arrowMat = new THREE.MeshStandardMaterial({ color: 0x221c1f, roughness: 0.4 });
      const arrowTip = new THREE.Mesh(arrowGeo, arrowMat);
      arrowTip.position.set(0.2, 0.08, -0.4);
      arrowTip.rotation.set(Math.PI / 2, 0, 0);
      characterRoot.add(arrowTip);

      // Customizable 3D Horns
      const hornColor = appearance.hornColor || '#18181b';
      const hornMat = new THREE.MeshStandardMaterial({
        color: new THREE.Color(hornColor),
        roughness: 0.35,
        metalness: 0.3,
      });

      const hornLen = appearance.hornLength || 1.0;
      const hornCurve = appearance.hornCurvature || 1.0;

      if (appearance.hornStyle === 'ram_curved') {
        const leftHornCurve = new THREE.CatmullRomCurve3([
          new THREE.Vector3(-0.1, 0.11, 0.04),
          new THREE.Vector3(-0.18 * hornCurve, 0.14, -0.02),
          new THREE.Vector3(-0.21 * hornCurve, 0.02, -0.1),
          new THREE.Vector3(-0.16 * hornCurve, -0.06, -0.06),
        ]);
        const hornGeo = new THREE.TubeGeometry(leftHornCurve, 24, 0.038 * hornLen, 8, false);
        const leftHorn = new THREE.Mesh(hornGeo, hornMat);
        headGroup.add(leftHorn);

        const rightHornCurve = new THREE.CatmullRomCurve3([
          new THREE.Vector3(0.1, 0.11, 0.04),
          new THREE.Vector3(0.18 * hornCurve, 0.14, -0.02),
          new THREE.Vector3(0.21 * hornCurve, 0.02, -0.1),
          new THREE.Vector3(0.16 * hornCurve, -0.06, -0.06),
        ]);
        const rightHornGeo = new THREE.TubeGeometry(rightHornCurve, 24, 0.038 * hornLen, 8, false);
        const rightHorn = new THREE.Mesh(rightHornGeo, hornMat);
        headGroup.add(rightHorn);
      } else {
        // Swept-back Horns (Default)
        const leftHornCurve = new THREE.CatmullRomCurve3([
          new THREE.Vector3(-0.08, 0.11, 0.05),
          new THREE.Vector3(-0.12 * hornCurve, 0.22 * hornLen, -0.04),
          new THREE.Vector3(-0.14 * hornCurve, 0.32 * hornLen, -0.22 * hornCurve),
          new THREE.Vector3(-0.11, 0.36 * hornLen, -0.32 * hornCurve),
        ]);
        const hornGeo = new THREE.TubeGeometry(leftHornCurve, 24, 0.034, 8, false);
        const leftHorn = new THREE.Mesh(hornGeo, hornMat);
        headGroup.add(leftHorn);

        const rightHornCurve = new THREE.CatmullRomCurve3([
          new THREE.Vector3(0.08, 0.11, 0.05),
          new THREE.Vector3(0.12 * hornCurve, 0.22 * hornLen, -0.04),
          new THREE.Vector3(0.14 * hornCurve, 0.32 * hornLen, -0.22 * hornCurve),
          new THREE.Vector3(0.11, 0.36 * hornLen, -0.32 * hornCurve),
        ]);
        const rightHornGeo = new THREE.TubeGeometry(rightHornCurve, 24, 0.034, 8, false);
        const rightHorn = new THREE.Mesh(rightHornGeo, hornMat);
        headGroup.add(rightHorn);
      }
    } else {
      // Human rounded ears
      const earGeo = new THREE.SphereGeometry(0.035, 10, 10);
      const leftEar = new THREE.Mesh(earGeo, skinMat);
      leftEar.position.set(-0.145 * faceW, 0.0, 0.0);
      leftEar.scale.set(0.4, 1.2, 0.8);
      headGroup.add(leftEar);

      const rightEar = new THREE.Mesh(earGeo, skinMat);
      rightEar.position.set(0.145 * faceW, 0.0, 0.0);
      rightEar.scale.set(0.4, 1.2, 0.8);
      headGroup.add(rightEar);
    }

    // 7. Hairstyle 3D Geometry
    const hairStyleId = appearance.hairStyleId || 'braided_crown';
    const hairGroup = new THREE.Group();
    headGroup.add(hairGroup);

    // Base Hair Cap
    const hairCapGeo = new THREE.SphereGeometry(0.145, 16, 16, 0, Math.PI * 2, 0, Math.PI * 0.55);
    const hairCap = new THREE.Mesh(hairCapGeo, hairMat);
    hairCap.position.y = 0.02;
    hairCap.scale.set(faceW, faceL, 1.05);
    hairGroup.add(hairCap);

    if (hairStyleId === 'flowing_long' || hairStyleId === 'sylvan_tresses') {
      const lockGeo = new THREE.CylinderGeometry(0.04, 0.07, 0.65, 8);
      const leftLock = new THREE.Mesh(lockGeo, hairMat);
      leftLock.position.set(-0.13, -0.22, 0.02);
      hairGroup.add(leftLock);

      const rightLock = new THREE.Mesh(lockGeo, hairMat);
      rightLock.position.set(0.13, -0.22, 0.02);
      hairGroup.add(rightLock);

      const backLockGeo = new THREE.CylinderGeometry(0.14, 0.18, 0.68, 12);
      const backLock = new THREE.Mesh(backLockGeo, hairMat);
      backLock.position.set(0, -0.24, -0.08);
      hairGroup.add(backLock);
    } else if (hairStyleId === 'warrior_ponytail' || hairStyleId === 'topknot_undercut') {
      const bunGeo = new THREE.SphereGeometry(0.065, 12, 12);
      const bun = new THREE.Mesh(bunGeo, hairMat);
      bun.position.set(0, 0.16, -0.12);
      hairGroup.add(bun);

      const tailGeo = new THREE.CylinderGeometry(0.04, 0.025, 0.42, 8);
      const ponyTail = new THREE.Mesh(tailGeo, hairMat);
      ponyTail.position.set(0, 0.02, -0.24);
      ponyTail.rotation.x = 0.75;
      hairGroup.add(ponyTail);
    } else if (hairStyleId === 'braided_crown' || hairStyleId === 'coiled_crown') {
      const crownGeo = new THREE.TorusGeometry(0.13, 0.038, 12, 32);
      const crown = new THREE.Mesh(crownGeo, hairMat);
      crown.position.set(0, 0.08, 0.01);
      crown.rotation.x = Math.PI / 2.15;
      hairGroup.add(crown);
    } else if (hairStyleId === 'twin_braids') {
      const braidGeo = new THREE.CylinderGeometry(0.03, 0.015, 0.5, 8);
      const leftBraid = new THREE.Mesh(braidGeo, hairMat);
      leftBraid.position.set(-0.12, -0.16, 0.08);
      hairGroup.add(leftBraid);

      const rightBraid = new THREE.Mesh(braidGeo, hairMat);
      rightBraid.position.set(0.12, -0.16, 0.08);
      hairGroup.add(rightBraid);
    } else if (hairStyleId === 'warden_mane') {
      const maneGeo = new THREE.SphereGeometry(0.2, 12, 12);
      const mane = new THREE.Mesh(maneGeo, hairMat);
      mane.position.set(0, 0.02, -0.06);
      mane.scale.set(1.15, 1.25, 1.1);
      hairGroup.add(mane);
    }

    // 8. Facial Hair
    const beardStyle = appearance.facialHairStyle || 'clean_shaven';
    if (beardStyle === 'warrior_beard' || beardStyle === 'frontier_beard') {
      const beardGeo = new THREE.ConeGeometry(0.1, 0.22, 10);
      const beard = new THREE.Mesh(beardGeo, hairMat);
      beard.position.set(0, -0.17, 0.08);
      beard.rotation.x = -0.3;
      headGroup.add(beard);
    } else if (beardStyle === 'braided_goatee') {
      const goateeGeo = new THREE.CylinderGeometry(0.025, 0.015, 0.15, 6);
      const goatee = new THREE.Mesh(goateeGeo, hairMat);
      goatee.position.set(0, -0.15, 0.08);
      headGroup.add(goatee);
    } else if (beardStyle === 'imperial_mustache') {
      const stacheGeo = new THREE.TorusGeometry(0.045, 0.014, 8, 16, Math.PI);
      const stache = new THREE.Mesh(stacheGeo, hairMat);
      stache.position.set(0, -0.05, 0.14);
      stache.rotation.z = Math.PI;
      headGroup.add(stache);
    }

    // 9. Class Weapons & Equipment
    const weaponsGroup = new THREE.Group();
    characterRoot.add(weaponsGroup);

    if (isWarrior) {
      // Bastion Greatsword strapped to back
      const swordGroup = new THREE.Group();
      swordGroup.position.set(0.14, 1.35, -0.22);
      swordGroup.rotation.z = -0.45;

      const bladeGeo = new THREE.BoxGeometry(0.08, 1.25, 0.02);
      const bladeMat = new THREE.MeshStandardMaterial({
        color: 0xcfd8dc,
        metalness: 0.9,
        roughness: 0.25,
      });
      const blade = new THREE.Mesh(bladeGeo, bladeMat);
      blade.castShadow = true;
      swordGroup.add(blade);

      const crossguardGeo = new THREE.BoxGeometry(0.28, 0.04, 0.05);
      const crossguard = new THREE.Mesh(crossguardGeo, trimMat);
      crossguard.position.y = -0.55;
      swordGroup.add(crossguard);

      const hiltGeo = new THREE.CylinderGeometry(0.02, 0.02, 0.32, 8);
      const hilt = new THREE.Mesh(hiltGeo, darkLeatherMat);
      hilt.position.y = -0.72;
      swordGroup.add(hilt);

      weaponsGroup.add(swordGroup);
    } else if (isPaladin) {
      // Sanctified Warhammer in Right Hand
      const hammerGroup = new THREE.Group();
      hammerGroup.position.set(0.42 * shoulderWidth, 0.95, 0.15);

      const shaftGeo = new THREE.CylinderGeometry(0.022, 0.022, 0.85, 8);
      const shaft = new THREE.Mesh(shaftGeo, darkLeatherMat);
      hammerGroup.add(shaft);

      const headGeo = new THREE.BoxGeometry(0.18, 0.15, 0.16);
      const hammerHead = new THREE.Mesh(headGeo, trimMat);
      hammerHead.position.y = 0.4;
      hammerGroup.add(hammerHead);
      weaponsGroup.add(hammerGroup);

      // Crested Kite Shield on Left Arm
      const shieldGroup = new THREE.Group();
      shieldGroup.position.set(-0.44 * shoulderWidth, 1.05, 0.1);

      const shieldPoints: THREE.Vector2[] = [
        new THREE.Vector2(0, 0.42),
        new THREE.Vector2(0.22, 0.38),
        new THREE.Vector2(0.24, 0.0),
        new THREE.Vector2(0.14, -0.32),
        new THREE.Vector2(0, -0.48),
      ];
      const shieldShape = new THREE.Shape(shieldPoints);
      const shieldGeo = new THREE.ShapeGeometry(shieldShape);
      const shield = new THREE.Mesh(shieldGeo, metalMat);
      shield.rotation.y = Math.PI / 2.2;
      shieldGroup.add(shield);
      weaponsGroup.add(shieldGroup);
    } else if (isMage) {
      // Runed Quarterstaff in Right Hand with Glowing Orb
      const staffGroup = new THREE.Group();
      staffGroup.position.set(0.44 * shoulderWidth, 0.95, 0.15);

      const shaftGeo = new THREE.CylinderGeometry(0.02, 0.025, 1.7, 8);
      const staffShaft = new THREE.Mesh(shaftGeo, darkLeatherMat);
      staffShaft.position.y = 0.35;
      staffGroup.add(staffShaft);

      const orbGeo = new THREE.SphereGeometry(0.075, 16, 16);
      const orbMat = new THREE.MeshStandardMaterial({
        color: 0x9333ea,
        emissive: 0xa855f7,
        emissiveIntensity: 0.85,
        roughness: 0.1,
      });
      const orb = new THREE.Mesh(orbGeo, orbMat);
      orb.position.y = 1.25;
      staffGroup.add(orb);
      weaponsGroup.add(staffGroup);
    } else if (isRogue) {
      // Twin Daggers at Hips
      const daggerGeo = new THREE.BoxGeometry(0.035, 0.42, 0.015);
      const daggerMat = new THREE.MeshStandardMaterial({
        color: 0x94a3b8,
        metalness: 0.95,
        roughness: 0.2,
      });

      const leftDagger = new THREE.Mesh(daggerGeo, daggerMat);
      leftDagger.position.set(-0.25 * shoulderWidth, 0.9, 0.04);
      leftDagger.rotation.z = 0.4;
      weaponsGroup.add(leftDagger);

      const rightDagger = new THREE.Mesh(daggerGeo, daggerMat);
      rightDagger.position.set(0.25 * shoulderWidth, 0.9, 0.04);
      rightDagger.rotation.z = -0.4;
      weaponsGroup.add(rightDagger);
    } else if (isRanger) {
      // Recurve Bow on back
      const bowCurve = new THREE.CatmullRomCurve3([
        new THREE.Vector3(-0.04, 0.45, 0),
        new THREE.Vector3(0.08, 0.22, 0),
        new THREE.Vector3(0.1, 0, 0),
        new THREE.Vector3(0.08, -0.22, 0),
        new THREE.Vector3(-0.04, -0.45, 0),
      ]);
      const bowGeo = new THREE.TubeGeometry(bowCurve, 20, 0.02, 8, false);
      const bowMat = new THREE.MeshStandardMaterial({ color: 0x5a3d28, roughness: 0.6 });
      const bow = new THREE.Mesh(bowGeo, bowMat);
      bow.position.set(0.12, 1.35, -0.22);
      bow.rotation.z = -0.3;
      weaponsGroup.add(bow);
    }

    // Cape / Mantle
    const capeGeo = new THREE.PlaneGeometry(0.55 * shoulderWidth, 1.2, 8, 8);
    const cape = new THREE.Mesh(capeGeo, clothMat);
    cape.position.set(0, 1.05, -0.16);
    cape.rotation.x = -0.1;
    cape.castShadow = true;
    characterRoot.add(cape);

    // =========================================================================
    // ANIMATION & RENDER LOOP
    // =========================================================================
    const clock = new THREE.Clock();

    const animate = () => {
      if (isDisposed) return;
      animationFrameId = requestAnimationFrame(animate);

      const delta = clock.getDelta();
      const elapsed = clock.getElapsedTime();

      // Smooth Orbit Camera Interpolation (Damped Lerp)
      orbitAngleY.current += (targetAngleY.current - orbitAngleY.current) * 0.12;
      orbitAngleX.current += (targetAngleX.current - orbitAngleX.current) * 0.12;
      orbitDistance.current += (targetDistance.current - orbitDistance.current) * 0.1;
      currentLookAtY.current += (targetLookAtY.current - currentLookAtY.current) * 0.1;

      // Position camera using spherical coordinates
      const dist = orbitDistance.current;
      const cy = Math.cos(orbitAngleY.current);
      const sy = Math.sin(orbitAngleY.current);
      const cx = Math.cos(orbitAngleX.current);
      const sx = Math.sin(orbitAngleX.current);

      camera.position.x = dist * cx * sy;
      camera.position.y = currentLookAtY.current + dist * sx;
      camera.position.z = dist * cx * cy;

      camera.lookAt(0, currentLookAtY.current, 0);

      // Subtle Breathing Idle Motion
      const breath = Math.sin(elapsed * 2.2) * 0.008;
      characterRoot.position.y = breath;
      torso.scale.x = 1.0 + breath * 0.8;
      torso.scale.z = 1.0 + breath * 0.8;

      // Slow floating particle drift
      const positions = particleGeo.attributes.position.array as Float32Array;
      for (let i = 0; i < particleCount; i++) {
        positions[i * 3 + 1] += delta * 0.18;
        if (positions[i * 3 + 1] > 2.8) {
          positions[i * 3 + 1] = 0.05;
        }
      }
      particleGeo.attributes.position.needsUpdate = true;

      // Slow pulse on glowing floor runes
      runeMat.opacity = 0.35 + Math.sin(elapsed * 1.8) * 0.15;

      renderer.render(scene, camera);
    };

    animate();

    // Resize Handler
    const handleResize = () => {
      if (!container || !renderer || !camera) return;
      const width = container.clientWidth;
      const height = container.clientHeight;
      camera.aspect = width / Math.max(height, 1);
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      isDisposed = true;
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
      scene.clear();
    };
  }, [raceId, archetypeClass, appearance, subclassId]);

  // =========================================================================
  // MOUSE & TOUCH ORBIT CONTROLS
  // =========================================================================
  const handlePointerDown = (e: React.PointerEvent) => {
    isDragging.current = true;
    lastMousePos.current = { x: e.clientX, y: e.clientY };
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging.current) return;
    const dx = e.clientX - lastMousePos.current.x;
    const dy = e.clientY - lastMousePos.current.y;
    lastMousePos.current = { x: e.clientX, y: e.clientY };

    targetAngleY.current += dx * 0.008;
    targetAngleX.current = Math.max(-0.25, Math.min(0.45, targetAngleX.current + dy * 0.005));
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    isDragging.current = false;
    try {
      (e.target as HTMLElement).releasePointerCapture(e.pointerId);
    } catch {
      // Ignored
    }
  };

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    zoomCamera(e.deltaY * 0.002);
  };

  return (
    <div
      ref={containerRef}
      className={`relative w-full h-full select-none overflow-hidden bg-[#0d120f] ${className}`}
      onWheel={handleWheel}
    >
      <canvas
        ref={canvasRef}
        className="w-full h-full block cursor-grab active:cursor-grabbing"
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
      />

      {/* Atmospheric Vignette Overlay */}
      <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(ellipse_at_center,transparent_45%,rgba(17,22,19,0.85)_100%)]" />

      {/* Top Framing Mode Badge */}
      <div className="absolute top-4 left-4 z-10 flex items-center space-x-2 bg-[rgba(17,22,19,0.75)] border border-[#5A4B38] px-3 py-1.5 rounded backdrop-blur-sm">
        <span className="w-2 h-2 rounded-full bg-[#E2B05A] animate-pulse" />
        <span className="text-[11px] font-mono tracking-wider text-[#B5AC9A] uppercase">
          {framingMode === 'face' ? 'Close-Up Portrait View' : 'Full-Body Overview'}
        </span>
      </div>

      {/* Floating 3D Viewport Controls */}
      <div className="absolute bottom-5 left-1/2 -translate-x-1/2 z-10 flex items-center space-x-1.5 bg-[rgba(22,28,24,0.9)] border border-[#5A4B38] px-3 py-1.5 rounded-full shadow-2xl backdrop-blur-md">
        {/* Step Rotate Left */}
        <button
          type="button"
          onClick={() => stepRotate(-Math.PI / 4)}
          title="Rotate Left (-45°)"
          className="p-1.5 text-[#B5AC9A] hover:text-[#E2B05A] hover:bg-[#2a352c] rounded transition"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
        </button>

        {/* View Presets */}
        <button
          type="button"
          onClick={() => setTargetYaw(0)}
          className="px-2 py-0.5 text-xs font-mono text-[#B5AC9A] hover:text-[#E2B05A] hover:bg-[#2a352c] rounded transition"
        >
          Front
        </button>
        <button
          type="button"
          onClick={() => setTargetYaw(Math.PI / 2)}
          className="px-2 py-0.5 text-xs font-mono text-[#B5AC9A] hover:text-[#E2B05A] hover:bg-[#2a352c] rounded transition"
        >
          Side
        </button>
        <button
          type="button"
          onClick={() => setTargetYaw(Math.PI)}
          className="px-2 py-0.5 text-xs font-mono text-[#B5AC9A] hover:text-[#E2B05A] hover:bg-[#2a352c] rounded transition"
        >
          Rear
        </button>

        {/* Step Rotate Right */}
        <button
          type="button"
          onClick={() => stepRotate(Math.PI / 4)}
          title="Rotate Right (+45°)"
          className="p-1.5 text-[#B5AC9A] hover:text-[#E2B05A] hover:bg-[#2a352c] rounded transition"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
          </svg>
        </button>

        <span className="w-px h-4 bg-[#5A4B38] mx-1" />

        {/* Zoom In */}
        <button
          type="button"
          onClick={() => zoomCamera(-0.35)}
          title="Zoom In"
          className="p-1.5 text-[#B5AC9A] hover:text-[#E2B05A] hover:bg-[#2a352c] rounded transition"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
          </svg>
        </button>

        {/* Zoom Out */}
        <button
          type="button"
          onClick={() => zoomCamera(0.35)}
          title="Zoom Out"
          className="p-1.5 text-[#B5AC9A] hover:text-[#E2B05A] hover:bg-[#2a352c] rounded transition"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 12H4" />
          </svg>
        </button>

        {/* Reset Camera */}
        <button
          type="button"
          onClick={resetCamera}
          title="Reset Camera"
          className="p-1.5 text-[#B5AC9A] hover:text-[#E2B05A] hover:bg-[#2a352c] rounded transition"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"
            />
          </svg>
        </button>
      </div>

      {/* Orbit Tip */}
      <div className="absolute bottom-5 right-5 z-10 hidden md:block text-[11px] text-[#B5AC9A]/70 font-mono tracking-wide pointer-events-none">
        Drag to Rotate · Scroll to Zoom
      </div>
    </div>
  );
};
