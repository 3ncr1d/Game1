import React, { useState, useMemo } from 'react';
import {
  TowerBossDefinition,
  TowerDifficulty,
  TowerEncounterType,
  TowerFloorDefinition,
  TowerProgressionState,
  TowerRegionId,
  TowerShopItem,
  TOWER_CHECKPOINT_FLOORS,
} from '../game/towerTypes';
import { ALL_100_TOWER_FLOORS, TOWER_REGIONS } from '../game/towerFloorsData';
import { TOWER_MAJOR_BOSSES, TOWER_MINI_BOSSES } from '../game/towerBossesData';
import {
  purchaseTowerShopItem,
  restAtTowerSanctuary,
  TOWER_SHOP_CATALOG,
} from '../game/towerEngine';

export interface TowerBattleResultSummary {
  floorNumber: number;
  outcome: 'victory' | 'defeat';
  roundsTaken: number;
  shardsEarned: number;
  xpEarned: number;
  firstClear: boolean;
  unlockedCheckpoint?: number;
  bossDefeatedName?: string;
  defeatReason?: string;
}

interface TowerHubModalProps {
  isOpen: boolean;
  onClose: () => void;
  towerState: TowerProgressionState;
  onUpdateTowerState: (next: TowerProgressionState) => void;
  onLaunchTowerFloor: (floorNumber: number) => void;
  partyLevel: number;
  commanderName: string;
}

const REGION_KEYS: TowerRegionId[] = [
  'forgotten_threshold',
  'withered_wilds',
  'ember_foundry',
  'frozen_reliquary',
  'astral_divide',
  'drowned_kingdom',
  'crimson_covenant',
  'ashen_dominion',
  'shattered_expanse',
  'throne_beyond',
];

const ROMAN_NUMERALS = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X'];

const DIFFICULTY_COLORS: Record<TowerDifficulty, string> = {
  Beginner: '#7E9C82',
  Easy: '#8FB397',
  Moderate: '#E2B05A',
  Hard: '#E67E22',
  'Very Hard': '#D35400',
  Extreme: '#C0392B',
  Legendary: '#E74C3C',
};

const RARITY_COLORS = {
  Common: '#9CA3AF',
  Uncommon: '#22C55E',
  Rare: '#3B82F6',
  Epic: '#A855F7',
  Legendary: '#F59E0B',
};

export const TowerHubModal: React.FC<TowerHubModalProps> = ({
  isOpen,
  onClose,
  towerState,
  onUpdateTowerState,
  onLaunchTowerFloor,
  partyLevel,
  commanderName,
}) => {
  const [activeTab, setActiveTab] = useState<'ascent' | 'shop' | 'bosses'>('ascent');
  const [selectedRegionIndex, setSelectedRegionIndex] = useState<number>(() => {
    // Default to the region corresponding to current unlocked floor
    const floor = towerState.currentUnlockedFloor || 1;
    return Math.min(9, Math.floor((floor - 1) / 10));
  });

  const [selectedFloorNumber, setSelectedFloorNumber] = useState<number>(() => {
    return towerState.currentUnlockedFloor || 1;
  });

  const [shopCategoryFilter, setShopCategoryFilter] = useState<string>('all');
  const [shopFeedbackMsg, setShopFeedbackMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const currentRegionId = REGION_KEYS[selectedRegionIndex];
  const currentRegionMeta = TOWER_REGIONS[currentRegionId];
  const selectedFloorDef: TowerFloorDefinition =
    ALL_100_TOWER_FLOORS[selectedFloorNumber] ?? ALL_100_TOWER_FLOORS[1];
  const selectedBossDef: TowerBossDefinition | undefined =
    selectedFloorDef.isBossFloor ? TOWER_MAJOR_BOSSES[selectedFloorNumber] : undefined;

  // Calculate Region Clearance Progress
  const [startFloor, endFloor] = currentRegionMeta.floorRange;
  const regionFloors: TowerFloorDefinition[] = [];
  let regionClearedCount = 0;
  for (let f = startFloor; f <= endFloor; f++) {
    const fDef = ALL_100_TOWER_FLOORS[f];
    if (fDef) {
      regionFloors.push(fDef);
      if (towerState.completedFloorNumbers.includes(f)) {
        regionClearedCount++;
      }
    }
  }

  const isFloorUnlocked = selectedFloorNumber <= towerState.currentUnlockedFloor;
  const isFloorCleared = towerState.completedFloorNumbers.includes(selectedFloorNumber);

  const handleSelectFloor = (floorNum: number) => {
    setSelectedFloorNumber(floorNum);
  };

  const handleSelectRegion = (idx: number) => {
    setSelectedRegionIndex(idx);
    const [rStart] = TOWER_REGIONS[REGION_KEYS[idx]].floorRange;
    // If the player has unlocked floors in this region, select the highest available, else the first floor
    const target = Math.min(rStart + 9, Math.max(rStart, towerState.currentUnlockedFloor));
    setSelectedFloorNumber(target);
  };

  const handlePurchase = (itemId: string) => {
    const res = purchaseTowerShopItem(towerState, itemId);
    if (res.success) {
      onUpdateTowerState(res.nextState);
      setShopFeedbackMsg(`Acquired ${res.item?.name}! Added to armory.`);
      setTimeout(() => setShopFeedbackMsg(null), 3000);
    } else {
      setShopFeedbackMsg(res.reason ?? 'Purchase failed.');
      setTimeout(() => setShopFeedbackMsg(null), 3500);
    }
  };

  const handleSanctuaryRest = () => {
    const nextState = restAtTowerSanctuary(towerState);
    onUpdateTowerState(nextState);
    setShopFeedbackMsg('Sanctuary blessing embraced: Party vitality fully restored.');
    setTimeout(() => setShopFeedbackMsg(null), 3000);
  };

  const filteredShopItems = useMemo(() => {
    if (shopCategoryFilter === 'all') return TOWER_SHOP_CATALOG;
    return TOWER_SHOP_CATALOG.filter((i) => i.category === shopCategoryFilter);
  }, [shopCategoryFilter]);

  const getEncounterBadge = (type: TowerEncounterType, isBoss: boolean, isMini: boolean) => {
    if (isBoss) return { label: 'MAJOR BOSS', icon: '👑', color: '#F59E0B' };
    if (isMini) return { label: 'MINI-BOSS', icon: '⚔️', color: '#E67E22' };
    switch (type) {
      case 'multi_wave':
        return { label: 'MULTI-WAVE', icon: '🌊', color: '#3B82F6' };
      case 'survival':
        return { label: 'SURVIVAL', icon: '⏳', color: '#A855F7' };
      case 'defense':
        return { label: 'DEFENSE', icon: '🛡️', color: '#22C55E' };
      case 'escort':
        return { label: 'ESCORT', icon: '🚶', color: '#06B6D4' };
      case 'destruction':
        return { label: 'DESTRUCTION', icon: '💥', color: '#EF4444' };
      case 'puzzle':
        return { label: 'PUZZLE', icon: '🧩', color: '#EC4899' };
      case 'trial':
        return { label: 'TRIAL', icon: '⚖️', color: '#F97316' };
      default:
        return { label: 'COMBAT', icon: '⚔️', color: '#7E9C82' };
    }
  };

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 9000,
        backgroundColor: 'rgba(10, 14, 12, 0.92)',
        backdropFilter: 'blur(8px)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '24px',
        color: '#F2ECE1',
        fontFamily: 'Cinzel, Georgia, serif',
      }}
    >
      <div
        style={{
          width: '100%',
          maxWidth: '1360px',
          height: '92vh',
          backgroundColor: '#171B19',
          border: '2px solid #5A4B38',
          borderRadius: '8px',
          display: 'flex',
          flexDirection: 'column',
          boxShadow: '0 20px 50px rgba(0, 0, 0, 0.8), inset 0 0 100px rgba(226, 176, 90, 0.05)',
          overflow: 'hidden',
        }}
      >
        {/* Top Header Bar */}
        <div
          style={{
            padding: '16px 24px',
            backgroundColor: '#111513',
            borderBottom: '2px solid #5A4B38',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}
        >
          <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
            <div
              style={{
                width: '44px',
                height: '44px',
                borderRadius: '50%',
                backgroundColor: '#222722',
                border: '2px solid #E2B05A',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '22px',
                color: '#E2B05A',
              }}
            >
              🏛️
            </div>
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                <h2
                  style={{
                    margin: 0,
                    fontSize: '22px',
                    letterSpacing: '2px',
                    color: '#E2B05A',
                    fontWeight: 700,
                  }}
                >
                  THE ASCENDANT TOWER
                </h2>
                <span
                  style={{
                    fontSize: '11px',
                    letterSpacing: '1px',
                    backgroundColor: '#292E29',
                    border: '1px solid #5A4B38',
                    padding: '3px 8px',
                    borderRadius: '4px',
                    color: '#B5AC9A',
                    fontFamily: 'JetBrains Mono, monospace',
                  }}
                >
                  100 FLOORS OF TRIAL
                </span>
              </div>
              <div
                style={{
                  fontSize: '12px',
                  color: '#B5AC9A',
                  marginTop: '3px',
                  letterSpacing: '0.5px',
                }}
              >
                Commander <strong style={{ color: '#F2ECE1' }}>{commanderName}</strong> · Party
                Ascent Lv <strong style={{ color: '#7E9C82' }}>{partyLevel}</strong> · Highest Floor
                Cleared:{' '}
                <strong style={{ color: '#E2B05A' }}>
                  Floor {towerState.highestFloorCleared} / 100
                </strong>
              </div>
            </div>
          </div>

          {/* Right Header: Currency & Close */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '20px' }}>
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                backgroundColor: '#222722',
                border: '1px solid #E2B05A',
                padding: '8px 16px',
                borderRadius: '6px',
              }}
            >
              <span style={{ fontSize: '18px', color: '#E2B05A' }}>◆</span>
              <div>
                <div
                  style={{
                    fontSize: '10px',
                    letterSpacing: '1px',
                    color: '#B5AC9A',
                    textTransform: 'uppercase',
                  }}
                >
                  Oath Shards
                </div>
                <div
                  style={{
                    fontSize: '18px',
                    fontWeight: 700,
                    color: '#F2ECE1',
                    fontFamily: 'JetBrains Mono, monospace',
                  }}
                >
                  {towerState.oathShards}
                </div>
              </div>
            </div>

            <button
              onClick={onClose}
              style={{
                backgroundColor: '#292E29',
                border: '1px solid #5A4B38',
                color: '#F2ECE1',
                padding: '8px 16px',
                borderRadius: '6px',
                cursor: 'pointer',
                fontFamily: 'Cinzel, Georgia, serif',
                fontSize: '13px',
                letterSpacing: '1px',
                transition: 'all 0.2s ease',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.backgroundColor = '#B85349';
                e.currentTarget.style.borderColor = '#E74C3C';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.backgroundColor = '#292E29';
                e.currentTarget.style.borderColor = '#5A4B38';
              }}
            >
              ESC · RETURN
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div
          style={{
            display: 'flex',
            backgroundColor: '#1E2320',
            borderBottom: '1px solid #5A4B38',
            padding: '0 24px',
            gap: '8px',
          }}
        >
          <button
            onClick={() => setActiveTab('ascent')}
            style={{
              padding: '12px 20px',
              border: 'none',
              borderBottom: activeTab === 'ascent' ? '3px solid #E2B05A' : '3px solid transparent',
              backgroundColor: activeTab === 'ascent' ? '#171B19' : 'transparent',
              color: activeTab === 'ascent' ? '#E2B05A' : '#B5AC9A',
              fontWeight: 700,
              fontSize: '14px',
              letterSpacing: '1px',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              fontFamily: 'Cinzel, Georgia, serif',
            }}
          >
            <span>⚔️</span> TOWER ASCENT (100 FLOORS)
          </button>

          <button
            onClick={() => setActiveTab('shop')}
            style={{
              padding: '12px 20px',
              border: 'none',
              borderBottom: activeTab === 'shop' ? '3px solid #E2B05A' : '3px solid transparent',
              backgroundColor: activeTab === 'shop' ? '#171B19' : 'transparent',
              color: activeTab === 'shop' ? '#E2B05A' : '#B5AC9A',
              fontWeight: 700,
              fontSize: '14px',
              letterSpacing: '1px',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              fontFamily: 'Cinzel, Georgia, serif',
            }}
          >
            <span>✨</span> SANCTUARY SHOP & RELIQUARY
          </button>

          <button
            onClick={() => setActiveTab('bosses')}
            style={{
              padding: '12px 20px',
              border: 'none',
              borderBottom: activeTab === 'bosses' ? '3px solid #E2B05A' : '3px solid transparent',
              backgroundColor: activeTab === 'bosses' ? '#171B19' : 'transparent',
              color: activeTab === 'bosses' ? '#E2B05A' : '#B5AC9A',
              fontWeight: 700,
              fontSize: '14px',
              letterSpacing: '1px',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              fontFamily: 'Cinzel, Georgia, serif',
            }}
          >
            <span>👑</span> HALL OF GUARDIANS & BESTIARY
          </button>

          {/* Feedback banner */}
          {shopFeedbackMsg && (
            <div
              style={{
                marginLeft: 'auto',
                alignSelf: 'center',
                padding: '6px 14px',
                borderRadius: '4px',
                backgroundColor: '#2A3B2E',
                border: '1px solid #7E9C82',
                color: '#7E9C82',
                fontSize: '12px',
                fontFamily: 'JetBrains Mono, monospace',
              }}
            >
              {shopFeedbackMsg}
            </div>
          )}
        </div>

        {/* Tab 1: Tower Ascent (100 Floors) */}
        {activeTab === 'ascent' && (
          <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
            {/* Left Column: 10 Region Selector Navigation */}
            <div
              style={{
                width: '320px',
                borderRight: '1px solid #5A4B38',
                backgroundColor: '#141816',
                display: 'flex',
                flexDirection: 'column',
                overflowY: 'auto',
              }}
            >
              <div
                style={{
                  padding: '14px 18px',
                  borderBottom: '1px solid #3A3324',
                  fontSize: '11px',
                  letterSpacing: '1.5px',
                  color: '#B5AC9A',
                  textTransform: 'uppercase',
                  fontWeight: 700,
                }}
              >
                10 ENVIRONMENTAL REGIONS
              </div>

              {REGION_KEYS.map((rId, idx) => {
                const meta = TOWER_REGIONS[rId];
                const isSelected = idx === selectedRegionIndex;
                const [rMin, rMax] = meta.floorRange;
                let clearedInReg = 0;
                for (let f = rMin; f <= rMax; f++) {
                  if (towerState.completedFloorNumbers.includes(f)) clearedInReg++;
                }
                const isRegUnlocked = towerState.currentUnlockedFloor >= rMin;

                return (
                  <button
                    key={rId}
                    onClick={() => handleSelectRegion(idx)}
                    style={{
                      padding: '12px 16px',
                      backgroundColor: isSelected ? '#292E29' : 'transparent',
                      border: 'none',
                      borderLeft: isSelected ? '4px solid #E2B05A' : '4px solid transparent',
                      borderBottom: '1px solid #222722',
                      textAlign: 'left',
                      cursor: 'pointer',
                      display: 'flex',
                      flexDirection: 'column',
                      gap: '4px',
                      transition: 'background-color 0.15s ease',
                    }}
                    onMouseEnter={(e) => {
                      if (!isSelected) e.currentTarget.style.backgroundColor = '#1E2320';
                    }}
                    onMouseLeave={(e) => {
                      if (!isSelected) e.currentTarget.style.backgroundColor = 'transparent';
                    }}
                  >
                    <div
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                      }}
                    >
                      <span
                        style={{
                          fontSize: '11px',
                          color: isSelected ? '#E2B05A' : '#77796F',
                          fontFamily: 'JetBrains Mono, monospace',
                          letterSpacing: '1px',
                        }}
                      >
                        REGION {ROMAN_NUMERALS[idx]} · F{rMin}–{rMax}
                      </span>
                      <span
                        style={{
                          fontSize: '10px',
                          padding: '2px 6px',
                          borderRadius: '3px',
                          backgroundColor: '#1E2320',
                          border: `1px solid ${DIFFICULTY_COLORS[meta.difficulty]}`,
                          color: DIFFICULTY_COLORS[meta.difficulty],
                          fontFamily: 'JetBrains Mono, monospace',
                        }}
                      >
                        {meta.difficulty}
                      </span>
                    </div>

                    <div
                      style={{
                        fontSize: '13px',
                        fontWeight: isSelected ? 700 : 500,
                        color: isRegUnlocked ? (isSelected ? '#F2ECE1' : '#D1C7B7') : '#77796F',
                        fontFamily: 'Cinzel, serif',
                      }}
                    >
                      {!isRegUnlocked ? '🔒 ' : ''}
                      {meta.name}
                    </div>

                    <div
                      style={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                        fontSize: '11px',
                        color: '#B5AC9A',
                        fontFamily: 'JetBrains Mono, monospace',
                      }}
                    >
                      <span>
                        Lv {meta.recommendedLevelRange[0]}–{meta.recommendedLevelRange[1]}
                      </span>
                      <span
                        style={{
                          color: clearedInReg === 10 ? '#7E9C82' : isSelected ? '#E2B05A' : '#B5AC9A',
                        }}
                      >
                        {clearedInReg}/10 Cleared
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Middle Column: 10 Floor Cards for Selected Region */}
            <div
              style={{
                width: '380px',
                borderRight: '1px solid #5A4B38',
                backgroundColor: '#171B19',
                display: 'flex',
                flexDirection: 'column',
                overflowY: 'auto',
              }}
            >
              <div
                style={{
                  padding: '14px 18px',
                  borderBottom: '1px solid #3A3324',
                  backgroundColor: '#141816',
                }}
              >
                <div
                  style={{
                    fontSize: '11px',
                    color: '#E2B05A',
                    fontFamily: 'JetBrains Mono, monospace',
                    letterSpacing: '1px',
                  }}
                >
                  REGION {ROMAN_NUMERALS[selectedRegionIndex]} FLOORS ({regionClearedCount}/10
                  CLEARED)
                </div>
                <div
                  style={{
                    fontSize: '14px',
                    fontWeight: 700,
                    color: '#F2ECE1',
                    marginTop: '2px',
                  }}
                >
                  {currentRegionMeta.name}
                </div>
              </div>

              <div style={{ padding: '12px', display: 'flex', flexDirection: 'column', gap: '8px' }}>
                {regionFloors.map((floor) => {
                  const isSelected = floor.floorNumber === selectedFloorNumber;
                  const isUnlocked = floor.floorNumber <= towerState.currentUnlockedFloor;
                  const isCleared = towerState.completedFloorNumbers.includes(floor.floorNumber);
                  const badge = getEncounterBadge(
                    floor.encounterType,
                    floor.isBossFloor,
                    floor.isMiniBossFloor
                  );

                  return (
                    <button
                      key={floor.floorNumber}
                      onClick={() => handleSelectFloor(floor.floorNumber)}
                      style={{
                        padding: '10px 14px',
                        backgroundColor: isSelected
                          ? '#3A3324'
                          : isCleared
                          ? '#1C241E'
                          : isUnlocked
                          ? '#222722'
                          : '#1B1E1C',
                        border: isSelected
                          ? '2px solid #E2B05A'
                          : isCleared
                          ? '1px solid #3D5E43'
                          : isUnlocked
                          ? '1px solid #5A4B38'
                          : '1px solid #2B2D2B',
                        borderRadius: '6px',
                        textAlign: 'left',
                        cursor: isUnlocked ? 'pointer' : 'not-allowed',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        gap: '12px',
                        transition: 'all 0.15s ease',
                        opacity: isUnlocked ? 1 : 0.6,
                      }}
                    >
                      <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                        <div
                          style={{
                            width: '32px',
                            height: '32px',
                            borderRadius: '4px',
                            backgroundColor: isSelected
                              ? '#E2B05A'
                              : isCleared
                              ? '#3D5E43'
                              : '#292E29',
                            color: isSelected ? '#171B19' : isCleared ? '#7E9C82' : '#F2ECE1',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            fontSize: '12px',
                            fontWeight: 700,
                            fontFamily: 'JetBrains Mono, monospace',
                          }}
                        >
                          {floor.floorNumber}
                        </div>
                        <div>
                          <div
                            style={{
                              fontSize: '13px',
                              fontWeight: isSelected ? 700 : 500,
                              color: isSelected ? '#F2ECE1' : isUnlocked ? '#E2DBCF' : '#77796F',
                              fontFamily: 'Cinzel, serif',
                            }}
                          >
                            {floor.name}
                          </div>
                          <div
                            style={{
                              fontSize: '10px',
                              color: badge.color,
                              display: 'flex',
                              alignItems: 'center',
                              gap: '4px',
                              fontFamily: 'JetBrains Mono, monospace',
                              marginTop: '2px',
                            }}
                          >
                            <span>{badge.icon}</span>
                            <span>{badge.label}</span>
                            <span style={{ color: '#77796F' }}>·</span>
                            <span style={{ color: '#B5AC9A' }}>Lv {floor.recommendedLevel}</span>
                          </div>
                        </div>
                      </div>

                      <div style={{ textAlign: 'right' }}>
                        {isCleared ? (
                          <span
                            style={{
                              fontSize: '14px',
                              color: '#7E9C82',
                              fontWeight: 700,
                            }}
                          >
                            ✓
                          </span>
                        ) : !isUnlocked ? (
                          <span style={{ fontSize: '13px', color: '#77796F' }}>🔒</span>
                        ) : (
                          <span
                            style={{
                              fontSize: '10px',
                              color: '#E2B05A',
                              border: '1px solid #E2B05A',
                              padding: '2px 5px',
                              borderRadius: '3px',
                              fontFamily: 'JetBrains Mono, monospace',
                            }}
                          >
                            READY
                          </span>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Right Column: Selected Floor Detail & Deployment Panel */}
            <div
              style={{
                flex: 1,
                backgroundColor: '#141816',
                display: 'flex',
                flexDirection: 'column',
                overflowY: 'auto',
                padding: '24px 32px',
              }}
            >
              {/* Floor Header */}
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'flex-start',
                  borderBottom: '1px solid #3A3324',
                  paddingBottom: '16px',
                }}
              >
                <div>
                  <div
                    style={{
                      fontSize: '12px',
                      color: '#E2B05A',
                      fontFamily: 'JetBrains Mono, monospace',
                      letterSpacing: '1px',
                    }}
                  >
                    REGION {ROMAN_NUMERALS[selectedRegionIndex]} · {currentRegionMeta.name.toUpperCase()}
                  </div>
                  <h1
                    style={{
                      margin: '4px 0 0 0',
                      fontSize: '26px',
                      color: '#F2ECE1',
                      letterSpacing: '1px',
                    }}
                  >
                    Floor {selectedFloorDef.floorNumber}: {selectedFloorDef.name}
                  </h1>
                  <div
                    style={{
                      fontSize: '13px',
                      color: '#B5AC9A',
                      marginTop: '4px',
                      fontStyle: 'italic',
                    }}
                  >
                    "{currentRegionMeta.tagline}"
                  </div>
                </div>

                <div style={{ textAlign: 'right', display: 'flex', flexDirection: 'column', gap: '6px' }}>
                  <span
                    style={{
                      fontSize: '12px',
                      padding: '4px 10px',
                      borderRadius: '4px',
                      backgroundColor: '#222722',
                      border: `1px solid ${DIFFICULTY_COLORS[selectedFloorDef.difficulty]}`,
                      color: DIFFICULTY_COLORS[selectedFloorDef.difficulty],
                      fontWeight: 700,
                      fontFamily: 'JetBrains Mono, monospace',
                    }}
                  >
                    DIFFICULTY: {selectedFloorDef.difficulty.toUpperCase()}
                  </span>
                  <div
                    style={{
                      fontSize: '12px',
                      color: partyLevel >= selectedFloorDef.recommendedLevel ? '#7E9C82' : '#B85349',
                      fontFamily: 'JetBrains Mono, monospace',
                    }}
                  >
                    Rec. Level {selectedFloorDef.recommendedLevel} (Party Lv {partyLevel})
                  </div>
                </div>
              </div>

              {/* Special Features & Objective */}
              <div
                style={{
                  marginTop: '20px',
                  display: 'grid',
                  gridTemplateColumns: '1fr 1fr',
                  gap: '16px',
                }}
              >
                {/* Objective Card */}
                <div
                  style={{
                    backgroundColor: '#1C211E',
                    border: '1px solid #5A4B38',
                    borderRadius: '6px',
                    padding: '16px',
                  }}
                >
                  <div
                    style={{
                      fontSize: '11px',
                      letterSpacing: '1.5px',
                      color: '#E2B05A',
                      textTransform: 'uppercase',
                      fontWeight: 700,
                      marginBottom: '8px',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '6px',
                    }}
                  >
                    <span>🎯</span> TACTICAL OBJECTIVE
                  </div>
                  <div
                    style={{
                      fontSize: '15px',
                      fontWeight: 700,
                      color: '#F2ECE1',
                      marginBottom: '4px',
                    }}
                  >
                    {selectedFloorDef.objective.title}
                  </div>
                  <div
                    style={{
                      fontSize: '12px',
                      color: '#B5AC9A',
                      lineHeight: '1.5',
                      fontFamily: 'sans-serif',
                    }}
                  >
                    {selectedFloorDef.objective.description}
                  </div>
                  {selectedFloorDef.objective.surviveRounds && (
                    <div
                      style={{
                        marginTop: '8px',
                        fontSize: '11px',
                        color: '#A855F7',
                        fontFamily: 'JetBrains Mono, monospace',
                      }}
                    >
                      Requirement: Survive {selectedFloorDef.objective.surviveRounds} combat rounds.
                    </div>
                  )}
                </div>

                {/* Environmental Hazard & Arena Preset */}
                <div
                  style={{
                    backgroundColor: '#1C211E',
                    border: '1px solid #5A4B38',
                    borderRadius: '6px',
                    padding: '16px',
                  }}
                >
                  <div
                    style={{
                      fontSize: '11px',
                      letterSpacing: '1.5px',
                      color: '#E2B05A',
                      textTransform: 'uppercase',
                      fontWeight: 700,
                      marginBottom: '8px',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '6px',
                    }}
                  >
                    <span>⚡</span> BATTLEFIELD HAZARD & TERRAIN
                  </div>
                  <div
                    style={{
                      fontSize: '14px',
                      fontWeight: 700,
                      color: '#F2ECE1',
                      marginBottom: '4px',
                    }}
                  >
                    {currentRegionMeta.signatureHazard}
                  </div>
                  <div
                    style={{
                      fontSize: '12px',
                      color: '#B5AC9A',
                      lineHeight: '1.5',
                      fontFamily: 'sans-serif',
                    }}
                  >
                    Theme: {selectedFloorDef.specialFeature}. Tactical elements include elevated
                    stone bastions, cover pillars, and environmental surfaces.
                  </div>
                </div>
              </div>

              {/* Boss Special Showcase (if Boss Floor) */}
              {selectedBossDef && (
                <div
                  style={{
                    marginTop: '20px',
                    backgroundColor: '#261F18',
                    border: '2px solid #E2B05A',
                    borderRadius: '8px',
                    padding: '18px',
                  }}
                >
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      marginBottom: '10px',
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                      <span style={{ fontSize: '24px' }}>👑</span>
                      <div>
                        <div
                          style={{
                            fontSize: '18px',
                            fontWeight: 700,
                            color: '#E2B05A',
                          }}
                        >
                          {selectedBossDef.name}
                        </div>
                        <div
                          style={{
                            fontSize: '12px',
                            color: '#F2ECE1',
                            fontStyle: 'italic',
                          }}
                        >
                          {selectedBossDef.epithet}
                        </div>
                      </div>
                    </div>
                    <span
                      style={{
                        fontSize: '11px',
                        padding: '3px 8px',
                        backgroundColor: '#171B19',
                        border: '1px solid #E2B05A',
                        borderRadius: '4px',
                        color: '#E2B05A',
                        fontFamily: 'JetBrains Mono, monospace',
                      }}
                    >
                      {selectedBossDef.phases.length} PHASES
                    </span>
                  </div>

                  <div
                    style={{
                      fontSize: '12px',
                      color: '#D1C7B7',
                      fontStyle: 'italic',
                      lineHeight: '1.5',
                      borderLeft: '2px solid #E2B05A',
                      paddingLeft: '12px',
                      marginBottom: '12px',
                    }}
                  >
                    "{selectedBossDef.introDialogue}"
                  </div>

                  <div
                    style={{
                      display: 'grid',
                      gridTemplateColumns: '1fr 1fr',
                      gap: '12px',
                      fontSize: '12px',
                      fontFamily: 'sans-serif',
                    }}
                  >
                    <div>
                      <strong style={{ color: '#E2B05A' }}>Weakness:</strong>{' '}
                      <span style={{ color: '#B5AC9A' }}>{selectedBossDef.weakness}</span>
                    </div>
                    <div>
                      <strong style={{ color: '#E2B05A' }}>Arena Alteration:</strong>{' '}
                      <span style={{ color: '#B5AC9A' }}>
                        {selectedBossDef.specialArenaMechanic}
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {/* Enemy Formation Preview */}
              <div style={{ marginTop: '20px' }}>
                <div
                  style={{
                    fontSize: '11px',
                    letterSpacing: '1.5px',
                    color: '#B5AC9A',
                    textTransform: 'uppercase',
                    fontWeight: 700,
                    marginBottom: '10px',
                  }}
                >
                  HOSTILE FORMATION ({selectedFloorDef.enemyFormation.length} FOES)
                </div>

                <div
                  style={{
                    display: 'grid',
                    gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))',
                    gap: '10px',
                  }}
                >
                  {selectedFloorDef.enemyFormation.map((enemy, idx) => (
                    <div
                      key={idx}
                      style={{
                        backgroundColor: '#1E2320',
                        border: '1px solid #3A3324',
                        borderRadius: '5px',
                        padding: '10px 12px',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                      }}
                    >
                      <div>
                        <div
                          style={{
                            fontSize: '13px',
                            fontWeight: 700,
                            color: enemy.isBoss ? '#E2B05A' : enemy.isMiniBoss ? '#E67E22' : '#F2ECE1',
                          }}
                        >
                          {enemy.name}
                        </div>
                        <div
                          style={{
                            fontSize: '10px',
                            color: '#77796F',
                            fontFamily: 'JetBrains Mono, monospace',
                          }}
                        >
                          {enemy.title}
                        </div>
                      </div>

                      <div
                        style={{
                          textAlign: 'right',
                          fontFamily: 'JetBrains Mono, monospace',
                          fontSize: '11px',
                        }}
                      >
                        <div style={{ color: '#B85349' }}>{enemy.hp} HP</div>
                        <div style={{ color: '#77796F', fontSize: '10px' }}>
                          AC {enemy.armorClass}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Rewards Box */}
              <div
                style={{
                  marginTop: '20px',
                  backgroundColor: '#1C211E',
                  border: '1px solid #5A4B38',
                  borderRadius: '6px',
                  padding: '16px',
                }}
              >
                <div
                  style={{
                    fontSize: '11px',
                    letterSpacing: '1.5px',
                    color: '#E2B05A',
                    textTransform: 'uppercase',
                    fontWeight: 700,
                    marginBottom: '8px',
                  }}
                >
                  FIRST-CLEAR REWARDS
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '24px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span style={{ fontSize: '16px', color: '#E2B05A' }}>◆</span>
                    <div>
                      <div
                        style={{
                          fontSize: '16px',
                          fontWeight: 700,
                          color: '#F2ECE1',
                          fontFamily: 'JetBrains Mono, monospace',
                        }}
                      >
                        +{selectedFloorDef.rewards.firstClearOathShards}
                      </div>
                      <div style={{ fontSize: '10px', color: '#B5AC9A' }}>Oath Shards</div>
                    </div>
                  </div>

                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <span style={{ fontSize: '16px', color: '#7E9C82' }}>⚡</span>
                    <div>
                      <div
                        style={{
                          fontSize: '16px',
                          fontWeight: 700,
                          color: '#F2ECE1',
                          fontFamily: 'JetBrains Mono, monospace',
                        }}
                      >
                        +{selectedFloorDef.rewards.firstClearXp} XP
                      </div>
                      <div style={{ fontSize: '10px', color: '#B5AC9A' }}>Progression XP</div>
                    </div>
                  </div>

                  {selectedFloorDef.rewards.guaranteedItemName && (
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <span style={{ fontSize: '16px', color: '#A855F7' }}>🎁</span>
                      <div>
                        <div
                          style={{
                            fontSize: '13px',
                            fontWeight: 700,
                            color: '#A855F7',
                          }}
                        >
                          {selectedFloorDef.rewards.guaranteedItemName}
                        </div>
                        <div style={{ fontSize: '10px', color: '#B5AC9A' }}>
                          Guaranteed Artifact
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Action Bar / Deploy Button */}
              <div
                style={{
                  marginTop: 'auto',
                  paddingTop: '24px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  gap: '16px',
                }}
              >
                {selectedFloorDef.isSanctuary && (
                  <button
                    onClick={handleSanctuaryRest}
                    style={{
                      padding: '12px 20px',
                      backgroundColor: '#222722',
                      border: '1px solid #7E9C82',
                      borderRadius: '6px',
                      color: '#7E9C82',
                      fontFamily: 'Cinzel, Georgia, serif',
                      fontSize: '13px',
                      fontWeight: 700,
                      cursor: 'pointer',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '8px',
                    }}
                  >
                    <span>🕯️</span> REST AT SANCTUARY (RESTORE PARTY HP)
                  </button>
                )}

                <div style={{ marginLeft: 'auto', display: 'flex', gap: '12px' }}>
                  <button
                    disabled={!isFloorUnlocked}
                    onClick={() => onLaunchTowerFloor(selectedFloorNumber)}
                    style={{
                      padding: '14px 36px',
                      backgroundColor: isFloorUnlocked ? '#E2B05A' : '#292E29',
                      border: isFloorUnlocked ? '2px solid #F59E0B' : '1px solid #5A4B38',
                      borderRadius: '6px',
                      color: isFloorUnlocked ? '#171B19' : '#77796F',
                      fontFamily: 'Cinzel, Georgia, serif',
                      fontSize: '15px',
                      fontWeight: 800,
                      letterSpacing: '2px',
                      cursor: isFloorUnlocked ? 'pointer' : 'not-allowed',
                      boxShadow: isFloorUnlocked
                        ? '0 0 20px rgba(226, 176, 90, 0.4)'
                        : 'none',
                      transition: 'all 0.2s ease',
                    }}
                    onMouseEnter={(e) => {
                      if (isFloorUnlocked) {
                        e.currentTarget.style.backgroundColor = '#F59E0B';
                        e.currentTarget.style.transform = 'translateY(-2px)';
                      }
                    }}
                    onMouseLeave={(e) => {
                      if (isFloorUnlocked) {
                        e.currentTarget.style.backgroundColor = '#E2B05A';
                        e.currentTarget.style.transform = 'translateY(0)';
                      }
                    }}
                  >
                    {isFloorUnlocked
                      ? isFloorCleared
                        ? `RE-ENTER FLOOR ${selectedFloorNumber}`
                        : `ASCEND TO FLOOR ${selectedFloorNumber}`
                      : `FLOOR ${selectedFloorNumber} SEALED`}
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Sanctuary Shop & Reliquary */}
        {activeTab === 'shop' && (
          <div
            style={{
              flex: 1,
              backgroundColor: '#141816',
              display: 'flex',
              flexDirection: 'column',
              overflowY: 'auto',
              padding: '24px 32px',
            }}
          >
            {/* Shop Header & Filter Tabs */}
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                borderBottom: '1px solid #3A3324',
                paddingBottom: '16px',
              }}
            >
              <div>
                <h2
                  style={{
                    margin: 0,
                    fontSize: '22px',
                    color: '#E2B05A',
                    letterSpacing: '1px',
                  }}
                >
                  SANCTUARY RELIQUARY & ARMORY
                </h2>
                <div
                  style={{
                    fontSize: '12px',
                    color: '#B5AC9A',
                    marginTop: '4px',
                  }}
                >
                  Exchange Oath Shards harvested from tower trials for ancient weaponry, relics, and
                  enduring blessings.
                </div>
              </div>

              {/* Filter Pills */}
              <div style={{ display: 'flex', gap: '8px' }}>
                {['all', 'weapon', 'armor', 'relic', 'oath_perk', 'consumable'].map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setShopCategoryFilter(cat)}
                    style={{
                      padding: '6px 12px',
                      backgroundColor:
                        shopCategoryFilter === cat ? '#E2B05A' : '#222722',
                      border: '1px solid #5A4B38',
                      borderRadius: '4px',
                      color: shopCategoryFilter === cat ? '#171B19' : '#F2ECE1',
                      fontFamily: 'Cinzel, Georgia, serif',
                      fontSize: '11px',
                      fontWeight: 700,
                      cursor: 'pointer',
                      textTransform: 'uppercase',
                      letterSpacing: '1px',
                    }}
                  >
                    {cat.replace('_', ' ')}
                  </button>
                ))}
              </div>
            </div>

            {/* Shop Grid */}
            <div
              style={{
                marginTop: '20px',
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fill, minmax(360px, 1fr))',
                gap: '16px',
              }}
            >
              {filteredShopItems.map((item) => {
                const isPurchased =
                  item.category !== 'consumable' &&
                  towerState.purchasedShopItemIds.includes(item.id);
                const isLocked = towerState.highestFloorCleared < item.requiredFloorCleared;
                const canAfford = towerState.oathShards >= item.oathShardCost;

                return (
                  <div
                    key={item.id}
                    style={{
                      backgroundColor: '#1C211E',
                      border: `1px solid ${RARITY_COLORS[item.rarity]}`,
                      borderRadius: '6px',
                      padding: '16px',
                      display: 'flex',
                      flexDirection: 'column',
                      justifyContent: 'space-between',
                      opacity: isLocked ? 0.6 : 1,
                    }}
                  >
                    <div>
                      <div
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'space-between',
                          marginBottom: '6px',
                        }}
                      >
                        <span
                          style={{
                            fontSize: '10px',
                            padding: '2px 6px',
                            borderRadius: '3px',
                            backgroundColor: '#171B19',
                            border: `1px solid ${RARITY_COLORS[item.rarity]}`,
                            color: RARITY_COLORS[item.rarity],
                            fontFamily: 'JetBrains Mono, monospace',
                            fontWeight: 700,
                          }}
                        >
                          {item.rarity.toUpperCase()} · {item.category.toUpperCase().replace('_', ' ')}
                        </span>

                        <span
                          style={{
                            fontSize: '14px',
                            fontWeight: 700,
                            color: '#E2B05A',
                            fontFamily: 'JetBrains Mono, monospace',
                          }}
                        >
                          ◆ {item.oathShardCost} Shards
                        </span>
                      </div>

                      <div
                        style={{
                          fontSize: '16px',
                          fontWeight: 700,
                          color: '#F2ECE1',
                          marginBottom: '6px',
                        }}
                      >
                        {item.name}
                      </div>

                      <div
                        style={{
                          fontSize: '12px',
                          color: '#7E9C82',
                          fontFamily: 'JetBrains Mono, monospace',
                          marginBottom: '8px',
                        }}
                      >
                        {item.statsSummary}
                      </div>

                      <div
                        style={{
                          fontSize: '11px',
                          color: '#B5AC9A',
                          lineHeight: '1.4',
                          fontFamily: 'sans-serif',
                          marginBottom: '14px',
                        }}
                      >
                        {item.description}
                      </div>
                    </div>

                    <div
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        borderTop: '1px solid #292E29',
                        paddingTop: '12px',
                      }}
                    >
                      <span
                        style={{
                          fontSize: '11px',
                          color: isLocked ? '#B85349' : '#7E9C82',
                          fontFamily: 'JetBrains Mono, monospace',
                        }}
                      >
                        {isLocked
                          ? `Req. Floor ${item.requiredFloorCleared} Cleared`
                          : `Unlocked (F${item.requiredFloorCleared})`}
                      </span>

                      <button
                        disabled={isPurchased || isLocked || !canAfford}
                        onClick={() => handlePurchase(item.id)}
                        style={{
                          padding: '8px 16px',
                          backgroundColor: isPurchased
                            ? '#2A3B2E'
                            : isLocked || !canAfford
                            ? '#292E29'
                            : '#E2B05A',
                          border: isPurchased
                            ? '1px solid #7E9C82'
                            : isLocked || !canAfford
                            ? '1px solid #5A4B38'
                            : '1px solid #F59E0B',
                          borderRadius: '4px',
                          color: isPurchased
                            ? '#7E9C82'
                            : isLocked || !canAfford
                            ? '#77796F'
                            : '#171B19',
                          fontFamily: 'Cinzel, Georgia, serif',
                          fontSize: '11px',
                          fontWeight: 700,
                          letterSpacing: '1px',
                          cursor: isPurchased || isLocked || !canAfford ? 'not-allowed' : 'pointer',
                        }}
                      >
                        {isPurchased
                          ? 'ACQUIRED ✓'
                          : isLocked
                          ? 'SEALED 🔒'
                          : !canAfford
                          ? 'NEED SHARDS'
                          : 'PURCHASE'}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Tab 3: Hall of Guardians & Bestiary */}
        {activeTab === 'bosses' && (
          <div
            style={{
              flex: 1,
              backgroundColor: '#141816',
              display: 'flex',
              flexDirection: 'column',
              overflowY: 'auto',
              padding: '24px 32px',
            }}
          >
            <div style={{ borderBottom: '1px solid #3A3324', paddingBottom: '16px' }}>
              <h2
                style={{
                  margin: 0,
                  fontSize: '22px',
                  color: '#E2B05A',
                  letterSpacing: '1px',
                }}
              >
                HALL OF GUARDIANS & BESTIARY
              </h2>
              <div style={{ fontSize: '12px', color: '#B5AC9A', marginTop: '4px' }}>
                Records and lore of the 10 Major Region Bosses guarding the seals of the Shattered
                Oath.
              </div>
            </div>

            <div
              style={{
                marginTop: '20px',
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fill, minmax(400px, 1fr))',
                gap: '16px',
              }}
            >
              {TOWER_CHECKPOINT_FLOORS.map((floorNum) => {
                const boss = TOWER_MAJOR_BOSSES[floorNum];
                if (!boss) return null;
                const record = towerState.bossClearRecords[floorNum];
                const isCleared = !!record;
                const isDiscovered = towerState.currentUnlockedFloor >= floorNum;

                return (
                  <div
                    key={floorNum}
                    style={{
                      backgroundColor: '#1C211E',
                      border: isCleared
                        ? '1px solid #E2B05A'
                        : isDiscovered
                        ? '1px solid #5A4B38'
                        : '1px solid #292E29',
                      borderRadius: '8px',
                      padding: '16px',
                      opacity: isDiscovered ? 1 : 0.5,
                    }}
                  >
                    <div
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        marginBottom: '8px',
                      }}
                    >
                      <span
                        style={{
                          fontSize: '11px',
                          color: '#E2B05A',
                          fontFamily: 'JetBrains Mono, monospace',
                        }}
                      >
                        FLOOR {floorNum} · MAJOR BOSS
                      </span>
                      {isCleared ? (
                        <span
                          style={{
                            fontSize: '11px',
                            color: '#7E9C82',
                            backgroundColor: '#1E2B20',
                            padding: '2px 6px',
                            borderRadius: '3px',
                            fontFamily: 'JetBrains Mono, monospace',
                          }}
                        >
                          VANQUISHED ({record.roundsTaken} Rounds)
                        </span>
                      ) : (
                        <span
                          style={{
                            fontSize: '11px',
                            color: isDiscovered ? '#B85349' : '#77796F',
                            fontFamily: 'JetBrains Mono, monospace',
                          }}
                        >
                          {isDiscovered ? 'AWAITING BATTLE' : 'SEALED 🔒'}
                        </span>
                      )}
                    </div>

                    <div
                      style={{
                        fontSize: '17px',
                        fontWeight: 700,
                        color: '#F2ECE1',
                        marginBottom: '2px',
                      }}
                    >
                      {isDiscovered ? boss.name : 'Unknown Astral Entity'}
                    </div>

                    <div
                      style={{
                        fontSize: '12px',
                        color: '#E2B05A',
                        fontStyle: 'italic',
                        marginBottom: '10px',
                      }}
                    >
                      {isDiscovered ? boss.epithet : 'Ancient Spire Sentinel'}
                    </div>

                    {isDiscovered ? (
                      <div>
                        <div
                          style={{
                            fontSize: '11px',
                            color: '#B5AC9A',
                            fontStyle: 'italic',
                            lineHeight: '1.4',
                            borderLeft: '2px solid #5A4B38',
                            paddingLeft: '10px',
                            marginBottom: '10px',
                          }}
                        >
                          "{boss.introDialogue}"
                        </div>

                        <div
                          style={{
                            fontSize: '11px',
                            fontFamily: 'sans-serif',
                            color: '#A855F7',
                            backgroundColor: '#1E1B24',
                            padding: '8px',
                            borderRadius: '4px',
                            border: '1px solid #6B46C1',
                          }}
                        >
                          <strong>Exclusive Relic Reward:</strong>{' '}
                          {boss.exclusiveArtifactReward.name} —{' '}
                          {boss.exclusiveArtifactReward.description}
                        </div>
                      </div>
                    ) : (
                      <div
                        style={{
                          fontSize: '12px',
                          color: '#77796F',
                          fontStyle: 'italic',
                          padding: '12px 0',
                        }}
                      >
                        Ascend through the spire to uncover the identity of this primordial guardian.
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

/**
 * Tower Post-Battle Summary Dialog
 */
export const TowerPostBattleModal: React.FC<{
  isOpen: boolean;
  summary: TowerBattleResultSummary | null;
  onAscendNext: () => void;
  onReturnToHub: () => void;
}> = ({ isOpen, summary, onAscendNext, onReturnToHub }) => {
  if (!isOpen || !summary) return null;

  const isVictory = summary.outcome === 'victory';

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 9500,
        backgroundColor: 'rgba(5, 8, 6, 0.88)',
        backdropFilter: 'blur(6px)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '24px',
        color: '#F2ECE1',
        fontFamily: 'Cinzel, Georgia, serif',
      }}
    >
      <div
        style={{
          width: '100%',
          maxWidth: '560px',
          backgroundColor: '#171B19',
          border: isVictory ? '2px solid #E2B05A' : '2px solid #B85349',
          borderRadius: '8px',
          padding: '28px',
          boxShadow: isVictory
            ? '0 0 50px rgba(226, 176, 90, 0.3)'
            : '0 0 50px rgba(184, 83, 73, 0.3)',
          textAlign: 'center',
        }}
      >
        <div style={{ fontSize: '42px', marginBottom: '8px' }}>
          {isVictory ? '🏆' : '💀'}
        </div>

        <h2
          style={{
            margin: '0 0 4px 0',
            fontSize: '24px',
            color: isVictory ? '#E2B05A' : '#B85349',
            letterSpacing: '2px',
          }}
        >
          {isVictory
            ? `FLOOR ${summary.floorNumber} CONQUERED!`
            : `FLOOR ${summary.floorNumber} TRIAL FAILED`}
        </h2>

        <div
          style={{
            fontSize: '13px',
            color: '#B5AC9A',
            marginBottom: '20px',
          }}
        >
          {isVictory
            ? `Bout concluded in ${summary.roundsTaken} tactical round(s). The path upward resonates.`
            : summary.defeatReason ?? 'The party collapsed beneath the guardian’s assault.'}
        </div>

        {summary.bossDefeatedName && isVictory && (
          <div
            style={{
              padding: '10px 14px',
              backgroundColor: '#261F18',
              border: '1px solid #E2B05A',
              borderRadius: '6px',
              fontSize: '12px',
              color: '#E2B05A',
              marginBottom: '16px',
            }}
          >
            👑 Guardian Vanquished: <strong>{summary.bossDefeatedName}</strong>
          </div>
        )}

        {/* Victory Spoils */}
        {isVictory && (
          <div
            style={{
              backgroundColor: '#1C211E',
              border: '1px solid #3A3324',
              borderRadius: '6px',
              padding: '16px',
              marginBottom: '24px',
              display: 'flex',
              justifyContent: 'space-around',
            }}
          >
            <div>
              <div
                style={{
                  fontSize: '20px',
                  fontWeight: 700,
                  color: '#E2B05A',
                  fontFamily: 'JetBrains Mono, monospace',
                }}
              >
                +◆ {summary.shardsEarned}
              </div>
              <div style={{ fontSize: '11px', color: '#B5AC9A' }}>Oath Shards</div>
            </div>

            <div style={{ borderLeft: '1px solid #3A3324' }} />

            <div>
              <div
                style={{
                  fontSize: '20px',
                  fontWeight: 700,
                  color: '#7E9C82',
                  fontFamily: 'JetBrains Mono, monospace',
                }}
              >
                +{summary.xpEarned} XP
              </div>
              <div style={{ fontSize: '11px', color: '#B5AC9A' }}>Experience Points</div>
            </div>
          </div>
        )}

        {summary.unlockedCheckpoint && isVictory && (
          <div
            style={{
              padding: '8px 12px',
              backgroundColor: '#1E2B20',
              border: '1px solid #7E9C82',
              borderRadius: '4px',
              color: '#7E9C82',
              fontSize: '12px',
              marginBottom: '20px',
              fontFamily: 'JetBrains Mono, monospace',
            }}
          >
            ⚡ Permanent Checkpoint & Sanctuary Unlocked at Floor{' '}
            {summary.unlockedCheckpoint}!
          </div>
        )}

        <div style={{ display: 'flex', gap: '12px', justifyContent: 'center' }}>
          <button
            onClick={onReturnToHub}
            style={{
              padding: '10px 22px',
              backgroundColor: '#292E29',
              border: '1px solid #5A4B38',
              borderRadius: '6px',
              color: '#F2ECE1',
              fontFamily: 'Cinzel, Georgia, serif',
              fontSize: '12px',
              letterSpacing: '1px',
              cursor: 'pointer',
            }}
          >
            RETURN TO TOWER HUB
          </button>

          {isVictory && summary.floorNumber < 100 && (
            <button
              onClick={onAscendNext}
              style={{
                padding: '10px 24px',
                backgroundColor: '#E2B05A',
                border: '1px solid #F59E0B',
                borderRadius: '6px',
                color: '#171B19',
                fontFamily: 'Cinzel, Georgia, serif',
                fontSize: '12px',
                fontWeight: 800,
                letterSpacing: '1px',
                cursor: 'pointer',
              }}
            >
              ASCEND TO FLOOR {summary.floorNumber + 1} →
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
