import React from 'react';
import { DiceRollToastEntry } from '../game/rules';
import { CharacterPortraitSvg, D20DieSvg } from './PortraitsAndIcons';

interface DiceRollToastOverlayProps {
  toasts: DiceRollToastEntry[];
  onDismiss: (id: number) => void;
}

export const DiceRollToastOverlay: React.FC<DiceRollToastOverlayProps> = ({
  toasts,
  onDismiss,
}) => {
  if (toasts.length === 0) return null;

  return (
    <aside
      aria-live="polite"
      aria-label="D20 Dice Roll Breakdown"
      data-testid="dice-roll-toast-overlay"
      className="fixed top-16 right-4 z-50 flex flex-col gap-2.5 w-full max-w-[390px] pointer-events-none"
    >
      {toasts.map((toast, idx) => {
        const dieVariant = toast.critical
          ? 'emerald'
          : toast.success
          ? 'gold'
          : 'crimson';

        const borderClass = toast.critical
          ? 'border-emerald-400/80'
          : toast.success
          ? 'border-amber-400/65'
          : 'border-rose-500/70';

        const badgeColorClass = toast.critical
          ? 'text-emerald-300'
          : toast.success
          ? 'text-amber-300'
          : 'text-rose-400';

        return (
          <div
            key={toast.id}
            data-testid={`dice-toast-${idx}`}
            className={`pointer-events-auto rounded-xl border ${borderClass} px-3.5 py-3 shadow-2xl transition-all duration-200`}
            style={{ backgroundColor: 'rgba(13, 11, 21, 0.96)' }}
          >
            {/* Header Row: Portrait, Actor & Action Label, Outcome Badge & Dismiss */}
            <div className="flex items-start justify-between gap-2.5">
              <div className="flex items-center gap-2 min-w-0">
                <CharacterPortraitSvg
                  id={toast.actorPortrait}
                  className="w-7 h-7 rounded border border-amber-500/40 shrink-0"
                />
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-display font-bold text-amber-100 truncate">
                      {toast.actorName}
                    </span>
                    <span aria-hidden="true" className="text-stone-600">
                      ·
                    </span>
                    <span
                      className={`text-[11px] font-mono font-bold tracking-wide whitespace-nowrap ${badgeColorClass}`}
                    >
                      {toast.outcomeBadge}
                    </span>
                  </div>
                  <p className="text-[11px] text-stone-300 truncate">{toast.actionLabel}</p>
                </div>
              </div>

              <button
                type="button"
                aria-label="Dismiss roll notification"
                onClick={() => onDismiss(toast.id)}
                className="text-stone-400 hover:text-amber-200 text-xs font-mono px-1.5 py-0.5 rounded border border-transparent hover:border-stone-700 transition-colors shrink-0"
              >
                ×
              </button>
            </div>

            {/* Body Row: Faceted D20 SVG + Interactive Modifier Breakdown & Total vs Threshold */}
            <div className="mt-2.5 pt-2 border-t border-stone-800/90 flex items-center gap-3">
              <div className="relative shrink-0 flex flex-col items-center">
                <D20DieSvg
                  value={toast.d20Roll}
                  variant={dieVariant}
                  className="w-12 h-12 shrink-0"
                />
                <span className="text-[10px] font-mono uppercase tracking-wider text-stone-400 mt-0.5">
                  {toast.d20Roll === 20
                    ? 'NAT 20'
                    : toast.d20Roll === 1
                    ? 'NAT 1'
                    : 'D20 ROLL'}
                </span>
              </div>

              <div className="flex-1 min-w-0">
                {/* Step-by-step Modifier Breakdown Row */}
                <div className="flex flex-wrap items-center gap-x-1.5 gap-y-1 text-xs font-mono tabular-nums">
                  <span className="px-1.5 py-0.5 rounded bg-stone-900 border border-stone-700 text-amber-200 font-bold">
                    d20: {toast.d20Roll}
                  </span>

                  {toast.modifiers.map((mod, mIdx) => (
                    <React.Fragment key={mIdx}>
                      <span className="text-stone-400 font-bold">
                        {mod.value >= 0 ? '+' : '−'}
                      </span>
                      <span
                        className={`px-1.5 py-0.5 rounded border ${
                          mod.value >= 0
                            ? 'bg-amber-950/40 border-amber-500/30 text-amber-200'
                            : 'bg-rose-950/40 border-rose-500/30 text-rose-300'
                        }`}
                      >
                        {Math.abs(mod.value)} {mod.label}
                      </span>
                    </React.Fragment>
                  ))}

                  <span className="text-stone-400 font-bold">=</span>
                  <span
                    className={`px-2 py-0.5 rounded font-bold border ${
                      toast.success
                        ? 'bg-emerald-950/60 border-emerald-400/50 text-emerald-200'
                        : 'bg-rose-950/60 border-rose-500/50 text-rose-200'
                    }`}
                  >
                    {toast.totalRoll}
                  </span>
                </div>

                {/* Comparison & Damage / Outcome Footer */}
                <div className="flex items-center justify-between gap-2 mt-1.5 text-[11px] font-mono tabular-nums">
                  <span className="text-stone-400 truncate">
                    Target: <strong className="text-stone-200">{toast.thresholdLabel}</strong>
                  </span>
                  <span
                    className={`font-semibold whitespace-nowrap ${
                      toast.success ? 'text-emerald-300' : 'text-rose-300'
                    }`}
                  >
                    {toast.impactSummary}
                  </span>
                </div>
              </div>
            </div>
          </div>
        );
      })}
    </aside>
  );
};
