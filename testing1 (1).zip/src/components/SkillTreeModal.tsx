import React, { useState, useEffect, useMemo } from 'react';
import {
  ALL_SKILLS_DATABASE,
  CharacterProgressionState,
  CLASS_MASTERY_CHOICES,
  equipSkillToSlot,
  unequipSkillSlot,
  PlayableClassKey,
  selectClassMastery,
  SkillProgressionDefinition,
  unlockSkill,
} from '../game/progressionData';
import { SkillIconSvg } from './SkillIcons';
import { CharacterClassId, CharacterSubclassId } from '../game/rules';
import {
  WARRIOR_ANIMATION_REGISTRY,
  WarriorSkillId,
  sampleWarriorRigTransform,
} from '../game/warriorAnimations';
import {
  MASTER_ANIMATION_REGISTRY,
  sampleMasterRigTransform,
} from '../game/skills/masterAnimationRegistry';

interface SkillTreeModalProps {
  progressionState: CharacterProgressionState;
  commanderName: string;
  classId: CharacterClassId | string;
  subclassId: CharacterSubclassId | string;
  onUpdateProgression: (nextState: CharacterProgressionState) => void;
  onLaunchWarriorTrialGrounds?: () => void;
  onLaunchMageTrialGrounds?: () => void;
  onClose: () => void;
}

type TreeTab = 'core' | 'specialization' | 'passives' | 'warrior_audit' | 'mage_audit';
type FilterStatus = 'all' | 'available' | 'learned' | 'equipped' | 'locked';

interface BranchDefinition {
  id: string;
  name: string;
  subtitle: string;
  focus: string;
  accentBorder: string;
  accentBg: string;
  accentText: string;
  skills: SkillProgressionDefinition[];
}

export const SkillTreeModal: React.FC<SkillTreeModalProps> = ({
  progressionState,
  commanderName,
  classId,
  subclassId,
  onUpdateProgression,
  onLaunchWarriorTrialGrounds,
  onLaunchMageTrialGrounds,
  onClose,
}) => {
  // Determine normalized active class key
  const activeClassKey: PlayableClassKey = useMemo(() => {
    const lower = (classId || '').toLowerCase();
    if (lower.includes('warrior')) return 'warrior';
    if (lower.includes('mage') || lower.includes('arcanist')) return 'mage';
    if (lower.includes('rogue')) return 'rogue';
    if (lower.includes('ranger') || lower.includes('warden')) return 'ranger';
    return 'paladin';
  }, [classId]);

  // View state
  const [selectedClass, setSelectedClass] = useState<PlayableClassKey>(activeClassKey);
  const [activeTab, setActiveTab] = useState<TreeTab>('core');
  const [filterStatus, setFilterStatus] = useState<FilterStatus>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedSkillId, setSelectedSkillId] = useState<string>(() => {
    return progressionState.equippedSkillIds.find((id) => Boolean(id)) ||
      (activeClassKey === 'warrior' ? 'sundering_strike' : 'consecrated_strike');
  });
  const [feedbackToast, setFeedbackToast] = useState<string | null>(null);
  const [auditIconPreviewState, setAuditIconPreviewState] = useState<
    'available' | 'selected' | 'cooldown' | 'disabled'
  >('available');
  const [auditAnimElapsed, setAuditAnimElapsed] = useState<number>(0.24);

  // Sync selected class when active class changes
  useEffect(() => {
    setSelectedClass(activeClassKey);
  }, [activeClassKey]);

  // Keyboard shortcut listener for Esc, K, and 1-4 quick slot equip
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' || e.code === 'KeyK') {
        e.preventDefault();
        onClose();
        return;
      }
      // Quick slot equip keys 1-4
      if (['Digit1', 'Digit2', 'Digit3', 'Digit4'].includes(e.code)) {
        const slotIdx = (parseInt(e.code.replace('Digit', ''), 10) - 1) as 0 | 1 | 2 | 3;
        const skill = ALL_SKILLS_DATABASE[selectedSkillId];
        if (skill && progressionState.learnedSkillIds.includes(skill.id) && !skill.isPassive) {
          e.preventDefault();
          handleEquipSlot(slotIdx, skill.id);
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedSkillId, progressionState, onClose]);

  const showToast = (msg: string) => {
    setFeedbackToast(msg);
    setTimeout(() => {
      setFeedbackToast((cur) => (cur === msg ? null : cur));
    }, 3200);
  };

  // Selected skill profile
  const selectedSkill: SkillProgressionDefinition | undefined = ALL_SKILLS_DATABASE[selectedSkillId];

  // Derive Character Specialization Name
  const specDisplayName = useMemo(() => {
    const spec = (subclassId || '').toString().replace(/_/g, ' ');
    if (!spec || spec.length === 0) {
      return activeClassKey === 'warrior' ? 'Vengeance Knight' : 'Dawn Warden';
    }
    return spec.replace(/\b\w/g, (c) => c.toUpperCase());
  }, [subclassId, activeClassKey]);

  // Curated 3-Branch structure for all 5 classes (4 skills each, sorted Tier 1 to Tier 4)
  const coreBranches: BranchDefinition[] = useMemo(() => {
    if (selectedClass === 'warrior') {
      return [
        {
          id: 'offense',
          name: 'OFFENSE',
          subtitle: 'Blade Cleaves & Sundering',
          focus: 'Melee weapon strikes, armor disruption, and heavy physical cleaves.',
          accentBorder: 'border-[#7A3636]/60',
          accentBg: 'bg-[#2B1717]',
          accentText: 'text-[#E08585]',
          skills: ['sundering_strike', 'whirlwind_assault', 'crippling_blow', 'iron_reprisal']
            .map((id) => ALL_SKILLS_DATABASE[id])
            .filter(Boolean),
        },
        {
          id: 'defense',
          name: 'DEFENSE',
          subtitle: 'Bastion Wards & Resilience',
          focus: 'Defensive postures, weapon deflections, and crowd-control counters.',
          accentBorder: 'border-[#3B5875]/60',
          accentBg: 'bg-[#152331]',
          accentText: 'text-[#85B0E0]',
          skills: ['guarded_stance', 'weapon_parry', 'unbreakable_resolve', 'last_stand']
            .map((id) => ALL_SKILLS_DATABASE[id])
            .filter(Boolean),
        },
        {
          id: 'mobility',
          name: 'MOBILITY & COMMAND',
          subtitle: 'Tactical Pursuit & War Cries',
          focus: 'Bull-rushes, gap-closers, seismic shockwaves, and squad rallying.',
          accentBorder: 'border-[#856E37]/60',
          accentBg: 'bg-[#292212]',
          accentText: 'text-[#E0C785]',
          skills: ['driving_assault', 'earthsplitter', 'relentless_pursuit', 'battlefield_commander']
            .map((id) => ALL_SKILLS_DATABASE[id])
            .filter(Boolean),
        },
      ];
    }

    if (selectedClass === 'paladin') {
      return [
        {
          id: 'offense',
          name: 'OFFENSE',
          subtitle: 'Radiant Strikes & Retribution',
          focus: 'Holy fire weapon attacks, brandings, and celestial judgments.',
          accentBorder: 'border-[#7A3636]/60',
          accentBg: 'bg-[#2B1717]',
          accentText: 'text-[#E08585]',
          skills: ['consecrated_strike', 'judgment_mark', 'shield_of_conviction', 'final_judgment']
            .map((id) => ALL_SKILLS_DATABASE[id])
            .filter(Boolean),
        },
        {
          id: 'defense',
          name: 'DEFENSE',
          subtitle: 'Sanctified Halos & Aegis',
          focus: 'Covenant shields, sanctuary rings, and holy consecrated zones.',
          accentBorder: 'border-[#3B5875]/60',
          accentBg: 'bg-[#152331]',
          accentText: 'text-[#85B0E0]',
          skills: ['oathward', 'sanctuary_ring', 'sacred_ground', 'beacon_of_hope']
            .map((id) => ALL_SKILLS_DATABASE[id])
            .filter(Boolean),
        },
        {
          id: 'mobility',
          name: 'MOBILITY & COMMAND',
          subtitle: 'Purging & Intercession',
          focus: 'Purging mends, golden chains of law, and teleportation intercession.',
          accentBorder: 'border-[#856E37]/60',
          accentBg: 'bg-[#292212]',
          accentText: 'text-[#E0C785]',
          skills: ['radiant_mend', 'oath_of_restraint', 'burden_of_sin', 'divine_intercession']
            .map((id) => ALL_SKILLS_DATABASE[id])
            .filter(Boolean),
        },
      ];
    }

    if (selectedClass === 'mage') {
      return [
        {
          id: 'elemental',
          name: 'ELEMENTAL DESTRUCTION',
          subtitle: 'Fire & Frost Evocation',
          focus: 'Area firestorms, piercing glacial rays, and deterministic chain lightning.',
          accentBorder: 'border-[#7A3636]/60',
          accentBg: 'bg-[#2B1717]',
          accentText: 'text-[#E08585]',
          skills: ['infernal_orb', 'glacial_lance', 'chain_lightning']
            .map((id) => ALL_SKILLS_DATABASE[id])
            .filter(Boolean),
        },
        {
          id: 'manipulation',
          name: 'ARCANE MANIPULATION',
          subtitle: 'Space-Time & Singularity',
          focus: 'Instant teleportation, gravitational collapse, and magical ward purges.',
          accentBorder: 'border-[#5B3E75]/60',
          accentBg: 'bg-[#221731]',
          accentText: 'text-[#C785E0]',
          skills: ['blink_step', 'gravitational_collapse', 'arcane_disjunction']
            .map((id) => ALL_SKILLS_DATABASE[id])
            .filter(Boolean),
        },
        {
          id: 'defense',
          name: 'MYSTICAL DEFENSE',
          subtitle: 'Aegis Barriers & Deflection',
          focus: 'Temporary HP buffers, shockwave retaliation, and spell counter-deflection.',
          accentBorder: 'border-[#3B5875]/60',
          accentBg: 'bg-[#152331]',
          accentText: 'text-[#85B0E0]',
          skills: ['aegis_ward', 'counterspell', 'phase_veil']
            .map((id) => ALL_SKILLS_DATABASE[id])
            .filter(Boolean),
        },
        {
          id: 'control',
          name: 'BATTLEFIELD CONTROL',
          subtitle: 'Runic Wards & Spatial Rifts',
          focus: 'Proximity mines, temporary spatial hazards, and harmonic team matrices.',
          accentBorder: 'border-[#37756E]/60',
          accentBg: 'bg-[#122926]',
          accentText: 'text-[#85E0C7]',
          skills: ['runic_mine', 'astral_rift', 'prismatic_field']
            .map((id) => ALL_SKILLS_DATABASE[id])
            .filter(Boolean),
        },
      ];
    }

    if (selectedClass === 'rogue') {
      return [
        {
          id: 'offense',
          name: 'OFFENSE',
          subtitle: 'Assassination & Toxins',
          focus: 'Quickdraw cross-bows, venom coatings, and surgical executions.',
          accentBorder: 'border-[#7A3636]/60',
          accentBg: 'bg-[#2B1717]',
          accentText: 'text-[#E08585]',
          skills: ['quickdraw', 'pickpocket', 'poisoned_edge', 'perfect_execution']
            .map((id) => ALL_SKILLS_DATABASE[id])
            .filter(Boolean),
        },
        {
          id: 'defense',
          name: 'DEFENSE',
          subtitle: 'Shadow Cloaks & Ripostes',
          focus: 'Shadow veils, counter-attacks, evasive rolls, and ambush reactions.',
          accentBorder: 'border-[#3B5875]/60',
          accentBg: 'bg-[#152331]',
          accentText: 'text-[#85B0E0]',
          skills: ['shadow_veil', 'false_opening', 'evasive_roll', 'ambush_protocol']
            .map((id) => ALL_SKILLS_DATABASE[id])
            .filter(Boolean),
        },
        {
          id: 'mobility',
          name: 'MOBILITY & COMMAND',
          subtitle: 'Snares & Position Swaps',
          focus: 'Quarry marks, wire traps, smoke bombs, and shadow swaps.',
          accentBorder: 'border-[#856E37]/60',
          accentBg: 'bg-[#292212]',
          accentText: 'text-[#E0C785]',
          skills: ['mark_for_death', 'tripwire', 'smoke_escape', 'shadow_exchange']
            .map((id) => ALL_SKILLS_DATABASE[id])
            .filter(Boolean),
        },
      ];
    }

    // Ranger
    return [
      {
        id: 'offense',
        name: 'OFFENSE',
        subtitle: 'Deadeye Snipes & Volleys',
        focus: 'Longbow snipes, trick ricochets, marked prey, and nature dominion.',
        accentBorder: 'border-[#7A3636]/60',
        accentBg: 'bg-[#2B1717]',
        accentText: 'text-[#E08585]',
        skills: ['longbow_volley', 'ricochet_shot', 'marked_prey', 'natures_dominion']
          .map((id) => ALL_SKILLS_DATABASE[id])
          .filter(Boolean),
      },
      {
        id: 'defense',
        name: 'DEFENSE',
        subtitle: 'Brambles & Animal Guardian',
        focus: 'Camouflage, razor thornlines, sylvan wolves, and deadfall traps.',
        accentBorder: 'border-[#3B5875]/60',
        accentBg: 'bg-[#152331]',
        accentText: 'text-[#85B0E0]',
        skills: ['camouflage', 'thornline', 'beast_call', 'deadfall_trap']
          .map((id) => ALL_SKILLS_DATABASE[id])
          .filter(Boolean),
      },
      {
        id: 'mobility',
        name: 'MOBILITY & COMMAND',
        subtitle: 'Prey Pursuit & Pinning',
        focus: 'Blood scent tracking, bodkin pins, killzones, and windrunner stride.',
        accentBorder: 'border-[#856E37]/60',
        accentBg: 'bg-[#292212]',
        accentText: 'text-[#E0C785]',
        skills: ['hunters_instinct', 'pinning_arrow', 'hunting_ground', 'windrunner']
          .map((id) => ALL_SKILLS_DATABASE[id])
          .filter(Boolean),
      },
    ];
  }, [selectedClass]);

  // Specialization skills for the character's sworn path
  const specializationSkills: SkillProgressionDefinition[] = useMemo(() => {
    const all = Object.values(ALL_SKILLS_DATABASE);
    const specKey = (subclassId || '').toString().toLowerCase();

    const matched = all.filter((s) => s.specializationKey && s.specializationKey === specKey);
    if (matched.length > 0) {
      return matched.sort((a, b) => a.minLevel - b.minLevel);
    }
    const fallbackSpecKey =
      selectedClass === 'warrior'
        ? 'vengeance_knight'
        : selectedClass === 'paladin'
        ? 'dawn_warden'
        : selectedClass === 'mage'
        ? 'crimson_savant'
        : selectedClass === 'rogue'
        ? 'shadowblade'
        : 'deadeye_sniper';
    return all.filter((s) => s.specializationKey === fallbackSpecKey).sort((a, b) => a.minLevel - b.minLevel);
  }, [subclassId, selectedClass]);

  // Total core skills for current class
  const classCoreSkills = useMemo(() => {
    return Object.values(ALL_SKILLS_DATABASE).filter(
      (s) => s.classKey === selectedClass && !s.specializationKey
    );
  }, [selectedClass]);

  // Dynamic filter counts
  const filterCounts = useMemo(() => {
    const pool = activeTab === 'specialization' ? specializationSkills : classCoreSkills;
    let availableCount = 0;
    let learnedCount = 0;
    let equippedCount = 0;
    let lockedCount = 0;

    for (const skill of pool) {
      const isLearned = progressionState.learnedSkillIds.includes(skill.id);
      const isEquipped = progressionState.equippedSkillIds.includes(skill.id);
      const isLevelMet = progressionState.level >= skill.minLevel;
      const canAfford = progressionState.unspentSkillPoints >= skill.skillPointCost;

      if (isLearned) learnedCount++;
      if (isEquipped) equippedCount++;
      if (!isLearned && isLevelMet && canAfford) availableCount++;
      if (!isLearned && !isLevelMet) lockedCount++;
    }

    return {
      all: pool.length,
      available: availableCount,
      learned: learnedCount,
      equipped: equippedCount,
      locked: lockedCount,
    };
  }, [activeTab, specializationSkills, classCoreSkills, progressionState]);

  // Filter verification helper
  const matchesFilterAndSearch = (skill: SkillProgressionDefinition): boolean => {
    if (searchQuery.trim().length > 0) {
      const q = searchQuery.toLowerCase().trim();
      const matchName = skill.name.toLowerCase().includes(q);
      const matchCat = skill.category.toLowerCase().includes(q);
      const matchEffect = (skill.statusEffect || '').toLowerCase().includes(q);
      const matchRole = (skill.tacticalExplanation || '').toLowerCase().includes(q);
      const matchDesc = (skill.description || '').toLowerCase().includes(q);
      if (!matchName && !matchCat && !matchEffect && !matchRole && !matchDesc) {
        return false;
      }
    }

    const isLearned = progressionState.learnedSkillIds.includes(skill.id);
    const isEquipped = progressionState.equippedSkillIds.includes(skill.id);
    const isLevelMet = progressionState.level >= skill.minLevel;
    const canAfford = progressionState.unspentSkillPoints >= skill.skillPointCost;

    switch (filterStatus) {
      case 'available':
        return !isLearned && isLevelMet && canAfford;
      case 'learned':
        return isLearned;
      case 'equipped':
        return isEquipped;
      case 'locked':
        return !isLearned && !isLevelMet;
      case 'all':
      default:
        return true;
    }
  };

  // Progression Actions
  const handleUnlockSkill = (skillId: string) => {
    const res = unlockSkill(progressionState, skillId);
    if (res.success) {
      onUpdateProgression(res.nextState);
      const sk = ALL_SKILLS_DATABASE[skillId];
      showToast(`✦ Unlocked: ${sk?.name ?? skillId}`);
    } else {
      showToast(res.error || 'Cannot unlock skill');
    }
  };

  const handleEquipSlot = (slotIdx: 0 | 1 | 2 | 3, skillId: string) => {
    // If already equipped in this exact slot, clicking again un-equips it
    if (progressionState.equippedSkillIds[slotIdx] === skillId) {
      handleUnequipSlot(slotIdx);
      return;
    }
    const res = equipSkillToSlot(progressionState, slotIdx, skillId);
    if (res.success) {
      onUpdateProgression(res.nextState);
      const sk = ALL_SKILLS_DATABASE[skillId];
      showToast(`Assigned ${sk?.name ?? skillId} to Slot ${slotIdx + 1}`);
    } else {
      showToast(res.error || 'Cannot equip skill');
    }
  };

  const handleUnequipSlot = (slotIdx: 0 | 1 | 2 | 3) => {
    const skillId = progressionState.equippedSkillIds[slotIdx];
    const sk = ALL_SKILLS_DATABASE[skillId];
    const res = unequipSkillSlot(progressionState, slotIdx);
    if (res.success) {
      onUpdateProgression(res.nextState);
      showToast(`Unequipped ${sk?.name ?? 'ability'} from Slot ${slotIdx + 1}`);
    }
  };

  const handleSelectMastery = (milestone: 5 | 10 | 15 | 20, choiceId: string) => {
    const res = selectClassMastery(progressionState, milestone, choiceId);
    if (res.success) {
      onUpdateProgression(res.nextState);
      showToast('Mastery Path Selected!');
    }
  };

  // Render Compact Square Skill Node with Icons & Learned-State Counter
  const renderSquareSkillNode = (skill: SkillProgressionDefinition) => {
    const isLearned = progressionState.learnedSkillIds.includes(skill.id);
    const isSelected = selectedSkillId === skill.id;
    const isLevelMet = progressionState.level >= skill.minLevel;
    const canAfford = progressionState.unspentSkillPoints >= skill.skillPointCost;
    const equippedSlotIdx = progressionState.equippedSkillIds.indexOf(skill.id);
    const isEquipped = equippedSlotIdx !== -1;
    const isAvailable = !isLearned && isLevelMet && canAfford;
    const isLocked = !isLearned && !isLevelMet;
    const matches = matchesFilterAndSearch(skill);

    return (
      <div
        key={skill.id}
        data-testid={`skill-node-${skill.id}`}
        onClick={() => setSelectedSkillId(skill.id)}
        className={`flex flex-col items-center cursor-pointer select-none group transition-transform ${
          !matches ? 'opacity-25 grayscale' : ''
        }`}
      >
        {/* Compact Square Node Box */}
        <div
          className={`relative w-16 h-16 sm:w-18 sm:h-18 rounded-lg border-2 p-1 flex items-center justify-center transition-all ${
            isSelected
              ? 'border-[#E2B05A] ring-2 ring-[#E2B05A] ring-offset-2 ring-offset-[#111613] bg-[#2E281C] shadow-xl scale-105'
              : isEquipped
              ? 'border-[#E2B05A] bg-[#242116] shadow-md hover:scale-102'
              : isLearned
              ? 'border-[#7E9C82] bg-[#162118] hover:border-[#96B89A] hover:scale-102 shadow-sm'
              : isAvailable
              ? 'border-[#E2B05A]/80 bg-[#1D211B] hover:border-[#F7E3A6] hover:scale-102 shadow-sm'
              : isLocked
              ? 'border-[#333830] bg-[#101211] opacity-70 hover:border-[#5A4B38]'
              : 'border-[#5A4B38]/60 bg-[#151916] hover:border-[#B5AC9A]'
          }`}
        >
          {/* Inner Textured Icon Frame */}
          <div
            className={`w-full h-full rounded overflow-hidden flex items-center justify-center ${
              isLocked ? 'grayscale brightness-40' : ''
            }`}
          >
            <SkillIconSvg skillId={skill.id} skillName={skill.name} className="w-full h-full object-cover" />
          </div>

          {/* Top-Right Badge: Slot or Learned-state counter */}
          {isEquipped && (
            <div className="absolute -top-2 -right-2 px-1.5 py-0.5 rounded bg-[#E2B05A] text-[#111613] text-[9px] font-mono font-bold shadow-md border border-[#111613]">
              Slot {equippedSlotIdx + 1}
            </div>
          )}
          {!isEquipped && isLearned && (
            <div className="absolute -top-2 -right-2 px-1 py-0.2 rounded bg-[#7E9C82] text-[#111613] text-[9px] font-bold shadow-md border border-[#111613]">
              1/1
            </div>
          )}
          {!isLearned && isAvailable && (
            <div className="absolute -top-2 -right-2 px-1 py-0.2 rounded bg-[#E2B05A] text-[#111613] text-[9px] font-mono font-bold shadow-md border border-[#111613] animate-pulse">
              1 SP
            </div>
          )}
          {!isLearned && isLocked && (
            <div className="absolute -top-2 -right-2 px-1 py-0.2 rounded bg-[#1C1F1D] text-[#77796F] text-[9px] font-mono shadow-md border border-[#333830]">
              🔒 Lv {skill.minLevel}
            </div>
          )}

          {/* Bottom-Left Mini Chip for Passive */}
          {skill.isPassive && (
            <div className="absolute -bottom-1 -left-1 px-1 rounded bg-[#A855F7] text-[#FFFFFF] text-[8px] font-bold uppercase tracking-tighter">
              PAS
            </div>
          )}
        </div>

        {/* Short Name Label (Up to 2 lines, non-truncated) */}
        <div className="mt-1.5 text-center max-w-[90px]">
          <span
            className={`block font-serif font-semibold text-[11px] leading-tight line-clamp-2 ${
              isSelected ? 'text-[#E2B05A]' : isEquipped ? 'text-[#F2ECE1]' : isLearned ? 'text-[#7E9C82]' : 'text-[#B5AC9A]'
            }`}
          >
            {skill.name}
          </span>
          <span className="block text-[9px] font-mono text-[#77796F] mt-0.5">
            {skill.isPassive ? 'Passive' : `${skill.apCost} AP`}
          </span>
        </div>
      </div>
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-2 sm:p-4">
      <div className="relative w-full max-w-7xl h-[94vh] max-h-[920px] bg-[#111613] border-2 border-[#5A4B38] rounded-xl flex flex-col shadow-2xl overflow-hidden text-[#F2ECE1]">

        {/* =================================================================== */}
        {/* 1. TOP HEADER ZONE                                                  */}
        {/* =================================================================== */}
        <header className="h-16 px-5 bg-[rgba(22,28,24,0.98)] border-b border-[#5A4B38] flex items-center justify-between shrink-0 gap-4">
          {/* Left Title & Tabs */}
          <div className="flex items-center gap-5">
            <div className="flex items-center gap-2">
              <span className="font-serif font-bold text-base text-[#E2B05A] tracking-wider uppercase">
                Skill Archive
              </span>
            </div>

            <div className="h-6 w-[1px] bg-[#5A4B38]/60 hidden sm:block" />

            {/* Core Skills and Specialization Tabs in Top Header */}
            <nav className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => setActiveTab('core')}
                className={`px-3 py-1.5 rounded-lg text-xs font-serif font-bold transition-colors ${
                  activeTab === 'core'
                    ? 'bg-[#3A3324] text-[#E2B05A] border border-[#E2B05A] shadow-sm'
                    : 'bg-[#171B19] text-[#B5AC9A] hover:bg-[#222722] hover:text-[#F2ECE1] border border-[#5A4B38]/40'
                }`}
              >
                Core Skills (3 Branches)
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('specialization')}
                className={`px-3 py-1.5 rounded-lg text-xs font-serif font-bold transition-colors flex items-center gap-1.5 ${
                  activeTab === 'specialization'
                    ? 'bg-[#3A3324] text-[#E2B05A] border border-[#E2B05A] shadow-sm'
                    : 'bg-[#171B19] text-[#B5AC9A] hover:bg-[#222722] hover:text-[#F2ECE1] border border-[#5A4B38]/40'
                }`}
              >
                <span>Specialization:</span>
                <span className="text-[#E2B05A]">{specDisplayName}</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('passives')}
                className={`px-3 py-1.5 rounded-lg text-xs font-serif font-bold transition-colors hidden md:block ${
                  activeTab === 'passives'
                    ? 'bg-[#3A3324] text-[#E2B05A] border border-[#E2B05A] shadow-sm'
                    : 'bg-[#171B19] text-[#B5AC9A] hover:bg-[#222722] hover:text-[#F2ECE1] border border-[#5A4B38]/40'
                }`}
              >
                Class Mastery Passives
              </button>

              <button
                type="button"
                data-testid="warrior-audit-tab-btn"
                onClick={() => {
                  setSelectedClass('warrior');
                  setActiveTab('warrior_audit');
                  if (!WARRIOR_ANIMATION_REGISTRY[selectedSkillId as WarriorSkillId]) {
                    setSelectedSkillId('sundering_strike');
                  }
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-serif font-bold transition-colors cursor-pointer ${
                  activeTab === 'warrior_audit'
                    ? 'bg-[#3A3324] text-[#E2B05A] border border-[#E2B05A] shadow-sm'
                    : 'bg-[#171B19] text-[#E0C785] hover:bg-[#222722] hover:text-[#F2ECE1] border border-[#856E37]/60'
                }`}
              >
                Warrior 12-Skill Audit &amp; Trial
              </button>

              <button
                type="button"
                data-testid="mage-audit-tab-btn"
                onClick={() => {
                  setSelectedClass('mage');
                  setActiveTab('mage_audit');
                  setSelectedSkillId('infernal_orb');
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-serif font-bold transition-colors cursor-pointer ${
                  activeTab === 'mage_audit'
                    ? 'bg-[#3A3324] text-[#E2B05A] border border-[#E2B05A] shadow-sm'
                    : 'bg-[#171B19] text-[#C785E0] hover:bg-[#222722] hover:text-[#F2ECE1] border border-[#5B3E75]/60'
                }`}
              >
                Mage 12-Skill Audit &amp; Trial
              </button>
            </nav>
          </div>

          {/* Right: Character Info, SP & Close Button */}
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-3">
              <div className="text-right hidden sm:block">
                <div className="text-xs font-serif font-bold text-[#F2ECE1]">
                  {commanderName.toUpperCase()} • <span className="capitalize">{selectedClass}</span>
                </div>
                <div className="text-[10px] font-mono text-[#B5AC9A]">
                  Level {progressionState.level} • {specDisplayName}
                </div>
              </div>

              {/* Live Skill Points Banner */}
              <div className="flex items-center gap-1.5 px-3 py-1 bg-[#1A1F1B] rounded-lg border border-[#E2B05A]/60 shadow-sm">
                <span className="text-xs font-mono font-bold text-[#E2B05A]">✦</span>
                <span className="text-xs font-mono font-bold text-[#E2B05A]">
                  {progressionState.unspentSkillPoints} SP
                </span>
              </div>
            </div>

            <button
              type="button"
              onClick={onClose}
              title="Close Skill Archive [ESC / K]"
              className="px-3 py-1.5 rounded-lg bg-[#222722] hover:bg-[#3A3324] border border-[#5A4B38] text-xs font-bold text-[#B5AC9A] hover:text-[#E2B05A] transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <span>✕</span>
              <span className="font-mono text-[10px] hidden sm:inline">[ESC]</span>
            </button>
          </div>
        </header>

        {/* =================================================================== */}
        {/* MAIN BODY: 3 COLUMNS (Left Nav, Center Tree, Right Details)         */}
        {/* =================================================================== */}
        <div className="flex-1 flex overflow-hidden">

          {/* ----------------------------------------------------------------- */}
          {/* 2. LEFT NAVIGATION PANEL                                          */}
          {/* ----------------------------------------------------------------- */}
          <aside className="w-56 sm:w-60 bg-[rgba(22,28,24,0.95)] border-r border-[#5A4B38] flex flex-col p-3.5 shrink-0 overflow-y-auto space-y-4">
            {/* Search Input */}
            <div>
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search abilities..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-[#111613] border border-[#5A4B38] rounded-md pl-2.5 pr-7 py-1.5 text-xs text-[#F2ECE1] placeholder-[#77796F] focus:outline-none focus:border-[#E2B05A]"
                />
                {searchQuery.length > 0 && (
                  <button
                    type="button"
                    onClick={() => setSearchQuery('')}
                    className="absolute right-2 top-1.5 text-xs text-[#77796F] hover:text-[#F2ECE1]"
                  >
                    ✕
                  </button>
                )}
              </div>
            </div>

            {/* Compact Class List */}
            <div>
              <div className="text-[10px] font-serif font-bold uppercase tracking-wider text-[#B5AC9A] mb-1.5">
                Class Discipline
              </div>
              <div className="space-y-1">
                {(['warrior', 'paladin', 'mage', 'rogue', 'ranger'] as const).map((cls) => {
                  const isCurrent = activeClassKey === cls;
                  const isSelected = selectedClass === cls;
                  return (
                    <button
                      key={cls}
                      type="button"
                      onClick={() => setSelectedClass(cls)}
                      className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-md text-xs font-serif transition-colors text-left cursor-pointer ${
                        isSelected
                          ? 'bg-[#3A3324] text-[#E2B05A] border border-[#E2B05A] font-bold shadow-sm'
                          : 'bg-[#171B19] text-[#B5AC9A] hover:bg-[#222722] hover:text-[#F2ECE1] border border-[#5A4B38]/40'
                      }`}
                    >
                      <span className="capitalize flex items-center gap-1.5">
                        {isCurrent && <span className="w-1.5 h-1.5 rounded-full bg-[#E2B05A]" />}
                        {cls}
                      </span>
                      {isCurrent ? (
                        <span className="text-[9px] font-mono text-[#E2B05A]">Active</span>
                      ) : (
                        <span className="text-[9px] font-mono text-[#77796F]">Preview</span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Skill Filters */}
            <div>
              <div className="flex items-center justify-between text-[10px] font-serif font-bold uppercase tracking-wider text-[#B5AC9A] mb-1.5">
                <span>Skill Filters</span>
                {(filterStatus !== 'all' || searchQuery.length > 0) && (
                  <button
                    type="button"
                    onClick={() => {
                      setFilterStatus('all');
                      setSearchQuery('');
                    }}
                    className="text-[9px] text-[#E2B05A] hover:underline cursor-pointer"
                  >
                    Reset
                  </button>
                )}
              </div>
              <div className="space-y-1">
                {(
                  [
                    { key: 'all', label: 'All Skills', count: filterCounts.all },
                    { key: 'available', label: 'Available', count: filterCounts.available },
                    { key: 'learned', label: 'Learned', count: filterCounts.learned },
                    { key: 'equipped', label: 'Equipped', count: filterCounts.equipped },
                    { key: 'locked', label: 'Locked', count: filterCounts.locked },
                  ] as const
                ).map(({ key, label, count }) => (
                  <button
                    key={key}
                    type="button"
                    onClick={() => setFilterStatus(key)}
                    className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded text-xs transition-colors cursor-pointer ${
                      filterStatus === key
                        ? 'bg-[#2B271B] text-[#E2B05A] border border-[#E2B05A]/70 font-bold'
                        : 'bg-[#171B19]/60 text-[#B5AC9A] hover:bg-[#222722] hover:text-[#F2ECE1] border border-[#5A4B38]/30'
                    }`}
                  >
                    <span>{label}</span>
                    <span
                      className={`text-[10px] font-mono px-1.5 py-0.2 rounded ${
                        filterStatus === key
                          ? 'bg-[#E2B05A]/20 text-[#E2B05A]'
                          : 'bg-[#111613] text-[#77796F]'
                      }`}
                    >
                      {count}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </aside>

          {/* ----------------------------------------------------------------- */}
          {/* 3. CENTRAL SKILL TREE PANEL (Scrolls independently)               */}
          {/* ----------------------------------------------------------------- */}
          <main className="flex-1 bg-[#111613] p-4 sm:p-6 overflow-y-auto">
            {activeTab === 'core' && (
              <div className="h-full flex flex-col space-y-4">
                {/* Tree Subheader */}
                <div className="border-b border-[#5A4B38]/60 pb-2 flex items-center justify-between">
                  <div>
                    <h2 className="font-serif font-bold text-base text-[#E2B05A] tracking-wide">
                      {selectedClass.toUpperCase()} CORE DISCIPLINES
                    </h2>
                    <p className="text-xs text-[#B5AC9A]">
                      Three structured combat branches. Advance through tiers by level and skill points.
                    </p>
                  </div>
                  <div className="text-xs font-mono text-[#B5AC9A]">
                    Learned:{' '}
                    <strong className="text-[#E2B05A]">
                      {coreBranches
                        .flatMap((b) => b.skills)
                        .filter((s) => progressionState.learnedSkillIds.includes(s.id)).length}
                    </strong>{' '}
                    / 12
                  </div>
                </div>

                {/* 3 or 4 Visually Separated Branches */}
                <div
                  className={`grid grid-cols-1 md:grid-cols-2 ${
                    coreBranches.length === 4 ? 'lg:grid-cols-4' : 'lg:grid-cols-3'
                  } gap-5 pt-2`}
                >
                  {coreBranches.map((branch) => (
                    <div
                      key={branch.id}
                      className={`flex flex-col ${branch.accentBg} border ${branch.accentBorder} rounded-xl p-3.5 space-y-4`}
                    >
                      {/* Branch Header with restrained accent */}
                      <div className="border-b border-[#5A4B38]/40 pb-2 text-center">
                        <h3 className={`font-serif font-bold text-xs tracking-wider ${branch.accentText}`}>
                          {branch.name}
                        </h3>
                        <div className="text-[10px] text-[#F2ECE1] font-semibold mt-0.5">
                          {branch.subtitle}
                        </div>
                        <p className="text-[10px] text-[#B5AC9A]/80 mt-1 leading-snug">
                          {branch.focus}
                        </p>
                      </div>

                      {/* Branch Nodes Vertical Progression Ladder with Connecting Lines */}
                      <div className="flex flex-col items-center space-y-1 py-1">
                        {branch.skills.map((skill, idx) => (
                          <React.Fragment key={skill.id}>
                            {renderSquareSkillNode(skill)}
                            {idx < branch.skills.length - 1 && (
                              <div className="flex items-center justify-center my-1">
                                <div
                                  className={`w-0.5 h-6 transition-colors ${
                                    progressionState.learnedSkillIds.includes(skill.id)
                                      ? 'bg-[#E2B05A]'
                                      : 'bg-[#333830]'
                                  }`}
                                />
                              </div>
                            )}
                          </React.Fragment>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'specialization' && (
              <div className="max-w-2xl mx-auto space-y-4">
                <div className="border-b border-[#5A4B38]/60 pb-3 flex items-center justify-between">
                  <div>
                    <h2 className="font-serif font-bold text-lg text-[#E2B05A]">
                      {specDisplayName.toUpperCase()} SPECIALIZATION
                    </h2>
                    <p className="text-xs text-[#B5AC9A] mt-1">
                      Sworn advanced specialization path granting exclusive tier-locked tactical abilities.
                    </p>
                  </div>
                  <span className="text-xs px-2.5 py-1 rounded bg-[#E2B05A]/20 text-[#E2B05A] border border-[#E2B05A]/50 font-bold font-serif">
                    Sworn Path
                  </span>
                </div>

                <div className="flex flex-col items-center space-y-1 py-3 bg-[#141815] border border-[#5A4B38]/60 rounded-xl p-5">
                  {specializationSkills.map((skill, idx) => (
                    <React.Fragment key={skill.id}>
                      {renderSquareSkillNode(skill)}
                      {idx < specializationSkills.length - 1 && (
                        <div className="flex items-center justify-center my-1">
                          <div
                            className={`w-0.5 h-6 transition-colors ${
                              progressionState.learnedSkillIds.includes(skill.id)
                                ? 'bg-[#E2B05A]'
                                : 'bg-[#333830]'
                            }`}
                          />
                        </div>
                      )}
                    </React.Fragment>
                  ))}
                </div>
              </div>
            )}

            {activeTab === 'passives' && (
              <div className="max-w-3xl mx-auto space-y-5">
                <div className="border-b border-[#5A4B38]/60 pb-2">
                  <h2 className="font-serif font-bold text-base text-[#E2B05A]">
                    CLASS MASTERY MILESTONES
                  </h2>
                  <p className="text-xs text-[#B5AC9A] mt-1">
                    Select permanent specialization masteries at character levels 5, 10, 15, and 20.
                  </p>
                </div>

                {([5, 10, 15, 20] as const).map((milestone) => {
                  const unlockedChoiceId = progressionState.unlockedMasteries[milestone];
                  const isAvailable = progressionState.level >= milestone;
                  const allChoices = CLASS_MASTERY_CHOICES[milestone] ?? [];
                  const classChoices = allChoices.filter((c) => c.classKey === selectedClass);

                  return (
                    <div
                      key={milestone}
                      className={`p-3.5 rounded-xl border ${
                        isAvailable ? 'bg-[#181C19] border-[#5A4B38]' : 'bg-[#111613] border-[#2A2E29] opacity-60'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <span
                            className={`w-6 h-6 flex items-center justify-center rounded-full font-bold text-xs ${
                              isAvailable ? 'bg-[#E2B05A] text-[#111613]' : 'bg-[#292E29] text-[#77796F]'
                            }`}
                          >
                            {milestone}
                          </span>
                          <span className="font-serif font-bold text-sm text-[#F2ECE1]">
                            Tier {milestone === 5 ? 'I' : milestone === 10 ? 'II' : milestone === 15 ? 'III' : 'IV'} Milestone (Level {milestone})
                          </span>
                        </div>
                        {!isAvailable && (
                          <span className="text-[11px] text-[#B85349] font-mono">Requires Lv {milestone}</span>
                        )}
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
                        {classChoices.map((choice) => {
                          const isChosen = unlockedChoiceId === choice.id;
                          return (
                            <div
                              key={choice.id}
                              className={`p-3 rounded-lg border text-left flex flex-col justify-between ${
                                isChosen
                                  ? 'bg-[#3A3324] border-[#E2B05A] ring-1 ring-[#E2B05A]'
                                  : 'bg-[#141815] border-[#5A4B38]/50'
                              }`}
                            >
                              <div>
                                <h4 className="font-serif font-bold text-xs text-[#E2B05A]">{choice.title}</h4>
                                <div className="text-[10px] text-[#7E9C82] font-mono mb-1">{choice.tagline}</div>
                                <p className="text-[11px] text-[#B5AC9A] leading-relaxed mb-2">{choice.description}</p>
                              </div>
                              {isChosen ? (
                                <div className="text-[10px] text-center font-bold text-[#E2B05A] py-1">✓ Active Path</div>
                              ) : (
                                <button
                                  type="button"
                                  disabled={!isAvailable}
                                  onClick={() => handleSelectMastery(milestone, choice.id)}
                                  className={`w-full py-1 rounded text-[11px] font-bold ${
                                    isAvailable
                                      ? 'bg-[#E2B05A] hover:bg-[#F7E3A6] text-[#111613] cursor-pointer'
                                      : 'bg-[#222722] text-[#77796F] cursor-not-allowed'
                                  }`}
                                >
                                  Select Path
                                </button>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {activeTab === 'warrior_audit' && (
              <div className="space-y-5">
                {/* Part VIII Combat Test Encounter Launcher */}
                <div className="p-4 rounded-xl bg-[#221A13] border border-[#E2B05A]/60 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                  <div>
                    <div className="text-[10px] font-mono uppercase tracking-widest text-[#E2B05A]">
                      Part VI · VII · VIII Verification Suite
                    </div>
                    <h2 className="font-serif font-bold text-base text-[#F2ECE1] mt-0.5">
                      WARRIOR CORE SKILL FAMILY (12 SKILLS) — ICON, ANIMATION &amp; COMBAT AUDIT
                    </h2>
                    <p className="text-xs text-[#B5AC9A] mt-0.5">
                      Inspect all 12 Warrior icons across 64px–24px gameplay scales, scrub 6-phase rig animations, or launch the dedicated 12-skill tactical test encounter.
                    </p>
                  </div>
                  {onLaunchWarriorTrialGrounds && (
                    <button
                      type="button"
                      data-testid="launch-warrior-trial-btn"
                      onClick={onLaunchWarriorTrialGrounds}
                      className="px-4 py-2.5 rounded-lg bg-[#E2B05A] hover:bg-[#F7E3A6] text-[#111613] font-serif font-bold text-xs shadow-lg transition-colors shrink-0 cursor-pointer"
                    >
                      ⚔ Launch Warrior Trial Grounds
                    </button>
                  )}
                </div>

                {/* Part VI: Multi-Scale Icon Audit Gallery (64x64, 48x48, 32x32, 24x24) */}
                <div className="p-4 rounded-xl bg-[#161B18] border border-[#5A4B38]/70 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#5A4B38]/50 pb-2">
                    <div>
                      <h3 className="font-serif font-bold text-xs uppercase tracking-wider text-[#E2B05A]">
                        Part VI — 12-Skill Icon Readability Gallery (64px · 48px · 32px · 24px)
                      </h3>
                      <p className="text-[11px] text-[#B5AC9A]">
                        Click any Warrior skill card to inspect its mechanical rules and scrub its 6-phase animation timeline.
                      </p>
                    </div>
                    <div className="flex items-center gap-1.5">
                      {(['available', 'selected', 'cooldown', 'disabled'] as const).map((st) => (
                        <button
                          key={st}
                          type="button"
                          onClick={() => setAuditIconPreviewState(st)}
                          className={`px-2.5 py-1 rounded text-[10px] font-mono uppercase cursor-pointer border ${
                            auditIconPreviewState === st
                              ? 'bg-[#3A3324] text-[#E2B05A] border-[#E2B05A] font-bold'
                              : 'bg-[#111613] text-[#B5AC9A] border-[#5A4B38]/40'
                          }`}
                        >
                          {st}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                    {Object.values(ALL_SKILLS_DATABASE)
                      .filter((s) => s.classKey === 'warrior' && !s.specializationKey)
                      .map((skill) => {
                        const isSel = selectedSkillId === skill.id;
                        const animCfg = WARRIOR_ANIMATION_REGISTRY[skill.id as WarriorSkillId];
                        return (
                          <div
                            key={skill.id}
                            data-testid={`audit-card-${skill.id}`}
                            onClick={() => {
                              setSelectedSkillId(skill.id);
                              if (animCfg) setAuditAnimElapsed(animCfg.impactTiming);
                            }}
                            className={`p-3 rounded-lg border transition-all cursor-pointer ${
                              isSel
                                ? 'bg-[#2B2418] border-[#E2B05A] ring-1 ring-[#E2B05A]'
                                : 'bg-[#111613] border-[#5A4B38]/50 hover:border-[#E2B05A]/60'
                            }`}
                          >
                            <div className="flex items-center justify-between mb-2">
                              <span className="font-serif font-bold text-xs text-[#F2ECE1]">
                                {skill.name}
                              </span>
                              <span className="text-[10px] font-mono text-[#E2B05A]">
                                {skill.apCost} AP · CD {skill.cooldown}T · R{skill.range}
                              </span>
                            </div>

                            {/* Multi-Resolution Row: 64px, 48px, 32px, 24px */}
                            <div className="flex flex-wrap items-end justify-between gap-1.5 py-1.5 px-2 rounded bg-[#0C0F0D] border border-[#333830]">
                              {(
                                [
                                  { size: 64, cls: 'w-14 h-14' },
                                  { size: 48, cls: 'w-11 h-11' },
                                  { size: 32, cls: 'w-8 h-8' },
                                  { size: 24, cls: 'w-6 h-6' },
                                ] as const
                              ).map(({ size, cls }) => (
                                <div key={size} className="flex flex-col items-center gap-1">
                                  <div
                                    className={`relative ${cls} rounded overflow-hidden border ${
                                      auditIconPreviewState === 'selected'
                                        ? 'border-[#E2B05A] ring-2 ring-[#E2B05A]'
                                        : auditIconPreviewState === 'disabled'
                                        ? 'border-[#333830] grayscale opacity-45'
                                        : auditIconPreviewState === 'cooldown'
                                        ? 'border-[#5A4B38] brightness-50'
                                        : 'border-[#5A4B38]'
                                    }`}
                                  >
                                    <SkillIconSvg
                                      skillId={skill.id}
                                      skillName={skill.name}
                                      className="w-full h-full object-cover"
                                    />
                                    {auditIconPreviewState === 'cooldown' && size >= 32 && (
                                      <div className="absolute inset-0 bg-black/60 flex items-center justify-center text-[10px] font-mono font-bold text-[#E2B05A]">
                                        2T
                                      </div>
                                    )}
                                  </div>
                                  <span className="text-[9px] font-mono text-[#77796F]">
                                    {size}px
                                  </span>
                                </div>
                              ))}
                            </div>

                            <div className="mt-2 text-[10px] text-[#B5AC9A] line-clamp-2">
                              {skill.centralMechanic}
                            </div>
                          </div>
                        );
                      })}
                  </div>
                </div>

                {/* Part VII: Interactive 6-Phase Animation Timeline & Rig Pose Inspector */}
                {(() => {
                  const activeWarriorId: WarriorSkillId = WARRIOR_ANIMATION_REGISTRY[
                    selectedSkillId as WarriorSkillId
                  ]
                    ? (selectedSkillId as WarriorSkillId)
                    : 'sundering_strike';
                  const cfg = WARRIOR_ANIMATION_REGISTRY[activeWarriorId];
                  const clampedElapsed = Math.min(cfg.totalDuration, Math.max(0, auditAnimElapsed));
                  const sampled = sampleWarriorRigTransform(activeWarriorId, clampedElapsed);
                  const currentPhase = sampled.phase;

                  return (
                    <div className="p-4 rounded-xl bg-[#161B18] border border-[#5A4B38]/70 space-y-3">
                      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#5A4B38]/50 pb-2">
                        <div>
                          <h3 className="font-serif font-bold text-xs uppercase tracking-wider text-[#E2B05A]">
                            Part VII — Animation Timeline &amp; Rig Pose Inspector:{' '}
                            <span className="text-[#F2ECE1]">{ALL_SKILLS_DATABASE[activeWarriorId]?.name}</span>
                          </h3>
                          <p className="text-[11px] text-[#B5AC9A]">
                            Animation ID: <code className="text-[#E2B05A]">{cfg.animationId}</code> · Total Duration:{' '}
                            <strong className="text-[#F2ECE1]">{cfg.totalDuration.toFixed(2)}s</strong> · Contact/Impact:{' '}
                            <strong className="text-[#7E9C82]">{cfg.impactTiming.toFixed(2)}s</strong>
                          </p>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => setAuditAnimElapsed(cfg.anticipationDuration * 0.5)}
                            className="px-2 py-1 rounded bg-[#111613] hover:bg-[#2B2418] border border-[#5A4B38] text-[10px] font-mono text-[#B5AC9A] cursor-pointer"
                          >
                            1. Wind-up ({(cfg.anticipationDuration * 0.5).toFixed(2)}s)
                          </button>
                          <button
                            type="button"
                            onClick={() => setAuditAnimElapsed(cfg.impactTiming)}
                            className="px-2 py-1 rounded bg-[#2B2418] hover:bg-[#3A3324] border border-[#E2B05A] text-[10px] font-mono text-[#E2B05A] font-bold cursor-pointer"
                          >
                            2. Contact/Impact ({cfg.impactTiming.toFixed(2)}s)
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              setAuditAnimElapsed(
                                cfg.anticipationDuration +
                                  cfg.executionDuration +
                                  cfg.recoveryDuration * 0.5
                              )
                            }
                            className="px-2 py-1 rounded bg-[#111613] hover:bg-[#2B2418] border border-[#5A4B38] text-[10px] font-mono text-[#B5AC9A] cursor-pointer"
                          >
                            3. Follow-through / Recovery
                          </button>
                          <button
                            type="button"
                            onClick={() => setAuditAnimElapsed(cfg.totalDuration + 0.05)}
                            className="px-2 py-1 rounded bg-[#162118] hover:bg-[#1E2E21] border border-[#7E9C82] text-[10px] font-mono text-[#7E9C82] cursor-pointer"
                          >
                            Interrupt / Reset to Idle
                          </button>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <span className="text-[11px] font-mono text-[#B5AC9A] w-24">
                          Time: {clampedElapsed.toFixed(2)}s
                        </span>
                        <input
                          type="range"
                          min={0}
                          max={cfg.totalDuration + 0.05}
                          step={0.01}
                          value={auditAnimElapsed}
                          onChange={(e) => setAuditAnimElapsed(parseFloat(e.target.value))}
                          className="flex-1 accent-[#E2B05A]"
                        />
                        <span className="px-2.5 py-0.5 rounded bg-[#2B2418] border border-[#E2B05A] text-[10px] font-mono font-bold uppercase text-[#E2B05A]">
                          Phase: {currentPhase}
                        </span>
                      </div>

                      <div className="space-y-3">
                        {/* Task 4: Pure Skeletal Audit Silhouette (Particles, Trails, Lighting & Overlays Disabled) */}
                        {(() => {
                          const [bx, by, bz] = sampled.transform.bodyPos;
                          const [rx, ry, rz] = sampled.transform.bodyRot;
                          const [wx, wy, wz] = sampled.transform.weaponPos;
                          const [wrx, wry, wrz] = sampled.transform.weaponRot;
                          const sx = sampled.transform.shieldPos?.[0] ?? 0.18;
                          const sy = sampled.transform.shieldPos?.[1] ?? 0;
                          const sz = sampled.transform.shieldPos?.[2] ?? 0.15;
                          const lLeg = sampled.transform.leftLegRot?.[0] ?? 0;
                          const rLeg = sampled.transform.rightLegRot?.[0] ?? 0;

                          const hipX = 110 + (bx + bz * 0.65) * 70;
                          const hipY = 92 - by * 85;
                          const torsoAngle = rx * 0.85 + rz * 0.35;
                          const shoulderX = hipX + Math.sin(torsoAngle) * 34;
                          const shoulderY = hipY - Math.cos(torsoAngle) * 34;
                          const headX = shoulderX + Math.sin(torsoAngle) * 12;
                          const headY = shoulderY - Math.cos(torsoAngle) * 12;

                          const lFootX = hipX - 10 + Math.sin(lLeg) * 26;
                          const lFootY = Math.min(126, hipY + Math.cos(lLeg) * 28);
                          const rFootX = hipX + 10 + Math.sin(rLeg) * 26;
                          const rFootY = Math.min(126, hipY + Math.cos(rLeg) * 28);

                          const handX = shoulderX + (wx + wz * 0.8) * 65 + Math.cos(ry) * 10;
                          const handY = shoulderY - wy * 65;
                          const bladeAngle = wrx + torsoAngle + wrz * 0.5;
                          const tipX = handX + Math.sin(bladeAngle + 0.6) * 42;
                          const tipY = handY - Math.cos(bladeAngle + 0.6) * 42;

                          const shieldX = shoulderX + (sx + sz * 0.7) * 55;
                          const shieldY = shoulderY - sy * 55 + 6;

                          return (
                            <div
                              data-testid="pure-skeletal-audit-view"
                              className="p-3 rounded-lg bg-[#0C0F0D] border border-[#5A4B38]/80 flex flex-col sm:flex-row items-center gap-4"
                            >
                              <svg
                                viewBox="0 0 220 136"
                                className="w-48 h-28 shrink-0 rounded bg-[#111613] border border-[#333830]"
                                aria-label={`Pure Skeletal Rig Pose for ${ALL_SKILLS_DATABASE[activeWarriorId]?.name}`}
                              >
                                {/* Ground reference line */}
                                <line x1="16" y1="126" x2="204" y2="126" stroke="#333830" strokeWidth="1.5" strokeDasharray="3 3" />
                                {/* Rotation / 360-spin indicator on floor */}
                                <ellipse
                                  cx={hipX}
                                  cy={126}
                                  rx={18 + Math.abs(Math.sin(ry)) * 10}
                                  ry="4"
                                  fill="none"
                                  stroke="#5A4B38"
                                  strokeWidth="1.2"
                                />
                                {/* Left & Right Legs */}
                                <line x1={hipX} y1={hipY} x2={lFootX} y2={lFootY} stroke="#B5AC9A" strokeWidth="3" strokeLinecap="round" />
                                <line x1={hipX} y1={hipY} x2={rFootX} y2={rFootY} stroke="#F2ECE1" strokeWidth="3.5" strokeLinecap="round" />
                                {/* Spine / Torso */}
                                <line x1={hipX} y1={hipY} x2={shoulderX} y2={shoulderY} stroke="#F2ECE1" strokeWidth="4.5" strokeLinecap="round" />
                                {/* Head */}
                                <circle cx={headX} cy={headY} r="7" fill="#111613" stroke="#F2ECE1" strokeWidth="2.5" />
                                {/* Shield Arm & Shield Plane (Wireframe only, zero VFX) */}
                                <line x1={shoulderX} y1={shoulderY} x2={shieldX} y2={shieldY} stroke="#7E9C82" strokeWidth="2.5" />
                                <rect
                                  x={shieldX - 5}
                                  y={shieldY - 11}
                                  width="10"
                                  height="22"
                                  rx="2"
                                  fill="none"
                                  stroke="#7E9C82"
                                  strokeWidth="2"
                                />
                                {/* Weapon Arm & Greatsword Bone */}
                                <line x1={shoulderX} y1={shoulderY} x2={handX} y2={handY} stroke="#E2B05A" strokeWidth="3" strokeLinecap="round" />
                                <line x1={handX} y1={handY} x2={tipX} y2={tipY} stroke="#E2B05A" strokeWidth="3.5" strokeLinecap="round" />
                                <circle cx={handX} cy={handY} r="3" fill="#E2B05A" />
                              </svg>
                              <div className="flex-1 text-xs font-mono space-y-1.5 text-[#B5AC9A]">
                                <div className="inline-block px-2 py-0.5 rounded bg-[#162118] border border-[#7E9C82]/50 text-[#7E9C82] font-bold uppercase text-[10px]">
                                  Pure Skeletal Audit Mode — VFX / Trails / Overlays: OFF
                                </div>
                                <div className="flex flex-wrap gap-x-6 gap-y-1 text-[11px]">
                                  <span className="text-[#F2ECE1] font-bold">
                                    Locomotion: <span className="text-[#E2B05A]">{cfg.movementBehavior}</span>
                                  </span>
                                  <span>
                                    Facing: <span className="text-[#F2ECE1]">{cfg.targetFacingBehavior}</span>
                                  </span>
                                </div>
                                <div className="text-[11px] text-[#B5AC9A] leading-snug">
                                  {cfg.combatEventSync}
                                </div>
                              </div>
                            </div>
                          );
                        })()}

                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] font-mono">
                          <div className="p-2 rounded bg-[#111613] border border-[#333830]">
                            <div className="text-[9px] text-[#77796F] uppercase">Body Offset (X,Y,Z)</div>
                            <div className="text-[#F2ECE1] mt-0.5">
                              [{sampled.transform.bodyPos.map((n) => n.toFixed(2)).join(', ')}]
                            </div>
                          </div>
                          <div className="p-2 rounded bg-[#111613] border border-[#333830]">
                            <div className="text-[9px] text-[#77796F] uppercase">Body Rotation (P,Y,R)</div>
                            <div className="text-[#F2ECE1] mt-0.5">
                              [{sampled.transform.bodyRot.map((n) => n.toFixed(2)).join(', ')}]
                            </div>
                          </div>
                          <div className="p-2 rounded bg-[#111613] border border-[#333830]">
                            <div className="text-[9px] text-[#77796F] uppercase">Weapon Offset (X,Y,Z)</div>
                            <div className="text-[#E2B05A] mt-0.5">
                              [{sampled.transform.weaponPos.map((n) => n.toFixed(2)).join(', ')}]
                            </div>
                          </div>
                          <div className="p-2 rounded bg-[#111613] border border-[#333830]">
                            <div className="text-[9px] text-[#77796F] uppercase">Weapon Rotation (P,Y,R)</div>
                            <div className="text-[#7E9C82] mt-0.5">
                              [{sampled.transform.weaponRot.map((n) => n.toFixed(2)).join(', ')}]
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })()}
              </div>
            )}

            {activeTab === 'mage_audit' && (
              <div className="space-y-5">
                {/* Part IX Combat Test Encounter Launcher */}
                <div className="p-4 rounded-xl bg-[#1E1627] border border-[#A855F7]/60 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                  <div>
                    <div className="text-[10px] font-mono uppercase tracking-widest text-[#C785E0]">
                      Phase 2 · Official Implementation Verification Suite
                    </div>
                    <h2 className="font-serif font-bold text-base text-[#F2ECE1] mt-0.5">
                      MAGE CORE SKILL FAMILY (12 SKILLS) — ICON, ANIMATION &amp; COMBAT AUDIT
                    </h2>
                    <p className="text-xs text-[#B5AC9A] mt-0.5">
                      Inspect all 12 Mage icons across 64px–24px gameplay scales, scrub 6-phase rig animations, or launch the dedicated 12-skill tactical test encounter.
                    </p>
                  </div>
                  {onLaunchMageTrialGrounds && (
                    <button
                      type="button"
                      data-testid="launch-mage-trial-btn"
                      onClick={onLaunchMageTrialGrounds}
                      className="px-4 py-2.5 rounded-lg bg-[#A855F7] hover:bg-[#C084FC] text-[#111613] font-serif font-bold text-xs shadow-lg transition-colors shrink-0 cursor-pointer"
                    >
                      ⚡ Launch Mage Trial Grounds
                    </button>
                  )}
                </div>

                {/* Multi-Scale Icon Audit Gallery (64x64, 48x48, 32x32, 24x24) */}
                <div className="p-4 rounded-xl bg-[#161B18] border border-[#5A4B38]/70 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#5A4B38]/50 pb-2">
                    <div>
                      <h3 className="font-serif font-bold text-xs uppercase tracking-wider text-[#C785E0]">
                        Phase 2 — 12-Skill Icon Readability Gallery (64px · 48px · 32px · 24px)
                      </h3>
                      <p className="text-[11px] text-[#B5AC9A]">
                        Click any Mage skill card to inspect its mechanical rules and scrub its 6-phase animation timeline.
                      </p>
                    </div>
                    <div className="flex items-center gap-1.5">
                      {(['available', 'selected', 'cooldown', 'disabled'] as const).map((st) => (
                        <button
                          key={st}
                          type="button"
                          onClick={() => setAuditIconPreviewState(st)}
                          className={`px-2.5 py-1 rounded text-[10px] font-mono uppercase cursor-pointer border ${
                            auditIconPreviewState === st
                              ? 'bg-[#3A2440] text-[#C785E0] border-[#A855F7] font-bold'
                              : 'bg-[#111613] text-[#B5AC9A] border-[#5A4B38]/40'
                          }`}
                        >
                          {st}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                    {Object.values(ALL_SKILLS_DATABASE)
                      .filter((s) => s.classKey === 'mage' && !s.specializationKey)
                      .map((skill) => {
                        const isSel = selectedSkillId === skill.id;
                        const animCfg = MASTER_ANIMATION_REGISTRY[skill.id];
                        return (
                          <div
                            key={skill.id}
                            data-testid={`audit-card-${skill.id}`}
                            onClick={() => {
                              setSelectedSkillId(skill.id);
                              if (animCfg) setAuditAnimElapsed(animCfg.impactTiming);
                            }}
                            className={`p-3 rounded-lg border transition-all cursor-pointer ${
                              isSel
                                ? 'bg-[#2E1E3B] border-[#A855F7] ring-1 ring-[#A855F7]'
                                : 'bg-[#111613] border-[#5A4B38]/50 hover:border-[#A855F7]/60'
                            }`}
                          >
                            <div className="flex items-center justify-between mb-2">
                              <span className="font-serif font-bold text-xs text-[#F2ECE1]">
                                {skill.name}
                              </span>
                              <span className="text-[10px] font-mono text-[#C785E0]">
                                {skill.apCost} AP · CD {skill.cooldown}T · R{skill.range}
                              </span>
                            </div>

                            {/* Multi-Resolution Row: 64px, 48px, 32px, 24px */}
                            <div className="flex flex-wrap items-end justify-between gap-1.5 py-1.5 px-2 rounded bg-[#0C0F0D] border border-[#333830]">
                              {(
                                [
                                  { size: 64, cls: 'w-14 h-14' },
                                  { size: 48, cls: 'w-11 h-11' },
                                  { size: 32, cls: 'w-8 h-8' },
                                  { size: 24, cls: 'w-6 h-6' },
                                ] as const
                              ).map(({ size, cls }) => (
                                <div key={size} className="flex flex-col items-center gap-1">
                                  <div
                                    className={`relative ${cls} rounded overflow-hidden border ${
                                      auditIconPreviewState === 'selected'
                                        ? 'border-[#A855F7] ring-2 ring-[#A855F7]'
                                        : auditIconPreviewState === 'disabled'
                                        ? 'border-[#333830] grayscale opacity-45'
                                        : auditIconPreviewState === 'cooldown'
                                        ? 'border-[#5A4B38] brightness-50'
                                        : 'border-[#5A4B38]'
                                    }`}
                                  >
                                    <SkillIconSvg
                                      skillId={skill.id}
                                      skillName={skill.name}
                                      className="w-full h-full object-cover"
                                    />
                                    {auditIconPreviewState === 'cooldown' && size >= 32 && (
                                      <div className="absolute inset-0 bg-black/60 flex items-center justify-center text-[10px] font-mono font-bold text-[#C785E0]">
                                        {skill.cooldown}T
                                      </div>
                                    )}
                                  </div>
                                  <span className="text-[8px] font-mono text-[#77796F]">{size}px</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        );
                      })}
                  </div>
                </div>

                {/* Interactive 6-Phase Animation Timeline & Rig Pose Inspector */}
                {(() => {
                  const activeMageId = MASTER_ANIMATION_REGISTRY[selectedSkillId]
                    ? selectedSkillId
                    : 'infernal_orb';
                  const cfg = MASTER_ANIMATION_REGISTRY[activeMageId] || MASTER_ANIMATION_REGISTRY.infernal_orb;
                  const clampedElapsed = Math.min(cfg.totalDuration, Math.max(0, auditAnimElapsed));
                  const sampled = sampleMasterRigTransform(activeMageId, clampedElapsed);
                  const currentPhase = sampled.phase;

                  const [bx, by, bz] = sampled.transform.bodyPos;
                  const [rx, ry, rz] = sampled.transform.bodyRot;
                  const [wx, wy, wz] = sampled.transform.weaponPos;
                  const [wrx, wry, wrz] = sampled.transform.weaponRot;
                  const sx = sampled.transform.shieldPos?.[0] ?? -0.25;
                  const sy = sampled.transform.shieldPos?.[1] ?? 0.65;
                  const sz = sampled.transform.shieldPos?.[2] ?? 0.2;
                  const lLeg = sampled.transform.leftLegRot?.[0] ?? 0;
                  const rLeg = sampled.transform.rightLegRot?.[0] ?? 0;

                  const hipX = 110 + (bx + bz * 0.65) * 70;
                  const hipY = 92 - by * 85;
                  const torsoAngle = rx * 0.85 + rz * 0.35;
                  const shoulderX = hipX + Math.sin(torsoAngle) * 34;
                  const shoulderY = hipY - Math.cos(torsoAngle) * 34;
                  const headX = shoulderX + Math.sin(torsoAngle) * 12;
                  const headY = shoulderY - Math.cos(torsoAngle) * 12;

                  const lFootX = hipX - 10 + Math.sin(lLeg) * 26;
                  const lFootY = Math.min(126, hipY + Math.cos(lLeg) * 28);
                  const rFootX = hipX + 10 + Math.sin(rLeg) * 26;
                  const rFootY = Math.min(126, hipY + Math.cos(rLeg) * 28);

                  const handX = shoulderX + (wx + wz * 0.8) * 65 + Math.cos(ry) * 10;
                  const handY = shoulderY - wy * 65;
                  const staffAngle = wrx + torsoAngle + wrz * 0.5;
                  const staffTipX = handX + Math.sin(staffAngle + 0.5) * 50;
                  const staffTipY = handY - Math.cos(staffAngle + 0.5) * 50;
                  const staffBaseX = handX - Math.sin(staffAngle + 0.5) * 25;
                  const staffBaseY = handY + Math.cos(staffAngle + 0.5) * 25;

                  const orbX = shoulderX + (sx + sz * 0.7) * 55;
                  const orbY = shoulderY - sy * 55 + 6;

                  return (
                    <div className="p-4 rounded-xl bg-[#161B18] border border-[#5A4B38]/70 space-y-3">
                      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#5A4B38]/50 pb-2">
                        <div>
                          <h3 className="font-serif font-bold text-xs uppercase tracking-wider text-[#C785E0]">
                            Phase 2 — Animation Timeline &amp; Rig Pose Inspector:{' '}
                            <span className="text-[#F2ECE1]">{ALL_SKILLS_DATABASE[activeMageId]?.name}</span>
                          </h3>
                          <p className="text-[11px] text-[#B5AC9A]">
                            Animation ID: <code className="text-[#C785E0]">{cfg.animationId}</code> · Total Duration:{' '}
                            <strong className="text-[#F2ECE1]">{cfg.totalDuration.toFixed(2)}s</strong> · Contact/Impact:{' '}
                            <strong className="text-[#A855F7]">{cfg.impactTiming.toFixed(2)}s</strong>
                          </p>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => setAuditAnimElapsed(cfg.anticipationDuration * 0.5)}
                            className="px-2 py-1 rounded bg-[#111613] hover:bg-[#2B2418] border border-[#5A4B38] text-[10px] font-mono text-[#B5AC9A] cursor-pointer"
                          >
                            1. Wind-up ({(cfg.anticipationDuration * 0.5).toFixed(2)}s)
                          </button>
                          <button
                            type="button"
                            onClick={() => setAuditAnimElapsed(cfg.impactTiming)}
                            className="px-2 py-1 rounded bg-[#2B1731] hover:bg-[#3A2440] border border-[#A855F7] text-[10px] font-mono text-[#C785E0] font-bold cursor-pointer"
                          >
                            2. Contact/Impact ({cfg.impactTiming.toFixed(2)}s)
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              setAuditAnimElapsed(
                                cfg.anticipationDuration +
                                  cfg.executionDuration +
                                  cfg.recoveryDuration * 0.5
                              )
                            }
                            className="px-2 py-1 rounded bg-[#111613] hover:bg-[#2B2418] border border-[#5A4B38] text-[10px] font-mono text-[#B5AC9A] cursor-pointer"
                          >
                            3. Recovery
                          </button>
                          <button
                            type="button"
                            onClick={() => setAuditAnimElapsed(cfg.totalDuration + 0.05)}
                            className="px-2 py-1 rounded bg-[#162118] hover:bg-[#1E2E21] border border-[#7E9C82] text-[10px] font-mono text-[#7E9C82] cursor-pointer"
                          >
                            Reset to Idle
                          </button>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <span className="text-[11px] font-mono text-[#B5AC9A] w-24">
                          Time: {clampedElapsed.toFixed(2)}s
                        </span>
                        <input
                          type="range"
                          min={0}
                          max={cfg.totalDuration + 0.05}
                          step={0.01}
                          value={auditAnimElapsed}
                          onChange={(e) => setAuditAnimElapsed(parseFloat(e.target.value))}
                          className="flex-1 accent-[#A855F7]"
                        />
                        <span className="px-2.5 py-0.5 rounded bg-[#2B1731] border border-[#A855F7] text-[10px] font-mono font-bold uppercase text-[#C785E0]">
                          Phase: {currentPhase}
                        </span>
                      </div>

                      <div className="space-y-3">
                        {/* Pure Skeletal Audit Silhouette (Mage Rig: Staff + Floating Focus Orb) */}
                        <div
                          data-testid="pure-skeletal-audit-view"
                          className="p-3 rounded-lg bg-[#0C0F0D] border border-[#5A4B38]/80 flex flex-col sm:flex-row items-center gap-4"
                        >
                          <svg
                            viewBox="0 0 220 136"
                            className="w-48 h-28 shrink-0 rounded bg-[#111613] border border-[#333830]"
                            aria-label={`Pure Skeletal Rig Pose for ${ALL_SKILLS_DATABASE[activeMageId]?.name}`}
                          >
                            {/* Ground reference line */}
                            <line x1="16" y1="126" x2="204" y2="126" stroke="#333830" strokeWidth="1.5" strokeDasharray="3 3" />

                            {/* Left Leg Bone */}
                            <line x1={hipX - 6} y1={hipY} x2={lFootX} y2={lFootY} stroke="#94A3B8" strokeWidth="2.5" strokeLinecap="round" />
                            {/* Right Leg Bone */}
                            <line x1={hipX + 6} y1={hipY} x2={rFootX} y2={rFootY} stroke="#94A3B8" strokeWidth="2.5" strokeLinecap="round" />

                            {/* Pelvis / Hip Joint */}
                            <circle cx={hipX} cy={hipY} r="4" fill="#A855F7" />

                            {/* Spine / Torso Bone */}
                            <line x1={hipX} y1={hipY} x2={shoulderX} y2={shoulderY} stroke="#E2E8F0" strokeWidth="4" strokeLinecap="round" />
                            <circle cx={shoulderX} cy={shoulderY} r="3.5" fill="#A855F7" />

                            {/* Head Silhouette */}
                            <circle cx={headX} cy={headY} r="6" fill="#CBD5E1" stroke="#334155" strokeWidth="1" />

                            {/* Left Arm & Floating Arcane Focus Orb */}
                            <line x1={shoulderX - 4} y1={shoulderY + 2} x2={orbX} y2={orbY} stroke="#C084FC" strokeWidth="2" strokeDasharray="2 2" />
                            <circle cx={orbX} cy={orbY} r="5.5" fill="#A855F7" stroke="#F43F5E" strokeWidth="1.5" />

                            {/* Right Arm & Arcane Staff */}
                            <line x1={shoulderX + 4} y1={shoulderY} x2={handX} y2={handY} stroke="#C785E0" strokeWidth="2.5" strokeLinecap="round" />
                            <line x1={staffBaseX} y1={staffBaseY} x2={staffTipX} y2={staffTipY} stroke="#78350F" strokeWidth="3" strokeLinecap="round" />
                            {/* Astrolabe ring & crystal head */}
                            <circle cx={staffTipX} cy={staffTipY} r="5" fill="none" stroke="#E2B05A" strokeWidth="1.5" />
                            <circle cx={staffTipX} cy={staffTipY} r="2.5" fill="#F43F5E" />
                            <circle cx={handX} cy={handY} r="2.5" fill="#C785E0" />
                          </svg>

                          <div className="flex-1 text-xs font-mono space-y-1.5 text-[#B5AC9A]">
                            <div className="inline-block px-2 py-0.5 rounded bg-[#2B1731] border border-[#A855F7]/50 text-[#C785E0] font-bold uppercase text-[10px]">
                              Pure Skeletal Audit Mode — VFX / Trails / Overlays: OFF
                            </div>
                            <div className="flex flex-wrap gap-x-6 gap-y-1 text-[11px]">
                              <span className="text-[#F2ECE1] font-bold">
                                Rig: <span className="text-[#C785E0]">Arcane Staff + Floating Focus Orb</span>
                              </span>
                              <span>
                                Phase: <span className="text-[#F2ECE1] font-bold uppercase">{currentPhase}</span>
                              </span>
                            </div>
                            <div className="text-[11px] text-[#B5AC9A] leading-snug">
                              Procedural animation synchronized with combat damage resolution and cast audio.
                            </div>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] font-mono">
                          <div className="p-2 rounded bg-[#111613] border border-[#333830]">
                            <div className="text-[9px] text-[#77796F] uppercase">Body Offset (X,Y,Z)</div>
                            <div className="text-[#F2ECE1] mt-0.5">
                              [{sampled.transform.bodyPos.map((n) => n.toFixed(2)).join(', ')}]
                            </div>
                          </div>
                          <div className="p-2 rounded bg-[#111613] border border-[#333830]">
                            <div className="text-[9px] text-[#77796F] uppercase">Body Rotation (P,Y,R)</div>
                            <div className="text-[#F2ECE1] mt-0.5">
                              [{sampled.transform.bodyRot.map((n) => n.toFixed(2)).join(', ')}]
                            </div>
                          </div>
                          <div className="p-2 rounded bg-[#111613] border border-[#333830]">
                            <div className="text-[9px] text-[#77796F] uppercase">Staff Offset (X,Y,Z)</div>
                            <div className="text-[#C785E0] mt-0.5">
                              [{sampled.transform.weaponPos.map((n) => n.toFixed(2)).join(', ')}]
                            </div>
                          </div>
                          <div className="p-2 rounded bg-[#111613] border border-[#333830]">
                            <div className="text-[9px] text-[#77796F] uppercase">Staff Rotation (P,Y,R)</div>
                            <div className="text-[#A855F7] mt-0.5">
                              [{sampled.transform.weaponRot.map((n) => n.toFixed(2)).join(', ')}]
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })()}
              </div>
            )}
          </main>

          {/* ----------------------------------------------------------------- */}
          {/* 4. RIGHT SKILL DETAILS PANEL                                      */}
          {/* ----------------------------------------------------------------- */}
          <aside className="w-80 sm:w-96 bg-[rgba(22,28,24,0.98)] border-l border-[#5A4B38] flex flex-col p-5 shrink-0 overflow-y-auto space-y-4">
            {selectedSkill ? (
              <div className="flex flex-col h-full justify-between space-y-4">
                <div>
                  {/* Skill Header */}
                  <div className="flex items-start gap-3.5 border-b border-[#5A4B38]/60 pb-3">
                    <div className="w-14 h-14 shrink-0 rounded-lg overflow-hidden border-2 border-[#E2B05A] bg-[#111317] shadow-md flex items-center justify-center">
                      <SkillIconSvg skillId={selectedSkill.id} skillName={selectedSkill.name} className="w-14 h-14" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-serif font-bold text-base text-[#E2B05A] leading-tight">
                        {selectedSkill.name}
                      </h3>
                      <div className="text-[11px] text-[#B5AC9A] mt-1 capitalize font-medium">
                        <span>{selectedSkill.classKey}</span>
                        {selectedSkill.specializationKey && (
                          <span className="text-[#E2B05A]"> • {selectedSkill.specializationKey.replace(/_/g, ' ')}</span>
                        )}
                      </div>
                      <div className="flex items-center gap-1.5 mt-1.5">
                        <span className="text-[9px] font-bold px-2 py-0.5 rounded bg-[#171B19] border border-[#5A4B38] text-[#F2ECE1] uppercase">
                          {selectedSkill.isPassive ? 'Passive' : selectedSkill.category.replace(/_/g, ' ')}
                        </span>
                        <span className="text-[9px] font-bold px-2 py-0.5 rounded bg-[#3A3324] border border-[#E2B05A]/40 text-[#E2B05A] capitalize">
                          {selectedSkill.element}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* 4-Tile Stat Strip */}
                  {!selectedSkill.isPassive && (
                    <div className="grid grid-cols-4 gap-1.5 text-center py-2 my-2.5 bg-[#171B19] rounded-lg border border-[#5A4B38]/60 font-mono">
                      <div>
                        <div className="text-[9px] text-[#77796F] uppercase">AP Cost</div>
                        <div className="font-bold text-[#E2B05A] text-xs mt-0.5">{selectedSkill.apCost} AP</div>
                      </div>
                      <div>
                        <div className="text-[9px] text-[#77796F] uppercase">Cooldown</div>
                        <div className="font-bold text-[#F2ECE1] text-xs mt-0.5">
                          {selectedSkill.cooldown === 0 ? 'Instant' : `${selectedSkill.cooldown}T`}
                        </div>
                      </div>
                      <div>
                        <div className="text-[9px] text-[#77796F] uppercase">Range</div>
                        <div className="font-bold text-[#7E9C82] text-xs mt-0.5">
                          {selectedSkill.range === 1 ? 'Melee' : `${selectedSkill.range}`}
                        </div>
                      </div>
                      <div>
                        <div className="text-[9px] text-[#77796F] uppercase">Target</div>
                        <div className="font-bold text-[#B5AC9A] text-[10px] mt-0.5 capitalize">{selectedSkill.targetType}</div>
                      </div>
                    </div>
                  )}

                  {/* Requirements & Cost Strip */}
                  <div className="flex items-center justify-between text-xs font-mono bg-[#171B19] px-3 py-2 rounded-lg border border-[#5A4B38]/50 my-2">
                    <div>
                      <span className="text-[#77796F] text-[10px] block">Level Requirement:</span>
                      <strong
                        className={`text-xs ${
                          progressionState.level >= selectedSkill.minLevel ? 'text-[#7E9C82]' : 'text-[#B85349]'
                        }`}
                      >
                        Lv {selectedSkill.minLevel} {progressionState.level >= selectedSkill.minLevel ? '✓' : '🔒'}
                      </strong>
                    </div>
                    <div className="text-right">
                      <span className="text-[#77796F] text-[10px] block">Skill Point Cost:</span>
                      <strong className="text-xs text-[#E2B05A]">
                        {selectedSkill.skillPointCost} SP
                      </strong>
                    </div>
                  </div>

                  {/* Formulas, Status & Terrain */}
                  <div className="space-y-1.5 text-xs text-[#B5AC9A] bg-[#171B19] p-2.5 rounded-lg border border-[#5A4B38]/40 mb-2.5">
                    <div>
                      <span className="text-[#77796F] uppercase text-[9px] block">Damage / Effect Formula:</span>
                      <strong className="text-[#F2ECE1] font-mono text-xs">{selectedSkill.damageFormula}</strong>
                    </div>
                    <div>
                      <span className="text-[#77796F] uppercase text-[9px] block">Attribute Scaling:</span>
                      <strong className="text-[#E2B05A] font-mono text-xs">{selectedSkill.attributeScaling}</strong>
                    </div>
                    {selectedSkill.statusEffect && (
                      <div>
                        <span className="text-[#77796F] uppercase text-[9px] block">Status Applied:</span>
                        <span className="inline-block mt-0.5 px-2 py-0.5 rounded text-[10px] font-bold bg-[#B85349]/20 text-[#B85349] border border-[#B85349]/40 uppercase">
                          {selectedSkill.statusEffect}
                        </span>
                      </div>
                    )}
                    {selectedSkill.terrainInteraction && (
                      <div>
                        <span className="text-[#77796F] uppercase text-[9px] block">Terrain Interaction:</span>
                        <span className="text-[11px] text-[#7E9C82]">{selectedSkill.terrainInteraction}</span>
                      </div>
                    )}
                  </div>

                  {/* Tactical Purpose & Rules */}
                  <div className="space-y-2 text-xs leading-relaxed">
                    <div>
                      <h4 className="text-[10px] font-bold uppercase tracking-wider text-[#E2B05A] mb-1">
                        Tactical Purpose
                      </h4>
                      <p className="text-[#F2ECE1] bg-[#1B201C] p-2 rounded border border-[#5A4B38]/50">
                        {selectedSkill.tacticalExplanation}
                      </p>
                    </div>
                    <div>
                      <h4 className="text-[10px] font-bold uppercase tracking-wider text-[#B5AC9A] mb-1">
                        Description
                      </h4>
                      <p className="text-[#B5AC9A] bg-[#171B19] p-2 rounded border border-[#5A4B38]/40">
                        {selectedSkill.description}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Bottom Action Area: Unlock, Equip & Unequip */}
                <div className="pt-2 border-t border-[#5A4B38]/60 space-y-2">
                  {progressionState.learnedSkillIds.includes(selectedSkill.id) ? (
                    <div>
                      <div className="text-center text-xs text-[#7E9C82] font-bold mb-1.5 flex items-center justify-center gap-1">
                        <span>✓</span>
                        <span>LEARNED ABILITY</span>
                      </div>

                      {!selectedSkill.isPassive ? (
                        <div className="space-y-1.5">
                          <div className="text-[10px] text-[#B5AC9A] text-center">
                            Assign to Active Combat Loadout:
                          </div>
                          <div className="grid grid-cols-4 gap-1.5">
                            {([0, 1, 2, 3] as const).map((slotIdx) => {
                              const isCur = progressionState.equippedSkillIds[slotIdx] === selectedSkill.id;
                              return (
                                <button
                                  key={slotIdx}
                                  type="button"
                                  onClick={() => handleEquipSlot(slotIdx, selectedSkill.id)}
                                  title={isCur ? `Equipped in Slot ${slotIdx + 1} (Click to unequip)` : `Equip to Slot ${slotIdx + 1}`}
                                  className={`py-1.5 rounded text-xs font-bold transition-all border cursor-pointer ${
                                    isCur
                                      ? 'bg-[#E2B05A] text-[#111613] border-[#E2B05A] shadow-md ring-1 ring-[#F7E3A6]'
                                      : 'bg-[#171B19] hover:bg-[#3A3324] text-[#B5AC9A] hover:text-[#E2B05A] border-[#5A4B38]'
                                  }`}
                                >
                                  {isCur ? `✓ Slot ${slotIdx + 1}` : `Slot ${slotIdx + 1}`}
                                </button>
                              );
                            })}
                          </div>

                          {/* Unequip Button if Equipped */}
                          {progressionState.equippedSkillIds.includes(selectedSkill.id) && (
                            <button
                              type="button"
                              onClick={() => {
                                const sIdx = progressionState.equippedSkillIds.indexOf(selectedSkill.id);
                                if (sIdx !== -1) handleUnequipSlot(sIdx as 0 | 1 | 2 | 3);
                              }}
                              className="w-full py-1.5 rounded bg-[#171B19] hover:bg-[#B85349]/20 text-[#B85349] border border-[#B85349]/40 text-xs font-bold transition-colors cursor-pointer"
                            >
                              UNEQUIP SKILL
                            </button>
                          )}
                        </div>
                      ) : (
                        <div className="text-center text-xs text-[#7E9C82] bg-[#7E9C82]/10 py-1.5 rounded border border-[#7E9C82]/30">
                          PERMANENT PASSIVE (ALWAYS ACTIVE)
                        </div>
                      )}
                    </div>
                  ) : (
                    <div>
                      {progressionState.level < selectedSkill.minLevel ? (
                        <button
                          type="button"
                          disabled
                          className="w-full py-2.5 rounded-lg bg-[#171B19] text-[#77796F] border border-[#5A4B38]/50 text-xs font-bold cursor-not-allowed text-center"
                        >
                          LOCKED — LEVEL REQUIREMENT NOT MET (Lv {selectedSkill.minLevel})
                        </button>
                      ) : progressionState.unspentSkillPoints < selectedSkill.skillPointCost ? (
                        <button
                          type="button"
                          disabled
                          className="w-full py-2.5 rounded-lg bg-[#171B19] text-[#B85349] border border-[#B85349]/40 text-xs font-bold cursor-not-allowed text-center"
                        >
                          NOT ENOUGH SKILL POINTS ({progressionState.unspentSkillPoints} / {selectedSkill.skillPointCost})
                        </button>
                      ) : (
                        <button
                          type="button"
                          data-testid="unlock-skill-button"
                          onClick={() => handleUnlockSkill(selectedSkill.id)}
                          className="w-full py-2.5 rounded-lg bg-[#E2B05A] hover:bg-[#F7E3A6] text-[#111613] font-bold text-xs shadow-lg hover:shadow-xl transition-all cursor-pointer text-center uppercase tracking-wide"
                        >
                          UNLOCK SKILL — {selectedSkill.skillPointCost} POINT
                        </button>
                      )}
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-center h-full text-xs text-[#77796F] italic">
                Select an ability from the tree to view its complete tactical profile.
              </div>
            )}
          </aside>
        </div>

        {/* =================================================================== */}
        {/* 5. BOTTOM EQUIPPED SKILLS (Visible at all times without covering)   */}
        {/* =================================================================== */}
        <footer className="h-16 px-6 bg-[rgba(17,22,19,0.98)] border-t border-[#5A4B38] flex items-center justify-between shrink-0">
          <div className="flex items-center gap-4">
            <span className="text-[11px] font-serif font-bold uppercase tracking-wider text-[#E2B05A]">
              Equipped Combat Loadout (4 Slots):
            </span>
            <div className="flex items-center gap-2">
              {([0, 1, 2, 3] as const).map((slotIdx) => {
                const skillId = progressionState.equippedSkillIds[slotIdx];
                const skill = ALL_SKILLS_DATABASE[skillId];
                return (
                  <div
                    key={slotIdx}
                    className="relative group"
                  >
                    <button
                      type="button"
                      onClick={() => {
                        if (skill) {
                          setSelectedSkillId(skill.id);
                        } else if (
                          selectedSkill &&
                          progressionState.learnedSkillIds.includes(selectedSkill.id) &&
                          !selectedSkill.isPassive
                        ) {
                          handleEquipSlot(slotIdx, selectedSkill.id);
                        }
                      }}
                      className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border text-left transition-all cursor-pointer ${
                        skill
                          ? 'bg-[#1D221F] hover:bg-[#28302B] border-[#5A4B38] text-[#F2ECE1]'
                          : 'bg-[#141815] border-[#2A2E29] border-dashed text-[#77796F] hover:border-[#5A4B38]'
                      }`}
                    >
                      <span className="w-5 h-5 flex items-center justify-center rounded bg-[#111613] text-[#E2B05A] font-mono text-xs font-bold border border-[#5A4B38]/60">
                        {slotIdx + 1}
                      </span>
                      {skill ? (
                        <div className="flex items-center gap-2">
                          <div className="w-6 h-6 shrink-0 rounded overflow-hidden">
                            <SkillIconSvg skillId={skill.id} skillName={skill.name} className="w-6 h-6" />
                          </div>
                          <span className="text-xs font-bold text-[#F2ECE1] max-w-[110px] truncate">
                            {skill.name}
                          </span>
                          <span className="text-[10px] font-mono text-[#E2B05A]">
                            {skill.apCost} AP
                          </span>
                        </div>
                      ) : (
                        <span className="text-xs text-[#77796F] italic">Empty Slot</span>
                      )}
                    </button>

                    {/* Quick Unequip Button */}
                    {skill && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleUnequipSlot(slotIdx);
                        }}
                        title="Unequip Slot"
                        className="absolute -top-1.5 -right-1.5 w-4 h-4 rounded-full bg-[#111613] border border-[#B85349] text-[#B85349] hover:bg-[#B85349] hover:text-[#fff] text-[10px] flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        ✕
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs text-[#B5AC9A]">
            <span className="text-[#77796F]">Hotkeys:</span>
            <span className="px-1.5 py-0.5 rounded bg-[#171B19] border border-[#5A4B38] font-mono text-[11px]">
              [1-4] Quick Equip
            </span>
            <span className="px-1.5 py-0.5 rounded bg-[#171B19] border border-[#5A4B38] font-mono text-[11px]">
              [K / ESC] Close
            </span>
          </div>
        </footer>

        {/* Inline Feedback Toast */}
        {feedbackToast && (
          <div className="absolute bottom-20 left-1/2 -translate-x-1/2 bg-[#171B19] border border-[#E2B05A] text-[#F2ECE1] px-4 py-2 rounded-lg text-xs font-bold shadow-2xl flex items-center gap-2 z-50 animate-fade-in">
            <span className="text-[#E2B05A]">✦</span>
            <span>{feedbackToast}</span>
          </div>
        )}

      </div>
    </div>
  );
};
