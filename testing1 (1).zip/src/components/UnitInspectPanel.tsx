import React from 'react';
import {
  CombatUnit,
  CompanionId,
  CompanionRelationship,
  WorldReactivityState,
  buildUnitInspectProfile,
} from '../game/rules';
import {
  CharacterPortraitSvg,
  StatusEffectIconSvg,
  STATUS_EFFECT_META,
} from './PortraitsAndIcons';
import { SkillIconSvg } from './SkillIcons';

interface UnitInspectPanelProps {
  unit: CombatUnit;
  allUnits: CombatUnit[];
  relationships: Record<CompanionId, CompanionRelationship>;
  worldState: WorldReactivityState;
  onSelectUnit: (unitId: string) => void;
  onClose: () => void;
}

export const UnitInspectPanel: React.FC<UnitInspectPanelProps> = ({
  unit,
  allUnits,
  relationships,
  worldState,
  onSelectUnit,
  onClose,
}) => {
  const profile = buildUnitInspectProfile(unit, relationships, worldState);
  const livingUnits = allUnits.filter((u) => !u.isKO);
  const hpPct = Math.max(0, Math.min(100, Math.round((profile.hp / profile.maxHp) * 100)));

  return (
    <aside
      role="dialog"
      aria-modal="false"
      aria-labelledby="unit-inspect-heading"
      data-testid="unit-inspect-panel"
      className="fixed top-16 right-4 bottom-36 z-30 w-full max-w-[430px] rounded-xl border border-amber-500/45 shadow-2xl flex flex-col overflow-hidden pointer-events-auto"
      style={{ backgroundColor: 'rgba(13, 11, 21, 0.97)' }}
    >
      {/* Top Bar: Codex Title + Close [I] / [Esc] */}
      <div
        className="px-4 py-2.5 border-b border-amber-500/30 flex items-center justify-between gap-2 shrink-0"
        style={{ backgroundColor: 'rgba(20, 16, 32, 0.98)' }}
      >
        <div className="flex items-center gap-2 whitespace-nowrap">
          <span className="text-[11px] font-mono uppercase tracking-widest text-amber-400">
            Unit Inspection
          </span>
          <span aria-hidden="true" className="text-stone-600">
            ·
          </span>
          <span className="text-[11px] font-mono text-stone-400">Key [I]</span>
        </div>
        <button
          type="button"
          data-testid="close-inspect-panel-btn"
          onClick={onClose}
          className="px-2.5 py-1 rounded border border-stone-700 hover:border-amber-400 text-xs font-mono text-stone-200 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
        >
          Close [I / Esc]
        </button>
      </div>

      {/* Unit Switcher Strip (Inspect Any Living Party Companion or Enemy) */}
      <div className="px-3.5 py-2 border-b border-stone-800/90 flex items-center gap-1.5 overflow-x-auto shrink-0">
        <span className="text-[10px] font-mono uppercase tracking-wider text-stone-400 mr-0.5 shrink-0">
          Units:
        </span>
        {livingUnits.map((u) => {
          const isInspected = u.id === unit.id;
          return (
            <button
              key={u.id}
              type="button"
              data-testid={`inspect-select-${u.id}`}
              onClick={() => onSelectUnit(u.id)}
              title={`Inspect ${u.name}`}
              className={`flex items-center gap-1.5 px-2 py-1 rounded border text-xs transition-colors shrink-0 cursor-pointer ${
                isInspected
                  ? 'border-amber-400 bg-amber-500/25 text-amber-100 font-semibold'
                  : u.faction === 'party'
                  ? 'border-stone-700/90 bg-stone-900/90 text-stone-300 hover:border-amber-400/60'
                  : 'border-rose-900/70 bg-rose-950/50 text-rose-200 hover:border-rose-400/60'
              }`}
            >
              <CharacterPortraitSvg
                id={u.companionId ?? u.archetype ?? 'inquisitor'}
                className="w-5 h-5 rounded shrink-0"
              />
              <span className="whitespace-nowrap">{u.name.split(' ')[0]}</span>
            </button>
          );
        })}
      </div>

      {/* Scrollable Body */}
      <div className="p-3.5 overflow-y-auto space-y-3.5 flex-1">
        {/* 1. Unit Identity, Vitality & Combat Readiness */}
        <section className="rounded-lg border border-stone-800 p-3 bg-stone-950/80 space-y-2.5">
          <div className="flex items-start gap-3">
            <div className="relative shrink-0">
              <CharacterPortraitSvg
                id={unit.companionId ?? unit.archetype ?? 'inquisitor'}
                className={`w-14 h-14 rounded-lg border ${
                  profile.faction === 'party' ? 'border-amber-400/70' : 'border-rose-500/70'
                }`}
              />
              {unit.statuses.length > 0 && (
                <div
                  className="absolute -bottom-1.5 -right-1.5 flex items-center gap-0.5 px-1 py-0.5 rounded border border-stone-700 shadow"
                  style={{ backgroundColor: 'rgba(10, 8, 16, 0.95)' }}
                >
                  {unit.statuses.map((s, idx) => (
                    <StatusEffectIconSvg
                      key={`${s.type}-${idx}`}
                      type={s.type}
                      turnsLeft={s.turnsLeft}
                      className="w-3.5 h-3.5"
                    />
                  ))}
                </div>
              )}
            </div>

            <div className="min-w-0 flex-1">
              <h2
                id="unit-inspect-heading"
                data-testid="inspect-unit-name"
                className="text-base font-display font-bold text-amber-100 whitespace-nowrap"
              >
                {profile.name}
              </h2>

              <p className="text-xs font-medium mt-0.5">
                <span className="text-amber-300/95">{profile.title}</span>
                <span aria-hidden="true" className="text-stone-600 mx-1.5">
                  ·
                </span>
                <span
                  className={`font-mono text-[11px] uppercase tracking-wider ${
                    profile.faction === 'party' ? 'text-emerald-300' : 'text-rose-400'
                  }`}
                >
                  {profile.faction === 'party' ? 'Party Companion' : 'Adversary'}
                </span>
              </p>
              <p className="text-[11px] text-stone-400 font-mono mt-0.5">
                {profile.roleSummary} · {profile.positionLabel} · {profile.elevationLabel}
              </p>
            </div>
          </div>

          {/* Vitality Bar & Combat Metrics */}
          <div className="space-y-1.5 pt-1">
            <div className="flex items-baseline justify-between text-xs font-mono">
              <span className="text-stone-400 uppercase tracking-wider">Vitality (HP)</span>
              <span className="font-bold text-amber-200 tabular-nums">
                {profile.hp} / {profile.maxHp} HP ({hpPct}%)
              </span>
            </div>
            <div className="w-full h-2 rounded-full bg-stone-900 border border-stone-700 overflow-hidden">
              <div
                className={`h-full transition-all duration-150 ${
                  profile.faction === 'party' ? 'bg-emerald-500' : 'bg-rose-500'
                }`}
                style={{ width: `${hpPct}%` }}
              />
            </div>
          </div>

          {/* 4-Cell Combat Parameters (AC, AP, Move, Initiative) */}
          <div className="grid grid-cols-4 gap-2 pt-1 text-left">
            <div className="p-2 rounded border border-stone-800 bg-stone-900/70">
              <p className="text-[10px] font-mono uppercase text-stone-400">Armor Class</p>
              <p
                data-testid="inspect-effective-ac"
                className="text-sm font-mono font-bold text-amber-200 tabular-nums mt-0.5"
              >
                {profile.effectiveAC} AC
              </p>
            </div>
            <div className="p-2 rounded border border-stone-800 bg-stone-900/70">
              <p className="text-[10px] font-mono uppercase text-stone-400">Action Pts</p>
              <p className="text-sm font-mono font-bold text-sky-300 tabular-nums mt-0.5">
                {profile.ap}/{profile.maxAp} AP
              </p>
            </div>
            <div className="p-2 rounded border border-stone-800 bg-stone-900/70">
              <p className="text-[10px] font-mono uppercase text-stone-400">Move Range</p>
              <p className="text-sm font-mono font-bold text-emerald-300 tabular-nums mt-0.5">
                {profile.moveRange} Tiles
              </p>
            </div>
            <div className="p-2 rounded border border-stone-800 bg-stone-900/70">
              <p className="text-[10px] font-mono uppercase text-stone-400">Initiative</p>
              <p className="text-sm font-mono font-bold text-stone-200 tabular-nums mt-0.5">
                +{profile.initiative}
              </p>
            </div>
          </div>

          {/* Armor Class & Attack Roll Formula Breakdown */}
          <div className="pt-1 border-t border-stone-800/80 space-y-1 text-[11px] font-mono">
            <div className="flex items-center justify-between text-stone-300">
              <span className="text-stone-400">Defense Formula:</span>
              <span className="text-amber-200">{profile.acBreakdown}</span>
            </div>
            <div className="flex items-center justify-between text-stone-300 gap-2">
              <span className="text-stone-400 shrink-0">Attack Roll:</span>
              <span
                data-testid="inspect-attack-formula"
                className="text-emerald-300 truncate text-right"
                title={profile.attackRollFormula}
              >
                {profile.attackRollFormula}
              </span>
            </div>
            <div className="flex items-center justify-between text-stone-300">
              <span className="text-stone-400">Critical Threat:</span>
              <span className="text-amber-300">Natural {profile.critRangeLabel} (2x Base Dice)</span>
            </div>
          </div>
        </section>

        {/* 2. Core Attributes & Modifiers (STR, DEX, INT, CHA) */}
        <section className="space-y-2">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-mono uppercase tracking-wider text-amber-300">
              Core Attributes &amp; D20 Modifiers
            </h3>
            <span className="text-[11px] font-mono text-stone-400">
              Primary: {profile.primaryStatLabel}
            </span>
          </div>

          <div
            data-testid="inspect-stats-grid"
            className="grid grid-cols-4 gap-2"
          >
            {profile.stats.map((st) => (
              <div
                key={st.key}
                data-testid={`inspect-stat-${st.key}`}
                className={`p-2.5 rounded-lg border text-center ${
                  st.isPrimary
                    ? 'border-amber-400/70 bg-amber-500/15'
                    : 'border-stone-800 bg-stone-950/80'
                }`}
              >
                <p className="text-[10px] font-mono uppercase tracking-wider text-stone-400">
                  {st.label} {st.isPrimary ? '★' : ''}
                </p>
                <p className="text-base font-mono font-bold text-amber-100 tabular-nums mt-0.5">
                  {st.score}
                </p>
                <p
                  className={`text-xs font-mono font-semibold tabular-nums ${
                    st.modifier >= 0 ? 'text-emerald-300' : 'text-rose-400'
                  }`}
                >
                  {st.formattedModifier} Mod
                </p>
              </div>
            ))}
          </div>

          {profile.companionBondLabel && (
            <div className="p-2.5 rounded-lg border border-amber-500/30 bg-stone-950/90 text-xs space-y-0.5">
              <div className="flex items-center justify-between font-mono">
                <span className="text-stone-400">Companion Bond:</span>
                <span className="text-amber-300 font-semibold">{profile.companionBondLabel}</span>
              </div>
              <p className="text-[11px] text-stone-300 font-mono">
                {profile.companionSynergySummary}
              </p>
            </div>
          )}
        </section>

        {/* 3. Active Status Effects */}
        <section className="space-y-2">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-mono uppercase tracking-wider text-amber-300">
              Active Status Effects ({profile.statuses.length})
            </h3>
          </div>

          {profile.statuses.length === 0 ? (
            <div
              data-testid="inspect-statuses-empty"
              className="p-3 rounded-lg border border-stone-800/80 bg-stone-950/60 text-xs text-stone-400 font-mono"
            >
              No active status effects — unit is operating at baseline condition.
            </div>
          ) : (
            <div data-testid="inspect-statuses-list" className="space-y-2">
              {profile.statuses.map((st, idx) => {
                const meta = STATUS_EFFECT_META[st.type] ?? STATUS_EFFECT_META.blessed;
                return (
                  <div
                    key={`${st.type}-${idx}`}
                    data-testid={`inspect-status-item-${st.type}`}
                    className={`p-2.5 rounded-lg border flex items-start gap-2.5 ${meta.borderColor}`}
                    style={{ backgroundColor: meta.bgColor }}
                  >
                    <StatusEffectIconSvg
                      type={st.type}
                      turnsLeft={st.turnsLeft}
                      className="w-5 h-5 shrink-0 mt-0.5"
                    />
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between gap-2">
                        <span className={`text-xs font-display font-bold ${meta.textColor}`}>
                          {st.label}
                        </span>
                        <span className="text-[11px] font-mono tabular-nums text-stone-300">
                          {st.turnsLeft} {st.turnsLeft === 1 ? 'Turn' : 'Turns'} Left
                        </span>
                      </div>
                      <p className="text-[11px] text-stone-200 mt-0.5">{st.mechanicalEffect}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>

        {/* 4. Full Ability Descriptions & Damage Dice Formulas */}
        <section className="space-y-2.5">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-mono uppercase tracking-wider text-amber-300">
              Abilities &amp; Damage Dice Formulas ({profile.abilities.length})
            </h3>
          </div>

          <div data-testid="inspect-abilities-list" className="space-y-2.5">
            {profile.abilities.map((ab) => (
              <div
                key={ab.id}
                data-testid={`inspect-ability-card-${ab.id}`}
                className="p-3 rounded-lg border border-stone-800 bg-stone-950/90 space-y-2"
              >
                {/* Header: Individual Skill Icon + Name + Key + Cost / Range / Cooldown */}
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-start gap-2.5 min-w-0">
                    <SkillIconSvg
                      skillId={ab.id}
                      skillName={ab.name}
                      className="w-9 h-9 rounded-md border border-amber-500/40 bg-stone-900 p-1 mt-0.5"
                    />
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-mono font-bold text-amber-400">
                          [{ab.key}]
                        </span>
                        <h4 className="text-sm font-display font-bold text-amber-100 truncate">
                          {ab.name}
                        </h4>
                      </div>
                      <p className="text-[11px] font-mono text-stone-400 mt-0.5">
                        {ab.element} · {ab.apCost} AP · Range {ab.range}
                        {ab.aoeRadius ? ` · AoE Radius ${ab.aoeRadius}` : ''}
                        {ab.pushDistance > 0 ? ` · Push ${ab.pushDistance}` : ''}
                        {ab.pullDistance && ab.pullDistance > 0 ? ` · Pull ${ab.pullDistance}` : ''}
                        {ab.statusEffect
                          ? ` · Inflicts ${
                              STATUS_EFFECT_META[ab.statusEffect]?.label ?? ab.statusEffect
                            }`
                          : ''}
                      </p>
                    </div>
                  </div>

                  <span
                    className={`text-[11px] font-mono tabular-nums shrink-0 ${
                      ab.cooldownRemaining > 0 ? 'text-rose-400' : 'text-emerald-300'
                    }`}
                  >
                    {ab.cooldownRemaining > 0
                      ? `Cooldown (${ab.cooldownRemaining}t)`
                      : ab.cooldown > 0
                      ? `Ready (${ab.cooldown}t CD)`
                      : 'Ready (At-Will)'}
                  </span>
                </div>

                {/* Unique Central Mechanic Callout */}
                {ab.uniqueMechanicLabel && (
                  <div className="px-2 py-1 rounded border border-amber-500/25 bg-amber-500/10 text-[11px] font-mono text-amber-200">
                    ★ {ab.uniqueMechanicLabel}
                  </div>
                )}

                {/* Full Ability Description */}
                <p className="text-xs text-stone-200 leading-relaxed">{ab.description}</p>

                {/* Explicit Dice Formula & Attack Roll Box */}
                <div className="p-2 rounded border border-amber-500/30 bg-stone-900/90 space-y-1 font-mono text-[11px]">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-stone-400 shrink-0">Dice Formula:</span>
                    <span
                      data-testid={`inspect-ability-formula-${ab.id}`}
                      className="text-amber-300 font-semibold text-right"
                    >
                      {ab.diceFormula} → {ab.effectiveOutputLabel}
                    </span>
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-stone-400 shrink-0">Hit Check:</span>
                    <span className="text-stone-300 truncate text-right" title={ab.attackRollFormula}>
                      {ab.attackRollFormula}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </aside>
  );
};
