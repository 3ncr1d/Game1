import React, { useEffect, useRef } from 'react';
import { CharacterRaceId } from '../game/rules';

export type ArchetypeClassId = 'warrior' | 'mage' | 'rogue' | 'paladin' | 'ranger';

export interface CharacterAppearanceConfig {
  bodyType: 'Slender' | 'Athletic' | 'Stout' | 'Towering';
  facePreset: 'Noble' | 'Weathered' | 'Serene' | 'Fierce';
  facialStructure: 'Angular' | 'Soft' | 'High Cheekbones' | 'Square Jaw';
  skinTone: string;
  hairStyle: 'Braided Crown' | 'Long Flowing' | 'Cropped Crest' | 'Swept Back' | 'Shorn';
  hairColor: string;
  eyeColor: string;
  facialHair:
    | 'Clean-Shaven'
    | 'Trimmed Beard'
    | 'Braided Mustache'
    | 'Goatee'
    | 'Full Ranger Beard';
  scarsAndMarkings:
    | 'None'
    | 'Brow Slash'
    | 'Cheek Duel Scar'
    | 'Ritual Ash Mark'
    | 'Starlight Brand';
  tattoos: 'None' | 'Runic Brow' | 'Sylvan Vine' | 'Covenant Sigil' | 'Ashen Woad';
  accessories:
    | 'None'
    | 'Bronze Circlet'
    | 'Silver Ear Cuff'
    | 'Cloak Clasp'
    | 'Ranger Eyepatch';
}

interface CharacterPixelPreviewCanvasProps {
  raceId: CharacterRaceId;
  archetypeClass: ArchetypeClassId;
  appearance: CharacterAppearanceConfig;
  silhouetteOnly?: boolean;
  className?: string;
}

/**
 * Renders an animated 2D pixel-art RPG character sprite on a pedestal
 * with race-distinct silhouettes (Half-Elf ears, Tiefling horns & tail,
 * Wood-Kin antlers/leaf-crest, Astral Human noble posture), full appearance
 * customization, and class-specific armor & weaponry.
 */
export const CharacterPixelPreviewCanvas: React.FC<CharacterPixelPreviewCanvasProps> = ({
  raceId,
  archetypeClass,
  appearance,
  silhouetteOnly = false,
  className = '',
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const W = 96;
    const H = 120;
    canvas.width = W;
    canvas.height = H;
    ctx.imageSmoothingEnabled = false;

    let animId = 0;
    let lastTime = performance.now();
    let elapsedSeconds = 0;

    // Helper to tint all colors to dark silhouette when on Welcome screen
    const col = (hex: string, silhouetteHex = '#1f2823') =>
      silhouetteOnly ? silhouetteHex : hex;

    const render = () => {
      const now = performance.now();
      const dt = Math.min(0.05, (now - lastTime) / 1000);
      lastTime = now;
      elapsedSeconds += dt;
      // Normalizes tick to a consistent 60fps baseline regardless of 60Hz-360Hz refresh rate
      const tick = elapsedSeconds * 60;
      ctx.clearRect(0, 0, W, H);

      // Subtle atmospheric aura & stone pedestal
      const pulse = 0.5 + 0.5 * Math.sin(tick * 0.04);
      ctx.fillStyle = silhouetteOnly
        ? 'rgba(226, 176, 90, 0.06)'
        : 'rgba(226, 176, 90, 0.09)';
      ctx.fillRect(22, 18, 52, 82);

      // Isometric stone pedestal base
      ctx.fillStyle = '#252b27';
      ctx.fillRect(22, 98, 52, 6);
      ctx.fillStyle = '#343b36';
      ctx.fillRect(26, 95, 44, 4);
      ctx.fillStyle = '#5A4B38';
      ctx.fillRect(26, 95, 44, 1);

      // Ground shadow under character
      ctx.fillStyle = 'rgba(8, 10, 9, 0.55)';
      ctx.fillRect(30, 94, 36, 3);

      // Body proportions based on bodyType
      const widthMod =
        appearance.bodyType === 'Stout'
          ? 2
          : appearance.bodyType === 'Slender'
          ? -1
          : appearance.bodyType === 'Towering'
          ? 1
          : 0;
      const heightMod =
        appearance.bodyType === 'Towering'
          ? -4
          : appearance.bodyType === 'Stout'
          ? 3
          : 0;

      // Idle breathing offset (1px vertical bob every ~50 frames)
      const breatheY = Math.sin(tick * 0.06) > 0.35 ? 1 : 0;
      const capeSway = Math.sin(tick * 0.05) > 0 ? 1 : 0;

      const cx = 48;
      const headY = 28 + heightMod + breatheY;
      const torsoY = headY + 15;
      const legsY = torsoY + 24;

      // Class palette
      const classArmorColors: Record<
        ArchetypeClassId,
        { primary: string; secondary: string; trim: string; cape: string }
      > = {
        warrior: {
          primary: '#4a5259',
          secondary: '#69362c',
          trim: '#b89352',
          cape: '#592922',
        },
        paladin: {
          primary: '#737982',
          secondary: '#2d4259',
          trim: '#e2b05a',
          cape: '#8c6d32',
        },
        mage: {
          primary: '#2c334d',
          secondary: '#4a2e52',
          trim: '#c99e52',
          cape: '#23273d',
        },
        rogue: {
          primary: '#262b29',
          secondary: '#3b322b',
          trim: '#7e9c82',
          cape: '#1c211f',
        },
        ranger: {
          primary: '#2f4232',
          secondary: '#4d3a2b',
          trim: '#9c8554',
          cape: '#243326',
        },
      };
      const armor = classArmorColors[archetypeClass];

      // 1. CAPE / CLOAK BEHIND CHARACTER
      ctx.fillStyle = col(armor.cape, '#18201c');
      ctx.fillRect(
        cx - 11 - widthMod,
        torsoY + 1,
        22 + widthMod * 2 + capeSway,
        36 - heightMod
      );

      // 2. TIEFLING TAIL (Distinct racial silhouette feature)
      if (raceId === 'tiefling') {
        const tailWag = Math.round(Math.sin(tick * 0.07) * 1.5);
        ctx.fillStyle = col(appearance.skinTone, '#242e28');
        ctx.fillRect(cx + 10 + widthMod, torsoY + 18, 6, 3);
        ctx.fillRect(cx + 14 + widthMod, torsoY + 14 + tailWag, 4, 5);
        ctx.fillRect(cx + 16 + widthMod, torsoY + 11 + tailWag, 4, 3);
      }

      // 3. LEGS & BOOTS
      ctx.fillStyle = col('#2b2622');
      ctx.fillRect(cx - 7 - Math.floor(widthMod / 2), legsY, 6, 18 - heightMod);
      ctx.fillRect(cx + 1 + Math.floor(widthMod / 2), legsY, 6, 18 - heightMod);

      // Greaves / Boots
      ctx.fillStyle = col(armor.secondary);
      ctx.fillRect(cx - 8 - Math.floor(widthMod / 2), 84, 7, 11);
      ctx.fillRect(cx + 1 + Math.floor(widthMod / 2), 84, 7, 11);
      ctx.fillStyle = col(armor.trim);
      ctx.fillRect(cx - 8 - Math.floor(widthMod / 2), 84, 7, 1);
      ctx.fillRect(cx + 1 + Math.floor(widthMod / 2), 84, 7, 1);

      // 4. TORSO & CLASS ARMOR
      const torsoW = 18 + widthMod * 2;
      ctx.fillStyle = col(armor.primary);
      ctx.fillRect(cx - Math.floor(torsoW / 2), torsoY, torsoW, 24);

      // Pauldrons / Shoulders
      ctx.fillStyle = col(armor.secondary);
      ctx.fillRect(cx - Math.floor(torsoW / 2) - 4, torsoY, 5, 8);
      ctx.fillRect(cx + Math.floor(torsoW / 2) - 1, torsoY, 5, 8);
      ctx.fillStyle = col(armor.trim);
      ctx.fillRect(cx - Math.floor(torsoW / 2) - 4, torsoY, 5, 2);
      ctx.fillRect(cx + Math.floor(torsoW / 2) - 1, torsoY, 5, 2);

      // Chest Trim / Tabard / Belt
      ctx.fillStyle = col(armor.secondary);
      ctx.fillRect(cx - 4, torsoY + 2, 8, 20);
      ctx.fillStyle = col(armor.trim);
      ctx.fillRect(cx - Math.floor(torsoW / 2), torsoY + 18, torsoW, 2);
      ctx.fillRect(cx - 2, torsoY + 17, 4, 4);

      // Cloak Clasp Accessory
      if (appearance.accessories === 'Cloak Clasp') {
        ctx.fillStyle = col('#e2b05a');
        ctx.fillRect(cx - 3, torsoY + 1, 6, 3);
      }

      // 5. ARMS & HANDS
      ctx.fillStyle = col(armor.primary);
      ctx.fillRect(cx - Math.floor(torsoW / 2) - 4, torsoY + 8, 4, 12);
      ctx.fillRect(cx + Math.floor(torsoW / 2), torsoY + 8, 4, 12);
      ctx.fillStyle = col(appearance.skinTone);
      ctx.fillRect(cx - Math.floor(torsoW / 2) - 4, torsoY + 20, 4, 4);
      ctx.fillRect(cx + Math.floor(torsoW / 2), torsoY + 20, 4, 4);

      // 6. HEAD & FACIAL STRUCTURE
      const headW =
        appearance.facialStructure === 'Square Jaw'
          ? 14
          : appearance.facialStructure === 'Angular'
          ? 12
          : 13;
      const headX = cx - Math.floor(headW / 2);

      // Neck
      ctx.fillStyle = col(appearance.skinTone);
      ctx.fillRect(cx - 3, headY + 12, 6, 4);

      // Face base
      ctx.fillStyle = col(appearance.skinTone);
      ctx.fillRect(headX, headY, headW, 13);
      if (appearance.facialStructure === 'High Cheekbones') {
        ctx.fillRect(headX - 1, headY + 4, headW + 2, 4);
      }

      // RACE-SPECIFIC EARS / HORNS / ANTLERS (Unique Silhouettes)
      if (raceId === 'half_elf') {
        // Long pointed elven ears
        ctx.fillStyle = col(appearance.skinTone, '#242e28');
        ctx.fillRect(headX - 4, headY + 4, 4, 2);
        ctx.fillRect(headX - 5, headY + 3, 2, 1);
        ctx.fillRect(headX + headW, headY + 4, 4, 2);
        ctx.fillRect(headX + headW + 3, headY + 3, 2, 1);
      } else if (raceId === 'tiefling') {
        // Swept-back curved horns
        ctx.fillStyle = col('#382924', '#26302a');
        ctx.fillRect(headX - 2, headY - 4, 3, 5);
        ctx.fillRect(headX - 4, headY - 8, 3, 5);
        ctx.fillRect(headX + headW - 1, headY - 4, 3, 5);
        ctx.fillRect(headX + headW + 1, headY - 8, 3, 5);
        // Pointed ears
        ctx.fillStyle = col(appearance.skinTone);
        ctx.fillRect(headX - 2, headY + 5, 2, 2);
        ctx.fillRect(headX + headW, headY + 5, 2, 2);
      } else if (raceId === 'wood_kin') {
        // Sylvan bark-antler crest & long wild ears
        ctx.fillStyle = col('#5e4934', '#26302a');
        ctx.fillRect(headX - 1, headY - 6, 2, 6);
        ctx.fillRect(headX - 3, headY - 8, 2, 3);
        ctx.fillRect(headX + headW - 1, headY - 6, 2, 6);
        ctx.fillRect(headX + headW + 1, headY - 8, 2, 3);
        ctx.fillStyle = col('#7e9c82', '#26302a');
        ctx.fillRect(headX - 4, headY - 8, 2, 2);
        ctx.fillRect(headX + headW + 2, headY - 8, 2, 2);
        // Pointed ears
        ctx.fillStyle = col(appearance.skinTone);
        ctx.fillRect(headX - 3, headY + 5, 3, 2);
        ctx.fillRect(headX + headW, headY + 5, 3, 2);
      } else {
        // Astral Human rounded ears + subtle astral halo/crest
        ctx.fillStyle = col(appearance.skinTone);
        ctx.fillRect(headX - 1, headY + 5, 1, 3);
        ctx.fillRect(headX + headW, headY + 5, 1, 3);
      }

      // 7. EYES & FACE PRESET EXPRESSION
      if (!silhouetteOnly) {
        const browY =
          appearance.facePreset === 'Fierce'
            ? headY + 4
            : appearance.facePreset === 'Serene'
            ? headY + 3
            : headY + 4;
        ctx.fillStyle = appearance.hairColor;
        ctx.fillRect(headX + 2, browY, 3, 1);
        ctx.fillRect(headX + headW - 5, browY, 3, 1);

        // Eyes
        ctx.fillStyle = appearance.eyeColor;
        ctx.fillRect(headX + 2, headY + 5, 2, 2);
        ctx.fillRect(headX + headW - 4, headY + 5, 2, 2);

        // Eyepatch accessory
        if (appearance.accessories === 'Ranger Eyepatch') {
          ctx.fillStyle = '#1c1917';
          ctx.fillRect(headX + 1, headY + 4, 4, 3);
          ctx.fillRect(headX, headY + 3, headW, 1);
        }

        // Scars & Markings
        if (appearance.scarsAndMarkings === 'Brow Slash') {
          ctx.fillStyle = '#a35c52';
          ctx.fillRect(headX + 2, headY + 2, 1, 6);
        } else if (appearance.scarsAndMarkings === 'Cheek Duel Scar') {
          ctx.fillStyle = '#a35c52';
          ctx.fillRect(headX + headW - 4, headY + 7, 3, 2);
        } else if (appearance.scarsAndMarkings === 'Ritual Ash Mark') {
          ctx.fillStyle = '#d6cfc2';
          ctx.fillRect(cx - 1, headY + 2, 2, 4);
        } else if (appearance.scarsAndMarkings === 'Starlight Brand') {
          ctx.fillStyle = '#e2b05a';
          ctx.fillRect(headX + 2, headY + 8, 2, 2);
        }

        // Tattoos
        if (appearance.tattoos === 'Runic Brow') {
          ctx.fillStyle = '#4a6b5d';
          ctx.fillRect(cx - 2, headY + 2, 4, 1);
        } else if (appearance.tattoos === 'Sylvan Vine') {
          ctx.fillStyle = '#527858';
          ctx.fillRect(headX + 1, headY + 6, 1, 5);
        } else if (appearance.tattoos === 'Covenant Sigil') {
          ctx.fillStyle = '#b88c42';
          ctx.fillRect(headX + headW - 3, headY + 7, 2, 3);
        } else if (appearance.tattoos === 'Ashen Woad') {
          ctx.fillStyle = '#384654';
          ctx.fillRect(headX + 1, headY + 5, headW - 2, 2);
        }
      }

      // 8. HAIR STYLE & FACIAL HAIR
      ctx.fillStyle = col(appearance.hairColor, '#1b2420');
      if (appearance.hairStyle === 'Braided Crown') {
        ctx.fillRect(headX - 1, headY - 2, headW + 2, 4);
        ctx.fillRect(headX - 1, headY + 1, 2, 6);
        ctx.fillRect(headX + headW - 1, headY + 1, 2, 6);
      } else if (appearance.hairStyle === 'Long Flowing') {
        ctx.fillRect(headX - 1, headY - 2, headW + 2, 4);
        ctx.fillRect(headX - 2, headY + 1, 3, 15);
        ctx.fillRect(headX + headW - 1, headY + 1, 3, 15);
      } else if (appearance.hairStyle === 'Cropped Crest') {
        ctx.fillRect(headX + 2, headY - 3, headW - 4, 4);
      } else if (appearance.hairStyle === 'Swept Back') {
        ctx.fillRect(headX, headY - 2, headW, 3);
        ctx.fillRect(headX - 1, headY, 2, 4);
        ctx.fillRect(headX + headW - 1, headY, 2, 4);
      }

      // Facial Hair
      if (!silhouetteOnly && appearance.facialHair !== 'Clean-Shaven') {
        ctx.fillStyle = appearance.hairColor;
        if (appearance.facialHair === 'Trimmed Beard') {
          ctx.fillRect(headX + 1, headY + 10, headW - 2, 3);
        } else if (appearance.facialHair === 'Braided Mustache') {
          ctx.fillRect(headX + 2, headY + 9, headW - 4, 2);
        } else if (appearance.facialHair === 'Goatee') {
          ctx.fillRect(cx - 2, headY + 10, 4, 4);
        } else if (appearance.facialHair === 'Full Ranger Beard') {
          ctx.fillRect(headX + 1, headY + 9, headW - 2, 7);
        }
      }

      // Head Accessories
      if (!silhouetteOnly) {
        if (appearance.accessories === 'Bronze Circlet') {
          ctx.fillStyle = '#e2b05a';
          ctx.fillRect(headX, headY + 1, headW, 1);
          ctx.fillRect(cx - 1, headY, 2, 2);
        } else if (appearance.accessories === 'Silver Ear Cuff') {
          ctx.fillStyle = '#d8e0e8';
          ctx.fillRect(headX - 2, headY + 4, 1, 2);
        }
      }

      // 9. CLASS WEAPON & OFF-HAND EQUIPMENT
      const weaponX = cx - Math.floor(torsoW / 2) - 8;
      const offhandX = cx + Math.floor(torsoW / 2) + 4;

      if (archetypeClass === 'warrior') {
        // Greatsword / Broadblade + Heavy Buckler
        ctx.fillStyle = col('#9ba4ad');
        ctx.fillRect(weaponX + 1, torsoY - 12, 3, 28);
        ctx.fillStyle = col('#e2b05a');
        ctx.fillRect(weaponX - 1, torsoY + 14, 7, 2);
        ctx.fillStyle = col('#5c4028');
        ctx.fillRect(weaponX + 2, torsoY + 16, 2, 6);
      } else if (archetypeClass === 'paladin') {
        // Radiant Warhammer / Longsword + Kite Shield
        ctx.fillStyle = col('#d8dfe6');
        ctx.fillRect(weaponX + 2, torsoY - 10, 2, 26);
        ctx.fillStyle = col('#e2b05a');
        ctx.fillRect(weaponX, torsoY + 14, 6, 2);
        // Shield on right arm
        ctx.fillStyle = col('#2d4259');
        ctx.fillRect(offhandX - 2, torsoY + 6, 8, 14);
        ctx.fillStyle = col('#e2b05a');
        ctx.fillRect(offhandX - 2, torsoY + 6, 8, 2);
        ctx.fillRect(offhandX + 1, torsoY + 9, 2, 8);
      } else if (archetypeClass === 'mage') {
        // Quarterstaff with glowing amber/astral crystal
        ctx.fillStyle = col('#59412c');
        ctx.fillRect(weaponX + 2, torsoY - 12, 2, 38);
        ctx.fillStyle = col(pulse > 0.5 ? '#e2b05a' : '#7e9c82');
        ctx.fillRect(weaponX + 1, torsoY - 16, 4, 4);
      } else if (archetypeClass === 'rogue') {
        // Twin Daggers
        ctx.fillStyle = col('#8c969e');
        ctx.fillRect(weaponX + 2, torsoY + 12, 2, 12);
        ctx.fillRect(offhandX, torsoY + 12, 2, 12);
        ctx.fillStyle = col('#5A4B38');
        ctx.fillRect(weaponX + 1, torsoY + 19, 4, 2);
        ctx.fillRect(offhandX - 1, torsoY + 19, 4, 2);
      } else if (archetypeClass === 'ranger') {
        // Recurve Hunting Bow
        ctx.fillStyle = col('#6e4e32');
        ctx.fillRect(offhandX + 1, torsoY - 4, 2, 26);
        ctx.fillRect(offhandX - 1, torsoY - 6, 2, 3);
        ctx.fillRect(offhandX - 1, torsoY + 21, 2, 3);
        ctx.fillStyle = col('#b5ac9a');
        ctx.fillRect(offhandX - 1, torsoY - 3, 1, 24);
      }

      animId = window.requestAnimationFrame(render);
    };

    render();
    return () => window.cancelAnimationFrame(animId);
  }, [raceId, archetypeClass, appearance, silhouetteOnly]);

  return (
    <div
      className={`relative flex flex-col items-center justify-center rounded p-4 ${className}`}
      style={{
        backgroundColor: 'rgba(15, 20, 17, 0.85)',
        border: '1px solid #5A4B38',
      }}
    >
      <canvas
        ref={canvasRef}
        data-testid="character-pixel-preview-canvas"
        className="w-44 h-56 sm:w-52 sm:h-64 object-contain"
        style={{ imageRendering: 'pixelated' }}
      />
    </div>
  );
};
