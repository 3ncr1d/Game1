import React from 'react';
import { resolveSkillIconAssetPath } from '../game/skillIconResolver';

interface SkillIconSvgProps {
  skillId: string;
  skillName?: string;
  className?: string;
}

export const SkillIconSvg: React.FC<SkillIconSvgProps> = ({
  skillId,
  skillName,
  className = 'w-6 h-6',
}) => {
  const src = resolveSkillIconAssetPath(skillId, skillName);
  return (
    <img
      src={src}
      alt=""
      width={128}
      height={128}
      aria-hidden="true"
      data-testid={`skill-icon-${skillId}`}
      className={`block select-none pointer-events-none shrink-0 object-cover ${className}`}
    />
  );
};
