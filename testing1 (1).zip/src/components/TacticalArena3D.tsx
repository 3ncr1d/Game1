import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import {
  CombatUnit,
  GridTile,
  GRID_SIZE,
  TacticalEnvObject,
  WorldReactivityState,
  manhattanDistance,
  gridToWorld,
} from '../game/rules';
import {
  performanceManager,
  exponentialDamp,
  clampDeltaTime,
} from '../game/performanceManager';
import { smoothRotateAngle } from '../game/eightDirectionalMovement';
import {
  WARRIOR_ANIMATION_REGISTRY,
  WarriorSkillId,
  sampleWarriorRigTransform,
  RigTransform,
  AnimationPhase,
} from '../game/warriorAnimations';
import {
  MASTER_ANIMATION_REGISTRY,
  sampleMasterRigTransform,
} from '../game/skills/masterAnimationRegistry';
import { soundEngine } from '../game/audio';

export interface FloatingTextEvent {
  id: number;
  worldX: number;
  worldY: number;
  worldZ: number;
  text: string;
  color: string;
}

export interface ParticleBurstEvent {
  id: number;
  worldX: number;
  worldY: number;
  worldZ: number;
  colorHex: number;
  count: number;
  heavy: boolean;
}

export interface ActiveCombatAnimationEvent {
  id: number;
  attackerId: string;
  targetId?: string;
  targetGrid?: [number, number];
  skillId: string;
  isMiss?: boolean;
}

interface TacticalArena3DProps {
  gameState: 'title' | 'playing' | 'paused' | 'gameover';
  stageId: number;
  grid: GridTile[][];
  units: CombatUnit[];
  envObjects: TacticalEnvObject[];
  activeUnitId: string;
  selectedAbilityKey: '1' | '2' | '3' | '4' | null;
  validMoveTiles: { x: number; z: number }[];
  worldState: WorldReactivityState;
  cameraPreset: 'tactical' | 'close' | 'overhead';
  burstEvent: ParticleBurstEvent | null;
  combatAnimationEvent?: ActiveCombatAnimationEvent | null;
  onTileClick: (x: number, z: number) => void;
  onUnitClick: (unitId: string) => void;
  onHoverChange: (info: { tile?: { x: number; z: number }; unitId?: string } | null) => void;
}

function createRunestoneTextures(maxAniso: number) {
  const colorCanvas = document.createElement('canvas');
  colorCanvas.width = 256;
  colorCanvas.height = 256;
  const cctx = colorCanvas.getContext('2d')!;

  cctx.fillStyle = '#2b2836';
  cctx.fillRect(0, 0, 256, 256);

  // Flagstone joints
  cctx.strokeStyle = '#15131c';
  cctx.lineWidth = 5;
  cctx.strokeRect(6, 6, 244, 244);
  cctx.beginPath();
  cctx.moveTo(0, 128);
  cctx.lineTo(256, 128);
  cctx.moveTo(128, 0);
  cctx.lineTo(128, 128);
  cctx.stroke();

  // Subtle gold inlay border
  cctx.strokeStyle = 'rgba(217, 119, 6, 0.32)';
  cctx.lineWidth = 2;
  cctx.strokeRect(18, 18, 220, 220);

  // Weathering speckles
  for (let i = 0; i < 180; i++) {
    const x = (i * 73) % 256;
    const y = (i * 137) % 256;
    cctx.fillStyle = i % 2 === 0 ? 'rgba(255,255,255,0.04)' : 'rgba(0,0,0,0.12)';
    cctx.fillRect(x, y, 4, 4);
  }

  const colorTex = new THREE.CanvasTexture(colorCanvas);
  colorTex.colorSpace = THREE.SRGBColorSpace;
  colorTex.wrapS = THREE.RepeatWrapping;
  colorTex.wrapT = THREE.RepeatWrapping;
  colorTex.anisotropy = maxAniso;

  // Grayscale bump map
  const bumpCanvas = document.createElement('canvas');
  bumpCanvas.width = 256;
  bumpCanvas.height = 256;
  const bctx = bumpCanvas.getContext('2d')!;
  bctx.fillStyle = '#888888';
  bctx.fillRect(0, 0, 256, 256);
  bctx.strokeStyle = '#222222';
  bctx.lineWidth = 6;
  bctx.strokeRect(6, 6, 244, 244);
  bctx.strokeStyle = '#cccccc';
  bctx.lineWidth = 2;
  bctx.strokeRect(18, 18, 220, 220);

  const bumpTex = new THREE.CanvasTexture(bumpCanvas);
  bumpTex.wrapS = THREE.RepeatWrapping;
  bumpTex.wrapT = THREE.RepeatWrapping;
  bumpTex.anisotropy = maxAniso;

  return { colorTex, bumpTex };
}

/**
 * Builds a composite 8–10 part procedural 3D character mesh (`THREE.Group`)
 * across primary silhouette, secondary read, and accent details.
 */
function buildCharacterCompositeMesh(
  unit: CombatUnit,
  contactShadowGeo: THREE.CircleGeometry,
  contactShadowMat: THREE.MeshBasicMaterial
): {
  root: THREE.Group;
  bodyGroup: THREE.Group;
  weaponGroup: THREE.Group;
  selectionRing: THREE.Mesh;
  telegraphRing: THREE.Mesh;
  hitMaterials: THREE.MeshStandardMaterial[];
  leftLeg: THREE.Mesh;
  rightLeg: THREE.Mesh;
  shieldGroup?: THREE.Group;
  weaponTrailMesh?: THREE.Mesh;
  trailGeo?: THREE.BufferGeometry;
  trailPositions?: Float32Array;
  trailColors?: Float32Array;
} {
  const root = new THREE.Group();
  const bodyGroup = new THREE.Group();
  root.add(bodyGroup);

  const hitMaterials: THREE.MeshStandardMaterial[] = [];
  const makeMat = (params: THREE.MeshStandardMaterialParameters) => {
    const m = new THREE.MeshStandardMaterial({
      ...params,
      transparent: true,
      opacity: 1.0,
    });
    m.userData.baseColorHex = m.color.getHex();
    hitMaterials.push(m);
    return m;
  };

  // Contact shadow disc grounded at y = 0.015
  const shadowDisc = new THREE.Mesh(contactShadowGeo, contactShadowMat);
  shadowDisc.rotation.x = -Math.PI / 2;
  shadowDisc.position.y = 0.015;
  root.add(shadowDisc);

  // Selection ring under feet
  const ringGeo = new THREE.RingGeometry(0.58, 0.72, 32);
  const ringMat = new THREE.MeshBasicMaterial({
    color: unit.faction === 'party' ? 0xf59e0b : 0xf43f5e,
    side: THREE.DoubleSide,
    transparent: true,
    opacity: 0.0,
    depthWrite: false,
  });
  const selectionRing = new THREE.Mesh(ringGeo, ringMat);
  selectionRing.rotation.x = -Math.PI / 2;
  selectionRing.position.y = 0.03;
  root.add(selectionRing);

  // Enemy windup telegraph ring
  const teleGeo = new THREE.RingGeometry(0.75, 0.92, 32);
  const teleMat = new THREE.MeshBasicMaterial({
    color: 0xff2255,
    side: THREE.DoubleSide,
    transparent: true,
    opacity: 0.0,
    depthWrite: false,
  });
  const telegraphRing = new THREE.Mesh(teleGeo, teleMat);
  telegraphRing.rotation.x = -Math.PI / 2;
  telegraphRing.position.y = 0.04;
  root.add(telegraphRing);

  // Colors by character identity
  const isSera = unit.companionId === 'seraphina';
  const isKaelen = unit.companionId === 'kaelen';
  const isThorne = unit.companionId === 'thorne';
  const isInquisitor = unit.archetype === 'inquisitor';
  const isWeaver = unit.archetype === 'weaver';
  const isMage =
    unit.characterClass === 'mage' ||
    isKaelen ||
    isWeaver ||
    (unit.faction === 'party' &&
      !isSera &&
      !isThorne &&
      (unit.stats?.int ?? 0) > (unit.stats?.str ?? 0) &&
      (unit.stats?.int ?? 0) >= (unit.stats?.dex ?? 0));
  const isWarrior =
    !isMage &&
    (isSera ||
      unit.id === 'commander' ||
      unit.archetype === 'bruiser' ||
      unit.archetype === 'champion' ||
      (unit.faction === 'party' && !isKaelen && !isThorne));

  const armorHex = isSera
    ? 0x475569
    : isKaelen
    ? 0x7f1d1d
    : isThorne
    ? 0x14532d
    : isInquisitor
    ? 0x1e1b2e
    : isWeaver
    ? 0x4c1d95
    : 0x334155;

  const trimHex = isSera
    ? 0xf59e0b
    : isKaelen
    ? 0xfbbf24
    : isThorne
    ? 0x84cc16
    : 0xa855f7;

  const cloakHex = isSera
    ? 0x991b1b
    : isKaelen
    ? 0x31102f
    : isThorne
    ? 0x064e3b
    : 0x0f172a;

  // 1. Boots / Greaves (Primary lower base)
  const bootGeo = new THREE.CylinderGeometry(0.13, 0.16, 0.48, 12);
  const bootMat = makeMat({ color: 0x1e293b, roughness: 0.55, metalness: 0.45 });
  const leftLeg = new THREE.Mesh(bootGeo, bootMat);
  leftLeg.position.set(-0.18, 0.24, 0);
  const rightLeg = new THREE.Mesh(bootGeo, bootMat);
  rightLeg.position.set(0.18, 0.24, 0);
  bodyGroup.add(leftLeg, rightLeg);

  // 2. Sculpted Torso Cuirass / Robe (LatheGeometry silhouette)
  const torsoPoints = [
    new THREE.Vector2(0.01, 0),
    new THREE.Vector2(0.36, 0.04),
    new THREE.Vector2(0.28, 0.45),
    new THREE.Vector2(0.38, 0.85),
    new THREE.Vector2(0.18, 0.96),
  ];
  const torsoGeo = new THREE.LatheGeometry(torsoPoints, 16);
  const torsoMat = makeMat({
    color: armorHex,
    roughness: isKaelen || isWeaver ? 0.78 : 0.28,
    metalness: isKaelen || isWeaver ? 0.15 : 0.78,
  });
  const torso = new THREE.Mesh(torsoGeo, torsoMat);
  torso.position.y = 0.42;
  torso.castShadow = true;
  bodyGroup.add(torso);

  // 3. Gilded Waist Sash / Belt Buckle (Accent)
  const beltGeo = new THREE.TorusGeometry(0.3, 0.055, 8, 20);
  const trimMat = makeMat({
    color: trimHex,
    roughness: 0.22,
    metalness: 0.88,
  });
  const belt = new THREE.Mesh(beltGeo, trimMat);
  belt.rotation.x = Math.PI / 2;
  belt.position.y = 0.82;
  bodyGroup.add(belt);

  // 4. Flowing Cape / Cloak (Secondary silhouette)
  const capeGeo = new THREE.BoxGeometry(0.62, 1.05, 0.08);
  const capeMat = makeMat({
    color: cloakHex,
    roughness: 0.85,
    metalness: 0.08,
  });
  const cape = new THREE.Mesh(capeGeo, capeMat);
  cape.position.set(0, 0.82, -0.26);
  cape.rotation.x = 0.16;
  bodyGroup.add(cape);

  // 5 & 6. Layered Pauldrons (Secondary read)
  const pauldronGeo = new THREE.SphereGeometry(0.22, 14, 10, 0, Math.PI * 2, 0, Math.PI * 0.6);
  const leftPauldron = new THREE.Mesh(pauldronGeo, trimMat);
  leftPauldron.position.set(-0.42, 1.24, 0);
  leftPauldron.rotation.z = 0.35;
  const rightPauldron = new THREE.Mesh(pauldronGeo, trimMat);
  rightPauldron.position.set(0.42, 1.24, 0);
  rightPauldron.rotation.z = -0.35;
  bodyGroup.add(leftPauldron, rightPauldron);

  // 7. Head & Visage
  const headGeo = new THREE.SphereGeometry(0.24, 16, 16);
  const skinMat = makeMat({
    color: unit.faction === 'party' ? 0xd9b396 : 0x64748b,
    roughness: 0.65,
    metalness: 0.1,
  });
  const head = new THREE.Mesh(headGeo, skinMat);
  head.position.y = 1.58;
  bodyGroup.add(head);

  // 8. Character-Specific Headgear (Crested Crown / Tiefling Horns / Ranger Hood / Horned Helm)
  if (isSera) {
    const crownGeo = new THREE.ConeGeometry(0.24, 0.25, 6, 1, true);
    const crown = new THREE.Mesh(crownGeo, trimMat);
    crown.position.y = 1.78;
    bodyGroup.add(crown);
  } else if (isKaelen || isInquisitor) {
    const hornCurveL = new THREE.CatmullRomCurve3([
      new THREE.Vector3(-0.14, 1.72, 0.05),
      new THREE.Vector3(-0.34, 1.92, -0.08),
      new THREE.Vector3(-0.24, 2.12, -0.22),
    ]);
    const hornCurveR = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0.14, 1.72, 0.05),
      new THREE.Vector3(0.34, 1.92, -0.08),
      new THREE.Vector3(0.24, 2.12, -0.22),
    ]);
    const hornMat = makeMat({ color: 0x0f172a, roughness: 0.3, metalness: 0.6 });
    const hornL = new THREE.Mesh(new THREE.TubeGeometry(hornCurveL, 10, 0.045, 8, false), hornMat);
    const hornR = new THREE.Mesh(new THREE.TubeGeometry(hornCurveR, 10, 0.045, 8, false), hornMat);
    bodyGroup.add(hornL, hornR);
  } else {
    const hoodGeo = new THREE.ConeGeometry(0.3, 0.38, 12);
    const hood = new THREE.Mesh(hoodGeo, capeMat);
    hood.position.set(0, 1.78, -0.03);
    bodyGroup.add(hood);
  }

  // 9. Weapon Assembly (`weaponGroup` for animated swings & casts)
  const weaponGroup = new THREE.Group();
  weaponGroup.position.set(0.48, 1.02, 0.22);
  bodyGroup.add(weaponGroup);

  let shieldGroup: THREE.Group | undefined;

  if (isWarrior || isInquisitor) {
    // Greatsword / Longsword with crossguard, pommel, and glowing fuller
    const hilt = new THREE.Mesh(
      new THREE.CylinderGeometry(0.035, 0.04, 0.42, 8),
      makeMat({ color: 0x78350f, roughness: 0.7, metalness: 0.2 })
    );
    const guard = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.06, 0.09), trimMat);
    guard.position.y = 0.2;
    const blade = new THREE.Mesh(
      new THREE.BoxGeometry(0.09, 1.15, 0.03),
      makeMat({
        color: 0xe2e8f0,
        roughness: 0.15,
        metalness: 0.92,
        emissive: isSera ? 0xf59e0b : isInquisitor ? 0x9333ea : 0xe2b05a,
        emissiveIntensity: 0.35,
      })
    );
    blade.position.y = 0.78;
    weaponGroup.add(hilt, guard, blade);

    // Left-arm Heater Shield for Warrior
    if (isWarrior) {
      shieldGroup = new THREE.Group();
      const shieldPlate = new THREE.Mesh(
        new THREE.BoxGeometry(0.075, 0.68, 0.46),
        makeMat({ color: armorHex, roughness: 0.38, metalness: 0.75 })
      );
      const shieldTrim = new THREE.Mesh(
        new THREE.BoxGeometry(0.082, 0.7, 0.48),
        trimMat
      );
      shieldTrim.scale.set(0.96, 0.98, 0.96);
      const shieldBoss = new THREE.Mesh(
        new THREE.SphereGeometry(0.065, 8, 8),
        trimMat
      );
      shieldBoss.position.x = -0.04;
      shieldGroup.add(shieldPlate, shieldTrim, shieldBoss);
      shieldGroup.position.set(-0.46, 1.02, 0.22);
      shieldGroup.rotation.set(0.18, 0.22, 0.04);
      bodyGroup.add(shieldGroup);
    }
  } else if (isKaelen || isWeaver) {
    // Arcane Blood-Weave Staff with floating crystal & brass astrolabe ring
    const staff = new THREE.Mesh(
      new THREE.CylinderGeometry(0.035, 0.03, 1.65, 10),
      makeMat({ color: 0x451a03, roughness: 0.6, metalness: 0.3 })
    );
    staff.position.y = 0.25;
    const headRing = new THREE.Mesh(new THREE.TorusGeometry(0.18, 0.025, 8, 20), trimMat);
    headRing.position.y = 1.12;
    const orb = new THREE.Mesh(
      new THREE.OctahedronGeometry(0.11, 0),
      makeMat({
        color: 0xf43f5e,
        emissive: isKaelen ? 0xf43f5e : 0xa855f7,
        emissiveIntensity: 0.85,
        roughness: 0.15,
      })
    );
    orb.position.y = 1.12;
    weaponGroup.add(staff, headRing, orb);
  } else {
    // Sylvan Recurve Longbow + Emerald Arrow
    const bowCurve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0, -0.55, -0.12),
      new THREE.Vector3(0, -0.25, 0.18),
      new THREE.Vector3(0, 0.25, 0.18),
      new THREE.Vector3(0, 0.55, -0.12),
    ]);
    const bowMesh = new THREE.Mesh(
      new THREE.TubeGeometry(bowCurve, 16, 0.035, 8, false),
      makeMat({ color: 0x854d0e, roughness: 0.55, metalness: 0.25 })
    );
    const arrowShaft = new THREE.Mesh(
      new THREE.CylinderGeometry(0.015, 0.015, 0.75, 6),
      makeMat({ color: 0x4ade80, emissive: 0x22c55e, emissiveIntensity: 0.5 })
    );
    arrowShaft.rotation.x = Math.PI / 2;
    arrowShaft.position.z = 0.12;
    weaponGroup.add(bowMesh, arrowShaft);
  }

  // 10. Dynamic Weapon Trail Ribbon (for warrior melee arcs)
  const TRAIL_SEGMENTS = 14;
  const TRAIL_VERTS = (TRAIL_SEGMENTS + 1) * 2;
  const trailPositions = new Float32Array(TRAIL_VERTS * 3);
  const trailColors = new Float32Array(TRAIL_VERTS * 3);
  const trailIndices: number[] = [];
  for (let s = 0; s < TRAIL_SEGMENTS; s++) {
    const i0 = s * 2;
    const i1 = s * 2 + 1;
    const i2 = (s + 1) * 2;
    const i3 = (s + 1) * 2 + 1;
    trailIndices.push(i0, i1, i2, i1, i3, i2);
  }
  const trailGeo = new THREE.BufferGeometry();
  trailGeo.setIndex(trailIndices);
  trailGeo.setAttribute('position', new THREE.BufferAttribute(trailPositions, 3));
  trailGeo.setAttribute('color', new THREE.BufferAttribute(trailColors, 3));

  const trailMat = new THREE.MeshBasicMaterial({
    vertexColors: true,
    transparent: true,
    opacity: 0.0,
    depthWrite: false,
    side: THREE.DoubleSide,
    blending: THREE.AdditiveBlending,
  });
  const weaponTrailMesh = new THREE.Mesh(trailGeo, trailMat);
  weaponTrailMesh.frustumCulled = false;
  root.add(weaponTrailMesh);

  return {
    root,
    bodyGroup,
    weaponGroup,
    selectionRing,
    telegraphRing,
    hitMaterials,
    leftLeg,
    rightLeg,
    shieldGroup,
    weaponTrailMesh,
    trailGeo,
    trailPositions,
    trailColors,
  };
}

interface UnitHealthBarActor {
  sprite: THREE.Sprite;
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  texture: THREE.CanvasTexture;
  ghostHp: number;
  lastDrawnHp: number;
  lastDrawnGhostHp: number;
  lastDrawnActive: boolean;
  lastDrawnHovered: boolean;
  lastDrawnStatusesCount: number;
}

function drawRoundedRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
) {
  if (typeof ctx.roundRect === 'function') {
    ctx.roundRect(x, y, w, h, r);
  } else {
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
  }
}

function drawUnitHealthBarCanvas(
  canvas: HTMLCanvasElement,
  ctx: CanvasRenderingContext2D,
  unit: CombatUnit,
  ghostHp: number,
  isActiveTurn: boolean,
  isHovered: boolean
) {
  const w = canvas.width;
  const h = canvas.height;
  ctx.clearRect(0, 0, w, h);

  const isParty = unit.faction === 'party';
  const maxHp = Math.max(1, unit.maxHp);
  const currentHp = Math.max(0, Math.min(maxHp, unit.hp));
  const displayedGhostHp = Math.max(currentHp, Math.min(maxHp, ghostHp));

  // 1. Dark fantasy background card
  const pad = 2;
  const cardW = w - pad * 2;
  const cardH = h - pad * 2;
  const radius = 6;

  ctx.save();
  ctx.beginPath();
  drawRoundedRect(ctx, pad, pad, cardW, cardH, radius);
  ctx.fillStyle = 'rgba(17, 22, 19, 0.94)';
  ctx.fill();

  // Highlight Border
  if (isActiveTurn) {
    ctx.strokeStyle = '#E2B05A'; // Golden active turn halo
    ctx.lineWidth = 3;
    ctx.shadowColor = '#E2B05A';
    ctx.shadowBlur = 8;
  } else if (isHovered) {
    ctx.strokeStyle = '#F2ECE1';
    ctx.lineWidth = 2;
    ctx.shadowColor = '#F2ECE1';
    ctx.shadowBlur = 4;
  } else if (isParty) {
    ctx.strokeStyle = '#5A4B38';
    ctx.lineWidth = 1.5;
    ctx.shadowBlur = 0;
  } else {
    ctx.strokeStyle = '#6B2D2D'; // Blood red border for enemy
    ctx.lineWidth = 1.5;
    ctx.shadowBlur = 0;
  }
  ctx.stroke();
  ctx.restore();

  // 2. Unit Name & AC Header Row
  ctx.save();
  // Faction crest pip
  ctx.beginPath();
  ctx.arc(13, 14, 4.5, 0, Math.PI * 2);
  ctx.fillStyle = isParty ? '#22C55E' : '#EF4444';
  ctx.fill();

  // Unit Name (cleanly rendered)
  ctx.font = 'bold 12px serif, sans-serif';
  ctx.fillStyle = isParty ? '#F2ECE1' : '#FCA5A5';
  ctx.textBaseline = 'middle';
  const displayName = unit.name.length > 17 ? unit.name.substring(0, 16) + '…' : unit.name;
  ctx.fillText(displayName, 22, 14);

  // AC Badge on top right
  ctx.font = 'bold 10px monospace';
  ctx.fillStyle = '#B5AC9A';
  ctx.textAlign = 'right';
  ctx.fillText(`AC ${unit.armorClass}`, w - 10, 14);
  ctx.restore();

  // 3. Health Bar Track
  const trackX = 8;
  const trackY = 24;
  const trackW = w - 16;
  const trackH = 18;
  const trackR = 4;

  ctx.save();
  ctx.beginPath();
  drawRoundedRect(ctx, trackX, trackY, trackW, trackH, trackR);
  ctx.fillStyle = '#141715';
  ctx.fill();
  ctx.strokeStyle = '#2A302B';
  ctx.lineWidth = 1;
  ctx.stroke();
  ctx.clip();

  // 3A. Ghost / Damage Lag Bar
  const ghostPct = displayedGhostHp / maxHp;
  if (ghostPct > 0) {
    ctx.fillStyle = isParty ? '#F59E0B' : '#DC2626';
    ctx.fillRect(trackX, trackY, trackW * ghostPct, trackH);
  }

  // 3B. Current Health Bar Fill
  const hpPct = currentHp / maxHp;
  if (hpPct > 0) {
    const hpGrad = ctx.createLinearGradient(trackX, trackY, trackX + trackW * hpPct, trackY);
    if (isParty) {
      if (hpPct > 0.3) {
        hpGrad.addColorStop(0, '#22C55E');
        hpGrad.addColorStop(1, '#16A34A');
      } else {
        hpGrad.addColorStop(0, '#EAB308');
        hpGrad.addColorStop(1, '#CA8A04');
      }
    } else {
      if (hpPct > 0.3) {
        hpGrad.addColorStop(0, '#EF4444');
        hpGrad.addColorStop(1, '#B91C1C');
      } else {
        hpGrad.addColorStop(0, '#991B1B');
        hpGrad.addColorStop(1, '#7F1D1D');
      }
    }
    ctx.fillStyle = hpGrad;
    ctx.fillRect(trackX, trackY, trackW * hpPct, trackH);
  }

  // 3C. Temp HP / Shield overlay if active
  if (unit.statuses.some((s) => s.type === 'warded')) {
    ctx.fillStyle = 'rgba(56, 189, 248, 0.45)';
    ctx.fillRect(trackX, trackY, trackW * Math.min(1, hpPct + 0.25), trackH);
  }

  ctx.restore();

  // 4. Health Numbers Centered with black outline for high contrast
  ctx.save();
  const hpStr = `${Math.round(currentHp)} / ${maxHp}`;
  ctx.font = 'bold 11px monospace';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.strokeStyle = 'rgba(0, 0, 0, 0.9)';
  ctx.lineWidth = 2.5;
  ctx.strokeText(hpStr, w / 2, trackY + trackH / 2);
  ctx.fillStyle = '#FFFFFF';
  ctx.fillText(hpStr, w / 2, trackY + trackH / 2);
  ctx.restore();

  // 5. Status indicators (small colored pips on top right)
  if (unit.statuses.length > 0) {
    ctx.save();
    unit.statuses.slice(0, 4).forEach((st, sIdx) => {
      ctx.beginPath();
      ctx.arc(w - 55 - sIdx * 8, 14, 2.5, 0, Math.PI * 2);
      let sColor = '#E2B05A';
      if (st.type === 'burning') sColor = '#F97316';
      else if (st.type === 'rooted') sColor = '#84CC16';
      else if (st.type === 'sundered') sColor = '#EF4444';
      else if (st.type === 'warded') sColor = '#38BDF8';
      ctx.fillStyle = sColor;
      ctx.fill();
    });
    ctx.restore();
  }
}

function createUnitHealthBarActor(unit: CombatUnit): UnitHealthBarActor {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 56;
  const ctx = canvas.getContext('2d')!;

  const texture = new THREE.CanvasTexture(canvas);
  texture.minFilter = THREE.LinearFilter;
  texture.magFilter = THREE.LinearFilter;

  const mat = new THREE.SpriteMaterial({
    map: texture,
    transparent: true,
    depthTest: false,
    depthWrite: false,
  });

  const sprite = new THREE.Sprite(mat);
  sprite.scale.set(1.4, 0.306, 1.0);
  sprite.position.set(0, 2.45, 0);

  drawUnitHealthBarCanvas(canvas, ctx, unit, unit.hp, false, false);
  texture.needsUpdate = true;

  return {
    sprite,
    canvas,
    ctx,
    texture,
    ghostHp: unit.hp,
    lastDrawnHp: unit.hp,
    lastDrawnGhostHp: unit.hp,
    lastDrawnActive: false,
    lastDrawnHovered: false,
    lastDrawnStatusesCount: unit.statuses.length,
  };
}

/**
 * Builds a composite multi-part 3D mesh for interactive environmental objects:
 * - 'runic_brazier': Bronze pedestal, brazier basin, and flickering flame crystal
 * - 'oil_barrel': Dark oak barrel with metallic hoops and volatile oil slick top
 * - 'runestone_block': Heavy rune-carved monolith block that can be shoved to crush enemies or seal rifts
 */
function buildEnvObjectCompositeMesh(obj: TacticalEnvObject): {
  root: THREE.Group;
  accentMesh: THREE.Mesh;
} {
  const root = new THREE.Group();

  if (obj.kind === 'runic_brazier') {
    const baseMat = new THREE.MeshStandardMaterial({
      color: 0x78350f,
      roughness: 0.4,
      metalness: 0.75,
    });
    const stand = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.44, 0.9, 8), baseMat);
    stand.position.y = 0.45;
    stand.castShadow = true;

    const bowl = new THREE.Mesh(
      new THREE.CylinderGeometry(0.58, 0.28, 0.36, 10),
      new THREE.MeshStandardMaterial({ color: 0xb45309, roughness: 0.28, metalness: 0.85 })
    );
    bowl.position.y = 1.02;

    const flameMat = new THREE.MeshStandardMaterial({
      color: 0xf97316,
      emissive: 0xfbbf24,
      emissiveIntensity: 1.1,
      roughness: 0.2,
    });
    const flame = new THREE.Mesh(new THREE.OctahedronGeometry(0.36, 0), flameMat);
    flame.position.y = 1.42;

    root.add(stand, bowl, flame);
    return { root, accentMesh: flame };
  }

  if (obj.kind === 'oil_barrel') {
    const woodMat = new THREE.MeshStandardMaterial({
      color: 0x451a03,
      roughness: 0.78,
      metalness: 0.15,
    });
    const cask = new THREE.Mesh(new THREE.CylinderGeometry(0.46, 0.42, 1.05, 12), woodMat);
    cask.position.y = 0.52;
    cask.castShadow = true;

    const hoopMat = new THREE.MeshStandardMaterial({
      color: 0x334155,
      roughness: 0.35,
      metalness: 0.85,
    });
    const hoop1 = new THREE.Mesh(new THREE.TorusGeometry(0.45, 0.04, 8, 16), hoopMat);
    hoop1.rotation.x = Math.PI / 2;
    hoop1.position.y = 0.3;
    const hoop2 = new THREE.Mesh(new THREE.TorusGeometry(0.46, 0.04, 8, 16), hoopMat);
    hoop2.rotation.x = Math.PI / 2;
    hoop2.position.y = 0.78;

    const oilCapMat = new THREE.MeshStandardMaterial({
      color: 0xd97706,
      emissive: 0xb45309,
      emissiveIntensity: 0.55,
      roughness: 0.12,
      metalness: 0.9,
    });
    const oilCap = new THREE.Mesh(new THREE.CylinderGeometry(0.38, 0.38, 0.08, 12), oilCapMat);
    oilCap.position.y = 1.06;

    root.add(cask, hoop1, hoop2, oilCap);
    return { root, accentMesh: oilCap };
  }

  // 'runestone_block'
  const stoneMat = new THREE.MeshStandardMaterial({
    color: 0x334155,
    roughness: 0.55,
    metalness: 0.35,
  });
  const block = new THREE.Mesh(new THREE.BoxGeometry(1.08, 1.35, 1.08), stoneMat);
  block.position.y = 0.68;
  block.castShadow = true;

  const runeMat = new THREE.MeshStandardMaterial({
    color: 0x38bdf8,
    emissive: 0x0ea5e9,
    emissiveIntensity: 0.85,
    roughness: 0.2,
    metalness: 0.8,
  });
  const runeCrown = new THREE.Mesh(new THREE.OctahedronGeometry(0.3, 0), runeMat);
  runeCrown.position.y = 1.56;

  root.add(block, runeCrown);
  return { root, accentMesh: runeCrown };
}

export const TacticalArena3D: React.FC<TacticalArena3DProps> = ({
  gameState,
  stageId,
  grid,
  units,
  envObjects,
  activeUnitId,
  selectedAbilityKey,
  validMoveTiles,
  worldState,
  cameraPreset,
  burstEvent,
  combatAnimationEvent,
  onTileClick,
  onUnitClick,
  onHoverChange,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);

  // Store latest props in refs so the 60fps loop never tears down the canvas
  const stateRef = useRef({
    gameState,
    stageId,
    grid,
    units,
    envObjects,
    activeUnitId,
    selectedAbilityKey,
    validMoveTiles,
    worldState,
    cameraPreset,
    combatAnimationEvent,
    onTileClick,
    onUnitClick,
    onHoverChange,
  });

  useEffect(() => {
    stateRef.current = {
      gameState,
      stageId,
      grid,
      units,
      envObjects,
      activeUnitId,
      selectedAbilityKey,
      validMoveTiles,
      worldState,
      cameraPreset,
      combatAnimationEvent,
      onTileClick,
      onUnitClick,
      onHoverChange,
    };
  }, [
    gameState,
    stageId,
    grid,
    units,
    envObjects,
    activeUnitId,
    selectedAbilityKey,
    validMoveTiles,
    worldState,
    cameraPreset,
    combatAnimationEvent,
    onTileClick,
    onUnitClick,
    onHoverChange,
  ]);

  const burstQueueRef = useRef<ParticleBurstEvent[]>([]);
  useEffect(() => {
    if (burstEvent) {
      burstQueueRef.current.push(burstEvent);
    }
  }, [burstEvent]);

  const combatAnimationQueueRef = useRef<ActiveCombatAnimationEvent[]>([]);
  useEffect(() => {
    if (combatAnimationEvent) {
      combatAnimationQueueRef.current.push(combatAnimationEvent);
    }
  }, [combatAnimationEvent]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // 1. Software WebGL detection per `threejs` skill
    const isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    const renderer = new THREE.WebGLRenderer({
      antialias: !isSoftwareGl,
      powerPreference: 'high-performance',
    });
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = !isSoftwareGl;
    renderer.shadowMap.type = THREE.PCFShadowMap;
    renderer.setSize(container.clientWidth || window.innerWidth, container.clientHeight || window.innerHeight);

    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const fogColor = new THREE.Color(0x110e1a);
    scene.background = fogColor;
    scene.fog = new THREE.Fog(0x110e1a, 44, 78);

    // Studio Environment Map (RoomEnvironment)
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // Fixed True Isometric OrthographicCamera (45° azimuth, ~35.264° elevation)
    const isoFrustumSize = 23;
    const initAspect =
      (container.clientWidth || window.innerWidth) /
      (container.clientHeight || window.innerHeight);
    const camera = new THREE.OrthographicCamera(
      (-isoFrustumSize * initAspect) / 2,
      (isoFrustumSize * initAspect) / 2,
      isoFrustumSize / 2,
      -isoFrustumSize / 2,
      0.1,
      150
    );
    const ISO_OFFSET = new THREE.Vector3(22, 22, 22);
    camera.position.copy(ISO_OFFSET);
    camera.lookAt(0, 0.4, 0);

    // 2. Balanced 3-Point Studio & Sanctum Lighting Rig
    const hemiLight = new THREE.HemisphereLight(0x88aaff, 0x2a1f2d, 0.95);
    hemiLight.position.set(0, 30, 0);
    scene.add(hemiLight);

    const keyLight = new THREE.DirectionalLight(0xffdfb0, 2.2);
    keyLight.position.set(14, 24, 16);
    keyLight.castShadow = !isSoftwareGl;
    keyLight.shadow.mapSize.width = 1024;
    keyLight.shadow.mapSize.height = 1024;
    const d = 14;
    keyLight.shadow.camera.left = -d;
    keyLight.shadow.camera.right = d;
    keyLight.shadow.camera.top = d;
    keyLight.shadow.camera.bottom = -d;
    keyLight.shadow.camera.near = 1;
    keyLight.shadow.camera.far = 60;
    keyLight.shadow.bias = -0.0005;
    keyLight.shadow.normalBias = 0.02;
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0xc084fc, 0.9);
    rimLight.position.set(-14, 14, -16);
    scene.add(rimLight);

    // Procedural Textures
    const maxAniso = renderer.capabilities.getMaxAnisotropy();
    const { colorTex: stoneTex, bumpTex: stoneBump } = createRunestoneTextures(maxAniso);

    // Outer natural ground terrain extending beyond playable grid
    const outerGroundGeo = new THREE.PlaneGeometry(140, 140);
    const outerGroundMat = new THREE.MeshStandardMaterial({
      color: 0x161420,
      roughness: 0.92,
      metalness: 0.05,
    });
    const outerGround = new THREE.Mesh(outerGroundGeo, outerGroundMat);
    outerGround.rotation.x = -Math.PI / 2;
    outerGround.position.y = -0.08;
    outerGround.receiveShadow = true;
    scene.add(outerGround);

    // Natural Perimeter Cliff Spires (InstancedMesh, 36 instances, ±15% scale & tint variation)
    const cliffGeo = new THREE.ConeGeometry(2.4, 7.5, 6);
    const cliffMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.88,
      metalness: 0.12,
      bumpMap: stoneBump,
      bumpScale: 0.08,
    });
    const cliffCount = 36;
    const cliffInstanced = new THREE.InstancedMesh(cliffGeo, cliffMat, cliffCount);
    const dummy = new THREE.Object3D();
    const tintColor = new THREE.Color();
    for (let i = 0; i < cliffCount; i++) {
      const angle = (i / cliffCount) * Math.PI * 2;
      const radius = 19 + (i % 3) * 3.2;
      dummy.position.set(Math.cos(angle) * radius, 2.8, Math.sin(angle) * radius);
      dummy.rotation.set((i % 2) * 0.1, angle, 0);
      const s = 0.85 + ((i * 17) % 30) / 100;
      dummy.scale.set(s, s * (0.9 + (i % 4) * 0.25), s);
      dummy.updateMatrix();
      cliffInstanced.setMatrixAt(i, dummy.matrix);
      tintColor.setHSL(0.72 + (i % 5) * 0.015, 0.18, 0.16 + (i % 4) * 0.03);
      cliffInstanced.setColorAt(i, tintColor);
    }
    cliffInstanced.instanceMatrix.needsUpdate = true;
    if (cliffInstanced.instanceColor) cliffInstanced.instanceColor.needsUpdate = true;
    cliffInstanced.computeBoundingSphere();
    scene.add(cliffInstanced);

    // Gnarled Sylvan Perimeter Trees (InstancedMesh trunks + canopies, 24 instances)
    const trunkGeo = new THREE.CylinderGeometry(0.22, 0.38, 2.6, 7);
    const trunkMat = new THREE.MeshStandardMaterial({ color: 0x3f2e21, roughness: 0.9, metalness: 0.05 });
    const canopyGeo = new THREE.DodecahedronGeometry(1.35, 0);
    const canopyMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.78, metalness: 0.05 });
    const treeCount = 24;
    const trunkInst = new THREE.InstancedMesh(trunkGeo, trunkMat, treeCount);
    const canopyInst = new THREE.InstancedMesh(canopyGeo, canopyMat, treeCount);
    for (let i = 0; i < treeCount; i++) {
      const angle = (i / treeCount) * Math.PI * 2 + 0.12;
      const radius = 14.2 + (i % 2) * 2.2;
      // Leave clear vista at North Obelisk (angle around -Math.PI/2)
      const wx = Math.cos(angle) * radius;
      const wz = Math.sin(angle) * radius;
      const scale = 0.85 + (i % 4) * 0.1;

      dummy.position.set(wx, 1.3 * scale, wz);
      dummy.rotation.set(0, angle, 0);
      dummy.scale.setScalar(scale);
      dummy.updateMatrix();
      trunkInst.setMatrixAt(i, dummy.matrix);

      dummy.position.set(wx, 2.9 * scale, wz);
      dummy.scale.set(scale * 1.1, scale * 0.85, scale * 1.1);
      dummy.updateMatrix();
      canopyInst.setMatrixAt(i, dummy.matrix);
      tintColor.setHSL(i % 2 === 0 ? 0.38 : 0.08, 0.45, 0.22 + (i % 3) * 0.04);
      canopyInst.setColorAt(i, tintColor);
    }
    trunkInst.instanceMatrix.needsUpdate = true;
    canopyInst.instanceMatrix.needsUpdate = true;
    if (canopyInst.instanceColor) canopyInst.instanceColor.needsUpdate = true;
    trunkInst.computeBoundingSphere();
    canopyInst.computeBoundingSphere();
    scene.add(trunkInst, canopyInst);

    // Tall Silhouette Landmark Vista: The Astral Rift Obelisk at North (0, 0, -11.6)
    const obeliskGroup = new THREE.Group();
    obeliskGroup.position.set(0, 0, -11.6);
    scene.add(obeliskGroup);

    const pedMat = new THREE.MeshStandardMaterial({
      color: 0x334155,
      roughness: 0.6,
      metalness: 0.35,
      bumpMap: stoneBump,
      bumpScale: 0.05,
    });
    const ped1 = new THREE.Mesh(new THREE.CylinderGeometry(2.3, 2.8, 0.7, 8), pedMat);
    ped1.position.y = 0.35;
    const ped2 = new THREE.Mesh(new THREE.CylinderGeometry(1.6, 2.0, 0.75, 8), pedMat);
    ped2.position.y = 1.05;
    const spireShaft = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.95, 4.2, 4), pedMat);
    spireShaft.position.y = 3.4;
    spireShaft.rotation.y = Math.PI / 4;
    obeliskGroup.add(ped1, ped2, spireShaft);

    const obeliskCoreMat = new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      emissive: 0xf59e0b,
      emissiveIntensity: 1.2,
      roughness: 0.15,
      metalness: 0.8,
    });
    const obeliskCore = new THREE.Mesh(new THREE.OctahedronGeometry(0.85, 0), obeliskCoreMat);
    obeliskCore.position.y = 6.4;
    const ring1 = new THREE.Mesh(new THREE.TorusGeometry(1.45, 0.065, 10, 32), obeliskCoreMat);
    ring1.position.y = 6.4;
    const ring2 = new THREE.Mesh(new THREE.TorusGeometry(1.9, 0.05, 10, 32), obeliskCoreMat);
    ring2.position.y = 6.4;
    obeliskGroup.add(obeliskCore, ring1, ring2);

    const obeliskLight = new THREE.PointLight(0xf59e0b, 4.5, 22, 1.8);
    obeliskLight.position.set(0, 6.2, -10.5);
    scene.add(obeliskLight);

    // 4 Corner Sanctum Braziers (Composite multi-part pedestals + flame crystals)
    const brazierPositions = [
      [-10.5, -10.5],
      [10.5, -10.5],
      [-10.5, 10.5],
      [10.5, 10.5],
    ];
    brazierPositions.forEach(([bx, bz]) => {
      const bGroup = new THREE.Group();
      bGroup.position.set(bx, 0, bz);
      const col = new THREE.Mesh(new THREE.CylinderGeometry(0.4, 0.55, 2.2, 8), pedMat);
      col.position.y = 1.1;
      const bowl = new THREE.Mesh(
        new THREE.CylinderGeometry(0.75, 0.35, 0.45, 10),
        new THREE.MeshStandardMaterial({ color: 0xb45309, roughness: 0.3, metalness: 0.85 })
      );
      bowl.position.y = 2.35;
      const flame = new THREE.Mesh(
        new THREE.OctahedronGeometry(0.42, 0),
        new THREE.MeshBasicMaterial({ color: 0xfbbf24 })
      );
      flame.position.y = 2.85;
      bGroup.add(col, bowl, flame);
      scene.add(bGroup);
    });

    // 3. Tactical 10x10 Grid Meshes & Overlays
    const interactables: THREE.Object3D[] = [];
    const tileMeshes: THREE.Mesh[][] = [];
    const highlightMeshes: THREE.Mesh[][] = [];
    const surfaceMeshes: THREE.Mesh[][] = [];
    const pillarGroups: THREE.Group[] = [];

    const baseTileGeo = new THREE.BoxGeometry(1.92, 0.24, 1.92);
    const bastionTileGeo = new THREE.BoxGeometry(1.92, 0.89, 1.92);
    const highlightGeo = new THREE.PlaneGeometry(1.78, 1.78);
    const surfacePoolGeo = new THREE.CircleGeometry(0.78, 20);

    const tileBaseMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      map: stoneTex,
      bumpMap: stoneBump,
      bumpScale: 0.04,
      roughness: 0.72,
      metalness: 0.18,
    });

    for (let x = 0; x < GRID_SIZE; x++) {
      tileMeshes[x] = [];
      highlightMeshes[x] = [];
      surfaceMeshes[x] = [];
      for (let z = 0; z < GRID_SIZE; z++) {
        const tMat = tileBaseMat.clone();
        const tMesh = new THREE.Mesh(baseTileGeo, tMat);
        const [wx, , wz] = gridToWorld(x, z, 0);
        tMesh.position.set(wx, -0.12, wz);
        tMesh.receiveShadow = true;
        tMesh.userData = { type: 'tile', gridX: x, gridZ: z };
        scene.add(tMesh);
        tileMeshes[x][z] = tMesh;
        interactables.push(tMesh);

        // Reactive Environmental Surface Pool disc at y + 0.018
        const sMat = new THREE.MeshStandardMaterial({
          color: 0x292524,
          emissive: 0x000000,
          emissiveIntensity: 0,
          roughness: 0.18,
          metalness: 0.65,
          transparent: true,
          opacity: 0.0,
          depthWrite: false,
        });
        const sMesh = new THREE.Mesh(surfacePoolGeo, sMat);
        sMesh.rotation.x = -Math.PI / 2;
        sMesh.position.set(wx, 0.018, wz);
        scene.add(sMesh);
        surfaceMeshes[x][z] = sMesh;

        // Coplanar-safe highlight overlay at y + 0.025
        const hMat = new THREE.MeshBasicMaterial({
          color: 0x38bdf8,
          transparent: true,
          opacity: 0.0,
          depthWrite: false,
          polygonOffset: true,
          polygonOffsetFactor: -1,
          polygonOffsetUnits: -1,
        });
        const hMesh = new THREE.Mesh(highlightGeo, hMat);
        hMesh.rotation.x = -Math.PI / 2;
        hMesh.position.set(wx, 0.025, wz);
        scene.add(hMesh);
        highlightMeshes[x][z] = hMesh;
      }
    }

    // 4. Pooled Zero-GC Particle Ring Buffer (`THREE.InstancedMesh` of 80 particles)
    const PARTICLE_CAP = 80;
    const pGeo = new THREE.OctahedronGeometry(0.11, 0);
    const pMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const particleMesh = new THREE.InstancedMesh(pGeo, pMat, PARTICLE_CAP);
    particleMesh.frustumCulled = false;
    scene.add(particleMesh);

    const particleState = Array.from({ length: PARTICLE_CAP }, () => ({
      active: false,
      x: 0,
      y: -100,
      z: 0,
      vx: 0,
      vy: 0,
      vz: 0,
      life: 0,
      maxLife: 0.6,
      scale: 1,
    }));
    let particleCursor = 0;
    const pDummy = new THREE.Object3D();
    const pColor = new THREE.Color();

    function spawnParticles(wx: number, wy: number, wz: number, colorHex: number, count: number) {
      pColor.setHex(colorHex);
      for (let i = 0; i < count; i++) {
        const idx = particleCursor % PARTICLE_CAP;
        particleCursor++;
        const p = particleState[idx];
        p.active = true;
        p.x = wx + (Math.random() - 0.5) * 0.5;
        p.y = wy + (Math.random() - 0.5) * 0.4;
        p.z = wz + (Math.random() - 0.5) * 0.5;
        const angle = Math.random() * Math.PI * 2;
        const speed = 1.6 + Math.random() * 3.4;
        p.vx = Math.cos(angle) * speed;
        p.vy = 2.0 + Math.random() * 3.2;
        p.vz = Math.sin(angle) * speed;
        p.life = 0;
        p.maxLife = 0.42 + Math.random() * 0.28;
        p.scale = 0.8 + Math.random() * 0.9;
        particleMesh.setColorAt(idx, pColor);
      }
      if (particleMesh.instanceColor) particleMesh.instanceColor.needsUpdate = true;
    }

    // 5. Unit & Environmental Object Composite 3D Actor Registries
    const shockwavePool = Array.from({ length: 8 }, () => {
      const ringMat = new THREE.MeshBasicMaterial({
        color: 0xf59e0b,
        transparent: true,
        opacity: 0,
        side: THREE.DoubleSide,
        depthWrite: false,
      });
      const ring = new THREE.Mesh(new THREE.RingGeometry(0.2, 0.5, 32), ringMat);
      ring.rotation.x = -Math.PI / 2;
      ring.position.set(0, -100, 0);
      scene.add(ring);
      return { mesh: ring, active: false, x: 0, z: 0, life: 0, maxLife: 0.36, maxRadius: 1.5, colorHex: 0xf59e0b };
    });

    function triggerShockwave(x: number, z: number, maxRadius: number, colorHex: number) {
      const sw = shockwavePool.find((s) => !s.active) ?? shockwavePool[0];
      sw.active = true;
      sw.x = x;
      sw.z = z;
      sw.life = 0;
      sw.maxLife = 0.38;
      sw.maxRadius = maxRadius;
      sw.colorHex = colorHex;
      (sw.mesh.material as THREE.MeshBasicMaterial).color.setHex(colorHex);
      sw.mesh.position.set(x, 0.04, z);
      sw.mesh.scale.setScalar(0.1);
    }

    const contactShadowGeo = new THREE.CircleGeometry(0.65, 20);
    const contactShadowMat = new THREE.MeshBasicMaterial({
      color: 0x050408,
      transparent: true,
      opacity: 0.45,
      depthWrite: false,
    });
    const hitProxyGeo = new THREE.CylinderGeometry(0.65, 0.65, 2.65, 8);
    const hitProxyMat = new THREE.MeshBasicMaterial({ visible: false });

    const unitActors = new Map<
      string,
      ReturnType<typeof buildCharacterCompositeMesh> & {
        hitProxy: THREE.Mesh;
        healthBar: UnitHealthBarActor;
        flashTimer: number;
        lastHp: number;
        collapseProgress: number;
        dustBurstSpawned: boolean;
        activeSkillAnimation: {
          skillId: string;
          elapsed: number;
          isMiss?: boolean;
          impactTriggered: boolean;
          targetId?: string;
          targetGrid?: [number, number];
          initialFacing: number;
        } | null;
      }
    >();

    const envActors = new Map<
      string,
      ReturnType<typeof buildEnvObjectCompositeMesh> & {
        hitProxy: THREE.Mesh;
      }
    >();

    // Fixed Isometric Camera & Input State
    const camTarget = new THREE.Vector3(0, 0.4, 0);
    const desiredCamTarget = new THREE.Vector3(0, 0.4, 0);
    let currentIsoZoom = 1.0;
    let trauma = 0;
    let hitstopTimer = 0;
    let hoveredGrid: { x: number; z: number } | null = null;
    let hoveredUnitId: string | null = null;

    // Raycasting with live getBoundingClientRect()
    const raycaster = new THREE.Raycaster();
    const pointerNdc = new THREE.Vector2();
    let lastHoverTime = 0;

    const updatePointerNdc = (clientX: number, clientY: number) => {
      const rect = renderer.domElement.getBoundingClientRect();
      if (rect.width === 0 || rect.height === 0) return false;
      pointerNdc.x = ((clientX - rect.left) / rect.width) * 2 - 1;
      pointerNdc.y = -((clientY - rect.top) / rect.height) * 2 + 1;
      return true;
    };

    const onPointerMove = (e: PointerEvent) => {
      const now = performance.now();
      if (now - lastHoverTime < 45) return;
      lastHoverTime = now;
      if (stateRef.current.gameState !== 'playing') return;
      if (!updatePointerNdc(e.clientX, e.clientY)) return;

      raycaster.setFromCamera(pointerNdc, camera);
      const hits = raycaster.intersectObjects(interactables, false);
      if (hits.length > 0) {
        const hitObj = hits[0].object;
        if (hitObj.userData.type === 'unit') {
          hoveredUnitId = hitObj.userData.unitId;
          const u = stateRef.current.units.find((item) => item.id === hoveredUnitId);
          hoveredGrid = u ? { x: u.gridX, z: u.gridZ } : null;
          stateRef.current.onHoverChange({ unitId: hoveredUnitId ?? undefined, tile: hoveredGrid ?? undefined });
          renderer.domElement.style.cursor = 'pointer';
          return;
        }
        if (hitObj.userData.type === 'envObject') {
          const envObj = stateRef.current.envObjects.find((item) => item.id === hitObj.userData.objectId && !item.destroyed);
          hoveredGrid = envObj ? { x: envObj.gridX, z: envObj.gridZ } : null;
          hoveredUnitId = null;
          stateRef.current.onHoverChange({ tile: hoveredGrid ?? undefined });
          renderer.domElement.style.cursor = 'pointer';
          return;
        }
        if (hitObj.userData.type === 'tile') {
          hoveredGrid = { x: hitObj.userData.gridX, z: hitObj.userData.gridZ };
          hoveredUnitId = null;
          stateRef.current.onHoverChange({ tile: hoveredGrid });
          renderer.domElement.style.cursor = 'pointer';
          return;
        }
      }
      hoveredGrid = null;
      hoveredUnitId = null;
      stateRef.current.onHoverChange(null);
      renderer.domElement.style.cursor = 'default';
    };

    const onPointerDown = (e: PointerEvent) => {
      if (e.button !== 0 || stateRef.current.gameState !== 'playing') return;
      if (!updatePointerNdc(e.clientX, e.clientY)) return;

      raycaster.setFromCamera(pointerNdc, camera);
      const hits = raycaster.intersectObjects(interactables, false);
      if (hits.length > 0) {
        const hitObj = hits[0].object;
        if (hitObj.userData.type === 'unit') {
          stateRef.current.onUnitClick(hitObj.userData.unitId);
          return;
        }
        if (hitObj.userData.type === 'envObject') {
          const envObj = stateRef.current.envObjects.find((item) => item.id === hitObj.userData.objectId && !item.destroyed);
          if (envObj) {
            stateRef.current.onTileClick(envObj.gridX, envObj.gridZ);
          }
          return;
        }
        if (hitObj.userData.type === 'tile') {
          const gx = hitObj.userData.gridX;
          const gz = hitObj.userData.gridZ;
          // Check if a unit stands on this tile
          const occupyingUnit = stateRef.current.units.find(
            (u) => !u.isKO && u.gridX === gx && u.gridZ === gz
          );
          if (occupyingUnit && stateRef.current.selectedAbilityKey !== null) {
            stateRef.current.onUnitClick(occupyingUnit.id);
          } else {
            stateRef.current.onTileClick(gx, gz);
          }
        }
      }
    };

    renderer.domElement.addEventListener('pointermove', onPointerMove);
    renderer.domElement.addEventListener('pointerdown', onPointerDown);

    // ResizeObserver for crisp orthographic isometric viewport sizing
    const resizeObserver = new ResizeObserver(() => {
      if (!container) return;
      const w = container.clientWidth || window.innerWidth;
      const h = container.clientHeight || window.innerHeight;
      const aspect = w / h;
      camera.left = (-isoFrustumSize * aspect) / 2;
      camera.right = (isoFrustumSize * aspect) / 2;
      camera.top = isoFrustumSize / 2;
      camera.bottom = -isoFrustumSize / 2;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    });
    resizeObserver.observe(container);

    // Pre-warm shaders on GPU
    if (!isSoftwareGl) {
      renderer.compile(scene, camera);
    }

    // 6. Main Animation Loop with Software-WebGL `afterDraw` Pacing
    let frameId = 0;
    let disposed = false;
    let lastTime = performance.now();

    function afterDraw(cb: () => void) {
      if (disposed) return;
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync ? gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0) : null;
      gl.flush();
      const poll = () => {
        if (disposed) {
          if (sync) gl.deleteSync(sync);
          return;
        }
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    }

    let cachedStageKey = '';
    let lastValidMovesRef: { x: number; z: number }[] | null = null;
    const cachedValidMoveSet = new Set<string>();

    function tick() {
      if (disposed) return;
      const now = performance.now();

      // Target FPS Limiter (supports Native VRR, 60, 120, 144, 240, 360, Uncapped)
      if (performanceManager.shouldThrottle(now, lastTime)) {
        if (isSoftwareGl) {
          afterDraw(tick);
        } else {
          frameId = requestAnimationFrame(tick);
        }
        return;
      }
      performanceManager.recordFrame(now);

      const rawDt = (now - lastTime) / 1000;
      lastTime = now;
      const dt = clampDeltaTime(rawDt, 0.05); // Clamped dt <= 0.05s, precision preserved for 360Hz (2.7ms)
      const elapsed = now / 1000;

      const cur = stateRef.current;

      // Consume queued particle bursts & trigger hitstop + camera shake
      while (burstQueueRef.current.length > 0) {
        const b = burstQueueRef.current.shift()!;
        spawnParticles(b.worldX, b.worldY, b.worldZ, b.colorHex, b.count);
        if (b.heavy) {
          hitstopTimer = 0.055;
          trauma = Math.min(1.0, trauma + 0.55);
        } else {
          trauma = Math.min(1.0, trauma + 0.22);
        }
      }

      if (hitstopTimer > 0) {
        hitstopTimer = Math.max(0, hitstopTimer - dt);
      }
      const simDt = hitstopTimer > 0 ? 0 : dt;

      // Dynamic World Reactivity Lighting & Obelisk Mutation
      const isPurified = cur.worldState.flags.includes('sanctum_purified');
      const isBlood = cur.worldState.flags.includes('blood_weave_unleashed');
      if (isPurified) {
        obeliskCoreMat.color.setHex(0x38bdf8);
        obeliskCoreMat.emissive.setHex(0xfbbf24);
        obeliskLight.color.setHex(0xfde68a);
        fogColor.setHex(0x101829);
      } else if (isBlood) {
        obeliskCoreMat.color.setHex(0xf43f5e);
        obeliskCoreMat.emissive.setHex(0xdc2626);
        obeliskLight.color.setHex(0xf43f5e);
        fogColor.setHex(0x1f0b16);
      } else {
        obeliskCoreMat.color.setHex(0xf59e0b);
        obeliskCoreMat.emissive.setHex(0xd97706);
        obeliskLight.color.setHex(0xf59e0b);
        fogColor.setHex(0x120f1d);
      }
      if (scene.fog instanceof THREE.Fog) {
        scene.fog.color.copy(fogColor);
      }

      // Rotate Astral Obelisk rings
      obeliskCore.rotation.y += simDt * (isBlood ? 2.4 : 1.1);
      ring1.rotation.x = Math.sin(elapsed * 0.9) * 0.6;
      ring1.rotation.y += simDt * 0.8;
      ring2.rotation.z = Math.cos(elapsed * 0.7) * 0.6;
      ring2.rotation.y -= simDt * 0.6;

      // Sync Grid Pillar Obstacles when stage or flags change
      const stageKey = `${cur.stageId}_${cur.worldState.flags.join(',')}`;
      if (stageKey !== cachedStageKey) {
        cachedStageKey = stageKey;
        pillarGroups.forEach((p) => scene.remove(p));
        pillarGroups.length = 0;

        for (let x = 0; x < GRID_SIZE; x++) {
          for (let z = 0; z < GRID_SIZE; z++) {
            const tileData = cur.grid[x]?.[z];
            const mesh = tileMeshes[x][z];
            const hMesh = highlightMeshes[x][z];
            const sMesh = surfaceMeshes[x][z];
            if (!tileData || !mesh) continue;

            const [wx, wy, wz] = gridToWorld(x, z, tileData.elevation);
            mesh.geometry = tileData.elevation > 0 ? bastionTileGeo : baseTileGeo;
            mesh.position.set(wx, tileData.elevation > 0 ? 0.22 : -0.12, wz);
            hMesh.position.set(wx, wy + 0.025, wz);
            sMesh.position.set(wx, wy + 0.018, wz);

            if (tileData.terrain === 'pillar') {
              const pGroup = new THREE.Group();
              pGroup.position.set(wx, 0, wz);
              const base = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.45, 1.4), pedMat);
              base.position.y = 0.22;
              const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.48, 0.55, 2.7, 8), pedMat);
              shaft.position.y = 1.65;
              const cap = new THREE.Mesh(new THREE.BoxGeometry(1.3, 0.35, 1.3), pedMat);
              cap.position.y = 3.1;
              pGroup.add(base, shaft, cap);
              scene.add(pGroup);
              pillarGroups.push(pGroup);
            }
          }
        }
      }

      // Update Tile Terrain, Reactive Surfaces & Highlights every frame
      const activeUnit = cur.units.find((u) => u.id === cur.activeUnitId);
      const selectedAbility = activeUnit?.abilities.find((a) => a.key === cur.selectedAbilityKey);
      // Reuse cached valid moves Set if validMoveTiles array reference is unchanged (zero GC)
      if (cur.validMoveTiles !== lastValidMovesRef) {
        lastValidMovesRef = cur.validMoveTiles;
        cachedValidMoveSet.clear();
        for (let i = 0; i < cur.validMoveTiles.length; i++) {
          const m = cur.validMoveTiles[i];
          cachedValidMoveSet.add(`${m.x},${m.z}`);
        }
      }
      const validMoveSet = cachedValidMoveSet;

      for (let x = 0; x < GRID_SIZE; x++) {
        for (let z = 0; z < GRID_SIZE; z++) {
          const tileData = cur.grid[x]?.[z];
          const mesh = tileMeshes[x][z];
          const sMesh = surfaceMeshes[x][z];
          const hMesh = highlightMeshes[x][z];
          if (!tileData || !mesh || !sMesh || !hMesh) continue;

          // 1. Base terrain material (updates dynamically if hazard_rift is sealed)
          const mat = mesh.material as THREE.MeshStandardMaterial;
          if (tileData.terrain === 'hazard_rift') {
            mat.color.setHex(0x991b1b);
            mat.emissive.setHex(0xdc2626);
            mat.emissiveIntensity = 0.35;
          } else if (tileData.terrain === 'bastion') {
            mat.color.setHex(0xd6d3d1);
            mat.emissive.setHex(0x000000);
            mat.emissiveIntensity = 0;
          } else if (tileData.terrain === 'moss') {
            mat.color.setHex(0x86efac);
            mat.emissive.setHex(0x000000);
            mat.emissiveIntensity = 0;
          } else {
            mat.color.setHex(0xffffff);
            mat.emissive.setHex(0x000000);
            mat.emissiveIntensity = 0;
          }

          // 2. Reactive Environmental Surface Pool ('oil_pool', 'fire_pool', 'sanctified_pool', 'bramble_snare')
          const sMat = sMesh.material as THREE.MeshStandardMaterial;
          const surface = tileData.surface ?? 'none';
          if (surface === 'oil_pool') {
            sMat.color.setHex(0x451a03);
            sMat.emissive.setHex(0x78350f);
            sMat.emissiveIntensity = 0.35;
            sMat.roughness = 0.08;
            sMat.metalness = 0.88;
            sMat.opacity = 0.88;
            sMesh.scale.setScalar(1.0);
          } else if (surface === 'fire_pool') {
            const flicker = 0.85 + Math.sin(elapsed * 9.0 + x * 1.7 + z * 2.3) * 0.25;
            sMat.color.setHex(0xf97316);
            sMat.emissive.setHex(0xef4444);
            sMat.emissiveIntensity = 1.15 * flicker;
            sMat.roughness = 0.25;
            sMat.metalness = 0.2;
            sMat.opacity = 0.92;
            sMesh.scale.setScalar(0.96 + Math.sin(elapsed * 6.5 + x) * 0.06);
          } else if (surface === 'sanctified_pool') {
            sMat.color.setHex(0x38bdf8);
            sMat.emissive.setHex(0xfde047);
            sMat.emissiveIntensity = 0.65;
            sMat.roughness = 0.2;
            sMat.metalness = 0.5;
            sMat.opacity = 0.8;
            sMesh.scale.setScalar(1.0);
          } else if (surface === 'bramble_snare') {
            sMat.color.setHex(0x15803d);
            sMat.emissive.setHex(0x4ade80);
            sMat.emissiveIntensity = 0.45;
            sMat.roughness = 0.65;
            sMat.metalness = 0.1;
            sMat.opacity = 0.88;
            sMesh.scale.setScalar(1.0);
          } else if (surface === 'runic_mine') {
            sMat.color.setHex(0xd97706);
            sMat.emissive.setHex(0xf59e0b);
            sMat.emissiveIntensity = 0.85 + Math.sin(elapsed * 4.5) * 0.25;
            sMat.roughness = 0.15;
            sMat.metalness = 0.8;
            sMat.opacity = 0.92;
            sMesh.scale.setScalar(0.95 + Math.sin(elapsed * 5) * 0.05);
          } else if (surface === 'astral_rift') {
            sMat.color.setHex(0x581c87);
            sMat.emissive.setHex(0xa855f7);
            sMat.emissiveIntensity = 0.9 + Math.cos(elapsed * 6) * 0.3;
            sMat.roughness = 0.1;
            sMat.metalness = 0.9;
            sMat.opacity = 0.95;
            sMesh.scale.setScalar(1.05 + Math.sin(elapsed * 7) * 0.06);
          } else if (surface === 'prismatic_field') {
            sMat.color.setHex(0x06b6d4);
            sMat.emissive.setHex(0xd946ef);
            sMat.emissiveIntensity = 0.75 + Math.sin(elapsed * 3) * 0.25;
            sMat.roughness = 0.1;
            sMat.metalness = 0.85;
            sMat.opacity = 0.88;
            sMesh.scale.setScalar(1.0 + Math.sin(elapsed * 4) * 0.04);
          } else {
            sMat.opacity = 0.0;
          }

          // 3. Tile Selection & Range Highlight
          const hMat = hMesh.material as THREE.MeshBasicMaterial;
          const isHovered = hoveredGrid?.x === x && hoveredGrid?.z === z;
          const key = `${x},${z}`;

          if (cur.gameState !== 'playing') {
            hMat.opacity = 0;
            continue;
          }

          if (selectedAbility && activeUnit) {
            const dist = manhattanDistance(activeUnit.gridX, activeUnit.gridZ, x, z);
            if (dist <= selectedAbility.range) {
              hMat.color.setHex(
                selectedAbility.targetType === 'ally' || selectedAbility.targetType === 'self'
                  ? 0x4ade80
                  : 0xf59e0b
              );
              hMat.opacity = isHovered ? 0.55 : 0.24;
            } else {
              hMat.opacity = 0;
            }
          } else if (validMoveSet.has(key)) {
            hMat.color.setHex(0x38bdf8);
            hMat.opacity = isHovered ? 0.58 : 0.25;
          } else if (isHovered) {
            hMat.color.setHex(0xfef08a);
            hMat.opacity = 0.32;
          } else {
            hMat.opacity = 0;
          }
        }
      }

      // Sync & Animate Interactive Environmental Objects (Braziers, Oil Barrels, Runestone Push-Blocks)
      for (const [id, envActor] of envActors.entries()) {
        let existsAndIntact = false;
        for (let i = 0; i < cur.envObjects.length; i++) {
          const o = cur.envObjects[i];
          if (o.id === id && !o.destroyed) {
            existsAndIntact = true;
            break;
          }
        }
        if (!existsAndIntact) {
          scene.remove(envActor.root);
          const idx = interactables.indexOf(envActor.hitProxy);
          if (idx !== -1) interactables.splice(idx, 1);
          envActors.delete(id);
        }
      }

      cur.envObjects.forEach((obj, oIdx) => {
        if (obj.destroyed) return;
        let envActor = envActors.get(obj.id);
        const tileElev = cur.grid[obj.gridX]?.[obj.gridZ]?.elevation ?? 0;
        if (!envActor) {
          const built = buildEnvObjectCompositeMesh(obj);
          const hitProxy = new THREE.Mesh(hitProxyGeo, hitProxyMat);
          hitProxy.position.y = 0.9;
          hitProxy.userData = { type: 'envObject', objectId: obj.id };
          built.root.add(hitProxy);
          interactables.push(hitProxy);

          const [wx, wy, wz] = gridToWorld(obj.gridX, obj.gridZ, tileElev);
          built.root.position.set(wx, wy, wz);
          scene.add(built.root);
          envActor = { ...built, hitProxy };
          envActors.set(obj.id, envActor);
        }

        const [targetX, targetY, targetZ] = gridToWorld(obj.gridX, obj.gridZ, tileElev);
        const dampAlpha = 1 - Math.exp(-10 * simDt);
        envActor.root.position.x = THREE.MathUtils.lerp(envActor.root.position.x, targetX, dampAlpha);
        envActor.root.position.y = THREE.MathUtils.lerp(envActor.root.position.y, targetY, dampAlpha);
        envActor.root.position.z = THREE.MathUtils.lerp(envActor.root.position.z, targetZ, dampAlpha);

        if (obj.kind === 'runic_brazier' || obj.kind === 'runestone_block') {
          envActor.accentMesh.rotation.y += simDt * 1.8;
          envActor.accentMesh.position.y =
            (obj.kind === 'runic_brazier' ? 1.42 : 1.56) + Math.sin(elapsed * 3.2 + oIdx) * 0.06;
        }
      });

      // Sync & Animate Unit Composite Meshes
      for (const [id, actor] of unitActors.entries()) {
        let unitExists = false;
        for (let i = 0; i < cur.units.length; i++) {
          if (cur.units[i].id === id) {
            unitExists = true;
            break;
          }
        }
        if (!unitExists) {
          scene.remove(actor.root);
          const idx = interactables.indexOf(actor.hitProxy);
          if (idx !== -1) interactables.splice(idx, 1);
          actor.healthBar.texture.dispose();
          actor.healthBar.sprite.material.dispose();
          unitActors.delete(id);
        }
      }

      // Process incoming Combat Skill Animation events
      while (combatAnimationQueueRef.current.length > 0) {
        const evt = combatAnimationQueueRef.current.shift()!;
        const attackerActor = unitActors.get(evt.attackerId);
        if (attackerActor) {
          const skillKey = (evt.skillId in MASTER_ANIMATION_REGISTRY)
            ? evt.skillId
            : 'sundering_strike';
          attackerActor.activeSkillAnimation = {
            skillId: skillKey,
            elapsed: 0,
            isMiss: evt.isMiss,
            impactTriggered: false,
            targetId: evt.targetId,
            targetGrid: evt.targetGrid,
            initialFacing: attackerActor.root.rotation.y,
          };
        }
      }

      cur.units.forEach((unit, idx) => {
        let actor = unitActors.get(unit.id);
        if (!actor) {
          const built = buildCharacterCompositeMesh(unit, contactShadowGeo, contactShadowMat);
          const hitProxy = new THREE.Mesh(hitProxyGeo, hitProxyMat);
          hitProxy.position.y = 1.35;
          hitProxy.userData = { type: 'unit', unitId: unit.id };
          built.root.add(hitProxy);
          interactables.push(hitProxy);

          const healthBar = createUnitHealthBarActor(unit);
          built.root.add(healthBar.sprite);

          const [wx, wy, wz] = gridToWorld(unit.gridX, unit.gridZ, unit.elevation);
          built.root.position.set(wx, wy, wz);
          built.root.rotation.y = unit.faction === 'party' ? Math.PI : 0;
          scene.add(built.root);

          actor = {
            ...built,
            hitProxy,
            healthBar,
            flashTimer: 0,
            lastHp: unit.hp,
            collapseProgress: unit.isKO || unit.hp <= 0 ? 1 : 0,
            dustBurstSpawned: unit.isKO || unit.hp <= 0,
            activeSkillAnimation: null,
          };
          unitActors.set(unit.id, actor);
        }

        // Detect damage for 50ms emissive white hit-flash & squash-and-stretch
        if (unit.hp < actor.lastHp) {
          actor.flashTimer = 0.08;
          actor.bodyGroup.scale.set(1.22, 0.78, 1.22);
        }
        actor.lastHp = unit.hp;

        // Smooth position glide + gait bob synced to distance traveled
        const [targetX, targetY, targetZ] = gridToWorld(unit.gridX, unit.gridZ, unit.elevation);
        const dx = targetX - actor.root.position.x;
        const dz = targetZ - actor.root.position.z;
        const distRemaining = Math.hypot(dx, dz);
        const dampAlpha = 1 - Math.exp(-10 * simDt);

        actor.root.position.x += dx * dampAlpha;
        actor.root.position.z += dz * dampAlpha;
        actor.root.position.y =
          THREE.MathUtils.lerp(actor.root.position.y, targetY, dampAlpha) +
          (distRemaining > 0.08 ? Math.abs(Math.sin(distRemaining * 4.5)) * 0.22 : 0);

        // Smooth shortest-arc rotation toward movement direction during 8-directional tactical glide
        if (distRemaining > 0.08) {
          const moveAngle = Math.atan2(dx, dz);
          actor.root.rotation.y = smoothRotateAngle(actor.root.rotation.y, moveAngle, 14.0, simDt);
          const strideCycle = Math.sin(elapsed * 12.0);
          actor.leftLeg.rotation.x = strideCycle * 0.45;
          actor.rightLeg.rotation.x = -strideCycle * 0.45;
          actor.bodyGroup.rotation.x = 0.08; // subtle forward tactical sprint lean
        } else {
          actor.leftLeg.rotation.x = THREE.MathUtils.lerp(actor.leftLeg.rotation.x, 0.05, 1 - Math.exp(-10 * simDt));
          actor.rightLeg.rotation.x = THREE.MathUtils.lerp(actor.rightLeg.rotation.x, -0.05, 1 - Math.exp(-10 * simDt));
          actor.bodyGroup.rotation.x = THREE.MathUtils.lerp(actor.bodyGroup.rotation.x, 0, 1 - Math.exp(-10 * simDt));
        }

        // Idle breathing & weapon poise OR 0-HP Collapse & Fade-to-Dust animation
        if (unit.isKO || unit.hp <= 0) {
          if (!actor.dustBurstSpawned) {
            actor.dustBurstSpawned = true;
            spawnParticles(
              actor.root.position.x,
              actor.root.position.y + 0.85,
              actor.root.position.z,
              0xd6d3d1,
              22
            );
            spawnParticles(
              actor.root.position.x,
              actor.root.position.y + 0.45,
              actor.root.position.z,
              unit.faction === 'enemy' ? 0xc084fc : 0xf97316,
              14
            );
          }

          actor.collapseProgress = Math.min(1, actor.collapseProgress + dt / 0.85);
          const cp = actor.collapseProgress;

          // Pitch forward & twist as the unit collapses and dissolves into ash/dust
          actor.bodyGroup.rotation.x = THREE.MathUtils.lerp(
            actor.bodyGroup.rotation.x,
            -Math.PI / 2.15,
            1 - Math.exp(-8 * dt)
          );
          actor.bodyGroup.rotation.z = THREE.MathUtils.lerp(
            actor.bodyGroup.rotation.z,
            0.26,
            1 - Math.exp(-6 * dt)
          );
          actor.bodyGroup.position.y = THREE.MathUtils.lerp(
            actor.bodyGroup.position.y,
            0.08,
            dampAlpha
          );

          // Flatten & shrink into a settling ash/dust mound
          const targetXZScale = Math.max(0.58, 1 - cp * 0.36);
          const targetYScale = Math.max(0.22, 1 - cp * 0.76);
          actor.bodyGroup.scale.x = THREE.MathUtils.lerp(actor.bodyGroup.scale.x, targetXZScale, dampAlpha);
          actor.bodyGroup.scale.y = THREE.MathUtils.lerp(actor.bodyGroup.scale.y, targetYScale, dampAlpha);
          actor.bodyGroup.scale.z = THREE.MathUtils.lerp(actor.bodyGroup.scale.z, targetXZScale, dampAlpha);

          // Fade materials to glowing ember-ash and then semi-transparent dust
          actor.hitMaterials.forEach((m) => {
            m.color.setHex(0x57534e);
            if (cp < 0.48) {
              m.emissive.setHex(unit.faction === 'enemy' ? 0xa855f7 : 0xf97316);
              m.emissiveIntensity = (1 - cp / 0.48) * 0.85;
            } else {
              m.emissiveIntensity = 0;
            }
            m.opacity = Math.max(0.12, 1 - cp * 0.88);
            m.depthWrite = cp < 0.25;
          });

          (actor.selectionRing.material as THREE.MeshBasicMaterial).opacity = 0;
          (actor.telegraphRing.material as THREE.MeshBasicMaterial).opacity = 0;

          // Fade out health bar when unit collapses / is KO
          actor.healthBar.sprite.material.opacity = Math.max(0, 1 - cp * 2.2);
          actor.healthBar.sprite.visible = cp < 0.95;
        } else {
          actor.healthBar.sprite.material.opacity = 1.0;
          actor.healthBar.sprite.visible = true;

          // Smoothly catch up ghost damage bar toward current HP
          if (actor.healthBar.ghostHp > unit.hp) {
            actor.healthBar.ghostHp = THREE.MathUtils.lerp(
              actor.healthBar.ghostHp,
              unit.hp,
              1 - Math.exp(-4.5 * dt)
            );
            if (Math.abs(actor.healthBar.ghostHp - unit.hp) < 0.1) {
              actor.healthBar.ghostHp = unit.hp;
            }
          } else {
            actor.healthBar.ghostHp = unit.hp;
          }

          const isActive = unit.id === cur.activeUnitId;
          const isUnitHovered = unit.id === hoveredUnitId;

          // Check if health bar needs redraw
          const needsRedraw =
            Math.abs(actor.healthBar.lastDrawnHp - unit.hp) > 0.05 ||
            Math.abs(actor.healthBar.lastDrawnGhostHp - actor.healthBar.ghostHp) > 0.1 ||
            actor.healthBar.lastDrawnActive !== isActive ||
            actor.healthBar.lastDrawnHovered !== isUnitHovered ||
            actor.healthBar.lastDrawnStatusesCount !== unit.statuses.length;

          if (needsRedraw) {
            drawUnitHealthBarCanvas(
              actor.healthBar.canvas,
              actor.healthBar.ctx,
              unit,
              actor.healthBar.ghostHp,
              isActive,
              isUnitHovered
            );
            actor.healthBar.texture.needsUpdate = true;
            actor.healthBar.lastDrawnHp = unit.hp;
            actor.healthBar.lastDrawnGhostHp = actor.healthBar.ghostHp;
            actor.healthBar.lastDrawnActive = isActive;
            actor.healthBar.lastDrawnHovered = isUnitHovered;
            actor.healthBar.lastDrawnStatusesCount = unit.statuses.length;
          }

          if (actor.collapseProgress > 0 || actor.dustBurstSpawned) {
            actor.collapseProgress = 0;
            actor.dustBurstSpawned = false;
            actor.bodyGroup.rotation.z = 0;
            actor.hitMaterials.forEach((m) => {
              if (typeof m.userData.baseColorHex === 'number') {
                m.color.setHex(m.userData.baseColorHex);
              }
              m.opacity = 1.0;
              m.depthWrite = true;
            });
          }

          if (actor.flashTimer > 0) {
            actor.flashTimer = Math.max(0, actor.flashTimer - dt);
            actor.hitMaterials.forEach((m) => {
              m.emissive.setHex(0xffffff);
              m.emissiveIntensity = 0.9;
            });
          } else {
            actor.hitMaterials.forEach((m, mIdx) => {
              if (mIdx === actor!.hitMaterials.length - 1) {
                // Preserve weapon glow
                m.emissive.setHex(unit.faction === 'party' ? 0xf59e0b : 0xa855f7);
                m.emissiveIntensity = 0.35;
              } else {
                m.emissiveIntensity = 0;
              }
            });
          }

          if (actor.activeSkillAnimation) {
            actor.activeSkillAnimation.elapsed += simDt;
            const animConfig = MASTER_ANIMATION_REGISTRY[actor.activeSkillAnimation.skillId];
            if (animConfig) {
              // 1. Facing
              let targetWorldPos: [number, number, number] | null = null;
              if (actor.activeSkillAnimation.targetId) {
                const tgtUnit = cur.units.find((u) => u.id === actor.activeSkillAnimation!.targetId);
                if (tgtUnit) {
                  targetWorldPos = gridToWorld(tgtUnit.gridX, tgtUnit.gridZ, tgtUnit.elevation);
                }
              } else if (actor.activeSkillAnimation.targetGrid) {
                const elev = cur.grid[actor.activeSkillAnimation.targetGrid[0]]?.[actor.activeSkillAnimation.targetGrid[1]]?.elevation ?? 0;
                targetWorldPos = gridToWorld(actor.activeSkillAnimation.targetGrid[0], actor.activeSkillAnimation.targetGrid[1], elev);
              }

              if (targetWorldPos && animConfig.targetFacingBehavior === 'face_target') {
                const tdx = targetWorldPos[0] - actor.root.position.x;
                const tdz = targetWorldPos[2] - actor.root.position.z;
                if (Math.hypot(tdx, tdz) > 0.08) {
                  const faceAngle = Math.atan2(tdx, tdz);
                  actor.root.rotation.y = smoothRotateAngle(actor.root.rotation.y, faceAngle, 20.0, simDt);
                }
              }

              // 2. Sample procedural pose
              const { transform, phase, isFinished } = sampleMasterRigTransform(
                actor.activeSkillAnimation.skillId,
                actor.activeSkillAnimation.elapsed,
                actor.activeSkillAnimation.isMiss
              );

              // 3. Apply rig transforms
              actor.bodyGroup.position.set(
                transform.bodyPos[0],
                transform.bodyPos[1],
                transform.bodyPos[2]
              );
              actor.bodyGroup.rotation.set(
                transform.bodyRot[0],
                transform.bodyRot[1],
                transform.bodyRot[2]
              );
              actor.bodyGroup.scale.set(
                transform.bodyScale[0],
                transform.bodyScale[1],
                transform.bodyScale[2]
              );

              actor.weaponGroup.position.set(
                0.48 + transform.weaponPos[0],
                1.02 + transform.weaponPos[1],
                0.22 + transform.weaponPos[2]
              );
              actor.weaponGroup.rotation.set(
                transform.weaponRot[0],
                transform.weaponRot[1],
                transform.weaponRot[2]
              );

              if (actor.shieldGroup) {
                const sp = transform.shieldPos ?? [0, 0, 0];
                const sr = transform.shieldRot ?? [0, 0, 0];
                actor.shieldGroup.position.set(
                  -0.46 + sp[0],
                  1.02 + sp[1],
                  0.22 + sp[2]
                );
                actor.shieldGroup.rotation.set(
                  0.18 + sr[0],
                  0.22 + sr[1],
                  0.04 + sr[2]
                );
              }

              if (transform.leftLegRot) {
                actor.leftLeg.rotation.set(transform.leftLegRot[0], transform.leftLegRot[1], transform.leftLegRot[2]);
              }
              if (transform.rightLegRot) {
                actor.rightLeg.rotation.set(transform.rightLegRot[0], transform.rightLegRot[1], transform.rightLegRot[2]);
              }

              // 4. Update Weapon Trail Ribbon
              if (actor.weaponTrailMesh && actor.trailGeo && actor.trailPositions && actor.trailColors) {
                const trailMat = actor.weaponTrailMesh.material as THREE.MeshBasicMaterial;
                if (animConfig.weaponTrail.enabled && (phase === 'execution' || phase === 'impact')) {
                  trailMat.opacity = Math.min(animConfig.weaponTrail.intensity, trailMat.opacity + simDt * 8);

                  const vBase = new THREE.Vector3(0, 0.25, 0);
                  const vTip = new THREE.Vector3(0, 1.45, 0);
                  actor.weaponGroup.localToWorld(vBase);
                  actor.weaponGroup.localToWorld(vTip);
                  actor.root.worldToLocal(vBase);
                  actor.root.worldToLocal(vTip);

                  const pArr = actor.trailPositions;
                  const cArr = actor.trailColors;
                  for (let s = 14; s > 0; s--) {
                    const src = (s - 1) * 6;
                    const dst = s * 6;
                    for (let k = 0; k < 6; k++) {
                      pArr[dst + k] = pArr[src + k];
                      cArr[dst + k] = cArr[src + k] * 0.88;
                    }
                  }
                  pArr[0] = vBase.x; pArr[1] = vBase.y; pArr[2] = vBase.z;
                  pArr[3] = vTip.x; pArr[4] = vTip.y; pArr[5] = vTip.z;

                  const trailCol = new THREE.Color(animConfig.weaponTrail.colorHex);
                  cArr[0] = trailCol.r; cArr[1] = trailCol.g; cArr[2] = trailCol.b;
                  cArr[3] = trailCol.r; cArr[4] = trailCol.g; cArr[5] = trailCol.b;

                  actor.trailGeo.attributes.position.needsUpdate = true;
                  actor.trailGeo.attributes.color.needsUpdate = true;
                } else {
                  trailMat.opacity = Math.max(0, trailMat.opacity - simDt * 6);
                }
              }

              // 5. Impact synchronization
              if (actor.activeSkillAnimation.elapsed >= animConfig.impactTiming && !actor.activeSkillAnimation.impactTriggered) {
                actor.activeSkillAnimation.impactTriggered = true;
                const soundFn = (soundEngine as any)[animConfig.soundMethod];
                if (typeof soundFn === 'function') {
                  soundFn.call(soundEngine);
                }

                if (!actor.activeSkillAnimation.isMiss) {
                  trauma = Math.min(0.4, trauma + 0.18);

                  if (actor.activeSkillAnimation.targetId) {
                    const targetActor = unitActors.get(actor.activeSkillAnimation.targetId);
                    if (targetActor) {
                      targetActor.flashTimer = 0.16;
                      targetActor.bodyGroup.scale.set(1.25, 0.76, 1.25);
                    }
                  }

                  let impactX = actor.root.position.x;
                  let impactY = actor.root.position.y;
                  let impactZ = actor.root.position.z;
                  if (targetWorldPos) {
                    impactX = targetWorldPos[0];
                    impactY = targetWorldPos[1];
                    impactZ = targetWorldPos[2];
                  }

                  if (animConfig.vfx.sparkBurst) {
                    spawnParticles(impactX, impactY + 1.2, impactZ, animConfig.vfx.particleColorHex, animConfig.vfx.particleCount);
                  }
                  if (animConfig.vfx.dustBurst) {
                    spawnParticles(actor.root.position.x, actor.root.position.y + 0.08, actor.root.position.z, 0xa8a29e, 10);
                  }
                  if (animConfig.vfx.shockwaveRadius) {
                    triggerShockwave(impactX, impactZ, animConfig.vfx.shockwaveRadius, animConfig.vfx.particleColorHex);
                  }
                  if (animConfig.vfx.allyPulse) {
                    for (const [otherId, otherActor] of unitActors.entries()) {
                      const otherUnit = cur.units.find((u) => u.id === otherId);
                      if (otherUnit && otherUnit.faction === 'party' && otherUnit.id !== unit.id) {
                        otherActor.flashTimer = 0.25;
                        spawnParticles(otherActor.root.position.x, otherActor.root.position.y + 1.2, otherActor.root.position.z, 0xf59e0b, 8);
                      }
                    }
                  }
                } else {
                  spawnParticles(actor.root.position.x, actor.root.position.y + 1.0, actor.root.position.z, 0x94a3b8, 6);
                }
              }

              if (isFinished) {
                actor.activeSkillAnimation = null;
                if (actor.weaponTrailMesh) {
                  (actor.weaponTrailMesh.material as THREE.MeshBasicMaterial).opacity = 0;
                }
              }
            } else {
              actor.activeSkillAnimation = null;
            }
          } else {
            // Fade out trail ribbon if not animating
            if (actor.weaponTrailMesh) {
              const trailMat = actor.weaponTrailMesh.material as THREE.MeshBasicMaterial;
              if (trailMat.opacity > 0) {
                trailMat.opacity = Math.max(0, trailMat.opacity - simDt * 6);
              }
            }
            // Exponentially damp squash-and-stretch back to (1, 1, 1)
            actor.bodyGroup.scale.x = THREE.MathUtils.lerp(actor.bodyGroup.scale.x, 1, dampAlpha);
            actor.bodyGroup.scale.y = THREE.MathUtils.lerp(actor.bodyGroup.scale.y, 1, dampAlpha);
            actor.bodyGroup.scale.z = THREE.MathUtils.lerp(actor.bodyGroup.scale.z, 1, dampAlpha);

            actor.bodyGroup.rotation.x = THREE.MathUtils.lerp(actor.bodyGroup.rotation.x, 0, dampAlpha);
            actor.bodyGroup.rotation.z = THREE.MathUtils.lerp(actor.bodyGroup.rotation.z, 0, dampAlpha);
            actor.bodyGroup.position.y = Math.sin(elapsed * 2.4 + idx) * 0.035;
            actor.weaponGroup.rotation.z = Math.sin(elapsed * 2.0 + idx) * 0.08;
            actor.weaponGroup.position.set(0.48, 1.02, 0.22);
            if (actor.shieldGroup) {
              actor.shieldGroup.position.set(-0.46, 1.02, 0.22);
              actor.shieldGroup.rotation.set(0.18, 0.22, 0.04);
            }
          }

          const ringMat = actor.selectionRing.material as THREE.MeshBasicMaterial;
          ringMat.opacity = isActive ? 0.92 : isUnitHovered ? 0.65 : 0.22;
          actor.selectionRing.scale.setScalar(isActive ? 1.12 : 1.0);

          const teleMat = actor.telegraphRing.material as THREE.MeshBasicMaterial;
          teleMat.opacity = unit.telegraph ? 0.78 : 0.0;
        }
      });

      // Update Pooled Particles
      for (let i = 0; i < PARTICLE_CAP; i++) {
        const p = particleState[i];
        if (!p.active) {
          pDummy.position.set(0, -100, 0);
          pDummy.scale.setScalar(0.001);
          pDummy.updateMatrix();
          particleMesh.setMatrixAt(i, pDummy.matrix);
          continue;
        }
        p.life += dt;
        if (p.life >= p.maxLife) {
          p.active = false;
          pDummy.position.set(0, -100, 0);
          pDummy.scale.setScalar(0.001);
        } else {
          p.x += p.vx * dt;
          p.y += p.vy * dt;
          p.z += p.vz * dt;
          p.vy -= 6.5 * dt; // Gravity
          const lifeRatio = 1 - p.life / p.maxLife;
          pDummy.position.set(p.x, p.y, p.z);
          pDummy.rotation.set(p.life * 6, p.life * 4, 0);
          pDummy.scale.setScalar(p.scale * lifeRatio);
        }
        pDummy.updateMatrix();
        particleMesh.setMatrixAt(i, pDummy.matrix);
      }
      particleMesh.instanceMatrix.needsUpdate = true;

      // Update Ground Shockwaves
      shockwavePool.forEach((sw) => {
        if (!sw.active) return;
        sw.life += dt;
        if (sw.life >= sw.maxLife) {
          sw.active = false;
          sw.mesh.position.set(0, -100, 0);
          (sw.mesh.material as THREE.MeshBasicMaterial).opacity = 0;
        } else {
          const t = sw.life / sw.maxLife;
          const currentR = THREE.MathUtils.lerp(0.3, sw.maxRadius, 1 - (1 - t) * (1 - t));
          sw.mesh.scale.set(currentR, currentR, currentR);
          (sw.mesh.material as THREE.MeshBasicMaterial).opacity = (1 - t) * 0.85;
        }
      });

      // 7. Locked Isometric Camera Rig (Fixed 45° Azimuth & True Isometric Projection)
      let targetZoom = 1.0;
      if (cur.gameState === 'title') {
        // Shift target slightly left so the isometric sanctum diamond sits in the right 65% of the title screen
        desiredCamTarget.set(-2.2, 0.5, 2.2);
        targetZoom = 0.96;
      } else if (cur.cameraPreset === 'close' && activeUnit) {
        const [ux, uy, uz] = gridToWorld(activeUnit.gridX, activeUnit.gridZ, activeUnit.elevation);
        desiredCamTarget.set(ux * 0.45, uy + 0.5, uz * 0.45);
        targetZoom = 1.24;
      } else if (cur.cameraPreset === 'overhead') {
        desiredCamTarget.set(0, 0.4, 0);
        targetZoom = 0.88;
      } else {
        // Default Fixed Isometric View framing the entire 10x10 tactical diamond & Obelisk
        desiredCamTarget.set(0, 0.4, 0);
        targetZoom = 1.02;
      }

      const camDamp = 1 - Math.exp(-7.5 * dt);
      camTarget.lerp(desiredCamTarget, camDamp);
      currentIsoZoom = THREE.MathUtils.lerp(currentIsoZoom, targetZoom, camDamp);
      if (Math.abs(camera.zoom - currentIsoZoom) > 0.001) {
        camera.zoom = currentIsoZoom;
        camera.updateProjectionMatrix();
      }

      // Decaying trauma*trauma camera shake on heavy impacts while keeping isometric angle fixed
      trauma = Math.max(0, trauma - dt * 1.8);
      const shakeAmt = trauma * trauma * 0.32;
      camera.position.set(
        camTarget.x + ISO_OFFSET.x + (Math.random() - 0.5) * shakeAmt,
        camTarget.y + ISO_OFFSET.y + (Math.random() - 0.5) * shakeAmt,
        camTarget.z + ISO_OFFSET.z + (Math.random() - 0.5) * shakeAmt
      );
      camera.lookAt(camTarget);

      renderer.render(scene, camera);

      if (isSoftwareGl) {
        afterDraw(tick);
      } else {
        frameId = requestAnimationFrame(tick);
      }
    }

    frameId = requestAnimationFrame(tick);

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      resizeObserver.disconnect();
      renderer.domElement.removeEventListener('pointermove', onPointerMove);
      renderer.domElement.removeEventListener('pointerdown', onPointerDown);

      for (const actor of unitActors.values()) {
        actor.healthBar.texture.dispose();
        actor.healthBar.sprite.material.dispose();
        if (actor.trailGeo) actor.trailGeo.dispose();
        if (actor.weaponTrailMesh) {
          (actor.weaponTrailMesh.material as THREE.Material).dispose();
        }
      }

      shockwavePool.forEach((sw) => {
        sw.mesh.geometry.dispose();
        (sw.mesh.material as THREE.Material).dispose();
      });

      renderer.dispose();
    };
  }, []);

  return (
    <div
      ref={mountRef}
      data-testid="tactical-3d-canvas"
      className="fixed inset-0 w-screen h-screen overflow-hidden bg-[#0b0a0e]"
    >
      {/* In-Arena Accessible & Inspectable Health Bar Overlay */}
      <div
        data-testid="arena-healthbars-overlay"
        className="pointer-events-none absolute inset-0 z-10 overflow-hidden"
        aria-hidden="true"
      >
        {units.map((unit) => (
          <div
            key={unit.id}
            data-testid={`arena-healthbar-${unit.id}`}
            data-faction={unit.faction}
            data-hp={Math.round(unit.hp)}
            data-max-hp={unit.maxHp}
            className="sr-only"
          >
            {unit.name} ({unit.faction}): {Math.round(unit.hp)}/{unit.maxHp} HP
          </div>
        ))}
      </div>
    </div>
  );
};
