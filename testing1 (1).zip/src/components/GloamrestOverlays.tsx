import React, { useMemo, useState } from 'react';
import {
  CharacterCreationBuild,
  CombatUnit,
  CompanionId,
  CompanionRelationship,
  SkillCheckResult,
  getCompanionSynergyBonus,
  getStatModifier,
} from '../game/rules';
import {
  GloamrestSaveState,
  TimeOfDayPhase,
} from '../game/gloamrestEngineTypes';
import {
  GLOAMREST_ITEMS,
  GLOAMREST_MERCHANTS,
  GLOAMREST_QUESTS,
  MerchantId,
  QuestId,
  RARITY_COLOR_MAP,
} from '../game/gloamrestItemsAndQuests';
import {
  BUILDING_EXTERIORS,
  DistrictId,
  GLOAMREST_DISTRICTS,
  GLOAMREST_INTERIORS,
  InteriorId,
  TOWN_GRID_SIZE,
  generateGloamrestExteriorGrid,
} from '../game/gloamrestMapAndInteriors';
import {
  GLOAMREST_NPCS,
  ResolvedTownDialogue,
  TownDialogueChoice,
  getNpcActiveSchedule,
} from '../game/gloamrestNpcsAndDialogue';
import {
  computeUnitGearBonuses,
  getAvailableMerchantStock,
  getItemSellPrice,
} from '../game/gloamrestEngine';
import {
  CharacterPortraitSvg,
  D20DieSvg,
  ItemIconSvg,
} from './PortraitsAndIcons';
import { NearbyInteractionPrompt } from './GloamrestWorld3D';

// ============================================================================
// 1. PERSISTENT GLOAMREST EXPLORATION HUD OVERLAY
// ============================================================================

interface GloamrestHudOverlayProps {
  gloamrestState: GloamrestSaveState;
  partyUnits: CombatUnit[];
  nearbyPrompt: NearbyInteractionPrompt | null;
  bannerMessage: string;
  cameraPreset: 'tactical' | 'close' | 'overhead';
  isMuted: boolean;
  onSetCameraPreset: (preset: 'tactical' | 'close' | 'overhead') => void;
  onTriggerNearbyInteract: () => void;
  onAdvanceWatchTime: () => void;
  onOpenMap: () => void;
  onOpenInventory: () => void;
  onOpenQuestJournal: () => void;
  onOpenSkillMenu: () => void;
  onOpenTower?: () => void;
  onOpenCamp: () => void;
  onOpenInspect: () => void;
  onQuickSave: () => void;
  onToggleMute: () => void;
  onPause: () => void;
}

const TIME_ICONS: Record<TimeOfDayPhase, string> = {
  morning: '☀ Morning',
  afternoon: '🌤 Afternoon',
  evening: '🌇 Evening',
  night: '🌙 Night',
};

const THREAT_LABELS: Record<
  GloamrestSaveState['townThreatPhase'],
  { label: string; color: string }
> = {
  peaceful: { label: 'Quiet Hearth', color: '#7E9C82' },
  uneasy: { label: 'Heightened Watch', color: '#E2B05A' },
  astral_resonance: { label: 'Well Resonance', color: '#60A5FA' },
  fortified: { label: 'Vale Alert', color: '#B85349' },
};

export const GloamrestHudOverlay: React.FC<GloamrestHudOverlayProps> = ({
  gloamrestState,
  partyUnits,
  nearbyPrompt,
  bannerMessage,
  cameraPreset,
  isMuted,
  onSetCameraPreset,
  onTriggerNearbyInteract,
  onAdvanceWatchTime,
  onOpenMap,
  onOpenInventory,
  onOpenQuestJournal,
  onOpenSkillMenu,
  onOpenTower,
  onOpenCamp,
  onOpenInspect,
  onQuickSave,
  onToggleMute,
  onPause,
}) => {
  const exteriorGrid = useMemo(() => generateGloamrestExteriorGrid(), []);
  const currentLocationLabel = useMemo(() => {
    if (gloamrestState.currentSceneId !== 'exterior') {
      return GLOAMREST_INTERIORS[gloamrestState.currentSceneId as InteriorId].name;
    }
    const rx = Math.round(gloamrestState.playerPos.x);
    const rz = Math.round(gloamrestState.playerPos.z);
    const distId = exteriorGrid[rx]?.[rz]?.districtId;
    if (distId) return `Gloamrest · ${GLOAMREST_DISTRICTS[distId].name}`;
    return 'Gloamrest · Whispering Vale';
  }, [gloamrestState.currentSceneId, gloamrestState.playerPos, exteriorGrid]);

  const trackedQuestDef = GLOAMREST_QUESTS[gloamrestState.activeTrackedQuestId];
  const trackedQuestState = gloamrestState.quests[gloamrestState.activeTrackedQuestId];
  const threatMeta = THREAT_LABELS[gloamrestState.townThreatPhase];

  const activeQuestCount = (Object.values(gloamrestState.quests) as GloamrestSaveState['quests'][QuestId][]).filter(
    (q) => q.status === 'active'
  ).length;

  return (
    <div
      data-testid="gloamrest-hud-overlay"
      className="fixed inset-0 z-20 pointer-events-none flex flex-col justify-between p-4"
    >
      {/* ==================== TOP BAR: LOCATION + QUEST TRACKER & UTILITY BUTTONS ==================== */}
      <div className="flex flex-col lg:flex-row items-start justify-between gap-3">
        {/* Top-Left Location, World Clock & Active Quest Tracker */}
        <div
          style={{ backgroundColor: 'rgba(23, 27, 25, 0.94)', borderColor: '#5A4B38' }}
          className="pointer-events-auto rounded-lg border px-4 py-2.5 shadow-xl max-w-md space-y-2"
        >
          <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1">
            <span
              data-testid="gloamrest-location-title"
              className="font-display font-bold text-sm tracking-wide"
              style={{ color: '#F2ECE1' }}
            >
              {currentLocationLabel}
            </span>
            <span style={{ color: '#5A4B38' }}>·</span>
            <span className="text-xs font-mono" style={{ color: '#E2B05A' }}>
              Day {gloamrestState.dayCount} · {TIME_ICONS[gloamrestState.timeOfDay]}
            </span>
            <button
              type="button"
              data-testid="advance-time-btn"
              onClick={onAdvanceWatchTime}
              title="Advance time of day to observe NPC daily schedules and lighting changes"
              style={{
                backgroundColor: '#222722',
                borderColor: '#5A4B38',
                color: '#B5AC9A',
              }}
              className="px-1.5 py-0.5 rounded border text-[10px] font-mono hover:border-[#E2B05A] hover:text-[#F2ECE1] transition-colors cursor-pointer"
            >
              ⏳ Pass Watch
            </button>
          </div>

          <div className="flex items-center justify-between text-[11px] font-mono border-t border-[#5A4B38]/45 pt-1.5">
            <span style={{ color: threatMeta.color }}>
              ◆ Town State: {threatMeta.label}
            </span>
            <span style={{ color: '#E2B05A' }} data-testid="hud-gold-counter">
              ⬡ {gloamrestState.inventory.gold} Gold
            </span>
          </div>

          {/* Active Tracked Quest Objective */}
          {trackedQuestDef && trackedQuestState && (
            <div
              data-testid="hud-quest-tracker"
              onClick={onOpenQuestJournal}
              style={{ backgroundColor: '#222722', borderColor: '#5A4B38' }}
              className="rounded border px-2.5 py-2 cursor-pointer hover:border-[#E2B05A] transition-colors"
            >
              <div className="flex items-center justify-between gap-2">
                <span className="text-[10px] font-mono uppercase tracking-wider text-[#E2B05A]">
                  {trackedQuestDef.code}
                </span>
                <span className="text-[10px] font-mono text-[#7E9C82]">
                  {trackedQuestState.status === 'completed' ? 'COMPLETED' : 'ACTIVE [J]'}
                </span>
              </div>
              <p className="text-xs font-display font-semibold text-[#F2ECE1] mt-0.5">
                {trackedQuestDef.title}
              </p>
              <ul className="mt-1 space-y-0.5">
                {trackedQuestDef.steps.slice(0, 5).map((st) => {
                  const done = trackedQuestState.completedStepIds.includes(st.id);
                  return (
                    <li
                      key={st.id}
                      className="text-[11px] flex items-start gap-1.5 leading-snug"
                      style={{ color: done ? '#77796F' : '#B5AC9A' }}
                    >
                      <span style={{ color: done ? '#7E9C82' : '#E2B05A' }}>
                        {done ? '✓' : '▸'}
                      </span>
                      <span className={done ? 'line-through' : ''}>{st.label}</span>
                    </li>
                  );
                })}
              </ul>
            </div>
          )}
        </div>

        {/* Top-Right Settlement Action Cluster */}
        <div className="pointer-events-auto flex flex-wrap items-center justify-end gap-2">
          <div
            className="hidden xl:flex items-center gap-0.5 p-1 rounded-md border border-[#5A4B38]"
            style={{ backgroundColor: '#171B19' }}
          >
            {(
              [
                { id: 'tactical', label: 'ISO 1x' },
                { id: 'close', label: 'Close' },
                { id: 'overhead', label: 'Wide' },
              ] as const
            ).map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => onSetCameraPreset(p.id)}
                style={{
                  backgroundColor: cameraPreset === p.id ? '#3A3324' : 'transparent',
                  color: cameraPreset === p.id ? '#E2B05A' : '#B5AC9A',
                }}
                className="px-2 py-1 text-[11px] font-mono rounded cursor-pointer hover:text-[#F2ECE1]"
              >
                {p.label}
              </button>
            ))}
          </div>

          <button
            type="button"
            data-testid="open-town-map-btn"
            onClick={onOpenMap}
            style={{ backgroundColor: '#171B19', borderColor: '#5A4B38', color: '#E2B05A' }}
            className="px-3 py-2 rounded-md border hover:border-[#E2B05A] text-xs font-semibold cursor-pointer"
          >
            Town Map [M]
          </button>

          <button
            type="button"
            data-testid="open-inventory-btn"
            onClick={onOpenInventory}
            style={{ backgroundColor: '#171B19', borderColor: '#5A4B38', color: '#F2ECE1' }}
            className="px-3 py-2 rounded-md border hover:border-[#E2B05A] text-xs font-semibold cursor-pointer"
          >
            Inventory [B]
          </button>

          <button
            type="button"
            data-testid="open-quests-btn"
            onClick={onOpenQuestJournal}
            style={{ backgroundColor: '#171B19', borderColor: '#5A4B38', color: '#F2ECE1' }}
            className="px-3 py-2 rounded-md border hover:border-[#E2B05A] text-xs font-semibold cursor-pointer"
          >
            Quests ({activeQuestCount}) [J]
          </button>

          <button
            type="button"
            onClick={onOpenSkillMenu}
            style={{ backgroundColor: '#171B19', borderColor: '#5A4B38', color: '#F2ECE1' }}
            className="px-3 py-2 rounded-md border hover:border-[#E2B05A] text-xs font-semibold cursor-pointer"
          >
            Skills [K]
          </button>

          {onOpenTower && (
            <button
              type="button"
              onClick={onOpenTower}
              style={{ backgroundColor: '#261F18', borderColor: '#E2B05A', color: '#E2B05A' }}
              className="px-3 py-2 rounded-md border hover:border-[#F59E0B] text-xs font-semibold cursor-pointer shadow-sm"
            >
              Tower [T]
            </button>
          )}

          <button
            type="button"
            onClick={onOpenCamp}
            style={{ backgroundColor: '#171B19', borderColor: '#5A4B38', color: '#F2ECE1' }}
            className="px-3 py-2 rounded-md border hover:border-[#E2B05A] text-xs font-semibold cursor-pointer"
          >
            Camp [C]
          </button>

          <button
            type="button"
            onClick={onOpenInspect}
            style={{ backgroundColor: '#171B19', borderColor: '#5A4B38', color: '#F2ECE1' }}
            className="px-3 py-2 rounded-md border hover:border-[#E2B05A] text-xs font-semibold cursor-pointer"
          >
            Inspect [I]
          </button>

          <button
            type="button"
            data-testid="quick-save-town-btn"
            onClick={onQuickSave}
            style={{ backgroundColor: '#222722', borderColor: '#5A4B38', color: '#7E9C82' }}
            className="px-3 py-2 rounded-md border hover:border-[#E2B05A] text-xs font-mono cursor-pointer"
          >
            Save [F5]
          </button>

          <button
            type="button"
            onClick={onToggleMute}
            style={{ backgroundColor: '#171B19', borderColor: '#5A4B38', color: '#B5AC9A' }}
            className="w-9 h-9 flex items-center justify-center rounded-md border hover:border-[#E2B05A] text-xs font-mono cursor-pointer"
          >
            {isMuted ? '✕' : '♪'}
          </button>

          <button
            type="button"
            onClick={onPause}
            style={{ backgroundColor: '#171B19', borderColor: '#5A4B38', color: '#B5AC9A' }}
            className="w-9 h-9 flex items-center justify-center rounded-md border hover:border-[#E2B05A] text-xs font-mono cursor-pointer"
          >
            P
          </button>
        </div>
      </div>

      {/* ==================== BOTTOM EXPLORATION PROMPT & COMPACT PARTY BAR ==================== */}
      <div className="mx-auto w-full max-w-[920px] flex flex-col items-center gap-2">
        {/* Contextual Spatial Interaction Button when adjacent to NPC, Door, Chest, Herb, Well */}
        {nearbyPrompt && (
          <button
            type="button"
            data-testid="spatial-interact-prompt"
            onClick={onTriggerNearbyInteract}
            style={{
              backgroundColor: '#3A3324',
              borderColor: '#E2B05A',
              color: '#F2ECE1',
            }}
            className="pointer-events-auto px-5 py-2 rounded-md border shadow-[0_8px_28px_rgba(0,0,0,0.85)] flex items-center gap-3 hover:brightness-110 transition-all cursor-pointer"
          >
            <span
              style={{ backgroundColor: '#E2B05A', color: '#171B19' }}
              className="px-2 py-0.5 rounded text-xs font-mono font-bold"
            >
              E
            </span>
            <div className="text-left">
              <p className="text-xs font-display font-bold tracking-wide text-[#F2ECE1]">
                {nearbyPrompt.promptLabel}
              </p>
              {nearbyPrompt.roleOrSubtitle && (
                <p className="text-[11px] text-[#B5AC9A]">{nearbyPrompt.roleOrSubtitle}</p>
              )}
            </div>
          </button>
        )}

        {/* Narrative / Exploration Feedback Ticker */}
        <div
          data-testid="gloamrest-banner-ticker"
          style={{ backgroundColor: '#171B19', borderColor: '#5A4B38', color: '#F2ECE1' }}
          className="pointer-events-auto px-4 py-1.5 rounded border text-xs shadow-lg max-w-2xl text-center"
        >
          {bannerMessage}
        </div>

        {/* Party Vitality & Controls Bar */}
        <div
          style={{ backgroundColor: 'rgba(23, 27, 25, 0.95)', borderColor: '#5A4B38' }}
          className="pointer-events-auto w-full rounded-lg border px-4 py-2 flex flex-wrap items-center justify-between gap-3 shadow-2xl"
        >
          <div className="flex flex-wrap items-center gap-3">
            {partyUnits.map((u) => {
              const hpPct = Math.max(0, Math.min(100, Math.round((u.hp / u.maxHp) * 100)));
              return (
                <div
                  key={u.id}
                  style={{ backgroundColor: '#222722', borderColor: '#5A4B38' }}
                  className="flex items-center gap-2 px-2.5 py-1.5 rounded border"
                >
                  <CharacterPortraitSvg
                    id={u.companionId ?? 'seraphina'}
                    className="w-8 h-8 rounded border border-[#5A4B38] shrink-0"
                  />
                  <div className="min-w-[96px]">
                    <div className="flex items-center justify-between gap-2 text-xs">
                      <span className="font-display font-semibold text-[#F2ECE1] truncate">
                        {u.name.split(' ')[0]}
                      </span>
                      <span className="font-mono text-[11px] text-[#7E9C82]">
                        {Math.round(u.hp)}/{u.maxHp}
                      </span>
                    </div>
                    <div className="w-full h-1.5 rounded-full bg-[#171B19] overflow-hidden mt-1">
                      <div
                        className="h-full transition-all"
                        style={{ width: `${hpPct}%`, backgroundColor: '#7E9C82' }}
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="text-[11px] font-mono text-[#B5AC9A]">
            WASD / Click Ground to Walk · Click NPC or Door / Press [E] to Interact
          </div>
        </div>
      </div>
    </div>
  );
};

// ============================================================================
// 2. GLOAMREST INTERACTIVE TOWN MAP MODAL ('M' KEY — NO FAST TRAVEL, NO SECRET SPOILERS)
// ============================================================================

import { GloamrestSettlementMapModal } from './GloamrestSettlementMapModal';

export interface GloamrestMapModalProps {
  gloamrestState: GloamrestSaveState;
  onClose: () => void;
  onTrackQuest?: (questId: any) => void;
}

export const GloamrestMapModal: React.FC<GloamrestMapModalProps> = ({
  gloamrestState,
  onClose,
  onTrackQuest,
}) => {
  return (
    <GloamrestSettlementMapModal
      gloamrestState={gloamrestState}
      onClose={onClose}
      onTrackQuest={onTrackQuest}
    />
  );
};
export { GloamrestSettlementMapModal };

// ============================================================================
// 3. CONTEXTUAL TOWN NPC DIALOGUE & D20 SKILL CHECK MODAL
// ============================================================================

interface GloamrestDialogueModalProps {
  dialogue: ResolvedTownDialogue;
  partyUnits: CombatUnit[];
  relationships: Record<CompanionId, CompanionRelationship>;
  onSelectChoice: (choice: TownDialogueChoice) => {
    replyText: string;
    skillCheckResult?: SkillCheckResult;
    closesDialogue: boolean;
  };
  onClose: () => void;
}

export const GloamrestDialogueModal: React.FC<GloamrestDialogueModalProps> = ({
  dialogue,
  partyUnits,
  relationships,
  onSelectChoice,
  onClose,
}) => {
  const [lastOutcome, setLastOutcome] = useState<{
    choice: TownDialogueChoice;
    replyText: string;
    roll?: SkillCheckResult;
    closesDialogue: boolean;
  } | null>(null);

  return (
    <div
      role="dialog"
      aria-modal="true"
      data-testid="gloamrest-dialogue-modal"
      className="fixed inset-0 z-40 flex items-center justify-center p-4 pointer-events-auto"
      style={{ backgroundColor: 'rgba(10, 12, 11, 0.8)' }}
    >
      <div
        style={{ backgroundColor: '#171B19', borderColor: '#5A4B38', color: '#F2ECE1' }}
        className="w-full max-w-3xl rounded-lg border p-6 shadow-2xl space-y-4 max-h-[88vh] overflow-y-auto"
      >
        {/* Speaker Header */}
        <div className="flex items-center justify-between gap-4 pb-3 border-b border-[#5A4B38]">
          <div className="flex items-center gap-3.5">
            <CharacterPortraitSvg
              id={dialogue.portraitId}
              className="w-16 h-16 rounded-md border border-[#E2B05A] shrink-0"
            />
            <div>
              <p className="text-[11px] font-mono text-[#E2B05A]">{dialogue.locationLabel}</p>
              <h2 className="text-xl font-display font-bold text-[#F2ECE1]">
                {dialogue.speakerName}
              </h2>
              <p className="text-xs text-[#B5AC9A]">
                {dialogue.speakerRole} · <span className="italic">{dialogue.activityStatus}</span>
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            style={{ backgroundColor: '#222722', borderColor: '#5A4B38', color: '#B5AC9A' }}
            className="px-3 py-1.5 rounded border hover:border-[#E2B05A] hover:text-[#F2ECE1] text-xs font-mono cursor-pointer"
          >
            Leave [Esc]
          </button>
        </div>

        {/* Greeting or Latest Reply */}
        <div
          style={{ backgroundColor: '#222722', borderColor: '#5A4B38' }}
          className="rounded-md border p-4 space-y-3"
        >
          {lastOutcome?.roll && (
            <div className="flex items-center gap-4 pb-3 border-b border-[#5A4B38]/60">
              <D20DieSvg
                value={lastOutcome.roll.d20Roll}
                variant={lastOutcome.roll.success ? 'emerald' : 'crimson'}
                className="w-14 h-14 shrink-0"
              />
              <div>
                <p className="text-xs font-mono text-[#B5AC9A]">
                  {lastOutcome.choice.skillCheck?.skillName} Check (DC {lastOutcome.roll.dc})
                </p>
                <p
                  className="text-base font-display font-bold"
                  style={{ color: lastOutcome.roll.success ? '#7E9C82' : '#B85349' }}
                >
                  {lastOutcome.roll.critical
                    ? 'Critical Success! (Natural 20)'
                    : lastOutcome.roll.success
                    ? `Check Succeeded (${lastOutcome.roll.total} vs DC ${lastOutcome.roll.dc})`
                    : `Check Resisted (${lastOutcome.roll.total} vs DC ${lastOutcome.roll.dc})`}
                </p>
                <p className="text-[11px] font-mono text-[#B5AC9A]">
                  D20 ({lastOutcome.roll.d20Roll}) + Stat (
                  {lastOutcome.roll.statMod >= 0
                    ? `+${lastOutcome.roll.statMod}`
                    : lastOutcome.roll.statMod}
                  ) + Bond (+{lastOutcome.roll.synergyMod}) = {lastOutcome.roll.total}
                </p>
              </div>
            </div>
          )}

          <p className="text-sm leading-relaxed text-[#F2ECE1]">
            {lastOutcome ? lastOutcome.replyText : dialogue.greetingText}
          </p>
        </div>

        {/* Companion Interjections */}
        {!lastOutcome && dialogue.companionInterjections.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
            {dialogue.companionInterjections.map((inter) => {
              const comp = relationships[inter.companionId];
              return (
                <div
                  key={inter.companionId}
                  style={{ backgroundColor: '#222722', borderColor: '#5A4B38' }}
                  className="p-2.5 rounded border flex items-start gap-2.5"
                >
                  <CharacterPortraitSvg
                    id={inter.companionId}
                    className="w-8 h-8 rounded shrink-0 mt-0.5"
                  />
                  <div className="min-w-0">
                    <p className="text-[11px] font-semibold text-[#E2B05A]">
                      {comp.name} · Bond {comp.approval}/100
                    </p>
                    <p className="text-xs italic text-[#B5AC9A] leading-snug">{inter.quote}</p>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Dialogue Choices */}
        <div className="space-y-2">
          {dialogue.choices.map((ch, idx) => {
            let checkLabel = '';
            if (ch.skillCheck) {
              const spk =
                partyUnits.find((u) => u.companionId === ch.skillCheck!.speakerId) ??
                partyUnits[0];
              const statMod = spk ? getStatModifier(spk.stats[ch.skillCheck.stat]) : 2;
              const synMod = getCompanionSynergyBonus(
                relationships[ch.skillCheck.speakerId].approval
              ).attackBonus;
              const ctxBonus = ch.skillCheck.contextualBonusValue ?? 0;
              const effDc = Math.max(5, ch.skillCheck.dc - ctxBonus);
              const totalBonus = statMod + synMod;
              checkLabel = `${ch.skillCheck.skillName} (${ch.skillCheck.stat.toUpperCase()}) · DC ${effDc} · ${
                totalBonus >= 0 ? `+${totalBonus}` : totalBonus
              }`;
            }

            return (
              <button
                key={ch.id}
                type="button"
                data-testid={`town-dialogue-choice-${ch.id}`}
                onClick={() => {
                  const res = onSelectChoice(ch);
                  if (res.closesDialogue && !res.skillCheckResult) {
                    return;
                  }
                  setLastOutcome({
                    choice: ch,
                    replyText: res.replyText,
                    roll: res.skillCheckResult,
                    closesDialogue: res.closesDialogue,
                  });
                }}
                style={{ backgroundColor: '#292E29', borderColor: '#5A4B38' }}
                className="w-full text-left p-3 rounded border hover:border-[#E2B05A] hover:bg-[#3A3324] transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-2 cursor-pointer"
              >
                <div className="flex items-start gap-2.5">
                  <span className="text-xs font-mono font-bold text-[#E2B05A]">
                    {idx + 1}.
                  </span>
                  <span className="text-xs sm:text-sm text-[#F2ECE1]">
                    {ch.contextTag && (
                      <span className="font-mono text-xs text-[#7E9C82] mr-1.5">
                        {ch.contextTag}
                      </span>
                    )}
                    {ch.text}
                  </span>
                </div>
                {checkLabel && (
                  <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-[#171B19] border border-[#5A4B38] text-[#E2B05A] shrink-0">
                    🎲 {checkLabel}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};

// ============================================================================
// 4. MERCHANT ECONOMY & PARTY INVENTORY / EQUIPMENT MODAL ('B' KEY)
// ============================================================================

interface GloamrestInventoryAndMerchantModalProps {
  gloamrestState: GloamrestSaveState;
  activeMerchantId: MerchantId | null;
  partyUnits: CombatUnit[];
  characterBuild: CharacterCreationBuild;
  statusNotice: string | null;
  onBuyItem: (merchantId: MerchantId, itemId: string) => void;
  onSellItem: (merchantId: MerchantId, itemId: string) => void;
  onEquipItem: (unitId: string, itemId: string) => void;
  onUseConsumable: (itemId: string, unitId: string) => void;
  onRepairAll: () => void;
  onRentRoomRest: () => void;
  onClose: () => void;
}

export const GloamrestInventoryAndMerchantModal: React.FC<
  GloamrestInventoryAndMerchantModalProps
> = ({
  gloamrestState,
  activeMerchantId,
  partyUnits,
  statusNotice,
  onBuyItem,
  onSellItem,
  onEquipItem,
  onUseConsumable,
  onRepairAll,
  onRentRoomRest,
  onClose,
}) => {
  const [selectedUnitId, setSelectedUnitId] = useState<string>(
    partyUnits[0]?.id ?? 'seraphina'
  );
  const [selectedItemId, setSelectedItemId] = useState<string>(
    gloamrestState.inventory.items[0]?.itemId ?? 'ironroot_longsword'
  );

  const activeUnit =
    partyUnits.find((u) => u.id === selectedUnitId) ?? partyUnits[0];
  const unitGear = gloamrestState.inventory.equippedByUnit[selectedUnitId] ?? {};
  const gearBonuses = computeUnitGearBonuses(unitGear);

  const merchantDef = activeMerchantId ? GLOAMREST_MERCHANTS[activeMerchantId] : null;
  const merchantStock = useMemo(
    () =>
      activeMerchantId
        ? getAvailableMerchantStock(gloamrestState, activeMerchantId)
        : [],
    [gloamrestState, activeMerchantId]
  );

  const inspectedItem = GLOAMREST_ITEMS[selectedItemId];

  return (
    <div
      role="dialog"
      aria-modal="true"
      data-testid="gloamrest-inventory-modal"
      className="fixed inset-0 z-40 flex items-center justify-center p-4 pointer-events-auto"
      style={{ backgroundColor: 'rgba(10, 12, 11, 0.84)' }}
    >
      <div
        style={{ backgroundColor: '#171B19', borderColor: '#5A4B38', color: '#F2ECE1' }}
        className="w-full max-w-6xl rounded-lg border p-5 shadow-2xl space-y-4 max-h-[88vh] overflow-y-auto"
      >
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-4 pb-3 border-b border-[#5A4B38]">
          <div>
            <p className="text-xs font-mono uppercase tracking-widest text-[#E2B05A]">
              {merchantDef ? `${merchantDef.districtName} · Merchant Exchange` : 'Party Outfitting & Pack'}
            </p>
            <h2 className="text-xl font-display font-bold text-[#F2ECE1]">
              {merchantDef ? merchantDef.shopName : 'Party Equipment & Inventory'}
            </h2>
            {merchantDef && (
              <p className="text-xs text-[#B5AC9A]">
                Proprietor: {merchantDef.ownerName} — {merchantDef.subtitle}
              </p>
            )}
          </div>

          <div className="flex items-center gap-3">
            <span
              data-testid="merchant-gold-display"
              className="px-3 py-1.5 rounded border border-[#E2B05A]/60 bg-[#222722] text-xs font-mono font-bold text-[#E2B05A]"
            >
              ⬡ {gloamrestState.inventory.gold} Gold
            </span>
            {merchantDef?.supportsRepair && (
              <button
                type="button"
                data-testid="forge-repair-btn"
                onClick={onRepairAll}
                style={{ backgroundColor: '#3A3324', borderColor: '#E2B05A', color: '#F2ECE1' }}
                className="px-3 py-1.5 rounded border text-xs font-mono cursor-pointer hover:brightness-110"
              >
                ⚒ Repair Gear (8g / Kit)
              </button>
            )}
            {merchantDef?.supportsRoomRest && (
              <button
                type="button"
                data-testid="tavern-rent-room-btn"
                onClick={onRentRoomRest}
                style={{ backgroundColor: '#3A3324', borderColor: '#E2B05A', color: '#F2ECE1' }}
                className="px-3 py-1.5 rounded border text-xs font-mono cursor-pointer hover:brightness-110"
              >
                🛏 Rent Room & Rest ({merchantDef.roomRestCost}g)
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              style={{ backgroundColor: '#222722', borderColor: '#5A4B38', color: '#F2ECE1' }}
              className="px-3.5 py-1.5 rounded border hover:border-[#E2B05A] text-xs font-mono cursor-pointer"
            >
              Close [Esc]
            </button>
          </div>
        </div>

        {statusNotice && (
          <div
            style={{ backgroundColor: '#222722', borderColor: '#7E9C82', color: '#F2ECE1' }}
            className="px-3.5 py-2 rounded border text-xs font-mono"
          >
            ◆ {statusNotice}
          </div>
        )}

        {/* Companion Selector */}
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs font-mono text-[#B5AC9A] mr-1">Outfit Companion:</span>
          {partyUnits.map((u) => {
            const active = u.id === selectedUnitId;
            return (
              <button
                key={u.id}
                type="button"
                onClick={() => setSelectedUnitId(u.id)}
                style={{
                  backgroundColor: active ? '#3A3324' : '#222722',
                  borderColor: active ? '#E2B05A' : '#5A4B38',
                }}
                className="px-3 py-1.5 rounded border flex items-center gap-2 cursor-pointer"
              >
                <CharacterPortraitSvg
                  id={u.companionId ?? 'seraphina'}
                  className="w-6 h-6 rounded"
                />
                <span className="text-xs font-display font-semibold text-[#F2ECE1]">
                  {u.name}
                </span>
                <span className="text-[11px] font-mono text-[#7E9C82]">
                  HP {Math.round(u.hp)}/{u.maxHp} · AC {u.armorClass}
                </span>
              </button>
            );
          })}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* LEFT COLUMN (5 cols): Either Merchant Stock OR Character Equipment Paperdoll */}
          <div
            style={{ backgroundColor: '#222722', borderColor: '#5A4B38' }}
            className="lg:col-span-5 rounded-md border p-4 space-y-3"
          >
            {merchantDef && activeMerchantId ? (
              <>
                <h3 className="text-sm font-display font-bold text-[#E2B05A]">
                  Merchant Wares ({merchantStock.length} Items)
                </h3>
                <div className="space-y-2 max-h-[370px] overflow-y-auto pr-1 dim-scroll">
                  {merchantStock.map(({ item, quantity, buyPrice }) => {
                    const rarityHex = RARITY_COLOR_MAP[item.rarity];
                    const selected = selectedItemId === item.id;
                    return (
                      <div
                        key={item.id}
                        data-testid={`merchant-item-${item.id}`}
                        onClick={() => setSelectedItemId(item.id)}
                        style={{
                          backgroundColor: selected ? '#3A3324' : '#292E29',
                          borderColor: selected ? '#E2B05A' : '#5A4B38',
                        }}
                        className="p-2.5 rounded border flex items-center justify-between gap-2.5 cursor-pointer"
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <ItemIconSvg
                            kind={item.iconKind}
                            rarityColor={rarityHex}
                            className="w-9 h-9 shrink-0"
                          />
                          <div className="min-w-0">
                            <p
                              className="text-xs font-display font-semibold truncate"
                              style={{ color: rarityHex }}
                            >
                              {item.name}
                            </p>
                            <p className="text-[11px] text-[#B5AC9A] truncate">
                              {item.category.toUpperCase()} · Stock: {quantity}
                            </p>
                          </div>
                        </div>

                        <button
                          type="button"
                          data-testid={`buy-btn-${item.id}`}
                          disabled={quantity <= 0 || gloamrestState.inventory.gold < buyPrice}
                          onClick={(e) => {
                            e.stopPropagation();
                            onBuyItem(activeMerchantId, item.id);
                          }}
                          style={{
                            backgroundColor: '#E2B05A',
                            color: '#171B19',
                          }}
                          className="px-2.5 py-1 rounded text-xs font-mono font-bold disabled:opacity-40 cursor-pointer shrink-0"
                        >
                          Buy {buyPrice}g
                        </button>
                      </div>
                    );
                  })}
                </div>
              </>
            ) : (
              <>
                <h3 className="text-sm font-display font-bold text-[#E2B05A]">
                  {activeUnit?.name} — Equipped Loadout
                </h3>
                <div className="grid grid-cols-2 gap-2.5">
                  {(['weapon', 'armor', 'shield', 'accessory'] as const).map((slot) => {
                    const eqId = unitGear[slot];
                    const eqDef = eqId ? GLOAMREST_ITEMS[eqId] : null;
                    return (
                      <div
                        key={slot}
                        onClick={() => eqId && setSelectedItemId(eqId)}
                        style={{ backgroundColor: '#292E29', borderColor: '#5A4B38' }}
                        className="p-2.5 rounded border space-y-1 cursor-pointer hover:border-[#E2B05A]"
                      >
                        <p className="text-[10px] font-mono uppercase text-[#77796F]">{slot}</p>
                        {eqDef ? (
                          <div className="flex items-center gap-2">
                            <ItemIconSvg
                              kind={eqDef.iconKind}
                              rarityColor={RARITY_COLOR_MAP[eqDef.rarity]}
                              className="w-8 h-8 shrink-0"
                            />
                            <span className="text-xs font-semibold text-[#F2ECE1] leading-tight">
                              {eqDef.name}
                            </span>
                          </div>
                        ) : (
                          <p className="text-xs italic text-[#77796F]">Empty Slot</p>
                        )}
                      </div>
                    );
                  })}
                </div>

                <div
                  style={{ backgroundColor: '#171B19', borderColor: '#5A4B38' }}
                  className="p-3 rounded border text-xs font-mono space-y-1"
                >
                  <p className="text-[#E2B05A] font-semibold">Active Equipment Bonuses:</p>
                  <p className="text-[#B5AC9A]">
                    AC +{gearBonuses.acBonus} · Max HP +{gearBonuses.maxHpBonus} · Weapon DMG +
                    {gearBonuses.damageBonus} · Attack +{gearBonuses.attackBonus}
                  </p>
                </div>
              </>
            )}
          </div>

          {/* CENTER COLUMN (4 cols): Party Inventory Pack */}
          <div
            style={{ backgroundColor: '#222722', borderColor: '#5A4B38' }}
            className="lg:col-span-4 rounded-md border p-4 space-y-3"
          >
            <h3 className="text-sm font-display font-bold text-[#F2ECE1]">
              Party Pack ({gloamrestState.inventory.items.length} Stacks)
            </h3>
            <div className="space-y-2 max-h-[370px] overflow-y-auto pr-1 dim-scroll">
              {gloamrestState.inventory.items.map((stack, sIdx) => {
                const def = GLOAMREST_ITEMS[stack.itemId];
                if (!def) return null;
                const rarityHex = RARITY_COLOR_MAP[def.rarity];
                const isEquippedHere =
                  unitGear.weapon === def.id ||
                  unitGear.armor === def.id ||
                  unitGear.shield === def.id ||
                  unitGear.accessory === def.id;
                const isSelected = selectedItemId === def.id;

                return (
                  <div
                    key={`${stack.itemId}-${sIdx}`}
                    data-testid={`pack-item-${def.id}`}
                    onClick={() => setSelectedItemId(def.id)}
                    style={{
                      backgroundColor: isSelected ? '#3A3324' : '#292E29',
                      borderColor: isSelected ? '#E2B05A' : '#5A4B38',
                    }}
                    className="p-2.5 rounded border flex items-center justify-between gap-2 cursor-pointer"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <ItemIconSvg
                        kind={def.iconKind}
                        rarityColor={rarityHex}
                        className="w-8 h-8 shrink-0"
                      />
                      <div className="min-w-0">
                        <p
                          className="text-xs font-display font-semibold truncate"
                          style={{ color: rarityHex }}
                        >
                          {def.name} {stack.quantity > 1 ? `×${stack.quantity}` : ''}
                        </p>
                        <p className="text-[10px] font-mono text-[#B5AC9A]">
                          {isEquippedHere ? '★ EQUIPPED' : def.category.toUpperCase()}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      {def.equipSlot && (
                        <button
                          type="button"
                          data-testid={`equip-btn-${def.id}`}
                          onClick={(e) => {
                            e.stopPropagation();
                            onEquipItem(selectedUnitId, def.id);
                          }}
                          style={{
                            backgroundColor: isEquippedHere ? '#171B19' : '#222722',
                            borderColor: '#5A4B38',
                            color: '#E2B05A',
                          }}
                          className="px-2 py-1 rounded border text-[11px] font-mono cursor-pointer hover:border-[#E2B05A]"
                        >
                          {isEquippedHere ? 'Unequip' : 'Equip'}
                        </button>
                      )}
                      {def.category === 'consumable' && (
                        <button
                          type="button"
                          data-testid={`use-btn-${def.id}`}
                          onClick={(e) => {
                            e.stopPropagation();
                            onUseConsumable(def.id, selectedUnitId);
                          }}
                          style={{
                            backgroundColor: '#222722',
                            borderColor: '#7E9C82',
                            color: '#7E9C82',
                          }}
                          className="px-2 py-1 rounded border text-[11px] font-mono cursor-pointer"
                        >
                          Use
                        </button>
                      )}
                      {activeMerchantId && !def.questItem && (
                        <button
                          type="button"
                          data-testid={`sell-btn-${def.id}`}
                          onClick={(e) => {
                            e.stopPropagation();
                            onSellItem(activeMerchantId, def.id);
                          }}
                          style={{
                            backgroundColor: '#171B19',
                            borderColor: '#5A4B38',
                            color: '#B5AC9A',
                          }}
                          className="px-2 py-1 rounded border text-[11px] font-mono cursor-pointer hover:border-[#E2B05A]"
                        >
                          Sell {getItemSellPrice(def)}g
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* RIGHT COLUMN (3 cols): Item Inspector Details */}
          <div
            style={{ backgroundColor: '#222722', borderColor: '#5A4B38' }}
            className="lg:col-span-3 rounded-md border p-4 space-y-3"
          >
            {inspectedItem ? (
              <>
                <div className="flex items-center gap-3">
                  <ItemIconSvg
                    kind={inspectedItem.iconKind}
                    rarityColor={RARITY_COLOR_MAP[inspectedItem.rarity]}
                    className="w-12 h-12 shrink-0"
                  />
                  <div>
                    <p
                      className="text-sm font-display font-bold"
                      style={{ color: RARITY_COLOR_MAP[inspectedItem.rarity] }}
                    >
                      {inspectedItem.name}
                    </p>
                    <p className="text-[11px] font-mono uppercase text-[#B5AC9A]">
                      {inspectedItem.rarity} {inspectedItem.category}
                    </p>
                  </div>
                </div>

                <p className="text-xs leading-relaxed text-[#F2ECE1]/90">
                  {inspectedItem.description}
                </p>

                {inspectedItem.stats && (
                  <div
                    style={{ backgroundColor: '#171B19', borderColor: '#5A4B38' }}
                    className="p-2.5 rounded border text-xs font-mono space-y-1 text-[#7E9C82]"
                  >
                    {inspectedItem.stats.attackBonus && (
                      <p>+{inspectedItem.stats.attackBonus} Attack Bonus</p>
                    )}
                    {inspectedItem.stats.damageBonus && (
                      <p>+{inspectedItem.stats.damageBonus} Weapon Damage</p>
                    )}
                    {inspectedItem.stats.acBonus && (
                      <p>+{inspectedItem.stats.acBonus} Armor Class (AC)</p>
                    )}
                    {inspectedItem.stats.maxHpBonus && (
                      <p>+{inspectedItem.stats.maxHpBonus} Max Vitality</p>
                    )}
                  </div>
                )}

                {inspectedItem.consumableEffect && (
                  <div
                    style={{ backgroundColor: '#171B19', borderColor: '#5A4B38' }}
                    className="p-2.5 rounded border text-xs font-mono space-y-1 text-[#7E9C82]"
                  >
                    {inspectedItem.consumableEffect.healHp && (
                      <p>
                        Restores {inspectedItem.consumableEffect.healHp}{' '}
                        {inspectedItem.consumableEffect.partyWide ? 'Party HP' : 'HP'}
                      </p>
                    )}
                    {inspectedItem.consumableEffect.grantTempHp && (
                      <p>+{inspectedItem.consumableEffect.grantTempHp} Temporary HP</p>
                    )}
                    {inspectedItem.consumableEffect.cleanseDebuffs && (
                      <p>Purges Burning, Rooted & Sundered</p>
                    )}
                  </div>
                )}

                {inspectedItem.loreNote && (
                  <p className="text-[11px] italic text-[#E2B05A]/90 border-t border-[#5A4B38]/50 pt-2">
                    {inspectedItem.loreNote}
                  </p>
                )}

                <p className="text-[11px] font-mono text-[#77796F] pt-1">
                  {inspectedItem.questItem
                    ? 'Quest Item (Bound to Story)'
                    : `Base Value: ${inspectedItem.value}g · Sell Value: ${getItemSellPrice(inspectedItem)}g`}
                </p>
              </>
            ) : (
              <p className="text-xs text-[#77796F]">Select an item to inspect its properties.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

// ============================================================================
// 5. GLOAMREST QUEST JOURNAL & CHRONICLE MODAL ('J' KEY)
// ============================================================================

interface GloamrestQuestJournalModalProps {
  gloamrestState: GloamrestSaveState;
  onTrackQuest: (questId: QuestId) => void;
  onOpenWorldChronicle: () => void;
  onClose: () => void;
}

export const GloamrestQuestJournalModal: React.FC<GloamrestQuestJournalModalProps> = ({
  gloamrestState,
  onTrackQuest,
  onOpenWorldChronicle,
  onClose,
}) => {
  const [selectedQuestId, setSelectedQuestId] = useState<QuestId>(
    gloamrestState.activeTrackedQuestId
  );

  const selectedDef = GLOAMREST_QUESTS[selectedQuestId];
  const selectedProg = gloamrestState.quests[selectedQuestId];

  return (
    <div
      role="dialog"
      aria-modal="true"
      data-testid="gloamrest-quest-journal"
      className="fixed inset-0 z-40 flex items-center justify-center p-4 pointer-events-auto"
      style={{ backgroundColor: 'rgba(10, 12, 11, 0.84)' }}
    >
      <div
        style={{ backgroundColor: '#171B19', borderColor: '#5A4B38', color: '#F2ECE1' }}
        className="w-full max-w-5xl rounded-lg border p-5 shadow-2xl grid grid-cols-1 lg:grid-cols-12 gap-5 max-h-[86vh] overflow-y-auto"
      >
        <div className="lg:col-span-12 flex items-center justify-between pb-3 border-b border-[#5A4B38]">
          <div>
            <p className="text-xs font-mono uppercase tracking-widest text-[#E2B05A]">
              Act I · Whispering Vale Journal
            </p>
            <h2 className="text-xl font-display font-bold text-[#F2ECE1]">
              Gloamrest Quests & Investigations
            </h2>
          </div>
          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={onOpenWorldChronicle}
              style={{ backgroundColor: '#222722', borderColor: '#5A4B38', color: '#E2B05A' }}
              className="px-3 py-1.5 rounded border hover:border-[#E2B05A] text-xs font-mono cursor-pointer"
            >
              Act Campaign Chronicle →
            </button>
            <button
              type="button"
              onClick={onClose}
              style={{ backgroundColor: '#222722', borderColor: '#5A4B38', color: '#F2ECE1' }}
              className="px-3.5 py-1.5 rounded border hover:border-[#E2B05A] text-xs font-mono cursor-pointer"
            >
              Close [J / Esc]
            </button>
          </div>
        </div>

        {/* Quest List */}
        <div className="lg:col-span-5 space-y-2">
          {(Object.keys(GLOAMREST_QUESTS) as QuestId[]).map((qId) => {
            const def = GLOAMREST_QUESTS[qId];
            const prog = gloamrestState.quests[qId];
            const isSelected = qId === selectedQuestId;
            const statusColor =
              prog.status === 'completed'
                ? '#7E9C82'
                : prog.status === 'active'
                ? '#E2B05A'
                : '#77796F';

            return (
              <button
                key={qId}
                type="button"
                onClick={() => setSelectedQuestId(qId)}
                style={{
                  backgroundColor: isSelected ? '#3A3324' : '#222722',
                  borderColor: isSelected ? '#E2B05A' : '#5A4B38',
                }}
                className="w-full text-left p-3 rounded border space-y-1 cursor-pointer"
              >
                <div className="flex items-center justify-between text-[10px] font-mono">
                  <span style={{ color: '#B5AC9A' }}>{def.code}</span>
                  <span style={{ color: statusColor }}>{prog.status.toUpperCase()}</span>
                </div>
                <p className="text-sm font-display font-bold text-[#F2ECE1]">{def.title}</p>
                <p className="text-xs text-[#B5AC9A] truncate">{def.summary}</p>
              </button>
            );
          })}
        </div>

        {/* Quest Details */}
        <div
          style={{ backgroundColor: '#222722', borderColor: '#5A4B38' }}
          className="lg:col-span-7 rounded-md border p-4 space-y-4"
        >
          <div className="flex items-start justify-between gap-3">
            <div>
              <span className="text-xs font-mono text-[#E2B05A]">{selectedDef.code}</span>
              <h3 className="text-lg font-display font-bold text-[#F2ECE1]">
                {selectedDef.title}
              </h3>
              <p className="text-xs text-[#B5AC9A]">Patron / Source: {selectedDef.giverName}</p>
            </div>
            {selectedProg.status !== 'completed' && (
              <button
                type="button"
                onClick={() => onTrackQuest(selectedQuestId)}
                style={{
                  backgroundColor:
                    gloamrestState.activeTrackedQuestId === selectedQuestId
                      ? '#E2B05A'
                      : '#171B19',
                  color:
                    gloamrestState.activeTrackedQuestId === selectedQuestId
                      ? '#171B19'
                      : '#E2B05A',
                  borderColor: '#E2B05A',
                }}
                className="px-3 py-1 rounded border text-xs font-mono font-bold cursor-pointer"
              >
                {gloamrestState.activeTrackedQuestId === selectedQuestId
                  ? '★ Tracking on HUD'
                  : 'Track Quest'}
              </button>
            )}
          </div>

          <p className="text-xs leading-relaxed text-[#F2ECE1]/90">{selectedDef.journalLore}</p>

          <div className="space-y-1.5">
            <p className="text-xs font-mono uppercase tracking-wider text-[#E2B05A]">
              Objectives
            </p>
            {selectedDef.steps.map((st) => {
              const done = selectedProg.completedStepIds.includes(st.id);
              return (
                <div
                  key={st.id}
                  style={{ backgroundColor: '#171B19', borderColor: '#5A4B38' }}
                  className="px-3 py-2 rounded border flex items-center gap-2.5 text-xs"
                >
                  <span style={{ color: done ? '#7E9C82' : '#E2B05A' }}>
                    {done ? '✓' : '◇'}
                  </span>
                  <span
                    className={done ? 'line-through text-[#77796F]' : 'text-[#F2ECE1]'}
                  >
                    {st.label}
                  </span>
                </div>
              );
            })}
          </div>

          <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-[#5A4B38]/60 text-xs font-mono">
            <span className="text-[#7E9C82]">
              Reward: {selectedDef.rewards.gold} Gold
              {selectedDef.rewards.unlockNote ? ` · ${selectedDef.rewards.unlockNote}` : ''}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

// ============================================================================
// 6. WHISPERING GATE WILDERNESS EXPEDITION & LORE / TUTORIAL MODALS
// ============================================================================

export const WildernessGateModal: React.FC<{
  gloamrestState: GloamrestSaveState;
  onStartOutskirtsCombat: () => void;
  onDepartActOneSanctum: () => void;
  onOpenTower?: () => void;
  onClose: () => void;
}> = ({ gloamrestState, onStartOutskirtsCombat, onDepartActOneSanctum, onOpenTower, onClose }) => {
  const mq03Done = gloamrestState.quests.mq03_shadows_beyond_gate.status === 'completed';
  const sanctumUnlocked =
    mq03Done || gloamrestState.storyFlags.includes('sanctum_route_unlocked');

  return (
    <div
      role="dialog"
      aria-modal="true"
      data-testid="wilderness-gate-modal"
      className="fixed inset-0 z-40 flex items-center justify-center p-4 pointer-events-auto"
      style={{ backgroundColor: 'rgba(10, 12, 11, 0.85)' }}
    >
      <div
        style={{ backgroundColor: '#171B19', borderColor: '#5A4B38', color: '#F2ECE1' }}
        className="w-full max-w-lg rounded-lg border p-6 shadow-2xl space-y-4"
      >
        <div>
          <p className="text-xs font-mono uppercase tracking-widest text-[#E2B05A]">
            District I · Whispering Gate Transition
          </p>
          <h2 className="text-xl font-display font-bold text-[#F2ECE1]">
            Depart into Whispering Vale
          </h2>
          <p className="text-xs text-[#B5AC9A] mt-1">
            Select your party’s destination beyond Gloamrest’s stone bridge.
          </p>
        </div>

        <div className="space-y-2.5">
          <button
            type="button"
            data-testid="gate-btn-outskirts"
            onClick={onStartOutskirtsCombat}
            style={{ backgroundColor: '#292E29', borderColor: '#E2B05A' }}
            className="w-full text-left p-3.5 rounded border hover:bg-[#3A3324] cursor-pointer space-y-1"
          >
            <div className="flex items-center justify-between">
              <span className="text-sm font-display font-bold text-[#F2ECE1]">
                Whispering Outskirts Trail (Tactical Encounter)
              </span>
              <span className="text-[11px] font-mono text-[#E2B05A]">
                {mq03Done ? 'Replay Patrol' : 'MAIN QUEST 03'}
              </span>
            </div>
            <p className="text-xs text-[#B5AC9A]">
              Investigate the vanished travelers’ trail and confront the hostile ambush vanguard using full turn-based AP combat.
            </p>
          </button>

          <button
            type="button"
            data-testid="gate-btn-sanctum"
            disabled={!sanctumUnlocked}
            onClick={onDepartActOneSanctum}
            style={{
              backgroundColor: sanctumUnlocked ? '#3A3324' : '#222722',
              borderColor: sanctumUnlocked ? '#E2B05A' : '#5A4B38',
            }}
            className="w-full text-left p-3.5 rounded border disabled:opacity-45 cursor-pointer space-y-1"
          >
            <div className="flex items-center justify-between">
              <span className="text-sm font-display font-bold text-[#E2B05A]">
                Act I — Sanctum of the Shattered Oath
              </span>
              <span className="text-[11px] font-mono text-[#7E9C82]">
                {sanctumUnlocked ? 'ROUTE OPEN' : 'Complete MQ03 First'}
              </span>
            </div>
            <p className="text-xs text-[#B5AC9A]">
              March deep into Whispering Vale to confront the fractured Silver Covenant at the Sanctum of the Shattered Oath.
            </p>
          </button>

          {onOpenTower && (
            <button
              type="button"
              data-testid="gate-btn-tower"
              onClick={() => {
                onClose();
                onOpenTower();
              }}
              style={{
                backgroundColor: '#261F18',
                borderColor: '#E2B05A',
              }}
              className="w-full text-left p-3.5 rounded border hover:border-[#F59E0B] cursor-pointer space-y-1"
            >
              <div className="flex items-center justify-between">
                <span className="text-sm font-display font-bold text-[#E2B05A]">
                  The Ascendant Tower (100-Floor Battle Spire)
                </span>
                <span className="text-[11px] font-mono text-[#E2B05A]">
                  100 FLOORS · REWARDS
                </span>
              </div>
              <p className="text-xs text-[#B5AC9A]">
                Enter the ancient sealed battle tower. Ascend through 10 environmental regions, defeat multi-phase bosses, and earn Oath Shards.
              </p>
            </button>
          )}
        </div>

        <div className="flex justify-end pt-2">
          <button
            type="button"
            onClick={onClose}
            style={{ backgroundColor: '#222722', borderColor: '#5A4B38', color: '#B5AC9A' }}
            className="px-4 py-1.5 rounded border hover:border-[#E2B05A] text-xs font-mono cursor-pointer"
          >
            Stay in Gloamrest [Esc]
          </button>
        </div>
      </div>
    </div>
  );
};

export const LoreAndTutorialModal: React.FC<{
  title: string;
  text: string;
  isTrainingDrill?: boolean;
  onStartSparring?: () => void;
  onClose: () => void;
}> = ({ title, text, isTrainingDrill, onStartSparring, onClose }) => (
  <div
    role="dialog"
    aria-modal="true"
    className="fixed inset-0 z-40 flex items-center justify-center p-4 pointer-events-auto"
    style={{ backgroundColor: 'rgba(10, 12, 11, 0.82)' }}
  >
    <div
      style={{ backgroundColor: '#171B19', borderColor: '#5A4B38', color: '#F2ECE1' }}
      className="w-full max-w-lg rounded-lg border p-6 shadow-2xl space-y-4"
    >
      <h3 className="text-lg font-display font-bold text-[#E2B05A]">{title}</h3>
      <p className="text-sm leading-relaxed whitespace-pre-line text-[#F2ECE1]/95">{text}</p>
      {isTrainingDrill && (
        <div
          style={{ backgroundColor: '#222722', borderColor: '#5A4B38' }}
          className="p-3 rounded border text-xs font-mono space-y-1 text-[#B5AC9A]"
        >
          <p className="text-[#E2B05A] font-semibold">Watch Barracks Tactical Primer:</p>
          <p>• Turn Order & AP: Each turn refreshes 4 Action Points (◆) and ticks skill cooldowns.</p>
          <p>• Positioning: High Ground grants +2 Hit / +2 DMG; Allied Flanking grants +2 Hit.</p>
          <p>• Telegraphs & Terrain: Watch red enemy windups, shove Runestones onto Rifts, and ignite Oil Pools with Fire skills!</p>
        </div>
      )}
      <div className="flex items-center justify-end gap-2.5 pt-2">
        {isTrainingDrill && onStartSparring && (
          <button
            type="button"
            onClick={onStartSparring}
            style={{ backgroundColor: '#E2B05A', color: '#171B19' }}
            className="px-4 py-1.5 rounded text-xs font-display font-bold cursor-pointer"
          >
            Enter Live Sparring Bout →
          </button>
        )}
        <button
          type="button"
          onClick={onClose}
          style={{ backgroundColor: '#222722', borderColor: '#5A4B38', color: '#F2ECE1' }}
          className="px-4 py-1.5 rounded border hover:border-[#E2B05A] text-xs font-mono cursor-pointer"
        >
          Close [Esc]
        </button>
      </div>
    </div>
  </div>
);
