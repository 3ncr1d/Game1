import React, { useState } from 'react';
import { CompanionId, getStatusEffectTooltipData } from '../game/rules';

export const TitleCrestLockup: React.FC = () => (
  <div className="flex flex-col items-start select-none">
    <svg
      viewBox="0 0 560 155"
      className="w-full max-w-[500px] h-auto drop-shadow-[0_12px_28px_rgba(0,0,0,0.92)]"
      aria-label="Dimraeth: The Shattered Oath"
    >
      <defs>
        <linearGradient id="goldBronze" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#fde68a" />
          <stop offset="50%" stopColor="#d97706" />
          <stop offset="100%" stopColor="#78350f" />
        </linearGradient>
        <linearGradient id="astralGlow" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#f59e0b" />
          <stop offset="100%" stopColor="#dc2626" />
        </linearGradient>
      </defs>

      {/* Ornate Astral Sword & Shattered Halo Crest on Left */}
      <g transform="translate(46, 74)">
        {/* Outer Runic Ring */}
        <circle
          cx="0"
          cy="0"
          r="38"
          fill="rgba(14, 12, 20, 0.85)"
          stroke="url(#goldBronze)"
          strokeWidth="2.5"
        />
        <circle
          cx="0"
          cy="0"
          r="31"
          fill="none"
          stroke="#b45309"
          strokeWidth="1"
          strokeDasharray="4 3"
        />
        {/* Shattered Star Points */}
        <polygon
          points="0,-45 6,-14 36,-22 14,-2 38,20 6,10 0,46 -6,10 -38,20 -14,-2 -36,-22 -6,-14"
          fill="url(#goldBronze)"
          opacity="0.28"
        />
        {/* Central Greatsword Silhouette */}
        <path
          d="M0,-42 L5,-10 L18,-12 L14,-5 L4,-5 L3,28 L-3,28 L-4,-5 L-14,-5 L-18,-12 L-5,-10 Z"
          fill="url(#goldBronze)"
          stroke="#09080d"
          strokeWidth="1.5"
        />
        {/* Astral Core Gem */}
        <polygon
          points="0,-14 6,-6 0,2 -6,-6"
          fill="url(#astralGlow)"
          stroke="#fef3c7"
          strokeWidth="1"
        />
      </g>

      {/* Top Ornamental Filigree Rule */}
      <path
        d="M104,28 L490,28 L508,36 L104,36 Z"
        fill="url(#goldBronze)"
        opacity="0.35"
      />
      <line x1="104" y1="32" x2="520" y2="32" stroke="url(#goldBronze)" strokeWidth="1.5" />

      {/* Main Title Lettering */}
      <text
        x="104"
        y="86"
        fontFamily="'Cinzel', Georgia, serif"
        fontWeight="700"
        fontSize="54"
        letterSpacing="6"
        fill="url(#goldBronze)"
        stroke="#08070c"
        strokeWidth="3"
        style={{ paintOrder: 'stroke fill' }}
      >
        DIMRAETH
      </text>

      {/* Bottom Ornamental Filigree Rule */}
      <line x1="104" y1="102" x2="520" y2="102" stroke="url(#goldBronze)" strokeWidth="1.5" />
      <polygon points="312,97 322,102 312,107 302,102" fill="#f59e0b" />

      {/* Subtitle */}
      <text
        x="106"
        y="130"
        fontFamily="'Cinzel', Georgia, serif"
        fontWeight="600"
        fontSize="18"
        letterSpacing="7.5"
        fill="#e7e0d0"
      >
        THE SHATTERED OATH
      </text>
    </svg>
  </div>
);

export const CharacterPortraitSvg: React.FC<{
  id: CompanionId | 'inquisitor' | 'oracle' | 'archon' | string;
  className?: string;
}> = ({ id, className = 'w-14 h-14' }) => {
  if (id === 'seraphina') {
    return (
      <svg viewBox="0 0 80 80" className={className} role="img" aria-label="Seraphina Vane portrait">
        <defs>
          <radialGradient id="seraBg" cx="50%" cy="35%" r="65%">
            <stop offset="0%" stopColor="#451a03" />
            <stop offset="100%" stopColor="#0c0a12" />
          </radialGradient>
        </defs>
        <rect width="80" height="80" rx="8" fill="url(#seraBg)" />
        {/* Radiant Halo Ring */}
        <circle cx="40" cy="34" r="24" fill="none" stroke="#f59e0b" strokeWidth="1.5" strokeDasharray="3 2" opacity="0.7" />
        {/* Gilded Pauldrons & Cloak */}
        <path d="M10,78 C12,56 26,50 40,50 C54,50 68,56 70,78 Z" fill="#334155" stroke="#d97706" strokeWidth="2" />
        <path d="M12,64 L28,52 L26,76 L10,76 Z" fill="#b45309" />
        <path d="M68,64 L52,52 L54,76 L70,76 Z" fill="#b45309" />
        {/* Half-Elf Visage & Silver Hair */}
        <path d="M24,36 C22,16 58,16 56,36 L60,54 L20,54 Z" fill="#cbd5e1" />
        <ellipse cx="40" cy="36" rx="12" ry="14" fill="#e2c6b0" />
        {/* Pointed Elf Ears */}
        <polygon points="28,34 21,30 27,40" fill="#e2c6b0" />
        <polygon points="52,34 59,30 53,40" fill="#e2c6b0" />
        {/* Silver Braids & Circlet */}
        <path d="M26,28 Q40,34 54,28" fill="none" stroke="#f59e0b" strokeWidth="2.5" />
        <polygon points="40,22 44,29 40,32 36,29" fill="#fde68a" />
        {/* Determined Amber Eyes */}
        <circle cx="35" cy="36" r="1.8" fill="#f59e0b" />
        <circle cx="45" cy="36" r="1.8" fill="#f59e0b" />
      </svg>
    );
  }

  if (id === 'kaelen') {
    return (
      <svg viewBox="0 0 80 80" className={className} role="img" aria-label="Kaelen Vos portrait">
        <defs>
          <radialGradient id="kaelBg" cx="50%" cy="35%" r="65%">
            <stop offset="0%" stopColor="#4c0519" />
            <stop offset="100%" stopColor="#09070e" />
          </radialGradient>
        </defs>
        <rect width="80" height="80" rx="8" fill="url(#kaelBg)" />
        {/* Arcane Sigil Ring */}
        <circle cx="40" cy="34" r="25" fill="none" stroke="#ec4899" strokeWidth="1.2" opacity="0.6" />
        {/* Crimson Scholarly Collar & Robes */}
        <path d="M12,78 C15,54 28,50 40,50 C52,50 65,54 68,78 Z" fill="#7f1d1d" stroke="#f59e0b" strokeWidth="1.8" />
        <polygon points="24,52 40,68 56,52 48,46 32,46" fill="#450a0a" stroke="#fbbf24" strokeWidth="1.2" />
        {/* Tiefling Curved Obsidian Horns */}
        <path d="M30,26 C20,16 14,10 18,4 C24,8 28,16 34,22 Z" fill="#1e1b2e" stroke="#94a3b8" strokeWidth="1" />
        <path d="M50,26 C60,16 66,10 62,4 C56,8 52,16 46,22 Z" fill="#1e1b2e" stroke="#94a3b8" strokeWidth="1" />
        {/* Visage */}
        <ellipse cx="40" cy="36" rx="11.5" ry="14" fill="#b87a7a" />
        {/* Dark Swept Hair */}
        <path d="M28,30 C30,18 50,18 52,30 C46,24 34,24 28,30 Z" fill="#0f172a" />
        {/* Glowing Golden-Violet Eyes */}
        <circle cx="35" cy="36" r="2" fill="#fbbf24" />
        <circle cx="45" cy="36" r="2" fill="#fbbf24" />
      </svg>
    );
  }

  if (id === 'thorne') {
    return (
      <svg viewBox="0 0 80 80" className={className} role="img" aria-label="Thorne Ironbough portrait">
        <defs>
          <radialGradient id="thorneBg" cx="50%" cy="35%" r="65%">
            <stop offset="0%" stopColor="#064e3b" />
            <stop offset="100%" stopColor="#090c0a" />
          </radialGradient>
        </defs>
        <rect width="80" height="80" rx="8" fill="url(#thorneBg)" />
        {/* Bow Silhouette Behind */}
        <path d="M16,14 Q68,40 18,74" fill="none" stroke="#a16207" strokeWidth="3" />
        {/* Sylvan Cloak & Leather Shoulder */}
        <path d="M12,78 C14,55 26,50 40,50 C54,50 66,55 68,78 Z" fill="#14532d" stroke="#84cc16" strokeWidth="1.5" />
        {/* Ranger Hood */}
        <path d="M20,44 C18,16 62,16 60,44 L54,54 L26,54 Z" fill="#166534" stroke="#052e16" strokeWidth="2" />
        {/* Face in Hood Shadow */}
        <ellipse cx="40" cy="38" rx="11" ry="13" fill="#c89d7c" />
        {/* Emerald Leaf Brooch */}
        <polygon points="40,52 45,58 40,64 35,58" fill="#22c55e" stroke="#dcfce7" strokeWidth="1" />
        {/* Hawk Eyes */}
        <circle cx="35.5" cy="37" r="1.8" fill="#4ade80" />
        <circle cx="44.5" cy="37" r="1.8" fill="#4ade80" />
      </svg>
    );
  }

  // Gloamrest Named NPC Portraits (12 distinct medieval dark-fantasy characters)
  const gloamrestNpcConfigs: Record<
    string,
    {
      bg: string;
      coat: string;
      trim: string;
      skin: string;
      hair: string;
      eye: string;
      feature: 'circlet' | 'apron' | 'smith' | 'wreath' | 'cowl' | 'helm' | 'cap' | 'saw' | 'hood' | 'glasses' | 'hat';
    }
  > = {
    aldric_veyne: { bg: '#2c251c', coat: '#3b352d', trim: '#e2b05a', skin: '#d8bfa9', hair: '#c8c5be', eye: '#e2b05a', feature: 'circlet' },
    mara_fenwick: { bg: '#382019', coat: '#5c3428', trim: '#e2b05a', skin: '#dead92', hair: '#7c3a25', eye: '#7e9c82', feature: 'apron' },
    garron_holt: { bg: '#2b1b15', coat: '#2e2a28', trim: '#d97706', skin: '#b88668', hair: '#2a2321', eye: '#d97706', feature: 'smith' },
    elowen_mire: { bg: '#162b20', coat: '#2d4a38', trim: '#7e9c82', skin: '#d8b89c', hair: '#4f3728', eye: '#7e9c82', feature: 'wreath' },
    brother_cael: { bg: '#1f2430', coat: '#3b3f4a', trim: '#e2b05a', skin: '#cfa98e', hair: '#9ca3af', eye: '#93c5fd', feature: 'cowl' },
    captain_roderic: { bg: '#202630', coat: '#333c48', trim: '#b45309', skin: '#ba886a', hair: '#3b2e26', eye: '#cbd5e1', feature: 'helm' },
    tessa_reed: { bg: '#242b1d', coat: '#4b533b', trim: '#e2b05a', skin: '#d9b39a', hair: '#6b3f28', eye: '#e2b05a', feature: 'cap' },
    bram_alder: { bg: '#2c2117', coat: '#574330', trim: '#c99a52', skin: '#c49474', hair: '#4f3728', eye: '#a3b18a', feature: 'saw' },
    sera_wren: { bg: '#16281d', coat: '#263d2d', trim: '#7e9c82', skin: '#c79e7e', hair: '#262224', eye: '#7e9c82', feature: 'hood' },
    old_nym: { bg: '#27202b', coat: '#463a4a', trim: '#e2b05a', skin: '#cbb09a', hair: '#d8d4cc', eye: '#fcd34d', feature: 'hood' },
    edrin_vale: { bg: '#1a2333', coat: '#2d3648', trim: '#60a5fa', skin: '#e0c4ad', hair: '#4b4642', eye: '#93c5fd', feature: 'glasses' },
    lysa_thorn: { bg: '#291c24', coat: '#3b2c35', trim: '#d97706', skin: '#c99c7e', hair: '#221d1c', eye: '#f59e0b', feature: 'hat' },
  };

  if (gloamrestNpcConfigs[id]) {
    const cfg = gloamrestNpcConfigs[id];
    return (
      <svg viewBox="0 0 80 80" className={className} role="img" aria-label={`${id} portrait`}>
        <rect width="80" height="80" rx="8" fill={cfg.bg} />
        <circle cx="40" cy="34" r="28" fill={cfg.trim} opacity="0.1" />
        {/* Shoulders & Cloak */}
        <path d="M12,78 C16,54 27,49 40,49 C53,49 64,54 68,78 Z" fill={cfg.coat} stroke={cfg.trim} strokeWidth="1.6" />
        {cfg.feature === 'apron' && (
          <path d="M29,52 L51,52 L54,78 L26,78 Z" fill="#d6cbb9" opacity="0.85" />
        )}
        {/* Hair Back */}
        <ellipse cx="40" cy="34" rx="15" ry="16" fill={cfg.hair} />
        {/* Face */}
        <ellipse cx="40" cy="36" rx="12" ry="14" fill={cfg.skin} />
        {/* Eyes */}
        <circle cx="35.5" cy="35" r="1.7" fill={cfg.eye} />
        <circle cx="44.5" cy="35" r="1.7" fill={cfg.eye} />
        {/* Feature / Headgear */}
        {cfg.feature === 'circlet' && (
          <>
            <path d="M28,27 Q40,22 52,27" fill="none" stroke="#e2b05a" strokeWidth="2.5" />
            <path d="M33,44 Q40,54 47,44" fill="#c8c5be" />
          </>
        )}
        {cfg.feature === 'smith' && (
          <>
            <rect x="27" y="24" width="26" height="4" rx="1.5" fill="#78350f" stroke="#d97706" strokeWidth="1" />
            <path d="M31,42 Q40,53 49,42 Z" fill="#2a2321" />
          </>
        )}
        {cfg.feature === 'wreath' && (
          <path d="M26,27 Q40,20 54,27" fill="none" stroke="#7e9c82" strokeWidth="3" strokeDasharray="4 2" />
        )}
        {cfg.feature === 'cowl' && (
          <path d="M22,42 C22,17 58,17 58,42 L53,26 L27,26 Z" fill="#4b5563" stroke="#e2b05a" strokeWidth="1.2" />
        )}
        {cfg.feature === 'helm' && (
          <path d="M25,33 C25,17 55,17 55,33 L40,29 Z" fill="#475569" stroke="#94a3b8" strokeWidth="1.5" />
        )}
        {cfg.feature === 'cap' && (
          <path d="M24,28 Q40,15 57,26 L26,29 Z" fill="#6b533b" stroke="#e2b05a" strokeWidth="1" />
        )}
        {cfg.feature === 'saw' && (
          <path d="M32,43 Q40,51 48,43 Z" fill="#4f3728" />
        )}
        {cfg.feature === 'hood' && (
          <path d="M20,48 C22,16 58,16 60,48 L52,25 L28,25 Z" fill={cfg.coat} stroke={cfg.trim} strokeWidth="1.3" />
        )}
        {cfg.feature === 'glasses' && (
          <>
            <circle cx="35.5" cy="35" r="4" fill="none" stroke="#e2b05a" strokeWidth="1.2" />
            <circle cx="44.5" cy="35" r="4" fill="none" stroke="#e2b05a" strokeWidth="1.2" />
            <line x1="39.5" y1="35" x2="40.5" y2="35" stroke="#e2b05a" strokeWidth="1.2" />
          </>
        )}
        {cfg.feature === 'hat' && (
          <polygon points="18,28 40,16 62,28 50,29 30,29" fill="#271d22" stroke="#d97706" strokeWidth="1.3" />
        )}
      </svg>
    );
  }

  // Enemy / Boss Portrait
  return (
    <svg viewBox="0 0 80 80" className={className} role="img" aria-label="Adversary portrait">
      <defs>
        <radialGradient id="enemyBg" cx="50%" cy="35%" r="65%">
          <stop offset="0%" stopColor="#581c87" />
          <stop offset="100%" stopColor="#09070d" />
        </radialGradient>
      </defs>
      <rect width="80" height="80" rx="8" fill="url(#enemyBg)" />
      {/* Spiked Plate Shoulders */}
      <path d="M10,78 C14,54 28,50 40,50 C52,50 66,54 70,78 Z" fill="#1e1b2e" stroke="#a855f7" strokeWidth="2" />
      {/* Horned Inquisitor Helm */}
      <path d="M24,46 L22,20 L32,28 L40,14 L48,28 L58,20 L56,46 L40,54 Z" fill="#334155" stroke="#0f172a" strokeWidth="2" />
      {/* Glowing Visor Slits */}
      <polygon points="30,36 38,39 31,41" fill="#f43f5e" />
      <polygon points="50,36 42,39 49,41" fill="#f43f5e" />
    </svg>
  );
};

export const D20DieSvg: React.FC<{
  value?: number;
  variant?: 'gold' | 'emerald' | 'crimson';
  className?: string;
}> = ({ value = 20, variant = 'gold', className = 'w-12 h-12' }) => {
  const palette =
    variant === 'emerald'
      ? {
          outerFill: '#082c22',
          outerStroke: '#34d399',
          innerFill: '#064e3b',
          innerStroke: '#6ee7b7',
          facetStroke: '#10b981',
          textFill: '#ecfdf5',
        }
      : variant === 'crimson'
      ? {
          outerFill: '#2d0a16',
          outerStroke: '#f43f5e',
          innerFill: '#4c0519',
          innerStroke: '#fda4af',
          facetStroke: '#e11d48',
          textFill: '#ffe4e6',
        }
      : {
          outerFill: '#1e192b',
          outerStroke: '#f59e0b',
          innerFill: '#2e2344',
          innerStroke: '#fbbf24',
          facetStroke: '#d97706',
          textFill: '#fef3c7',
        };

  return (
    <svg viewBox="0 0 64 64" className={className} aria-hidden="true">
      <polygon
        points="32,4 58,18 58,46 32,60 6,46 6,18"
        fill={palette.outerFill}
        stroke={palette.outerStroke}
        strokeWidth="2.5"
      />
      <polygon
        points="32,12 50,42 14,42"
        fill={palette.innerFill}
        stroke={palette.innerStroke}
        strokeWidth="1.5"
      />
      <line x1="32" y1="4" x2="32" y2="12" stroke={palette.facetStroke} strokeWidth="1.5" />
      <line x1="58" y1="18" x2="50" y2="42" stroke={palette.facetStroke} strokeWidth="1.5" />
      <line x1="6" y1="18" x2="14" y2="42" stroke={palette.facetStroke} strokeWidth="1.5" />
      <line x1="32" y1="60" x2="50" y2="42" stroke={palette.facetStroke} strokeWidth="1.5" />
      <line x1="32" y1="60" x2="14" y2="42" stroke={palette.facetStroke} strokeWidth="1.5" />
      <text
        x="32"
        y="36"
        textAnchor="middle"
        fontFamily="'JetBrains Mono', monospace"
        fontWeight="700"
        fontSize="16"
        fill={palette.textFill}
      >
        {value}
      </text>
    </svg>
  );
};

export const ActionPointPipSvg: React.FC<{ state: 'full' | 'cracked' | 'empty' }> = ({ state }) => (
  <svg viewBox="0 0 20 20" className="w-4 h-4" aria-hidden="true">
    <polygon
      points="10,2 18,10 10,18 2,10"
      fill={state === 'full' ? '#f59e0b' : state === 'cracked' ? '#78350f' : '#181520'}
      stroke={state === 'full' ? '#fef3c7' : '#78350f'}
      strokeWidth="1.8"
    />
    {state === 'full' && <polygon points="10,5 14,10 10,15 6,10" fill="#fde68a" />}
    {state === 'cracked' && (
      <path d="M7,6 L11,10 L9,14" stroke="#09080d" strokeWidth="1.5" fill="none" />
    )}
  </svg>
);

export type StatusEffectType = 'blessed' | 'burning' | 'chilled' | 'rooted' | 'sundered' | 'warded';

export const STATUS_EFFECT_META: Record<
  StatusEffectType,
  {
    label: string;
    shortClue: string;
    textColor: string;
    borderColor: string;
    bgColor: string;
  }
> = {
  blessed: {
    label: 'Blessed',
    shortClue: '+2 Attack',
    textColor: 'text-amber-200',
    borderColor: 'border-amber-400/70',
    bgColor: 'rgba(69, 26, 3, 0.92)',
  },
  burning: {
    label: 'Burning',
    shortClue: '-3 HP/turn',
    textColor: 'text-rose-200',
    borderColor: 'border-rose-500/75',
    bgColor: 'rgba(76, 5, 25, 0.92)',
  },
  chilled: {
    label: 'Chilled',
    shortClue: '-1 Move / +4 Frost Vulnerability',
    textColor: 'text-cyan-200',
    borderColor: 'border-cyan-400/75',
    bgColor: 'rgba(8, 51, 68, 0.92)',
  },
  rooted: {
    label: 'Rooted',
    shortClue: '0 Move',
    textColor: 'text-emerald-200',
    borderColor: 'border-emerald-400/70',
    bgColor: 'rgba(5, 46, 22, 0.92)',
  },
  sundered: {
    label: 'Sundered',
    shortClue: '-2 AC',
    textColor: 'text-purple-200',
    borderColor: 'border-purple-400/75',
    bgColor: 'rgba(46, 16, 101, 0.92)',
  },
  warded: {
    label: 'Warded',
    shortClue: '+2 AC',
    textColor: 'text-sky-200',
    borderColor: 'border-sky-400/75',
    bgColor: 'rgba(8, 47, 73, 0.92)',
  },
};

const StatusEffectRawSvg: React.FC<{
  type: StatusEffectType;
  dimClass: string;
  titleText: string;
}> = ({ type, dimClass, titleText }) => (
  <svg
    viewBox="0 0 24 24"
    className={`${dimClass} shrink-0 drop-shadow-[0_1px_3px_rgba(0,0,0,0.9)]`}
    role="img"
    aria-label={titleText}
  >
    <title>{titleText}</title>
      {type === 'blessed' && (
        <>
          <rect
            x="1.5"
            y="1.5"
            width="21"
            height="21"
            rx="5"
            fill="#451a03"
            stroke="#fbbf24"
            strokeWidth="1.8"
          />
          <circle cx="12" cy="12" r="6.5" fill="none" stroke="#f59e0b" strokeWidth="1" opacity="0.65" />
          <polygon
            points="12,3.5 14.3,9.7 20.5,12 14.3,14.3 12,20.5 9.7,14.3 3.5,12 9.7,9.7"
            fill="#fef08a"
            stroke="#d97706"
            strokeWidth="0.8"
          />
        </>
      )}

      {type === 'burning' && (
        <>
          <rect
            x="1.5"
            y="1.5"
            width="21"
            height="21"
            rx="5"
            fill="#4c0519"
            stroke="#f43f5e"
            strokeWidth="1.8"
          />
          <path
            d="M12,3.5 C15.5,7.5 18.5,10.2 18.5,14.2 C18.5,17.8 15.6,20.5 12,20.5 C8.4,20.5 5.5,17.8 5.5,14.2 C5.5,11.3 7.3,9.2 8.8,7.3 C8.6,9.5 9.8,10.6 10.6,11.2 C10.1,8.4 10.8,5.8 12,3.5 Z"
            fill="#fb7185"
            stroke="#e11d48"
            strokeWidth="0.9"
          />
          <path
            d="M12,9.2 C13.8,11.5 15,13.2 15,15.3 C15,17.2 13.7,18.8 12,18.8 C10.3,18.8 9,17.2 9,15.3 C9,13.6 10.3,11.8 12,9.2 Z"
            fill="#fde047"
          />
        </>
      )}

      {type === 'rooted' && (
        <>
          <rect
            x="1.5"
            y="1.5"
            width="21"
            height="21"
            rx="5"
            fill="#052e16"
            stroke="#4ade80"
            strokeWidth="1.8"
          />
          <path
            d="M5,18 C8,13 11,10 19,6 M6,6 C11,10 14,13 19,18"
            stroke="#86efac"
            strokeWidth="2.2"
            strokeLinecap="round"
            fill="none"
          />
          <polygon points="12,8 14.5,12 12,16 9.5,12" fill="#22c55e" stroke="#dcfce7" strokeWidth="1" />
        </>
      )}

      {type === 'sundered' && (
        <>
          <rect
            x="1.5"
            y="1.5"
            width="21"
            height="21"
            rx="5"
            fill="#2e1065"
            stroke="#c084fc"
            strokeWidth="1.8"
          />
          {/* Left & Right Fractured Shield Halves */}
          <path
            d="M5.5,6 L10.8,5 L9.2,11.5 L11.2,13.5 L9.5,19.2 C6.8,17.4 5.5,14.2 5.5,10.2 Z"
            fill="#d8b4fe"
          />
          <path
            d="M13.5,5 L18.5,6 L18.5,10.2 C18.5,14.2 17.2,17.4 14.2,19.2 L13.2,14.2 L11.4,12.2 Z"
            fill="#a855f7"
          />
          {/* Lightning Crack */}
          <polyline
            points="12.5,4 10.2,11.2 13.4,13.2 11.2,20"
            fill="none"
            stroke="#fef08a"
            strokeWidth="1.6"
          />
        </>
      )}

      {type === 'warded' && (
        <>
          <rect
            x="1.5"
            y="1.5"
            width="21"
            height="21"
            rx="5"
            fill="#082f49"
            stroke="#38bdf8"
            strokeWidth="1.8"
          />
          <path
            d="M12,4.2 L18.5,6.8 L18.5,12.2 C18.5,16.2 15.6,18.9 12,20.2 C8.4,18.9 5.5,16.2 5.5,12.2 L5.5,6.8 Z"
            fill="#0284c7"
            stroke="#bae6fd"
            strokeWidth="1.4"
          />
          <polygon points="12,8 15,12 12,16 9,12" fill="#e0f2fe" />
        </>
      )}
  </svg>
);

export const StatusEffectTooltipCard: React.FC<{
  type: StatusEffectType;
  turnsLeft?: number;
  placement?: 'top' | 'bottom';
}> = ({ type, turnsLeft, placement = 'top' }) => {
  const meta = STATUS_EFFECT_META[type] ?? STATUS_EFFECT_META.blessed;
  const data = getStatusEffectTooltipData(type, turnsLeft);

  return (
    <div
      role="tooltip"
      data-testid="status-effect-tooltip"
      data-status-type={type}
      className={`pointer-events-none absolute left-0 z-50 w-60 rounded-lg border p-2.5 shadow-2xl text-left font-sans normal-case tracking-normal ${
        placement === 'bottom' ? 'top-full mt-2' : 'bottom-full mb-2'
      } ${meta.borderColor}`}
      style={{ backgroundColor: 'rgba(11, 9, 18, 0.98)' }}
    >
      <div className="flex items-center justify-between gap-2 pb-1.5 border-b border-stone-800">
        <div className="flex items-center gap-1.5">
          <StatusEffectRawSvg
            type={type}
            dimClass="w-4 h-4"
            titleText={data.label}
          />
          <span
            data-testid="status-tooltip-label"
            className={`text-xs font-display font-bold ${meta.textColor}`}
          >
            {data.label}
          </span>
        </div>
        <span
          className={`text-[9px] font-mono uppercase tracking-wider px-1.5 py-0.5 rounded border ${
            data.isBuff
              ? 'border-emerald-400/50 text-emerald-300 bg-emerald-950/60'
              : 'border-rose-400/50 text-rose-300 bg-rose-950/60'
          }`}
        >
          {data.categoryLabel}
        </span>
      </div>

      <p
        data-testid="status-tooltip-effect"
        className="mt-1.5 text-[11px] leading-snug text-stone-200 whitespace-normal"
      >
        {data.mechanicalEffect}
      </p>

      <div className="mt-2 pt-1.5 border-t border-stone-800/90 flex items-center justify-between text-[10px] font-mono tabular-nums">
        <span className={meta.textColor}>{data.shortClue}</span>
        <span
          data-testid="status-tooltip-duration"
          className="text-amber-300 font-semibold"
        >
          ⏳ {data.durationLabel}
        </span>
      </div>
    </div>
  );
};

export const StatusEffectIconSvg: React.FC<{
  type: StatusEffectType;
  turnsLeft?: number;
  size?: 'sm' | 'md';
  className?: string;
  showTooltip?: boolean;
  tooltipPlacement?: 'top' | 'bottom';
  testId?: string;
}> = ({
  type,
  turnsLeft,
  size = 'sm',
  className,
  showTooltip = true,
  tooltipPlacement = 'top',
  testId,
}) => {
  const [isHovered, setIsHovered] = useState(false);
  const data = getStatusEffectTooltipData(type, turnsLeft);
  const dimClass = className ?? (size === 'sm' ? 'w-4 h-4' : 'w-5 h-5');
  const titleText = `${data.label} (${data.shortClue}) — ${data.mechanicalEffect} [${data.durationLabel}]`;

  if (!showTooltip) {
    return <StatusEffectRawSvg type={type} dimClass={dimClass} titleText={titleText} />;
  }

  return (
    <span
      data-testid={testId ?? `status-icon-${type}`}
      data-status-type={type}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onFocus={() => setIsHovered(true)}
      onBlur={() => setIsHovered(false)}
      className="relative inline-flex items-center justify-center cursor-help"
    >
      <StatusEffectRawSvg type={type} dimClass={dimClass} titleText={titleText} />
      {isHovered && (
        <StatusEffectTooltipCard
          type={type}
          turnsLeft={turnsLeft}
          placement={tooltipPlacement}
        />
      )}
    </span>
  );
};

export const StatusEffectChipWithTooltip: React.FC<{
  type: StatusEffectType;
  turnsLeft: number;
  tooltipPlacement?: 'top' | 'bottom';
  testId?: string;
}> = ({ type, turnsLeft, tooltipPlacement = 'top', testId }) => {
  const [isHovered, setIsHovered] = useState(false);
  const meta = STATUS_EFFECT_META[type] ?? STATUS_EFFECT_META.blessed;
  const data = getStatusEffectTooltipData(type, turnsLeft);

  return (
    <span
      data-testid={testId ?? `active-dock-status-${type}`}
      data-status-type={type}
      tabIndex={0}
      aria-label={`${data.label}: ${data.mechanicalEffect} (${data.durationLabel})`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onFocus={() => setIsHovered(true)}
      onBlur={() => setIsHovered(false)}
      className={`relative inline-flex items-center gap-1 px-1.5 py-0.5 rounded border text-[10px] font-mono tabular-nums whitespace-nowrap cursor-help transition-colors ${meta.borderColor} ${meta.textColor}`}
      style={{ backgroundColor: meta.bgColor }}
    >
      <StatusEffectIconSvg
        type={type}
        turnsLeft={turnsLeft}
        showTooltip={false}
        className="w-3 h-3"
      />
      <span>
        {meta.label} {turnsLeft}t
      </span>
      {isHovered && (
        <StatusEffectTooltipCard
          type={type}
          turnsLeft={turnsLeft}
          placement={tooltipPlacement}
        />
      )}
    </span>
  );
};

export const ItemIconSvg: React.FC<{
  kind: string;
  rarityColor?: string;
  className?: string;
}> = ({ kind, rarityColor = '#E2B05A', className = 'w-8 h-8' }) => (
  <svg viewBox="0 0 36 36" className={className} aria-hidden="true">
    <rect
      x="1.5"
      y="1.5"
      width="33"
      height="33"
      rx="5"
      fill="#1A1E1B"
      stroke={rarityColor}
      strokeWidth="1.4"
      opacity="0.95"
    />
    {kind === 'sword' && (
      <g strokeLinecap="round" strokeLinejoin="round">
        <path d="M26,8 L13,21" stroke="#E2E8F0" strokeWidth="2.8" />
        <path d="M11,17 L19,25" stroke="#E2B05A" strokeWidth="2.2" />
        <path d="M13,21 L9,25" stroke="#78350F" strokeWidth="2.6" />
        <circle cx="8.5" cy="26.5" r="1.8" fill="#E2B05A" />
      </g>
    )}
    {kind === 'bow' && (
      <g fill="none" strokeLinecap="round">
        <path d="M11,7 C24,11 24,25 11,29" stroke="#B45309" strokeWidth="2.5" />
        <line x1="11" y1="7" x2="11" y2="29" stroke="#D6D3D1" strokeWidth="1.2" />
        <line x1="9" y1="18" x2="26" y2="18" stroke="#E2B05A" strokeWidth="1.8" />
        <polygon points="27,18 23,15.5 23,20.5" fill="#E2E8F0" />
      </g>
    )}
    {kind === 'staff' && (
      <g strokeLinecap="round">
        <line x1="10" y1="27" x2="24" y2="11" stroke="#92400E" strokeWidth="2.6" />
        <polygon points="25,7 29,11 25,15 21,11" fill="#60A5FA" stroke="#DBEAFE" strokeWidth="1" />
      </g>
    )}
    {kind === 'armor' && (
      <path
        d="M12,8 L18,10 L24,8 L27,13 L24,16 L24,27 L12,27 L12,16 L9,13 Z"
        fill="#475569"
        stroke="#CBD5E1"
        strokeWidth="1.5"
      />
    )}
    {kind === 'shield' && (
      <path
        d="M18,7 L27,10 V18 C27,23.5 23,27.5 18,29.5 C13,27.5 9,23.5 9,18 V10 Z"
        fill="#334155"
        stroke="#E2B05A"
        strokeWidth="1.8"
      />
    )}
    {(kind === 'amulet' || kind === 'relic') && (
      <g>
        <path d="M12,9 Q18,20 24,9" fill="none" stroke="#D97706" strokeWidth="1.5" />
        <polygon points="18,15 23,22 18,28 13,22" fill={kind === 'relic' ? '#A855F7' : '#E2B05A'} stroke="#FEF3C7" strokeWidth="1.2" />
      </g>
    )}
    {(kind === 'potion_green' || kind === 'potion_amber' || kind === 'potion_blue') && (
      <g>
        <rect x="15" y="7" width="6" height="4" rx="1" fill="#A8A29E" />
        <path
          d="M15,11 L11,19 C10,23 13,28 18,28 C23,28 26,23 25,19 L21,11 Z"
          fill={
            kind === 'potion_green'
              ? '#22C55E'
              : kind === 'potion_amber'
              ? '#F59E0B'
              : '#38BDF8'
          }
          stroke="#F8FAFC"
          strokeWidth="1.3"
        />
      </g>
    )}
    {(kind === 'food' || kind === 'drink') && (
      <g>
        <path
          d="M10,16 H25 V24 C25,26.5 22,28 17.5,28 C13,28 10,26.5 10,24 Z"
          fill={kind === 'drink' ? '#92400E' : '#B45309'}
          stroke="#FDE68A"
          strokeWidth="1.3"
        />
        <path d="M14,12 Q15,9 14,7 M19,12 Q20,9 19,7" stroke="#E5E7EB" strokeWidth="1.3" fill="none" />
      </g>
    )}
    {(kind === 'herb' || kind === 'blight_herb') && (
      <g>
        <path
          d="M11,26 Q18,18 25,9"
          stroke={kind === 'blight_herb' ? '#60A5FA' : '#4ADE80'}
          strokeWidth="2"
          fill="none"
        />
        <ellipse
          cx="16"
          cy="17"
          rx="4"
          ry="2.2"
          transform="rotate(-35 16 17)"
          fill={kind === 'blight_herb' ? '#818CF8' : '#22C55E'}
        />
        <ellipse
          cx="21"
          cy="14"
          rx="4"
          ry="2.2"
          transform="rotate(25 21 14)"
          fill={kind === 'blight_herb' ? '#38BDF8' : '#86EFAC'}
        />
      </g>
    )}
    {kind === 'ingot' && (
      <polygon
        points="9,24 13,15 23,15 27,24"
        fill="#64748B"
        stroke="#E2E8F0"
        strokeWidth="1.5"
      />
    )}
    {kind === 'timber' && (
      <g>
        <rect x="8" y="13" width="20" height="5" rx="1.5" fill="#92400E" stroke="#FCD34D" strokeWidth="1" />
        <rect x="9" y="19" width="18" height="5" rx="1.5" fill="#78350F" stroke="#D97706" strokeWidth="1" />
      </g>
    )}
    {kind === 'oil' && (
      <g>
        <rect x="12" y="10" width="12" height="17" rx="3" fill="#78350F" stroke="#F59E0B" strokeWidth="1.4" />
        <line x1="12" y1="15" x2="24" y2="15" stroke="#FDE68A" strokeWidth="1.2" />
      </g>
    )}
    {(kind === 'tool' || kind === 'key' || kind === 'dagger') && (
      <g stroke="#E2B05A" strokeWidth="2" fill="none" strokeLinecap="round">
        <circle cx="13" cy="22" r="4" />
        <line x1="16" y1="19" x2="26" y2="9" />
        <line x1="23" y1="12" x2="26" y2="15" />
      </g>
    )}
    {kind === 'book' && (
      <g>
        <rect x="10" y="8" width="16" height="20" rx="2" fill="#44403C" stroke="#E2B05A" strokeWidth="1.5" />
        <line x1="14" y1="13" x2="22" y2="13" stroke="#E7E5E4" strokeWidth="1.3" />
        <line x1="14" y1="17" x2="22" y2="17" stroke="#E7E5E4" strokeWidth="1.3" />
      </g>
    )}
  </svg>
);



