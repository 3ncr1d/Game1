import React, { useEffect, useMemo, useState } from 'react';
import {
  CharacterCreationBuild,
  CombatUnit,
  CompanionId,
  CompanionRelationship,
  GridTile,
  TacticalEnvObject,
  WorldReactivityState,
} from '../game/rules';
import {
  buildSkillDetailViewModel,
  getAvailableSkillCategories,
  getUnitClassIdentity,
  getUnitSkillCatalog,
  SkillMenuCategoryId,
  UnitSkillCatalogEntry,
} from '../game/skillSystemUi';
import { CharacterPortraitSvg, StatusEffectIconSvg } from './PortraitsAndIcons';
import { SkillIconSvg } from './SkillIcons';
import { SkillTooltipAnchor } from './SkillTooltip';

interface TacticalSkillMenuModalProps {
  unit: CombatUnit;
  allUnits: CombatUnit[];
  grid: GridTile[][];
  envObjects: TacticalEnvObject[];
  relationships: Record<CompanionId, CompanionRelationship>;
  worldState: WorldReactivityState;
  characterBuild: CharacterCreationBuild;
  selectedAbilityKey: '1' | '2' | '3' | '4' | null;
  onSelectPartyUnit: (unitId: string) => void;
  onAssignSkillToSlot: (
    unitId: string,
    entry: UnitSkillCatalogEntry,
    slotKey: '1' | '2' | '3' | '4'
  ) => void;
  onClose: () => void;
}

export const TacticalSkillMenuModal: React.FC<TacticalSkillMenuModalProps> = ({
  unit,
  allUnits,
  grid,
  envObjects,
  relationships,
  worldState,
  characterBuild,
  selectedAbilityKey,
  onSelectPartyUnit,
  onAssignSkillToSlot,
  onClose,
}) => {
  const livingPartyUnits = useMemo(
    () => allUnits.filter((u) => u.faction === 'party' && !u.isKO),
    [allUnits]
  );

  // Always reflect active party character; if an enemy turn is briefly active, fall back to first conscious party companion
  const inspectedPartyUnit = useMemo(() => {
    if (unit.faction === 'party' && !unit.isKO) return unit;
    return livingPartyUnits[0] ?? unit;
  }, [unit, livingPartyUnits]);

  const identity = useMemo(
    () => getUnitClassIdentity(inspectedPartyUnit, characterBuild),
    [inspectedPartyUnit, characterBuild]
  );

  const catalog = useMemo(
    () => getUnitSkillCatalog(inspectedPartyUnit, worldState, characterBuild),
    [inspectedPartyUnit, worldState, characterBuild]
  );

  const availableCategories = useMemo(
    () => getAvailableSkillCategories(catalog),
    [catalog]
  );

  const [activeCategory, setActiveCategory] = useState<SkillMenuCategoryId>('all');
  const [selectedSkillId, setSelectedSkillId] = useState<string>(
    () => catalog[0]?.ability.id ?? ''
  );
  const [mobilePane, setMobilePane] = useState<'collection' | 'details'>('collection');

  // Pending slot replacement confirmation state (Part 5F)
  const [pendingAssignSlot, setPendingAssignSlot] = useState<'1' | '2' | '3' | '4' | null>(null);
  const [recentlyAssignedSlot, setRecentlyAssignedSlot] = useState<'1' | '2' | '3' | '4' | null>(
    null
  );

  // Right-click contextual menu state (Part 4.3)
  const [contextMenu, setContextMenu] = useState<{
    x: number;
    y: number;
    entry: UnitSkillCatalogEntry;
  } | null>(null);

  // Keep category & selected skill synchronized when switching characters
  useEffect(() => {
    setPendingAssignSlot(null);
    setContextMenu(null);
    const catStillValid = availableCategories.some((c) => c.id === activeCategory);
    const nextCat = catStillValid ? activeCategory : 'all';
    if (nextCat !== activeCategory) {
      setActiveCategory(nextCat);
    }
    const filtered = catalog.filter((entry) => entry.categories.includes(nextCat));
    if (!filtered.some((e) => e.ability.id === selectedSkillId) && filtered[0]) {
      setSelectedSkillId(filtered[0].ability.id);
    }
  }, [inspectedPartyUnit.id, catalog, availableCategories, activeCategory, selectedSkillId]);

  const filteredCatalog = useMemo(
    () => catalog.filter((entry) => entry.categories.includes(activeCategory)),
    [catalog, activeCategory]
  );

  const handleSelectCategory = (catId: SkillMenuCategoryId) => {
    setActiveCategory(catId);
    setPendingAssignSlot(null);
    setContextMenu(null);
    const nextList = catalog.filter((entry) => entry.categories.includes(catId));
    if (!nextList.some((entry) => entry.ability.id === selectedSkillId) && nextList[0]) {
      setSelectedSkillId(nextList[0].ability.id);
    }
  };

  const selectedEntry = useMemo(
    () =>
      catalog.find((e) => e.ability.id === selectedSkillId) ??
      filteredCatalog[0] ??
      catalog[0],
    [catalog, filteredCatalog, selectedSkillId]
  );

  const detailBySkillId = useMemo(() => {
    const map = new Map<string, ReturnType<typeof buildSkillDetailViewModel>>();
    for (const entry of catalog) {
      map.set(
        entry.ability.id,
        buildSkillDetailViewModel(
          inspectedPartyUnit,
          entry,
          allUnits,
          relationships,
          worldState,
          grid,
          envObjects,
          selectedAbilityKey
        )
      );
    }
    return map;
  }, [
    catalog,
    inspectedPartyUnit,
    allUnits,
    relationships,
    worldState,
    grid,
    envObjects,
    selectedAbilityKey,
  ]);

  const selectedDetail = selectedEntry
    ? detailBySkillId.get(selectedEntry.ability.id) ?? null
    : null;

  const requestSlotAssignment = (
    entry: UnitSkillCatalogEntry,
    slotKey: '1' | '2' | '3' | '4'
  ) => {
    if (entry.isLocked || entry.equippedSlotKey === slotKey) return;
    setSelectedSkillId(entry.ability.id);
    setPendingAssignSlot(slotKey);
    setMobilePane('details');
    setContextMenu(null);
  };

  const confirmSlotAssignment = () => {
    if (!selectedEntry || !pendingAssignSlot || selectedEntry.isLocked) return;
    const chosenSlot = pendingAssignSlot;
    onAssignSkillToSlot(inspectedPartyUnit.id, selectedEntry, chosenSlot);
    setPendingAssignSlot(null);
    setRecentlyAssignedSlot(chosenSlot);
    window.setTimeout(() => {
      setRecentlyAssignedSlot((cur) => (cur === chosenSlot ? null : cur));
    }, 300);
  };

  const handleCardDoubleClick = (entry: UnitSkillCatalogEntry) => {
    if (entry.isLocked) return;
    if (entry.equippedSlotKey !== null) return;
    // Propose matching tactical slot (e.g. Slot 1 for at-will attacks, Slot 2 for 2-AP signatures) with required confirmation
    const defaultSlot: '1' | '2' | '3' | '4' =
      entry.ability.apCost >= 2 ? '2' : entry.primaryCategoryLabel === 'Support' ? '4' : '1';
    requestSlotAssignment(entry, defaultSlot);
  };

  const pendingOccupant = pendingAssignSlot
    ? inspectedPartyUnit.abilities.find((a) => a.key === pendingAssignSlot) ?? null
    : null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="skill-menu-heading"
      data-testid="tactical-skill-menu-modal"
      onClick={() => setContextMenu(null)}
      style={{ backgroundColor: 'rgba(11, 13, 12, 0.74)' }}
      className="fixed inset-0 z-40 flex items-center justify-center p-3 sm:p-5 pointer-events-auto"
    >
      <div
        onClick={(e) => {
          e.stopPropagation();
          if (contextMenu) setContextMenu(null);
        }}
        style={{
          backgroundColor: '#171B19',
          borderColor: '#5A4B38',
          color: '#F2ECE1',
        }}
        className="dim-skill-menu-enter w-[94vw] lg:w-[84vw] max-w-[1320px] h-[88vh] lg:h-[83vh] max-h-[850px] rounded-lg border shadow-[0_24px_64px_rgba(0,0,0,0.92)] flex flex-col overflow-hidden"
      >
        {/* ==================== HEADER BAR ==================== */}
        <header
          style={{ backgroundColor: '#222722', borderColor: '#5A4B38' }}
          className="px-4 sm:px-5 py-3 border-b flex flex-wrap items-center justify-between gap-3 shrink-0"
        >
          <div className="flex items-center gap-3 min-w-0">
            <CharacterPortraitSvg
              id={inspectedPartyUnit.companionId ?? 'seraphina'}
              className="w-10 h-10 rounded border border-[#E2B05A]/70 shrink-0"
            />
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h2
                  id="skill-menu-heading"
                  className="font-display font-bold text-base sm:text-lg tracking-wider uppercase"
                  style={{ color: '#F2ECE1' }}
                >
                  Skills
                </h2>
                <span aria-hidden="true" style={{ color: '#5A4B38' }}>
                  ◆
                </span>
                <span
                  className="font-mono text-xs tabular-nums"
                  style={{ color: '#E2B05A' }}
                >
                  AP {inspectedPartyUnit.ap} / {inspectedPartyUnit.maxAp}
                </span>
              </div>
              <p
                data-testid="skill-menu-character-header"
                className="text-xs font-display tracking-wide uppercase truncate"
                style={{ color: '#B5AC9A' }}
              >
                {inspectedPartyUnit.name} — {identity.className} — {identity.subclassName}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {/* Party Companion Switcher */}
            <div
              role="group"
              aria-label="Select Party Member"
              className="flex items-center gap-1.5 mr-1"
            >
              {livingPartyUnits.map((pu) => {
                const isCurrent = pu.id === inspectedPartyUnit.id;
                return (
                  <button
                    key={pu.id}
                    type="button"
                    data-testid={`skill-menu-unit-${pu.id}`}
                    onClick={() => onSelectPartyUnit(pu.id)}
                    style={{
                      backgroundColor: isCurrent ? '#3A3324' : '#171B19',
                      borderColor: isCurrent ? '#E2B05A' : '#5A4B38',
                      color: isCurrent ? '#F2ECE1' : '#B5AC9A',
                    }}
                    className="px-2.5 py-1 rounded border text-xs font-medium flex items-center gap-1.5 transition-colors hover:border-[#E2B05A] cursor-pointer"
                  >
                    <CharacterPortraitSvg
                      id={pu.companionId ?? 'seraphina'}
                      className="w-4 h-4 rounded-sm shrink-0"
                    />
                    <span className="whitespace-nowrap">{pu.name.split(' ')[0]}</span>
                  </button>
                );
              })}
            </div>

            {/* Responsive Compact Screen Pane Switcher (< lg) */}
            <div className="flex lg:hidden items-center rounded border border-[#5A4B38] overflow-hidden text-xs font-mono">
              <button
                type="button"
                onClick={() => setMobilePane('collection')}
                style={{
                  backgroundColor: mobilePane === 'collection' ? '#3A3324' : '#171B19',
                  color: mobilePane === 'collection' ? '#E2B05A' : '#B5AC9A',
                }}
                className="px-2.5 py-1"
              >
                Skills
              </button>
              <button
                type="button"
                onClick={() => setMobilePane('details')}
                style={{
                  backgroundColor: mobilePane === 'details' ? '#3A3324' : '#171B19',
                  color: mobilePane === 'details' ? '#E2B05A' : '#B5AC9A',
                }}
                className="px-2.5 py-1 border-l border-[#5A4B38]"
              >
                Details
              </button>
            </div>

            <button
              type="button"
              data-testid="close-skill-menu-btn"
              onClick={onClose}
              style={{
                backgroundColor: '#171B19',
                borderColor: '#5A4B38',
                color: '#F2ECE1',
              }}
              className="px-3 py-1.5 rounded border text-xs font-mono font-semibold hover:border-[#E2B05A] hover:text-[#E2B05A] transition-colors cursor-pointer"
            >
              [K] CLOSE
            </button>
          </div>
        </header>

        {/* ==================== THREE-COLUMN MAIN WORKSPACE ==================== */}
        <div className="flex-1 min-h-0 flex flex-col lg:flex-row overflow-hidden">
          {/* -------- COLUMN 1 (LEFT): SKILL CATEGORIES -------- */}
          <nav
            aria-label="Skill Categories"
            data-testid="skill-menu-categories"
            style={{ backgroundColor: '#171B19', borderColor: '#5A4B38' }}
            className={`${
              mobilePane === 'details' ? 'hidden lg:flex' : 'flex'
            } lg:w-[205px] border-b lg:border-b-0 lg:border-r p-2.5 lg:p-3.5 flex-row lg:flex-col gap-1.5 overflow-x-auto lg:overflow-y-auto shrink-0 dim-scroll`}
          >
            <p
              className="hidden lg:block text-[11px] font-mono uppercase tracking-widest mb-1.5 px-2"
              style={{ color: '#77796F' }}
            >
              Categories
            </p>
            {availableCategories.map((cat) => {
              const isSelected = cat.id === activeCategory;
              return (
                <button
                  key={cat.id}
                  type="button"
                  data-testid={`skill-category-${cat.id}`}
                  onClick={() => handleSelectCategory(cat.id)}
                  style={{
                    backgroundColor: isSelected ? '#3A3324' : 'transparent',
                    borderColor: isSelected ? '#E2B05A' : 'transparent',
                    color: isSelected ? '#F2ECE1' : '#B5AC9A',
                  }}
                  className="px-3 py-2 rounded border text-left text-xs font-medium flex items-center justify-between gap-2 transition-colors hover:text-[#F2ECE1] hover:bg-[#222722] whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <span>{cat.label}</span>
                  <span
                    className="font-mono text-[11px] tabular-nums"
                    style={{ color: isSelected ? '#E2B05A' : '#77796F' }}
                  >
                    ({cat.count})
                  </span>
                </button>
              );
            })}
          </nav>

          {/* -------- COLUMN 2 (CENTER): SKILL COLLECTION GRID -------- */}
          <div
            data-testid="skill-menu-collection"
            style={{ backgroundColor: '#171B19', borderColor: '#5A4B38' }}
            className={`${
              mobilePane === 'details' ? 'hidden lg:flex' : 'flex'
            } flex-1 min-w-0 flex-col overflow-hidden lg:border-r`}
          >
            <div
              style={{ borderColor: '#5A4B38' }}
              className="px-4 py-2.5 border-b flex items-center justify-between text-xs shrink-0"
            >
              <span
                className="font-mono uppercase tracking-wider text-[11px]"
                style={{ color: '#B5AC9A' }}
              >
                Available Skills ({filteredCatalog.length})
              </span>
              <span className="text-[11px] hidden sm:inline" style={{ color: '#77796F' }}>
                Click to inspect · Double-click or Right-click to assign
              </span>
            </div>

            <div className="p-4 overflow-y-auto flex-1 dim-scroll">
              <div className="grid grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4 gap-3">
                {filteredCatalog.map((entry) => {
                  const detail = detailBySkillId.get(entry.ability.id)!;
                  const { slotEvaluation } = detail;
                  const isCardSelected = selectedEntry?.ability.id === entry.ability.id;
                  const isLocked = entry.isLocked;

                  return (
                    <SkillTooltipAnchor
                      key={entry.ability.id}
                      detail={detail}
                      placement="top"
                      delayMs={180}
                    >
                      <button
                        type="button"
                        data-testid={`skill-card-${entry.ability.id}`}
                        data-locked={isLocked ? 'true' : 'false'}
                        onClick={() => {
                          setSelectedSkillId(entry.ability.id);
                          setPendingAssignSlot(null);
                          setMobilePane('details');
                        }}
                        onDoubleClick={() => handleCardDoubleClick(entry)}
                        onContextMenu={(e) => {
                          e.preventDefault();
                          e.stopPropagation();
                          setSelectedSkillId(entry.ability.id);
                          if (!entry.isLocked) {
                            setContextMenu({
                              x: e.clientX,
                              y: e.clientY,
                              entry,
                            });
                          }
                        }}
                        style={{
                          backgroundColor: isCardSelected ? '#3A3324' : '#292E29',
                          borderColor: isCardSelected ? '#E2B05A' : '#5A4B38',
                        }}
                        className="w-full h-full rounded-md border p-3 flex flex-col items-center text-center justify-between gap-2.5 transition-all duration-125 hover:border-[#E2B05A] hover:brightness-105 cursor-pointer"
                      >
                        {/* Top Meta Badge Row */}
                        <div className="w-full flex items-center justify-between text-[10px] font-mono">
                          <span style={{ color: '#B5AC9A' }}>
                            {entry.primaryCategoryLabel.toUpperCase()}
                          </span>
                          {entry.equippedSlotKey ? (
                            <span
                              style={{
                                backgroundColor: '#222722',
                                borderColor: '#E2B05A',
                                color: '#E2B05A',
                              }}
                              className="px-1.5 py-0.5 rounded border font-bold"
                            >
                              SLOT {entry.equippedSlotKey}
                            </span>
                          ) : isLocked ? (
                            <span style={{ color: '#77796F' }} className="font-semibold">
                              LOCKED
                            </span>
                          ) : null}
                        </div>

                        {/* Centered 56x56 Standalone Skill Icon */}
                        <div className="relative w-14 h-14 rounded overflow-hidden border border-[#5A4B38]">
                          <SkillIconSvg
                            skillId={entry.ability.id}
                            skillName={entry.ability.name}
                            className={`w-full h-full ${
                              isLocked ? 'grayscale brightness-50' : ''
                            }`}
                          />
                        </div>

                        {/* Full Readable Skill Name (No Truncation) */}
                        <p
                          className="font-display font-bold text-[13px] leading-snug"
                          style={{ color: isLocked ? '#B5AC9A' : '#F2ECE1' }}
                        >
                          {entry.ability.name}
                        </p>

                        {/* Footer Stats: AP, Cooldown/Range & Unlock/Availability Status */}
                        <div
                          style={{ borderColor: 'rgba(90, 75, 56, 0.55)' }}
                          className="w-full pt-2 border-t space-y-1 font-mono text-[11px] tabular-nums"
                        >
                          <div className="flex items-center justify-between">
                            <span style={{ color: '#E2B05A' }}>
                              ◆ {entry.ability.apCost} AP
                            </span>
                            <span style={{ color: '#B5AC9A' }}>
                              {entry.ability.cooldown > 0
                                ? `CD ${entry.ability.cooldown}T`
                                : `RNG ${entry.ability.range}`}
                            </span>
                          </div>
                          <div className="text-[10px] font-semibold tracking-wider uppercase">
                            {isLocked ? (
                              <span style={{ color: '#B85349' }}>SUBCLASS LOCKED</span>
                            ) : slotEvaluation.state === 'cooldown' ? (
                              <span style={{ color: '#B85349' }}>
                                COOLDOWN ({slotEvaluation.cooldownRemaining}T)
                              </span>
                            ) : slotEvaluation.state === 'insufficient_ap' ? (
                              <span style={{ color: '#B85349' }}>INSUFFICIENT AP</span>
                            ) : slotEvaluation.state === 'out_of_range' ? (
                              <span style={{ color: '#E2B05A' }}>OUT OF RANGE</span>
                            ) : (
                              <span style={{ color: '#7E9C82' }}>AVAILABLE</span>
                            )}
                          </div>
                        </div>
                      </button>
                    </SkillTooltipAnchor>
                  );
                })}
              </div>
            </div>
          </div>

          {/* -------- COLUMN 3 (RIGHT): SKILL DETAIL PANEL (PART 5) -------- */}
          <aside
            aria-label="Selected Skill Details"
            data-testid="skill-menu-detail-panel"
            style={{ backgroundColor: '#222722' }}
            className={`${
              mobilePane === 'collection' ? 'hidden lg:flex' : 'flex'
            } w-full lg:w-[390px] xl:w-[420px] flex-col overflow-y-auto p-4 sm:p-5 space-y-4 shrink-0 dim-scroll`}
          >
            {selectedDetail && (
              <>
                {/* A. SKILL IDENTITY */}
                <div className="flex items-start gap-3.5 pb-3.5 border-b border-[#5A4B38]">
                  <div className="w-[72px] h-[72px] rounded-md overflow-hidden border border-[#E2B05A]/80 shrink-0 shadow-md">
                    <SkillIconSvg
                      skillId={selectedDetail.entry.ability.id}
                      skillName={selectedDetail.entry.ability.name}
                      className={`w-full h-full ${
                        selectedDetail.entry.isLocked ? 'grayscale brightness-60' : ''
                      }`}
                    />
                  </div>
                  <div className="min-w-0 flex-1 space-y-1">
                    <h3
                      data-testid="detail-skill-name"
                      className="font-display font-bold text-lg leading-tight"
                      style={{ color: '#F2ECE1' }}
                    >
                      {selectedDetail.entry.ability.name}
                    </h3>
                    <p className="text-xs font-medium" style={{ color: '#E2B05A' }}>
                      {selectedDetail.entry.className}
                      {selectedDetail.entry.subclassName
                        ? ` · ${selectedDetail.entry.subclassName}`
                        : ''}
                    </p>
                    <div className="flex flex-wrap items-center gap-1.5 pt-0.5 text-[11px] font-mono">
                      <span
                        style={{
                          backgroundColor: '#292E29',
                          borderColor: '#5A4B38',
                          color: '#B5AC9A',
                        }}
                        className="px-2 py-0.5 rounded border"
                      >
                        {selectedDetail.entry.primaryCategoryLabel} ·{' '}
                        {selectedDetail.entry.specialtyLabel}
                      </span>
                      {selectedDetail.entry.equippedSlotKey && (
                        <span
                          style={{
                            backgroundColor: '#3A3324',
                            borderColor: '#E2B05A',
                            color: '#E2B05A',
                          }}
                          className="px-2 py-0.5 rounded border font-bold"
                        >
                          Equipped [{selectedDetail.entry.equippedSlotKey}]
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Unlock / Combat Availability Notice */}
                {selectedDetail.entry.isLocked && selectedDetail.entry.unlockRequirement && (
                  <div
                    data-testid="detail-locked-banner"
                    style={{
                      backgroundColor: 'rgba(184, 83, 73, 0.14)',
                      borderColor: '#B85349',
                      color: '#F2ECE1',
                    }}
                    className="rounded border px-3 py-2 text-xs flex items-center gap-2"
                  >
                    <span className="font-mono font-bold" style={{ color: '#B85349' }}>
                      LOCKED:
                    </span>
                    <span>{selectedDetail.entry.unlockRequirement}</span>
                  </div>
                )}

                {/* B. SKILL DESCRIPTION (Flavor separated from Mechanics) */}
                <div className="space-y-2">
                  <p
                    className="text-xs italic leading-relaxed"
                    style={{ color: '#B5AC9A' }}
                  >
                    “{selectedDetail.flavorText}”
                  </p>
                  <p
                    data-testid="detail-skill-description"
                    className="text-[13px] leading-relaxed"
                    style={{ color: '#F2ECE1' }}
                  >
                    {selectedDetail.mechanicalDescription}
                  </p>
                </div>

                {/* C. COMBAT INFORMATION TABLE */}
                <div className="space-y-1.5">
                  <h4
                    className="text-[11px] font-mono uppercase tracking-widest"
                    style={{ color: '#E2B05A' }}
                  >
                    Combat Information
                  </h4>
                  <div
                    style={{ backgroundColor: '#171B19', borderColor: '#5A4B38' }}
                    className="rounded border divide-y divide-[#5A4B38]/55 text-xs"
                  >
                    {selectedDetail.combatStats.map((row) => (
                      <div
                        key={row.label}
                        className="px-3 py-1.5 flex items-baseline justify-between gap-3"
                      >
                        <span className="shrink-0" style={{ color: '#B5AC9A' }}>
                          {row.label}
                        </span>
                        <span
                          className="font-mono tabular-nums text-right font-semibold"
                          style={{
                            color:
                              row.tone === 'gold'
                                ? '#E2B05A'
                                : row.tone === 'positive'
                                ? '#7E9C82'
                                : row.tone === 'danger'
                                ? '#B85349'
                                : '#F2ECE1',
                          }}
                        >
                          {row.value}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* D. EFFECTS (Individual Actual Effect Rows + Status Icons) */}
                <div className="space-y-1.5">
                  <h4
                    className="text-[11px] font-mono uppercase tracking-widest"
                    style={{ color: '#E2B05A' }}
                  >
                    Effects
                  </h4>
                  <div className="space-y-1.5">
                    {selectedDetail.effects.map((eff) => (
                      <div
                        key={eff.id}
                        style={{ backgroundColor: '#292E29', borderColor: '#5A4B38' }}
                        className="rounded border px-3 py-2 flex items-start gap-2.5 text-xs"
                      >
                        {eff.statusType ? (
                          <StatusEffectIconSvg
                            type={eff.statusType}
                            turnsLeft={2}
                            showTooltip={false}
                            className="w-5 h-5 mt-0.5 shrink-0"
                          />
                        ) : (
                          <span
                            aria-hidden="true"
                            style={{ color: '#E2B05A' }}
                            className="font-mono font-bold mt-0.5 shrink-0"
                          >
                            ◆
                          </span>
                        )}
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center justify-between gap-2">
                            <span className="font-semibold" style={{ color: '#F2ECE1' }}>
                              {eff.title}
                            </span>
                            {eff.durationLabel && (
                              <span
                                className="font-mono text-[11px]"
                                style={{ color: '#E2B05A' }}
                              >
                                {eff.durationLabel}
                              </span>
                            )}
                          </div>
                          <p
                            className="text-[11.5px] leading-snug mt-0.5"
                            style={{ color: '#B5AC9A' }}
                          >
                            {eff.detail}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* E. TACTICAL USE */}
                <div className="space-y-1.5">
                  <h4
                    className="text-[11px] font-mono uppercase tracking-widest"
                    style={{ color: '#E2B05A' }}
                  >
                    Tactical Use
                  </h4>
                  <div
                    style={{ backgroundColor: '#171B19', borderColor: '#5A4B38' }}
                    className="rounded border p-3 space-y-2 text-xs leading-relaxed"
                  >
                    <p style={{ color: '#F2ECE1' }}>
                      <strong style={{ color: '#E2B05A' }}>Optimal Timing: </strong>
                      {selectedDetail.tacticalUse.whenToUse}
                    </p>
                    <p style={{ color: '#B5AC9A' }}>
                      <strong style={{ color: '#F2ECE1' }}>Target Priority: </strong>
                      {selectedDetail.tacticalUse.bestTargets}
                    </p>
                    <p style={{ color: '#B5AC9A' }}>
                      <strong style={{ color: '#F2ECE1' }}>Positioning &amp; Terrain: </strong>
                      {selectedDetail.tacticalUse.positioningAndTerrain}
                    </p>
                    <p style={{ color: '#B5AC9A' }}>
                      <strong style={{ color: '#B85349' }}>Limitations: </strong>
                      {selectedDetail.tacticalUse.limitations}
                    </p>
                  </div>
                </div>

                {/* F. SKILL ASSIGNMENT (Slots 1-4 with Duplicate Prevention & Confirmation) */}
                {!selectedDetail.entry.isLocked && inspectedPartyUnit.faction === 'party' && (
                  <div className="space-y-2 pt-1">
                    <h4
                      className="text-[11px] font-mono uppercase tracking-widest"
                      style={{ color: '#E2B05A' }}
                    >
                      Skill Assignment
                    </h4>

                    {pendingAssignSlot && pendingOccupant && (
                      <div
                        data-testid="slot-replace-confirm-box"
                        style={{
                          backgroundColor: '#3A3324',
                          borderColor: '#E2B05A',
                        }}
                        className="rounded border p-3 space-y-2.5 text-xs"
                      >
                        <p style={{ color: '#F2ECE1' }}>
                          {selectedDetail.entry.equippedSlotKey ? (
                            <>
                              Move <strong>{selectedDetail.entry.ability.name}</strong> to{' '}
                              <strong>Slot {pendingAssignSlot}</strong> and swap{' '}
                              <strong>{pendingOccupant.name}</strong> into{' '}
                              <strong>Slot {selectedDetail.entry.equippedSlotKey}</strong>?
                            </>
                          ) : (
                            <>
                              Assign <strong>{selectedDetail.entry.ability.name}</strong> to{' '}
                              <strong>Slot {pendingAssignSlot}</strong>, replacing{' '}
                              <strong>{pendingOccupant.name}</strong>?
                            </>
                          )}
                        </p>
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            data-testid="confirm-slot-assign-btn"
                            onClick={confirmSlotAssignment}
                            style={{
                              backgroundColor: '#E2B05A',
                              color: '#171B19',
                            }}
                            className="px-3 py-1.5 rounded font-display font-bold text-xs uppercase tracking-wider cursor-pointer"
                          >
                            Confirm Assignment
                          </button>
                          <button
                            type="button"
                            data-testid="cancel-slot-assign-btn"
                            onClick={() => setPendingAssignSlot(null)}
                            style={{
                              backgroundColor: '#171B19',
                              borderColor: '#5A4B38',
                              color: '#B5AC9A',
                            }}
                            className="px-3 py-1.5 rounded border text-xs font-mono cursor-pointer hover:text-[#F2ECE1]"
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    )}

                    <div className="grid grid-cols-2 gap-2">
                      {(['1', '2', '3', '4'] as const).map((slotKey) => {
                        const isAlreadyHere =
                          selectedDetail.entry.equippedSlotKey === slotKey;
                        const occupant = inspectedPartyUnit.abilities.find(
                          (a) => a.key === slotKey
                        );
                        return (
                          <button
                            key={slotKey}
                            type="button"
                            disabled={isAlreadyHere}
                            data-testid={`equip-to-slot-${slotKey}`}
                            onClick={() =>
                              requestSlotAssignment(selectedDetail.entry, slotKey)
                            }
                            style={{
                              backgroundColor: isAlreadyHere ? '#3A3324' : '#292E29',
                              borderColor:
                                pendingAssignSlot === slotKey || isAlreadyHere
                                  ? '#E2B05A'
                                  : '#5A4B38',
                              color: isAlreadyHere ? '#E2B05A' : '#F2ECE1',
                            }}
                            className="px-2.5 py-2 rounded border text-left transition-colors hover:border-[#E2B05A] disabled:cursor-default cursor-pointer"
                          >
                            <div className="font-mono text-[11px] font-bold">
                              {isAlreadyHere
                                ? `EQUIPPED IN SLOT ${slotKey}`
                                : `EQUIP TO SLOT ${slotKey}`}
                            </div>
                            {occupant && !isAlreadyHere && (
                              <div
                                className="text-[10.5px] truncate mt-0.5"
                                style={{ color: '#B5AC9A' }}
                              >
                                {selectedDetail.entry.equippedSlotKey
                                  ? `Swaps: ${occupant.name}`
                                  : `Replaces: ${occupant.name}`}
                              </div>
                            )}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}
              </>
            )}
          </aside>
        </div>

        {/* ==================== PART 6: BOTTOM EQUIPPED SKILL STRIP ==================== */}
        <footer
          data-testid="skill-menu-equipped-strip"
          style={{ backgroundColor: '#222722', borderColor: '#5A4B38' }}
          className="px-4 py-2.5 border-t grid grid-cols-2 sm:grid-cols-4 gap-2.5 shrink-0"
        >
          {(['1', '2', '3', '4'] as const).map((slotKey) => {
            const equippedAb = inspectedPartyUnit.abilities.find((a) => a.key === slotKey);
            const isInspected =
              equippedAb && selectedDetail?.entry.ability.id === equippedAb.id;
            const isFlashing = recentlyAssignedSlot === slotKey;

            return (
              <button
                key={slotKey}
                type="button"
                data-testid={`equipped-strip-slot-${slotKey}`}
                onClick={() => {
                  if (equippedAb) {
                    setSelectedSkillId(equippedAb.id);
                    setPendingAssignSlot(null);
                    setMobilePane('details');
                  }
                }}
                style={{
                  backgroundColor: isInspected ? '#3A3324' : '#171B19',
                  borderColor: isInspected ? '#E2B05A' : '#5A4B38',
                }}
                className={`rounded border px-3 py-2 flex items-center gap-2.5 text-left transition-colors hover:border-[#E2B05A] cursor-pointer ${
                  isFlashing ? 'dim-slot-assign-flash' : ''
                }`}
              >
                {equippedAb && (
                  <div className="w-10 h-10 rounded overflow-hidden border border-[#5A4B38] shrink-0">
                    <SkillIconSvg
                      skillId={equippedAb.id}
                      skillName={equippedAb.name}
                      className="w-full h-full"
                    />
                  </div>
                )}
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-1 font-mono text-[10px]">
                    <span style={{ color: '#B5AC9A' }}>SLOT {slotKey}</span>
                    {equippedAb && (
                      <span className="font-bold" style={{ color: '#E2B05A' }}>
                        ◆ {equippedAb.apCost} AP
                      </span>
                    )}
                  </div>
                  <p
                    className="font-display font-bold text-xs truncate mt-0.5"
                    style={{ color: '#F2ECE1' }}
                  >
                    {equippedAb ? equippedAb.name : 'Empty Slot'}
                  </p>
                </div>
              </button>
            );
          })}
        </footer>

        {/* Right-Click Contextual Slot Assignment Menu */}
        {contextMenu && (
          <div
            role="menu"
            style={{
              left: `${Math.min(window.innerWidth - 210, contextMenu.x)}px`,
              top: `${Math.min(window.innerHeight - 190, contextMenu.y)}px`,
              backgroundColor: '#171B19',
              borderColor: '#E2B05A',
            }}
            onClick={(e) => e.stopPropagation()}
            className="fixed z-50 w-48 rounded border py-1.5 shadow-2xl text-xs font-mono"
          >
            <p
              className="px-3 py-1 text-[10px] uppercase border-b border-[#5A4B38]/70 truncate"
              style={{ color: '#E2B05A' }}
            >
              {contextMenu.entry.ability.name}
            </p>
            {(['1', '2', '3', '4'] as const).map((slotKey) => {
              const isSame = contextMenu.entry.equippedSlotKey === slotKey;
              return (
                <button
                  key={slotKey}
                  type="button"
                  disabled={isSame}
                  onClick={() => requestSlotAssignment(contextMenu.entry, slotKey)}
                  style={{ color: isSame ? '#77796F' : '#F2ECE1' }}
                  className="w-full px-3 py-1.5 text-left hover:bg-[#3A3324] disabled:cursor-default cursor-pointer"
                >
                  {isSame ? `✓ Equipped in Slot ${slotKey}` : `Assign to Slot ${slotKey}...`}
                </button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
