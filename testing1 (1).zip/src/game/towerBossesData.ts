import { TowerBossDefinition } from './towerTypes';

/**
 * DIMRAETH: THE ASCENDANT TOWER
 * Major Boss & Mini-Boss Encounter Definitions (Floors 10, 20, 30 ... 100 & 5, 15, 25 ... 95)
 */

export const TOWER_MAJOR_BOSSES: Record<number, TowerBossDefinition> = {
  // ---------------------------------------------------------------------------
  // FLOOR 10 — REGION I: THE FORGOTTEN THRESHOLD
  // ---------------------------------------------------------------------------
  10: {
    floorNumber: 10,
    bossId: 'boss_valerius',
    name: 'Valerius the Unbroken',
    epithet: 'The Threshold Warden',
    introDialogue:
      'Turn back, wanderers of Whispering Vale. A thousand oaths were sworn upon these stone steps, and a thousand were shattered. My greatshield alone stands between mortals and the abyss.',
    defeatDialogue:
      'The threshold... yields. The ancient seals groan beneath your footsteps. Take my shield, commander... and pray your conviction outlasts the descent.',
    phases: [
      {
        phaseNumber: 1,
        name: 'The Unyielding Bulwark',
        hpThresholdPercent: 100,
        announceQuote: 'My shield is forged of Covenant granite! You cannot move me!',
        bonusStatModifiers: { acBonus: 2 },
        telegraphedAttack: {
          name: 'Shield Ram Shockwave',
          targetTiles: [
            { x: 4, z: 4 }, { x: 5, z: 4 }, { x: 4, z: 5 }, { x: 5, z: 5 },
          ],
          damage: 14,
          element: 'physical',
          warningMessage: 'Valerius lowers his greatshield! Frontline impact imminent!',
        },
      },
      {
        phaseNumber: 2,
        name: 'Wrath of the Broken Oath',
        hpThresholdPercent: 50,
        announceQuote: 'If the shield must crack, then steel shall reap!',
        arenaModification: {
          collapsePillars: [{ x: 2, z: 2 }, { x: 7, z: 7 }],
          spawnHazards: [
            { x: 3, z: 3, surface: 'oil_pool' },
            { x: 6, z: 6, surface: 'oil_pool' },
          ],
        },
        bonusStatModifiers: { apBonus: 1, damageMultiplier: 1.25 },
        telegraphedAttack: {
          name: 'Pillar-Shattering Halberd Cleave',
          targetTiles: [
            { x: 3, z: 5 }, { x: 4, z: 5 }, { x: 5, z: 5 }, { x: 6, z: 5 },
          ],
          damage: 20,
          element: 'physical',
          warningMessage: 'Valerius sweeps his two-handed halberd across the central corridor!',
        },
      },
    ],
    weakness: 'Vulnerable to Sundered status and rear flanking maneuvers while in shield stance.',
    resistanceProfile: 'High physical Armor Class (AC 16); immune to knockback displacement.',
    specialArenaMechanic: 'Outer perimeter pillars can be collapsed onto Valerius using shove abilities for 15 crushing damage.',
    exclusiveArtifactReward: {
      id: 'relic_threshold_aegis',
      name: 'Bulwark of the Unbroken Warden',
      type: 'armor',
      description: 'Ancient tower kite shield (+3 AC, grants immunity to forced push/pull displacement).',
    },
  },

  // ---------------------------------------------------------------------------
  // FLOOR 20 — REGION II: THE WITHERED WILDS
  // ---------------------------------------------------------------------------
  20: {
    floorNumber: 20,
    bossId: 'boss_sylvaeth',
    name: 'Sylvaeth the Rot-Mother',
    epithet: 'Matron of the Iron Roots',
    introDialogue:
      'The soil remembers every corpse buried in Whispering Vale. Your bones shall nourish my bramble garden, child of ash!',
    defeatDialogue:
      'The rot... recedes into the deep clay. But the roots go deeper than you know... the lower floors thirst for living sap...',
    phases: [
      {
        phaseNumber: 1,
        name: 'Toxic Canopies',
        hpThresholdPercent: 100,
        announceQuote: 'Breathe the black pollen of the withered bough!',
        telegraphedAttack: {
          name: 'Spore Rain',
          targetTiles: [
            { x: 2, z: 4 }, { x: 2, z: 5 }, { x: 7, z: 4 }, { x: 7, z: 5 },
          ],
          damage: 12,
          element: 'nature',
          warningMessage: 'Pollen clouds thicken overhead! Toxic spore burst targeting perimeter tiles!',
        },
      },
      {
        phaseNumber: 2,
        name: 'Primordial Treant Manifestation',
        hpThresholdPercent: 45,
        announceQuote: 'Awaken, ancient heartwood! Crush their brittle marrow!',
        arenaModification: {
          spawnHazards: [
            { x: 4, z: 3, surface: 'bramble_snare' },
            { x: 5, z: 3, surface: 'bramble_snare' },
            { x: 4, z: 6, surface: 'bramble_snare' },
            { x: 5, z: 6, surface: 'bramble_snare' },
          ],
        },
        bonusStatModifiers: { acBonus: 2, damageMultiplier: 1.3 },
      },
    ],
    weakness: 'Highly vulnerable to Pyromantic and Fire abilities (ignites connecting bramble roots for +8 damage).',
    resistanceProfile: 'Immune to Rooted status; absorbs 40% of Nature damage.',
    specialArenaMechanic: 'Bramble snares entangle the arena every 3 rounds; fire spells clear brambles and detonate them.',
    exclusiveArtifactReward: {
      id: 'relic_rot_mothers_heartwood',
      name: 'Heartwood of the Primordial Treant',
      type: 'relic',
      description: 'Increases Nature spell damage by +5 and regenerates 4 HP when standing on rough or plant terrain.',
    },
  },

  // ---------------------------------------------------------------------------
  // FLOOR 30 — REGION III: THE EMBER FOUNDRY
  // ---------------------------------------------------------------------------
  30: {
    floorNumber: 30,
    bossId: 'boss_ignis',
    name: 'Forgemaster Ignis',
    epithet: 'The Molten Heart',
    introDialogue:
      'Fools! You step into the Crucible of Dimraeth! Here, weapons of god-slaying were hammered in astral flame! Let us see if your flesh tempers or boils!',
    defeatDialogue:
      'My forge... cold? The slag hardens... You are tempered iron indeed... Go, plunge into the frost below and see if your edge holds...',
    phases: [
      {
        phaseNumber: 1,
        name: 'Anvil of Hephaestian Flame',
        hpThresholdPercent: 100,
        announceQuote: 'Feel the heat of a fallen sun!',
        telegraphedAttack: {
          name: 'Slag Eruption',
          targetTiles: [
            { x: 3, z: 3 }, { x: 4, z: 3 }, { x: 5, z: 3 }, { x: 6, z: 3 },
          ],
          damage: 18,
          element: 'fire',
          warningMessage: 'Crucible pressure rising! Molten slag spilling down the central furnace trench!',
        },
      },
      {
        phaseNumber: 2,
        name: 'Superheated Meltdown',
        hpThresholdPercent: 40,
        announceQuote: 'I shall melt this floor into an ocean of glass!',
        arenaModification: {
          spawnHazards: [
            { x: 1, z: 5, surface: 'fire_pool' },
            { x: 8, z: 5, surface: 'fire_pool' },
            { x: 4, z: 4, surface: 'fire_pool' },
            { x: 5, z: 5, surface: 'fire_pool' },
          ],
        },
        bonusStatModifiers: { damageMultiplier: 1.4 },
      },
    ],
    weakness: 'Vulnerable to Frost and Radiant spells; water tiles cool his heated mantle, reducing his AC by 3.',
    resistanceProfile: 'Complete immunity to Fire and Burning; reflecting 4 Fire DMG to adjacent melee attackers.',
    specialArenaMechanic: 'Runic cooling vents on tiles (2,2) and (7,7) can be activated to extinguish fire pools across a 3x3 radius.',
    exclusiveArtifactReward: {
      id: 'weapon_molten_crucible_greatsword',
      name: 'Crucible Forgemaster Greatsword',
      type: 'weapon',
      description: 'Heavy 2-handed greatsword (14-22 DMG, ignites oil on impact, +6 DMG vs Rooted/Sundered).',
    },
  },

  // ---------------------------------------------------------------------------
  // FLOOR 40 — REGION IV: THE FROZEN RELIQUARY
  // ---------------------------------------------------------------------------
  40: {
    floorNumber: 40,
    bossId: 'boss_illyria',
    name: 'Cryomancer Illyria',
    epithet: 'The Frost Sovereign',
    introDialogue:
      'Silence, at last. Here in the reliquary, memories are preserved in diamond ice. Let your blood freeze, and become statues in my eternal vault.',
    defeatDialogue:
      'The ice cracks... thawing what should have stayed sleeping. The astral rift above... it stirs because of your warmth...',
    phases: [
      {
        phaseNumber: 1,
        name: 'Glacial Mirrors',
        hpThresholdPercent: 100,
        announceQuote: 'Which of my reflections holds your death?',
        telegraphedAttack: {
          name: 'Permafrost Lance',
          targetTiles: [
            { x: 1, z: 1 }, { x: 2, z: 2 }, { x: 3, z: 3 }, { x: 4, z: 4 },
          ],
          damage: 16,
          element: 'physical',
          warningMessage: 'Glacial mirror beams align diagonally across the arena!',
        },
      },
      {
        phaseNumber: 2,
        name: 'Absolute Zero Permafrost',
        hpThresholdPercent: 50,
        announceQuote: 'The air itself shall solidify in your lungs!',
        bonusStatModifiers: { acBonus: 3 },
      },
    ],
    weakness: 'Vulnerable to Fire abilities and blunt Warhammers; fire shatters her mirror shields.',
    resistanceProfile: 'Immune to cold and Rooted; high magical warding.',
    specialArenaMechanic: 'Slippery ice tiles double move distance but prevent sharp directional changes without sliding.',
    exclusiveArtifactReward: {
      id: 'armor_glacial_sovereign_cuirass',
      name: 'Cuirass of the Frost Sovereign',
      type: 'armor',
      description: 'Diamond-ice half plate (+3 AC, reflects 6 Frost damage to melee attackers, immune to Burning).',
    },
  },

  // ---------------------------------------------------------------------------
  // FLOOR 50 — REGION V: THE ASTRAL DIVIDE
  // ---------------------------------------------------------------------------
  50: {
    floorNumber: 50,
    bossId: 'boss_xalkareth',
    name: "Xal'Kareth the Unraveler",
    epithet: 'The Rift Weaver',
    introDialogue:
      'Look into the divide! Space is but fabric, and time but a stitch. The Shattered Oath was not a sin—it was an incision to let the multiverse breathe!',
    defeatDialogue:
      'The rift pulls inward... You have only collapsed one node! The tower’s core transcends physical geometry...',
    phases: [
      {
        phaseNumber: 1,
        name: 'Dimensional Inversion',
        hpThresholdPercent: 100,
        announceQuote: 'Down is up! Distance is an illusion!',
        telegraphedAttack: {
          name: 'Event Horizon Tear',
          targetTiles: [
            { x: 4, z: 4 }, { x: 5, z: 4 }, { x: 4, z: 5 }, { x: 5, z: 5 },
          ],
          damage: 22,
          element: 'arcane',
          warningMessage: 'Singularity forming in center arena! Massive spatial collapse in 1 turn!',
        },
      },
      {
        phaseNumber: 2,
        name: 'Event Horizon Singularity',
        hpThresholdPercent: 40,
        announceQuote: 'All things return to the planar void!',
        bonusStatModifiers: { apBonus: 1, damageMultiplier: 1.35 },
      },
    ],
    weakness: 'Pushing runestone blocks into the astral rifts disrupts his spell channeling, stunning him for 1 round.',
    resistanceProfile: 'Can phase blink when damaged; immune to conventional knockback.',
    specialArenaMechanic: 'Astral rifts on tiles (3,3) and (6,6) periodically pull all combatants 1 tile toward them.',
    exclusiveArtifactReward: {
      id: 'relic_chronos_astral_compass',
      name: 'Rift Weaver’s Astral Compass',
      type: 'relic',
      description: 'Grants Phase Blink ability (teleport 4 tiles once per combat at 0 AP cost).',
    },
  },

  // ---------------------------------------------------------------------------
  // FLOOR 60 — REGION VI: THE DROWNED KINGDOM
  // ---------------------------------------------------------------------------
  60: {
    floorNumber: 60,
    bossId: 'boss_thalassos',
    name: 'Leviathan Lord Thalassos',
    epithet: 'Scourge of the Sunken Spires',
    introDialogue:
      'The drowned spires of the old dynasty belong to the depths. Drown beneath our forgotten tides, surface dwellers!',
    defeatDialogue:
      'The sea retreats... but blood is thicker than water... the Crimson Covenant waits on the battlements above...',
    phases: [
      {
        phaseNumber: 1,
        name: 'Tidal Surges',
        hpThresholdPercent: 100,
        announceQuote: 'The ocean obeys my trident!',
        telegraphedAttack: {
          name: 'Tsunami Wave',
          targetTiles: [
            { x: 0, z: 3 }, { x: 1, z: 3 }, { x: 2, z: 3 }, { x: 3, z: 3 },
            { x: 4, z: 3 }, { x: 5, z: 3 }, { x: 6, z: 3 }, { x: 7, z: 3 },
            { x: 8, z: 3 }, { x: 9, z: 3 },
          ],
          damage: 18,
          element: 'physical',
          warningMessage: 'Massive tidal wave cresting across row 3! Seek high ground bastions immediately!',
        },
      },
      {
        phaseNumber: 2,
        name: 'Electrified Deluge',
        hpThresholdPercent: 50,
        announceQuote: 'Storm and sea unite in wrath!',
        bonusStatModifiers: { damageMultiplier: 1.3 },
      },
    ],
    weakness: 'Vulnerable while standing on high-ground bastions; radiant spells vaporize his water shields.',
    resistanceProfile: 'Heals 5 HP whenever ending a turn inside water or sanctified pools.',
    specialArenaMechanic: 'Rising water levels submerge lower elevation tiles, reducing movement speed by -1.',
    exclusiveArtifactReward: {
      id: 'weapon_leviathan_trident',
      name: 'Trident of the Sunken Spire',
      type: 'weapon',
      description: 'Polearm weapon (12-18 DMG, pushes 2 tiles, creates water puddles on impact).',
    },
  },

  // ---------------------------------------------------------------------------
  // FLOOR 70 — REGION VII: THE CRIMSON COVENANT
  // ---------------------------------------------------------------------------
  70: {
    floorNumber: 70,
    bossId: 'boss_vespera',
    name: 'High Priestess Vespera',
    epithet: 'The Blood Archon',
    introDialogue:
      'Every floor of this tower was sealed with the blood of martyrs. Drink of the chalice or bleed your soul into our altar!',
    defeatDialogue:
      'My blood... joins the stone. You think you conquer? Every drop you spill only feeds the Ashen Dominion above...',
    phases: [
      {
        phaseNumber: 1,
        name: 'Sanguine Puppetry',
        hpThresholdPercent: 100,
        announceQuote: 'Your veins dance to my rhythm!',
        telegraphedAttack: {
          name: 'Blood Well Rupture',
          targetTiles: [
            { x: 2, z: 2 }, { x: 2, z: 7 }, { x: 7, z: 2 }, { x: 7, z: 7 },
          ],
          damage: 20,
          element: 'arcane',
          warningMessage: 'Ritual blood runes glowing violently on the four corner altars!',
        },
      },
      {
        phaseNumber: 2,
        name: 'Avatar of the Flayed God',
        hpThresholdPercent: 35,
        announceQuote: 'I offer my own heart to fuel your annihilation!',
        bonusStatModifiers: { apBonus: 2, damageMultiplier: 1.4 },
      },
    ],
    weakness: 'Radiant spells cleanse her blood rituals; destroying the 4 corner sacrificial anchors dispels her immunity.',
    resistanceProfile: 'Siphons 50% of all damage dealt as healing unless afflicted by Sundered or Burning.',
    specialArenaMechanic: 'Sacrificial blood wells heal Vespera each round until companions or warriors occupy the altars.',
    exclusiveArtifactReward: {
      id: 'relic_vesperas_blood_chalice',
      name: 'Blood Archon’s Sanguine Chalice',
      type: 'relic',
      description: 'Grants +6 bonus damage against bleeding or burning foes, and heals 3 HP on enemy KO.',
    },
  },

  // ---------------------------------------------------------------------------
  // FLOOR 80 — REGION VIII: THE ASHEN DOMINION
  // ---------------------------------------------------------------------------
  80: {
    floorNumber: 80,
    bossId: 'boss_malakor',
    name: 'Warmaster Malakor',
    epithet: 'General of the Ashen Legion',
    introDialogue:
      'I commanded the siege engines that broke the Silver Covenant! You stand before the architect of total conquest!',
    defeatDialogue:
      'An army defeated... by a lone strike team. The Shattered Expanse awaits you... where physics and time break like twigs...',
    phases: [
      {
        phaseNumber: 1,
        name: 'Siege Wall Barricade',
        hpThresholdPercent: 100,
        announceQuote: 'Artillery, bombard the perimeter!',
        telegraphedAttack: {
          name: 'Catapult Barrage',
          targetTiles: [
            { x: 1, z: 4 }, { x: 2, z: 4 }, { x: 7, z: 4 }, { x: 8, z: 4 },
          ],
          damage: 24,
          element: 'physical',
          warningMessage: 'Siege catapults fired! High-explosive boulders incoming on perimeter tiles!',
        },
      },
      {
        phaseNumber: 2,
        name: 'Ashen Juggernaut Cleave',
        hpThresholdPercent: 40,
        announceQuote: 'I shall grind your skulls beneath my war-cleaver myself!',
        bonusStatModifiers: { acBonus: 2, damageMultiplier: 1.5 },
      },
    ],
    weakness: 'Detonating nearby oil barrels and braziers next to his siege barricade knocks him prone.',
    resistanceProfile: 'Heavy legionary plate (AC 18); highly resistant to non-critical physical strikes.',
    specialArenaMechanic: 'Volatile explosive barrels line the battlefield; kicking or shoving them causes massive chain reactions.',
    exclusiveArtifactReward: {
      id: 'weapon_malakors_siege_cleaver',
      name: 'Malakor’s Ashen Siege Cleaver',
      type: 'weapon',
      description: 'Devastating greataxe (18-26 DMG, 2-tile cleave arc, stuns on critical hits).',
    },
  },

  // ---------------------------------------------------------------------------
  // FLOOR 90 — REGION IX: THE SHATTERED EXPANSE
  // ---------------------------------------------------------------------------
  90: {
    floorNumber: 90,
    bossId: 'boss_chronos',
    name: 'Chronos the Fractured',
    epithet: 'The Timelord of the Void',
    introDialogue:
      'I have seen your expedition die ten thousand times across ten thousand timelines. This moment is not your triumph—it is your permanent recursion!',
    defeatDialogue:
      'The paradox... resolves. The timelines collapse into a single thread... The Throne Beyond opens. Meet the one who designed your fate...',
    phases: [
      {
        phaseNumber: 1,
        name: 'Paradox Decoys',
        hpThresholdPercent: 100,
        announceQuote: 'Past, present, and future strike as one!',
        telegraphedAttack: {
          name: 'Timeline Collapse',
          targetTiles: [
            { x: 3, z: 3 }, { x: 6, z: 3 }, { x: 3, z: 6 }, { x: 6, z: 6 },
          ],
          damage: 26,
          element: 'arcane',
          warningMessage: 'Temporal paradox fissures opening at focal points! Reverses buffs in area!',
        },
      },
      {
        phaseNumber: 2,
        name: 'Timeline Shatter',
        hpThresholdPercent: 30,
        announceQuote: 'I will erase the seconds that gave you breath!',
        bonusStatModifiers: { apBonus: 2, damageMultiplier: 1.45 },
      },
    ],
    weakness: 'Defeating his temporal echoes prevents him from rewinding health; vulnerable to Radiant smites.',
    resistanceProfile: 'Can reverse time to undo 20% of damage taken once per combat round unless stunned.',
    specialArenaMechanic: 'Shifting fractured floor panels rotate elevation levels every 2 turns.',
    exclusiveArtifactReward: {
      id: 'relic_chronos_infinite_hourglass',
      name: 'Hourglass of the Fractured Timelord',
      type: 'relic',
      description: 'Reduces all active companion cooldowns by 1 turn at the start of combat, +2 Initiative.',
    },
  },

  // ---------------------------------------------------------------------------
  // FLOOR 100 — REGION X: THE THRONE BEYOND (FINAL TOWER ENCOUNTER)
  // ---------------------------------------------------------------------------
  100: {
    floorNumber: 100,
    bossId: 'boss_architect',
    name: 'The Oath Architect',
    epithet: 'Creator of the Ascendant Tower',
    introDialogue:
      'At last, mortals stand in the presence of the Prime Design. The Shattered Oath was not a tragedy—it was the crucible constructed to forge warriors capable of surviving what lies beyond the stars. Now, demonstrate whether you are worthy to inherit the cosmos!',
    defeatDialogue:
      'Magnificent... The design is perfected. You have transcended mortality, broken the hundred trials, and conquered the Ascendant Tower. The cosmos is yours, Commander of Dimraeth!',
    phases: [
      {
        phaseNumber: 1,
        name: 'Planar Conduit Weaver',
        hpThresholdPercent: 100,
        announceQuote: 'Behold the convergence of the nine realms!',
        telegraphedAttack: {
          name: 'Celestial Nova',
          targetTiles: [
            { x: 4, z: 4 }, { x: 5, z: 4 }, { x: 4, z: 5 }, { x: 5, z: 5 },
            { x: 3, z: 4 }, { x: 6, z: 4 }, { x: 4, z: 3 }, { x: 4, z: 6 },
          ],
          damage: 30,
          element: 'radiant',
          warningMessage: 'The Architect channels the core of the Ascendant Tower! Cross-shaped cataclysm in 1 round!',
        },
      },
      {
        phaseNumber: 2,
        name: 'Oathbreaker Ascendant',
        hpThresholdPercent: 60,
        announceQuote: 'Every broken vow shall rain down upon you as fire and void!',
        arenaModification: {
          spawnHazards: [
            { x: 2, z: 2, surface: 'sanctified_pool' },
            { x: 7, z: 7, surface: 'sanctified_pool' },
            { x: 2, z: 7, surface: 'fire_pool' },
            { x: 7, z: 2, surface: 'fire_pool' },
          ],
        },
        bonusStatModifiers: { apBonus: 1, acBonus: 2, damageMultiplier: 1.4 },
      },
      {
        phaseNumber: 3,
        name: 'Cosmic Apotheosis',
        hpThresholdPercent: 25,
        announceQuote: 'Witness the true birth of the new world!',
        bonusStatModifiers: { apBonus: 2, damageMultiplier: 1.6 },
        telegraphedAttack: {
          name: 'Reality Collapse Finality',
          targetTiles: [
            { x: 0, z: 0 }, { x: 9, z: 9 }, { x: 0, z: 9 }, { x: 9, z: 0 },
            { x: 4, z: 4 }, { x: 5, z: 5 },
          ],
          damage: 35,
          element: 'arcane',
          warningMessage: 'Cosmic Apotheosis reaches critical mass! Disintegrate anchors or fall!',
        },
      },
    ],
    weakness: 'Vulnerable to coordinated party combos (Chronomancer + Paladin + Rogue/Warrior synergies deal double crit damage).',
    resistanceProfile: 'Mastery over all 5 elements; absorbs 20% of non-synergized damage.',
    specialArenaMechanic: 'Planar conduits on tiles (1,1), (1,8), (8,1), and (8,8) can be seized to grant party +4 AP and +10 Temp HP.',
    exclusiveArtifactReward: {
      id: 'weapon_crown_of_the_oath_architect',
      name: 'Crown of the Ascendant Architect',
      type: 'relic',
      description: 'Legendary tower capstone artifact (+4 to All Attributes, +1 Max AP, +20 Max HP, radiant aura).',
    },
  },
};

/**
 * 10 Mini-Boss Encounter Definitions (Floors 5, 15, 25, 35, 45, 55, 65, 75, 85, 95)
 */
export const TOWER_MINI_BOSSES: Record<number, { name: string; title: string; archetype: string; specialMechanic: string; rewardItem: string }> = {
  5: {
    name: 'Gatekeeper Brutus',
    title: 'The Iron Bulwark',
    archetype: 'bruiser',
    specialMechanic: 'Shield bash inflicts 2-tile knockback; gains +2 AC when flanked.',
    rewardItem: 'Tower Guard Ring (+1 AC)',
  },
  15: {
    name: 'Briar Behemoth',
    title: 'Grave of Thorns',
    archetype: 'bruiser',
    specialMechanic: 'Leaves bramble snares behind on every move tile; heals 4 HP in foliage.',
    rewardItem: 'Sylvan Root Pauldrons (+8 Max HP)',
  },
  25: {
    name: 'Cinder Golem Primus',
    title: 'Slag Engine',
    archetype: 'champion',
    specialMechanic: 'Detonates oil pools in 3x3 radius on melee impact; explodes on defeat for 12 Fire DMG.',
    rewardItem: 'Cinder Core Amulet (+2 Fire DMG)',
  },
  35: {
    name: 'Frostfang Glacial Reaver',
    title: 'The Frozen Stalker',
    archetype: 'stalker',
    specialMechanic: 'Leaps behind furthest companion, inflicting Rooted and 10 Frost DMG.',
    rewardItem: 'Frostfang Dagger (10-15 DMG, applies Root)',
  },
  45: {
    name: 'Astral Shade Inquisitor',
    title: 'Planar Heretic',
    archetype: 'inquisitor',
    specialMechanic: 'Teleports between high-ground pillars every turn, raining piercing rays.',
    rewardItem: 'Planar Weaver Robes (+2 INT, +1 Spell Range)',
  },
  55: {
    name: 'Abyssal Siren Naida',
    title: 'Singer of the Drowned',
    archetype: 'weaver',
    specialMechanic: 'Charms 1 random companion for 1 turn (cannot attack enemies, only move toward siren).',
    rewardItem: 'Pearl of the Siren (+3 CHA, +5 Temp HP on start)',
  },
  65: {
    name: 'Sanguine Executioner Krell',
    title: 'The Crimson Cleaver',
    archetype: 'champion',
    specialMechanic: 'Deals +8 execution damage against allies below 40% HP; heals on kill.',
    rewardItem: 'Executioner’s Belt (+4 Melee DMG vs wounded)',
  },
  75: {
    name: 'Ashen Siege Commander Rictus',
    title: 'Artillery Captain',
    archetype: 'inquisitor',
    specialMechanic: 'Orders mortar strikes on 2 random tiles every round for 14 physical damage.',
    rewardItem: 'Siege Master Crest (+2 STR, +10% Crit)',
  },
  85: {
    name: 'Paradox Phantom Mirage',
    title: 'Echo of the Shattered',
    archetype: 'stalker',
    specialMechanic: 'Splits into 2 mirror clones when reduced below 50% HP; only true phantom takes damage.',
    rewardItem: 'Mirage Band (25% chance to dodge attacks)',
  },
  95: {
    name: 'Oath-Seraph Azariel',
    title: 'The Final Gatekeeper',
    archetype: 'champion',
    specialMechanic: 'Surrounded by a 3-tile radiant halo that deals 8 Radiant DMG to enemies inside.',
    rewardItem: 'Seraphic Greatsword (16-24 DMG, Holy Cross cleave)',
  },
};
