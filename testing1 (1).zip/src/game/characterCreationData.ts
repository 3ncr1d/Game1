import {
  CharacterRaceId,
  CharacterClassId,
  CharacterSubclassId,
} from './rules';
import {
  ArchetypeClassId,
  CharacterAppearanceConfig,
} from '../components/CharacterPixelPreviewCanvas';

export type { ArchetypeClassId, CharacterAppearanceConfig };

// ============================================================================
// D20 MODIFIER UTILITIES (Immutable Rule: floor((score - 10) / 2))
// ============================================================================

export function getD20Modifier(score: number): number {
  return Math.floor((score - 10) / 2);
}

export function formatD20Modifier(mod: number): string {
  return mod >= 0 ? `+${mod}` : `${mod}`;
}

// ============================================================================
// SCREEN 02: ANCESTRY & RACE DATA
// ============================================================================

export interface RaceExtendedMetadata {
  raceId: CharacterRaceId;
  name: string;
  tagline: string;
  identityDescription: string;
  physicalCharacteristics: string[];
  compatibleSkinTones: { label: string; hex: string; undertone: string }[];
  defaultAppearance: CharacterAppearanceConfig;
}

export const RACE_EXTENDED_DETAILS: Record<CharacterRaceId, RaceExtendedMetadata> = {
  half_elf: {
    raceId: 'half_elf',
    name: 'Silverborn Half-Elf',
    tagline: '+2 CHA · +1 STR · Fey-Touched Poise',
    identityDescription:
      'Graceful, adaptable, and intellectually gifted, carrying the ancient starlight lineage of the fractured Silver Covenant.',
    physicalCharacteristics: [
      'Slender, poised silhouette with finely tapered elven ears',
      'Luminous eyes that reflect faint astral starlight at dusk',
      'Graceful stride bridging mortal endurance and fey agility',
      'High cheekbones and aristocratic posture shaped by spire sanctums',
    ],
    compatibleSkinTones: [
      { label: 'Porcelain Ivory', hex: '#f0dfd0', undertone: 'cool' },
      { label: 'Warm Alabaster', hex: '#e8cbb8', undertone: 'neutral' },
      { label: 'Sunlit Bronze', hex: '#b88b6e', undertone: 'warm' },
      { label: 'Moonlit Silver-Tan', hex: '#c8bfb8', undertone: 'cool' },
      { label: 'Rose Alabaster', hex: '#e5c0b0', undertone: 'warm' },
      { label: 'Starlight Fair', hex: '#f8ebe0', undertone: 'cool' },
    ],
    defaultAppearance: {
      bodyType: 'Athletic',
      facePreset: 'Noble',
      facialStructure: 'High Cheekbones',
      skinTone: '#e8cbb8',
      hairStyle: 'Braided Crown',
      hairColor: '#d8d0c5',
      eyeColor: '#e2b05a',
      facialHair: 'Clean-Shaven',
      scarsAndMarkings: 'None',
      tattoos: 'None',
      accessories: 'Bronze Circlet',
    },
  },
  tiefling: {
    raceId: 'tiefling',
    name: 'Ashen Tiefling',
    tagline: '+2 INT · +1 DEX · Infernal Resilience',
    identityDescription:
      'Resilient, sharp-witted, and shaped by an ancient planar rift heritage that grants instinctive resistance to ash and fire.',
    physicalCharacteristics: [
      'Swept-back obsidian or bone ridges and a prehensile ember-tipped tail',
      'Planar-touched complexion ranging from smoldering slate to deep terracotta',
      'Resonant ember eyes that gleam warmly in darkened sanctums',
      'Chiseled angular jawlines with distinctive planar skin textures',
    ],
    compatibleSkinTones: [
      { label: 'Ashen Terracotta', hex: '#b56e65', undertone: 'ashen' },
      { label: 'Crimson Dusk', hex: '#964946', undertone: 'infernal' },
      { label: 'Obsidian Slate', hex: '#786e78', undertone: 'ashen' },
      { label: 'Smoldering Umber', hex: '#8c5b50', undertone: 'smoldering' },
      { label: 'Ashen Violet', hex: '#6e5f72', undertone: 'infernal' },
      { label: 'Molten Copper', hex: '#a65842', undertone: 'smoldering' },
    ],
    defaultAppearance: {
      bodyType: 'Slender',
      facePreset: 'Fierce',
      facialStructure: 'Angular',
      skinTone: '#b56e65',
      hairStyle: 'Swept Back',
      hairColor: '#262224',
      eyeColor: '#e2b05a',
      facialHair: 'Clean-Shaven',
      scarsAndMarkings: 'Ritual Ash Mark',
      tattoos: 'Runic Brow',
      accessories: 'Silver Ear Cuff',
    },
  },
  wood_kin: {
    raceId: 'wood_kin',
    name: 'Sylvan Wood-Kin',
    tagline: '+2 DEX · +1 STR · Thornwood Agility',
    identityDescription:
      'Ancient, patient, and deeply attuned to the living pulse of ancient forests, carrying natural sylvan traits into battle.',
    physicalCharacteristics: [
      'Natural bark-like brow ridges crowned with subtle sylvan antler shoots',
      'Long, wind-swept ears attuned to the faintest rustle of the vale',
      'Earth-toned complexion resilient against bramble and blade',
      'Weather-touched eyes colored like moss, lichen, or amber sap',
    ],
    compatibleSkinTones: [
      { label: 'Birch Tawny', hex: '#c79e7e', undertone: 'earthy' },
      { label: 'Ironwood Bark', hex: '#8f694d', undertone: 'sylvan' },
      { label: 'Moss-Touched Olive', hex: '#a3967a', undertone: 'verdant' },
      { label: 'Amber Heartwood', hex: '#ad7d5c', undertone: 'sylvan' },
      { label: 'Deep Forest Clay', hex: '#755642', undertone: 'earthy' },
      { label: 'Lichen Ochre', hex: '#b49970', undertone: 'verdant' },
    ],
    defaultAppearance: {
      bodyType: 'Athletic',
      facePreset: 'Serene',
      facialStructure: 'Angular',
      facialHair: 'Clean-Shaven',
      skinTone: '#c79e7e',
      hairStyle: 'Long Flowing',
      hairColor: '#5c3c28',
      eyeColor: '#7e9c82',
      scarsAndMarkings: 'None',
      tattoos: 'Sylvan Vine',
      accessories: 'Cloak Clasp',
    },
  },
  astral_human: {
    raceId: 'astral_human',
    name: 'Highborne Human',
    tagline: '+1 ALL STATS · Versatile Bastion Resolve',
    identityDescription:
      'Adaptable, disciplined, and culturally diverse, with relentless mortal grit conditioned by marches across contested frontiers.',
    physicalCharacteristics: [
      'Broad, versatile frame conditioned by frontier marches and siege defense',
      'Weather-tested features bearing the discipline of the old bastions',
      'Steady gaze suited to vanguard steel, diplomacy, or arcane study',
      'Broadest range of natural skin complexions and facial structures',
    ],
    compatibleSkinTones: [
      { label: 'Warm Fair', hex: '#dead92', undertone: 'warm' },
      { label: 'Frontier Tan', hex: '#ba886a', undertone: 'neutral' },
      { label: 'Deep Umber', hex: '#7a523b', undertone: 'warm' },
      { label: 'Highland Olive', hex: '#c99c7e', undertone: 'olive' },
      { label: 'Sunbaked Bronze', hex: '#996345', undertone: 'warm' },
      { label: 'Northern Pale', hex: '#f0d3c0', undertone: 'cool' },
    ],
    defaultAppearance: {
      bodyType: 'Athletic',
      facePreset: 'Weathered',
      facialStructure: 'Square Jaw',
      skinTone: '#ba886a',
      hairStyle: 'Cropped Crest',
      hairColor: '#3b2e26',
      eyeColor: '#6d8ca3',
      facialHair: 'Trimmed Beard',
      scarsAndMarkings: 'Brow Slash',
      tattoos: 'None',
      accessories: 'Cloak Clasp',
    },
  },
};

export const RACE_RANDOM_NAMES: Record<CharacterRaceId, string[]> = {
  half_elf: [
    'Seraphina Vane',
    'Aeliana Dawnstar',
    'Caelum Silverquill',
    'Lyraeth Solis',
    'Valerius Starlight',
    'Elenaril Feyborne',
    'Sylas Dawnseeker',
    'Thalor Moonwhisper',
    'Aerin Vesper',
    'Faelar Starfall',
    'Morwenna Solis',
    'Kaelith Silverthorne',
  ],
  tiefling: [
    'Mordecai Ashveil',
    'Nyxia Emberhorn',
    'Vespera Noctis',
    'Kaelith Pyre',
    'Malakor Brimstone',
    'Xarath Ashenspire',
    'Zephyra Ashbrand',
    'Azazel Pyrelight',
    'Lilith Umberveil',
    'Ravana Smolder',
    'Ignis Duskheart',
    'Sorsha Netherflame',
  ],
  wood_kin: [
    'Sylas Briarheart',
    'Rowan Ironbough',
    'Elowen Thornvale',
    'Garrick Mossward',
    'Bramble Rootkeeper',
    'Alder Wildmane',
    'Briar Greenstrider',
    'Fenn Deepbark',
    'Teryn Sylvanleaf',
    'Moss Havenstrider',
    'Oakhaven Thorn',
    'Kestrel Valeborn',
  ],
  astral_human: [
    'Valerius Vance',
    'Cassian Thorne',
    'Helena Sterling',
    'Octavia Falk',
    'Marcus Ironclad',
    'Lucian Bastion',
    'Aurelia Redguard',
    'Brandon Hawkwood',
    'Cynthia Vance',
    'Donald Ironheart',
    'Kenneth Sterling',
    'Diana Highwatch',
  ],
};

// ============================================================================
// SCREEN 03: BODY & PHYSIQUE PRESETS & SLIDERS
// ============================================================================

export type BodyPresetType = 'slim' | 'balanced' | 'athletic' | 'muscular' | 'heavyset';

export interface BodyPresetDefinition {
  id: BodyPresetType;
  name: string;
  description: string;
  proportions: {
    height: number; // 0.85 to 1.15
    shoulderWidth: number; // 0.8 to 1.25
    chest: number; // 0.8 to 1.25
    waist: number; // 0.8 to 1.25
    armThickness: number; // 0.8 to 1.25
    legThickness: number; // 0.8 to 1.25
    muscularity: number; // 0.0 to 1.0
    posture: number; // 0.0 to 1.0
  };
}

export const BODY_PRESETS: BodyPresetDefinition[] = [
  {
    id: 'slim',
    name: 'Slim',
    description: 'Slender, nimble frame with streamlined shoulders and rapid evasion agility.',
    proportions: {
      height: 0.98,
      shoulderWidth: 0.88,
      chest: 0.88,
      waist: 0.84,
      armThickness: 0.86,
      legThickness: 0.88,
      muscularity: 0.25,
      posture: 0.8,
    },
  },
  {
    id: 'balanced',
    name: 'Balanced',
    description: 'Harmonious proportions suited to fluid weapon transitions and balanced stamina.',
    proportions: {
      height: 1.0,
      shoulderWidth: 1.0,
      chest: 1.0,
      waist: 1.0,
      armThickness: 1.0,
      legThickness: 1.0,
      muscularity: 0.5,
      posture: 0.7,
    },
  },
  {
    id: 'athletic',
    name: 'Athletic',
    description: 'Conditioned physique with broadened shoulders, tapered waist, and spring-like poise.',
    proportions: {
      height: 1.04,
      shoulderWidth: 1.08,
      chest: 1.06,
      waist: 0.94,
      armThickness: 1.05,
      legThickness: 1.06,
      muscularity: 0.7,
      posture: 0.85,
    },
  },
  {
    id: 'muscular',
    name: 'Muscular',
    description: 'Powerfully built vanguard physique capable of wielding massive greatswords and shields.',
    proportions: {
      height: 1.07,
      shoulderWidth: 1.18,
      chest: 1.16,
      waist: 1.02,
      armThickness: 1.18,
      legThickness: 1.15,
      muscularity: 0.95,
      posture: 0.9,
    },
  },
  {
    id: 'heavyset',
    name: 'Heavyset',
    description: 'Sturdy, dense frame with unyielding poise against enemy shoves and knockdowns.',
    proportions: {
      height: 0.96,
      shoulderWidth: 1.14,
      chest: 1.2,
      waist: 1.2,
      armThickness: 1.12,
      legThickness: 1.16,
      muscularity: 0.6,
      posture: 0.65,
    },
  },
];

// ============================================================================
// SCREEN 04: FACE PRESETS (12 DISTINCT PRESETS PER RACE = 48 TOTAL) & SLIDERS
// ============================================================================

export interface FacePresetDefinition {
  id: number;
  raceId: CharacterRaceId;
  name: string;
  archetype: string;
  description: string;
  proportions: {
    faceWidth: number;
    faceLength: number;
    jawWidth: number;
    jawShape: number; // 0=round, 1=chiseled/angular
    chinLength: number;
    chinWidth: number;
    cheekboneHeight: number;
    cheekboneWidth: number;
    foreheadHeight: number;
    eyeShape: number; // 0=almond, 1=round/wide
    eyeSize: number;
    eyeSpacing: number;
    eyeDepth: number;
    eyeAngle: number;
    noseLength: number;
    noseWidth: number;
    bridgeHeight: number;
    tipShape: number; // 0=pointed, 1=rounded
    mouthWidth: number;
    lipThickness: number;
    browThickness: number;
    browAngle: number;
    earSize: number;
    earAngle: number;
  };
}

export const FACE_PRESETS_BY_RACE: Record<CharacterRaceId, FacePresetDefinition[]> = {
  half_elf: [
    {
      id: 1,
      raceId: 'half_elf',
      name: 'Noble Dawn',
      archetype: 'Aristocratic',
      description: 'Finely carved cheekbones with a slender jaw and poised starlight gaze.',
      proportions: { faceWidth: 0.92, faceLength: 1.04, jawWidth: 0.88, jawShape: 0.85, chinLength: 1.02, chinWidth: 0.86, cheekboneHeight: 1.12, cheekboneWidth: 0.95, foreheadHeight: 1.02, eyeShape: 0.3, eyeSize: 1.04, eyeSpacing: 1.0, eyeDepth: 0.94, eyeAngle: 0.15, noseLength: 1.05, noseWidth: 0.88, bridgeHeight: 1.08, tipShape: 0.3, mouthWidth: 0.92, lipThickness: 0.95, browThickness: 0.88, browAngle: 0.1, earSize: 1.1, earAngle: 0.95 },
    },
    {
      id: 2,
      raceId: 'half_elf',
      name: 'Silver Starlight',
      archetype: 'Serene',
      description: 'Gentle contours and almond eyes holding deep fey serenity.',
      proportions: { faceWidth: 0.9, faceLength: 1.0, jawWidth: 0.85, jawShape: 0.6, chinLength: 0.95, chinWidth: 0.84, cheekboneHeight: 1.08, cheekboneWidth: 0.92, foreheadHeight: 1.0, eyeShape: 0.2, eyeSize: 1.08, eyeSpacing: 1.02, eyeDepth: 0.9, eyeAngle: 0.2, noseLength: 0.98, noseWidth: 0.86, bridgeHeight: 1.04, tipShape: 0.25, mouthWidth: 0.9, lipThickness: 1.05, browThickness: 0.85, browAngle: 0.05, earSize: 1.12, earAngle: 0.9 },
    },
    {
      id: 3,
      raceId: 'half_elf',
      name: 'Vanguard Steel',
      archetype: 'Warrior',
      description: 'Determined brow line and structured jaw tempered by frontline combat.',
      proportions: { faceWidth: 0.98, faceLength: 1.02, jawWidth: 0.96, jawShape: 0.9, chinLength: 1.05, chinWidth: 0.94, cheekboneHeight: 1.05, cheekboneWidth: 1.0, foreheadHeight: 0.96, eyeShape: 0.4, eyeSize: 0.98, eyeSpacing: 0.98, eyeDepth: 1.04, eyeAngle: -0.05, noseLength: 1.02, noseWidth: 0.94, bridgeHeight: 1.05, tipShape: 0.4, mouthWidth: 0.96, lipThickness: 0.9, browThickness: 1.1, browAngle: 0.15, earSize: 1.05, earAngle: 1.0 },
    },
    {
      id: 4,
      raceId: 'half_elf',
      name: 'Arcane Scholar',
      archetype: 'Inquisitive',
      description: 'High brow and analytical gaze accustomed to ancient parchment runes.',
      proportions: { faceWidth: 0.91, faceLength: 1.05, jawWidth: 0.86, jawShape: 0.75, chinLength: 1.0, chinWidth: 0.85, cheekboneHeight: 1.1, cheekboneWidth: 0.94, foreheadHeight: 1.1, eyeShape: 0.25, eyeSize: 1.02, eyeSpacing: 1.04, eyeDepth: 0.96, eyeAngle: 0.08, noseLength: 1.06, noseWidth: 0.87, bridgeHeight: 1.06, tipShape: 0.28, mouthWidth: 0.91, lipThickness: 0.92, browThickness: 0.9, browAngle: 0.0, earSize: 1.08, earAngle: 0.92 },
    },
    {
      id: 5,
      raceId: 'half_elf',
      name: 'Shadow Whisper',
      archetype: 'Subtle',
      description: 'Narrow, predatory silhouette with sharp elven features masked in mystery.',
      proportions: { faceWidth: 0.88, faceLength: 0.98, jawWidth: 0.84, jawShape: 0.92, chinLength: 0.96, chinWidth: 0.82, cheekboneHeight: 1.15, cheekboneWidth: 0.93, foreheadHeight: 0.98, eyeShape: 0.15, eyeSize: 0.96, eyeSpacing: 0.96, eyeDepth: 1.08, eyeAngle: 0.25, noseLength: 1.0, noseWidth: 0.84, bridgeHeight: 1.02, tipShape: 0.2, mouthWidth: 0.88, lipThickness: 0.88, browThickness: 0.92, browAngle: 0.2, earSize: 1.15, earAngle: 0.88 },
    },
    {
      id: 6,
      raceId: 'half_elf',
      name: 'Highland Diplomat',
      archetype: 'Emissary',
      description: 'Balanced, approachable structure radiating calm confidence.',
      proportions: { faceWidth: 0.94, faceLength: 1.0, jawWidth: 0.9, jawShape: 0.65, chinLength: 0.98, chinWidth: 0.88, cheekboneHeight: 1.06, cheekboneWidth: 0.96, foreheadHeight: 1.02, eyeShape: 0.35, eyeSize: 1.02, eyeSpacing: 1.0, eyeDepth: 0.95, eyeAngle: 0.05, noseLength: 1.0, noseWidth: 0.9, bridgeHeight: 1.0, tipShape: 0.35, mouthWidth: 0.95, lipThickness: 1.0, browThickness: 0.95, browAngle: 0.05, earSize: 1.08, earAngle: 0.95 },
    },
    {
      id: 7,
      raceId: 'half_elf',
      name: 'Bastion Scout',
      archetype: 'Vigilant',
      description: 'Weathered cheekbones with alert, wide-set eyes trained on distant horizons.',
      proportions: { faceWidth: 0.93, faceLength: 1.01, jawWidth: 0.91, jawShape: 0.8, chinLength: 0.99, chinWidth: 0.87, cheekboneHeight: 1.07, cheekboneWidth: 0.98, foreheadHeight: 0.99, eyeShape: 0.3, eyeSize: 1.05, eyeSpacing: 1.05, eyeDepth: 0.98, eyeAngle: 0.12, noseLength: 1.01, noseWidth: 0.91, bridgeHeight: 1.02, tipShape: 0.3, mouthWidth: 0.93, lipThickness: 0.94, browThickness: 1.0, browAngle: 0.08, earSize: 1.1, earAngle: 0.96 },
    },
    {
      id: 8,
      raceId: 'half_elf',
      name: 'Sunblade Champion',
      archetype: 'Resolute',
      description: 'Chiseled jawline and piercing gaze fit for an anointed oath-warden.',
      proportions: { faceWidth: 0.96, faceLength: 1.03, jawWidth: 0.95, jawShape: 0.88, chinLength: 1.04, chinWidth: 0.92, cheekboneHeight: 1.09, cheekboneWidth: 0.99, foreheadHeight: 1.01, eyeShape: 0.32, eyeSize: 1.0, eyeSpacing: 0.99, eyeDepth: 1.02, eyeAngle: 0.1, noseLength: 1.04, noseWidth: 0.92, bridgeHeight: 1.07, tipShape: 0.32, mouthWidth: 0.97, lipThickness: 0.93, browThickness: 1.05, browAngle: 0.12, earSize: 1.06, earAngle: 0.98 },
    },
    {
      id: 9,
      raceId: 'half_elf',
      name: 'Moonlit Wanderer',
      archetype: 'Enigmatic',
      description: 'Asymmetric subtle grace with a wistful expression and tapered chin.',
      proportions: { faceWidth: 0.89, faceLength: 1.02, jawWidth: 0.86, jawShape: 0.7, chinLength: 1.01, chinWidth: 0.83, cheekboneHeight: 1.11, cheekboneWidth: 0.93, foreheadHeight: 1.04, eyeShape: 0.22, eyeSize: 1.06, eyeSpacing: 1.01, eyeDepth: 0.92, eyeAngle: 0.18, noseLength: 1.03, noseWidth: 0.86, bridgeHeight: 1.05, tipShape: 0.26, mouthWidth: 0.89, lipThickness: 0.98, browThickness: 0.87, browAngle: 0.06, earSize: 1.14, earAngle: 0.91 },
    },
    {
      id: 10,
      raceId: 'half_elf',
      name: 'Covenant Justiciar',
      archetype: 'Severe',
      description: 'Sharp, unyielding angles communicating relentless dedication to the law.',
      proportions: { faceWidth: 0.95, faceLength: 1.04, jawWidth: 0.94, jawShape: 0.92, chinLength: 1.06, chinWidth: 0.91, cheekboneHeight: 1.13, cheekboneWidth: 0.97, foreheadHeight: 1.03, eyeShape: 0.28, eyeSize: 0.97, eyeSpacing: 0.98, eyeDepth: 1.06, eyeAngle: 0.14, noseLength: 1.07, noseWidth: 0.89, bridgeHeight: 1.09, tipShape: 0.27, mouthWidth: 0.94, lipThickness: 0.89, browThickness: 1.08, browAngle: 0.16, earSize: 1.07, earAngle: 0.94 },
    },
    {
      id: 11,
      raceId: 'half_elf',
      name: 'Pale Weaver',
      archetype: 'Mystic',
      description: 'Slender, ethereal facial contours bearing astral luminescence.',
      proportions: { faceWidth: 0.88, faceLength: 1.03, jawWidth: 0.83, jawShape: 0.72, chinLength: 1.0, chinWidth: 0.81, cheekboneHeight: 1.14, cheekboneWidth: 0.91, foreheadHeight: 1.06, eyeShape: 0.18, eyeSize: 1.09, eyeSpacing: 1.03, eyeDepth: 0.89, eyeAngle: 0.22, noseLength: 1.02, noseWidth: 0.83, bridgeHeight: 1.04, tipShape: 0.22, mouthWidth: 0.87, lipThickness: 1.02, browThickness: 0.84, browAngle: 0.04, earSize: 1.16, earAngle: 0.89 },
    },
    {
      id: 12,
      raceId: 'half_elf',
      name: 'Silverguard Veteran',
      archetype: 'Hardened',
      description: 'Firm, weathered contours with a deep-set brow from decades of vigilance.',
      proportions: { faceWidth: 0.97, faceLength: 1.01, jawWidth: 0.97, jawShape: 0.89, chinLength: 1.03, chinWidth: 0.95, cheekboneHeight: 1.06, cheekboneWidth: 1.01, foreheadHeight: 0.97, eyeShape: 0.36, eyeSize: 0.96, eyeSpacing: 0.97, eyeDepth: 1.07, eyeAngle: 0.07, noseLength: 1.03, noseWidth: 0.95, bridgeHeight: 1.03, tipShape: 0.38, mouthWidth: 0.98, lipThickness: 0.88, browThickness: 1.12, browAngle: 0.11, earSize: 1.04, earAngle: 1.01 },
    },
  ],
  tiefling: [
    {
      id: 1,
      raceId: 'tiefling',
      name: 'Ashen Sovereign',
      archetype: 'Regal',
      description: 'Regal angular contours with proud brow ridges framing smoldering eyes.',
      proportions: { faceWidth: 0.95, faceLength: 1.05, jawWidth: 0.94, jawShape: 0.9, chinLength: 1.06, chinWidth: 0.88, cheekboneHeight: 1.15, cheekboneWidth: 0.98, foreheadHeight: 1.04, eyeShape: 0.2, eyeSize: 1.02, eyeSpacing: 0.98, eyeDepth: 1.05, eyeAngle: 0.2, noseLength: 1.06, noseWidth: 0.9, bridgeHeight: 1.1, tipShape: 0.25, mouthWidth: 0.94, lipThickness: 0.96, browThickness: 1.1, browAngle: 0.22, earSize: 0.95, earAngle: 1.0 },
    },
    {
      id: 2,
      raceId: 'tiefling',
      name: 'Cinder Fiend',
      archetype: 'Fierce',
      description: 'Aggressive cheekbone lines and sharp jawline built for intimidating presence.',
      proportions: { faceWidth: 0.98, faceLength: 1.03, jawWidth: 0.98, jawShape: 0.95, chinLength: 1.08, chinWidth: 0.92, cheekboneHeight: 1.18, cheekboneWidth: 1.02, foreheadHeight: 0.98, eyeShape: 0.15, eyeSize: 0.98, eyeSpacing: 0.95, eyeDepth: 1.12, eyeAngle: 0.28, noseLength: 1.04, noseWidth: 0.94, bridgeHeight: 1.12, tipShape: 0.22, mouthWidth: 0.97, lipThickness: 0.9, browThickness: 1.2, browAngle: 0.28, earSize: 0.92, earAngle: 1.05 },
    },
    {
      id: 3,
      raceId: 'tiefling',
      name: 'Obsidian Scholar',
      archetype: 'Arcane',
      description: 'Narrow, contemplative features marked by intense analytical focus.',
      proportions: { faceWidth: 0.9, faceLength: 1.06, jawWidth: 0.87, jawShape: 0.82, chinLength: 1.04, chinWidth: 0.84, cheekboneHeight: 1.12, cheekboneWidth: 0.93, foreheadHeight: 1.08, eyeShape: 0.25, eyeSize: 1.04, eyeSpacing: 1.02, eyeDepth: 1.0, eyeAngle: 0.15, noseLength: 1.08, noseWidth: 0.88, bridgeHeight: 1.07, tipShape: 0.28, mouthWidth: 0.9, lipThickness: 0.94, browThickness: 0.98, browAngle: 0.12, earSize: 0.96, earAngle: 0.98 },
    },
    {
      id: 4,
      raceId: 'tiefling',
      name: 'Nether Stalker',
      archetype: 'Infiltrator',
      description: 'Sharp, lean structure with narrowed predator eyes and chiseled chin.',
      proportions: { faceWidth: 0.88, faceLength: 1.0, jawWidth: 0.85, jawShape: 0.92, chinLength: 1.0, chinWidth: 0.82, cheekboneHeight: 1.16, cheekboneWidth: 0.94, foreheadHeight: 0.97, eyeShape: 0.12, eyeSize: 0.95, eyeSpacing: 0.96, eyeDepth: 1.15, eyeAngle: 0.3, noseLength: 1.02, noseWidth: 0.85, bridgeHeight: 1.08, tipShape: 0.18, mouthWidth: 0.88, lipThickness: 0.86, browThickness: 1.05, browAngle: 0.26, earSize: 0.94, earAngle: 1.02 },
    },
    {
      id: 5,
      raceId: 'tiefling',
      name: 'Brimstone Bastion',
      archetype: 'Vanguard',
      description: 'Heavy square jaw and broad brow plate built like forged iron armor.',
      proportions: { faceWidth: 1.02, faceLength: 1.02, jawWidth: 1.04, jawShape: 0.92, chinLength: 1.06, chinWidth: 0.98, cheekboneHeight: 1.08, cheekboneWidth: 1.04, foreheadHeight: 0.96, eyeShape: 0.3, eyeSize: 0.96, eyeSpacing: 0.98, eyeDepth: 1.08, eyeAngle: 0.1, noseLength: 1.03, noseWidth: 0.98, bridgeHeight: 1.05, tipShape: 0.35, mouthWidth: 1.0, lipThickness: 0.92, browThickness: 1.25, browAngle: 0.18, earSize: 0.9, earAngle: 1.08 },
    },
    {
      id: 6,
      raceId: 'tiefling',
      name: 'Smoldering Seductress',
      archetype: 'Alluring',
      description: 'Curved, dangerous beauty with arched brows and full planar lips.',
      proportions: { faceWidth: 0.91, faceLength: 1.01, jawWidth: 0.86, jawShape: 0.75, chinLength: 0.98, chinWidth: 0.83, cheekboneHeight: 1.14, cheekboneWidth: 0.96, foreheadHeight: 1.02, eyeShape: 0.22, eyeSize: 1.08, eyeSpacing: 1.0, eyeDepth: 0.95, eyeAngle: 0.24, noseLength: 0.98, noseWidth: 0.86, bridgeHeight: 1.04, tipShape: 0.25, mouthWidth: 0.93, lipThickness: 1.15, browThickness: 0.92, browAngle: 0.25, earSize: 0.97, earAngle: 0.95 },
    },
    {
      id: 7,
      raceId: 'tiefling',
      name: 'Riftborn Wanderer',
      archetype: 'Exile',
      description: 'Weather-beaten planar skin with guarded, calculating golden irises.',
      proportions: { faceWidth: 0.93, faceLength: 1.02, jawWidth: 0.91, jawShape: 0.85, chinLength: 1.02, chinWidth: 0.87, cheekboneHeight: 1.1, cheekboneWidth: 0.97, foreheadHeight: 1.0, eyeShape: 0.26, eyeSize: 1.0, eyeSpacing: 0.99, eyeDepth: 1.04, eyeAngle: 0.16, noseLength: 1.03, noseWidth: 0.9, bridgeHeight: 1.06, tipShape: 0.28, mouthWidth: 0.92, lipThickness: 0.94, browThickness: 1.06, browAngle: 0.15, earSize: 0.95, earAngle: 1.0 },
    },
    {
      id: 8,
      raceId: 'tiefling',
      name: 'Hellforge Smith',
      archetype: 'Artisan',
      description: 'Solid, blunt-angled features hardened by cinder embers and anvils.',
      proportions: { faceWidth: 1.0, faceLength: 1.0, jawWidth: 1.02, jawShape: 0.88, chinLength: 1.04, chinWidth: 0.96, cheekboneHeight: 1.06, cheekboneWidth: 1.02, foreheadHeight: 0.98, eyeShape: 0.32, eyeSize: 0.98, eyeSpacing: 1.0, eyeDepth: 1.02, eyeAngle: 0.08, noseLength: 1.01, noseWidth: 0.96, bridgeHeight: 1.02, tipShape: 0.36, mouthWidth: 0.98, lipThickness: 0.95, browThickness: 1.18, browAngle: 0.12, earSize: 0.92, earAngle: 1.04 },
    },
    {
      id: 9,
      raceId: 'tiefling',
      name: 'Duskblade Mercenary',
      archetype: 'Mercenary',
      description: 'Asymmetric scars across a chiseled jaw and cynical downturned smirk.',
      proportions: { faceWidth: 0.96, faceLength: 1.03, jawWidth: 0.95, jawShape: 0.9, chinLength: 1.05, chinWidth: 0.9, cheekboneHeight: 1.12, cheekboneWidth: 0.99, foreheadHeight: 0.99, eyeShape: 0.24, eyeSize: 0.99, eyeSpacing: 0.97, eyeDepth: 1.09, eyeAngle: 0.18, noseLength: 1.04, noseWidth: 0.92, bridgeHeight: 1.07, tipShape: 0.29, mouthWidth: 0.95, lipThickness: 0.91, browThickness: 1.12, browAngle: 0.2, earSize: 0.93, earAngle: 1.02 },
    },
    {
      id: 10,
      raceId: 'tiefling',
      name: 'Nether Inquisitor',
      archetype: 'Zealot',
      description: 'Harsh, razor-sharp angles with piercing eyes seeking planar apostasy.',
      proportions: { faceWidth: 0.94, faceLength: 1.06, jawWidth: 0.93, jawShape: 0.94, chinLength: 1.07, chinWidth: 0.89, cheekboneHeight: 1.16, cheekboneWidth: 0.97, foreheadHeight: 1.05, eyeShape: 0.18, eyeSize: 0.96, eyeSpacing: 0.97, eyeDepth: 1.14, eyeAngle: 0.22, noseLength: 1.08, noseWidth: 0.88, bridgeHeight: 1.11, tipShape: 0.21, mouthWidth: 0.93, lipThickness: 0.87, browThickness: 1.15, browAngle: 0.24, earSize: 0.94, earAngle: 1.01 },
    },
    {
      id: 11,
      raceId: 'tiefling',
      name: 'Pyre Mystic',
      archetype: 'Shaman',
      description: 'Sunken cheeks and ritualistic intensity glowing within the pupils.',
      proportions: { faceWidth: 0.89, faceLength: 1.04, jawWidth: 0.86, jawShape: 0.86, chinLength: 1.02, chinWidth: 0.83, cheekboneHeight: 1.17, cheekboneWidth: 0.94, foreheadHeight: 1.04, eyeShape: 0.16, eyeSize: 1.05, eyeSpacing: 1.01, eyeDepth: 1.06, eyeAngle: 0.19, noseLength: 1.05, noseWidth: 0.86, bridgeHeight: 1.09, tipShape: 0.23, mouthWidth: 0.89, lipThickness: 0.93, browThickness: 1.02, browAngle: 0.17, earSize: 0.96, earAngle: 0.97 },
    },
    {
      id: 12,
      raceId: 'tiefling',
      name: 'Ashguard Lord',
      archetype: 'Commander',
      description: 'Commanding planar visage with broad horns base and immovable resolve.',
      proportions: { faceWidth: 0.99, faceLength: 1.04, jawWidth: 1.0, jawShape: 0.93, chinLength: 1.06, chinWidth: 0.95, cheekboneHeight: 1.14, cheekboneWidth: 1.01, foreheadHeight: 1.02, eyeShape: 0.22, eyeSize: 0.98, eyeSpacing: 0.98, eyeDepth: 1.1, eyeAngle: 0.21, noseLength: 1.06, noseWidth: 0.94, bridgeHeight: 1.1, tipShape: 0.27, mouthWidth: 0.98, lipThickness: 0.93, browThickness: 1.22, browAngle: 0.23, earSize: 0.91, earAngle: 1.06 },
    },
  ],
  wood_kin: [
    {
      id: 1,
      raceId: 'wood_kin',
      name: 'Ironwood Warden',
      archetype: 'Protector',
      description: 'Sturdy brow ridges resembling carved ironwood with long swept ears.',
      proportions: { faceWidth: 0.98, faceLength: 1.02, jawWidth: 0.96, jawShape: 0.85, chinLength: 1.02, chinWidth: 0.94, cheekboneHeight: 1.08, cheekboneWidth: 1.02, foreheadHeight: 0.98, eyeShape: 0.35, eyeSize: 1.0, eyeSpacing: 1.02, eyeDepth: 1.0, eyeAngle: 0.08, noseLength: 1.02, noseWidth: 0.96, bridgeHeight: 1.02, tipShape: 0.38, mouthWidth: 0.96, lipThickness: 0.96, browThickness: 1.18, browAngle: 0.12, earSize: 1.2, earAngle: 0.85 },
    },
    {
      id: 2,
      raceId: 'wood_kin',
      name: 'Sylvan Whisper',
      archetype: 'Serene',
      description: 'Delicate leaf-like facial contours with deep moss-green eyes.',
      proportions: { faceWidth: 0.9, faceLength: 1.0, jawWidth: 0.85, jawShape: 0.65, chinLength: 0.96, chinWidth: 0.82, cheekboneHeight: 1.12, cheekboneWidth: 0.94, foreheadHeight: 1.02, eyeShape: 0.2, eyeSize: 1.08, eyeSpacing: 1.04, eyeDepth: 0.9, eyeAngle: 0.18, noseLength: 0.98, noseWidth: 0.86, bridgeHeight: 1.0, tipShape: 0.28, mouthWidth: 0.9, lipThickness: 1.08, browThickness: 0.88, browAngle: 0.04, earSize: 1.25, earAngle: 0.82 },
    },
    {
      id: 3,
      raceId: 'wood_kin',
      name: 'Briar Predator',
      archetype: 'Hunter',
      description: 'Lean, sinewy bone structure with sharp predatory eyes and swept cheekbones.',
      proportions: { faceWidth: 0.92, faceLength: 1.03, jawWidth: 0.89, jawShape: 0.9, chinLength: 1.04, chinWidth: 0.86, cheekboneHeight: 1.15, cheekboneWidth: 0.96, foreheadHeight: 0.97, eyeShape: 0.15, eyeSize: 0.98, eyeSpacing: 0.98, eyeDepth: 1.08, eyeAngle: 0.25, noseLength: 1.04, noseWidth: 0.88, bridgeHeight: 1.06, tipShape: 0.22, mouthWidth: 0.91, lipThickness: 0.88, browThickness: 1.1, browAngle: 0.22, earSize: 1.22, earAngle: 0.88 },
    },
    {
      id: 4,
      raceId: 'wood_kin',
      name: 'Elder Bark Druid',
      archetype: 'Sage',
      description: 'Deeply etched weathered grooves around the eyes resembling ancient oak bark.',
      proportions: { faceWidth: 0.96, faceLength: 1.04, jawWidth: 0.95, jawShape: 0.8, chinLength: 1.05, chinWidth: 0.92, cheekboneHeight: 1.06, cheekboneWidth: 1.0, foreheadHeight: 1.06, eyeShape: 0.38, eyeSize: 0.96, eyeSpacing: 1.01, eyeDepth: 1.06, eyeAngle: 0.02, noseLength: 1.05, noseWidth: 0.94, bridgeHeight: 1.04, tipShape: 0.4, mouthWidth: 0.95, lipThickness: 0.92, browThickness: 1.15, browAngle: 0.06, earSize: 1.18, earAngle: 0.9 },
    },
    {
      id: 5,
      raceId: 'wood_kin',
      name: 'Thorn Vale Scout',
      archetype: 'Tracker',
      description: 'Alert, agile features with widened nostrils attuned to scent and wind.',
      proportions: { faceWidth: 0.93, faceLength: 1.01, jawWidth: 0.9, jawShape: 0.82, chinLength: 1.0, chinWidth: 0.87, cheekboneHeight: 1.1, cheekboneWidth: 0.97, foreheadHeight: 0.99, eyeShape: 0.28, eyeSize: 1.04, eyeSpacing: 1.02, eyeDepth: 0.96, eyeAngle: 0.14, noseLength: 1.01, noseWidth: 0.92, bridgeHeight: 1.02, tipShape: 0.3, mouthWidth: 0.92, lipThickness: 0.95, browThickness: 1.04, browAngle: 0.1, earSize: 1.24, earAngle: 0.86 },
    },
    {
      id: 6,
      raceId: 'wood_kin',
      name: 'Moss Heart Shaman',
      archetype: 'Mystic',
      description: 'Soft rounded features crowned with organic brow nodules and calm lips.',
      proportions: { faceWidth: 0.94, faceLength: 0.99, jawWidth: 0.88, jawShape: 0.6, chinLength: 0.97, chinWidth: 0.86, cheekboneHeight: 1.09, cheekboneWidth: 0.98, foreheadHeight: 1.03, eyeShape: 0.32, eyeSize: 1.06, eyeSpacing: 1.03, eyeDepth: 0.92, eyeAngle: 0.06, noseLength: 0.99, noseWidth: 0.9, bridgeHeight: 1.0, tipShape: 0.36, mouthWidth: 0.93, lipThickness: 1.05, browThickness: 0.95, browAngle: 0.05, earSize: 1.21, earAngle: 0.84 },
    },
    {
      id: 7,
      raceId: 'wood_kin',
      name: 'Deepwood Stalker',
      archetype: 'Rogue',
      description: 'Narrow jaw and high forehead designed for silent nocturnal canopy stalking.',
      proportions: { faceWidth: 0.89, faceLength: 1.02, jawWidth: 0.84, jawShape: 0.88, chinLength: 1.01, chinWidth: 0.81, cheekboneHeight: 1.14, cheekboneWidth: 0.93, foreheadHeight: 1.04, eyeShape: 0.18, eyeSize: 1.02, eyeSpacing: 0.99, eyeDepth: 1.04, eyeAngle: 0.22, noseLength: 1.02, noseWidth: 0.86, bridgeHeight: 1.05, tipShape: 0.24, mouthWidth: 0.89, lipThickness: 0.9, browThickness: 1.02, browAngle: 0.18, earSize: 1.26, earAngle: 0.85 },
    },
    {
      id: 8,
      raceId: 'wood_kin',
      name: 'Antler Crown Sentinel',
      archetype: 'Champion',
      description: 'Prominent brow crests with noble, wide-set features and firm chin.',
      proportions: { faceWidth: 0.99, faceLength: 1.03, jawWidth: 0.98, jawShape: 0.89, chinLength: 1.05, chinWidth: 0.95, cheekboneHeight: 1.1, cheekboneWidth: 1.03, foreheadHeight: 1.01, eyeShape: 0.3, eyeSize: 1.0, eyeSpacing: 1.0, eyeDepth: 1.02, eyeAngle: 0.1, noseLength: 1.04, noseWidth: 0.95, bridgeHeight: 1.06, tipShape: 0.34, mouthWidth: 0.98, lipThickness: 0.94, browThickness: 1.22, browAngle: 0.15, earSize: 1.22, earAngle: 0.88 },
    },
    {
      id: 9,
      raceId: 'wood_kin',
      name: 'River Reed Wanderer',
      archetype: 'Traveler',
      description: 'Fluid, adaptable contours reflecting riparian marshlands and winding vales.',
      proportions: { faceWidth: 0.91, faceLength: 1.01, jawWidth: 0.87, jawShape: 0.7, chinLength: 0.99, chinWidth: 0.85, cheekboneHeight: 1.08, cheekboneWidth: 0.95, foreheadHeight: 1.01, eyeShape: 0.25, eyeSize: 1.05, eyeSpacing: 1.01, eyeDepth: 0.94, eyeAngle: 0.12, noseLength: 1.0, noseWidth: 0.89, bridgeHeight: 1.02, tipShape: 0.3, mouthWidth: 0.91, lipThickness: 1.0, browThickness: 0.92, browAngle: 0.08, earSize: 1.23, earAngle: 0.83 },
    },
    {
      id: 10,
      raceId: 'wood_kin',
      name: 'Bramble Berserker',
      archetype: 'Warrior',
      description: 'Heavy rugged features, thick brow ridges, and scarred jaw.',
      proportions: { faceWidth: 1.01, faceLength: 1.02, jawWidth: 1.02, jawShape: 0.92, chinLength: 1.06, chinWidth: 0.98, cheekboneHeight: 1.08, cheekboneWidth: 1.04, foreheadHeight: 0.95, eyeShape: 0.32, eyeSize: 0.95, eyeSpacing: 0.97, eyeDepth: 1.1, eyeAngle: 0.16, noseLength: 1.03, noseWidth: 0.98, bridgeHeight: 1.04, tipShape: 0.38, mouthWidth: 1.01, lipThickness: 0.92, browThickness: 1.26, browAngle: 0.2, earSize: 1.18, earAngle: 0.92 },
    },
    {
      id: 11,
      raceId: 'wood_kin',
      name: 'Silverleaf Seer',
      archetype: 'Oracle',
      description: 'Ethereal, elongated face with pale irises and translucent skin texture.',
      proportions: { faceWidth: 0.88, faceLength: 1.05, jawWidth: 0.83, jawShape: 0.74, chinLength: 1.02, chinWidth: 0.81, cheekboneHeight: 1.14, cheekboneWidth: 0.92, foreheadHeight: 1.07, eyeShape: 0.18, eyeSize: 1.08, eyeSpacing: 1.04, eyeDepth: 0.88, eyeAngle: 0.16, noseLength: 1.03, noseWidth: 0.84, bridgeHeight: 1.05, tipShape: 0.24, mouthWidth: 0.87, lipThickness: 1.04, browThickness: 0.85, browAngle: 0.04, earSize: 1.28, earAngle: 0.8 },
    },
    {
      id: 12,
      raceId: 'wood_kin',
      name: 'Ancient Grove Keeper',
      archetype: 'Veteran',
      description: 'Timeless solemn features with deep bark ridges and unwavering gaze.',
      proportions: { faceWidth: 0.97, faceLength: 1.03, jawWidth: 0.96, jawShape: 0.84, chinLength: 1.04, chinWidth: 0.93, cheekboneHeight: 1.07, cheekboneWidth: 1.01, foreheadHeight: 1.03, eyeShape: 0.36, eyeSize: 0.98, eyeSpacing: 1.0, eyeDepth: 1.04, eyeAngle: 0.05, noseLength: 1.04, noseWidth: 0.95, bridgeHeight: 1.03, tipShape: 0.36, mouthWidth: 0.96, lipThickness: 0.94, browThickness: 1.2, browAngle: 0.09, earSize: 1.2, earAngle: 0.89 },
    },
  ],
  astral_human: [
    {
      id: 1,
      raceId: 'astral_human',
      name: 'Highland Veteran',
      archetype: 'Warrior',
      description: 'Square jaw, battle-tested brow, and disciplined gaze from frontier garrisons.',
      proportions: { faceWidth: 1.02, faceLength: 1.02, jawWidth: 1.03, jawShape: 0.92, chinLength: 1.04, chinWidth: 0.96, cheekboneHeight: 1.04, cheekboneWidth: 1.02, foreheadHeight: 0.98, eyeShape: 0.45, eyeSize: 0.98, eyeSpacing: 1.0, eyeDepth: 1.04, eyeAngle: 0.0, noseLength: 1.02, noseWidth: 0.96, bridgeHeight: 1.04, tipShape: 0.42, mouthWidth: 1.0, lipThickness: 0.92, browThickness: 1.15, browAngle: 0.1, earSize: 1.0, earAngle: 1.0 },
    },
    {
      id: 2,
      raceId: 'astral_human',
      name: 'Noble Scion',
      archetype: 'Aristocrat',
      description: 'Refined symmetry, straight bridge, and poised posture of bastion dynasties.',
      proportions: { faceWidth: 0.95, faceLength: 1.01, jawWidth: 0.92, jawShape: 0.78, chinLength: 1.0, chinWidth: 0.88, cheekboneHeight: 1.08, cheekboneWidth: 0.97, foreheadHeight: 1.02, eyeShape: 0.4, eyeSize: 1.02, eyeSpacing: 1.0, eyeDepth: 0.96, eyeAngle: 0.05, noseLength: 1.0, noseWidth: 0.9, bridgeHeight: 1.06, tipShape: 0.32, mouthWidth: 0.95, lipThickness: 0.98, browThickness: 0.95, browAngle: 0.04, earSize: 1.0, earAngle: 1.0 },
    },
    {
      id: 3,
      raceId: 'astral_human',
      name: 'Frontier Ranger',
      archetype: 'Scout',
      description: 'Lean, weathered cheeks with keen eyes accustomed to tracking in mist.',
      proportions: { faceWidth: 0.94, faceLength: 1.0, jawWidth: 0.91, jawShape: 0.84, chinLength: 0.99, chinWidth: 0.86, cheekboneHeight: 1.07, cheekboneWidth: 0.96, foreheadHeight: 0.99, eyeShape: 0.38, eyeSize: 1.0, eyeSpacing: 1.01, eyeDepth: 1.02, eyeAngle: 0.08, noseLength: 1.01, noseWidth: 0.91, bridgeHeight: 1.02, tipShape: 0.35, mouthWidth: 0.93, lipThickness: 0.92, browThickness: 1.06, browAngle: 0.08, earSize: 1.0, earAngle: 1.0 },
    },
    {
      id: 4,
      raceId: 'astral_human',
      name: 'Sanctum Prelate',
      archetype: 'Devout',
      description: 'Calm, measured features with solemn brow and steady compassionate eyes.',
      proportions: { faceWidth: 0.96, faceLength: 1.03, jawWidth: 0.93, jawShape: 0.7, chinLength: 1.01, chinWidth: 0.89, cheekboneHeight: 1.05, cheekboneWidth: 0.98, foreheadHeight: 1.05, eyeShape: 0.42, eyeSize: 1.04, eyeSpacing: 1.02, eyeDepth: 0.94, eyeAngle: 0.0, noseLength: 1.03, noseWidth: 0.92, bridgeHeight: 1.04, tipShape: 0.38, mouthWidth: 0.95, lipThickness: 1.02, browThickness: 0.96, browAngle: 0.02, earSize: 1.0, earAngle: 1.0 },
    },
    {
      id: 5,
      raceId: 'astral_human',
      name: 'Vanguard Berserker',
      archetype: 'Heavy',
      description: 'Massive jaw, prominent brow, and broad nose built to absorb heavy strikes.',
      proportions: { faceWidth: 1.06, faceLength: 1.03, jawWidth: 1.08, jawShape: 0.95, chinLength: 1.07, chinWidth: 1.02, cheekboneHeight: 1.03, cheekboneWidth: 1.06, foreheadHeight: 0.94, eyeShape: 0.46, eyeSize: 0.94, eyeSpacing: 0.98, eyeDepth: 1.1, eyeAngle: 0.12, noseLength: 1.04, noseWidth: 1.02, bridgeHeight: 1.02, tipShape: 0.48, mouthWidth: 1.04, lipThickness: 0.92, browThickness: 1.25, browAngle: 0.16, earSize: 1.0, earAngle: 1.0 },
    },
    {
      id: 6,
      raceId: 'astral_human',
      name: 'Citadel Archon',
      archetype: 'Commander',
      description: 'Sharp, commanding contours projecting authority across crowded battlements.',
      proportions: { faceWidth: 0.98, faceLength: 1.02, jawWidth: 0.97, jawShape: 0.88, chinLength: 1.03, chinWidth: 0.93, cheekboneHeight: 1.09, cheekboneWidth: 1.0, foreheadHeight: 1.01, eyeShape: 0.4, eyeSize: 1.0, eyeSpacing: 1.0, eyeDepth: 1.02, eyeAngle: 0.06, noseLength: 1.03, noseWidth: 0.93, bridgeHeight: 1.08, tipShape: 0.34, mouthWidth: 0.98, lipThickness: 0.94, browThickness: 1.1, browAngle: 0.1, earSize: 1.0, earAngle: 1.0 },
    },
    {
      id: 7,
      raceId: 'astral_human',
      name: 'Alchemical Scholar',
      archetype: 'Intellectual',
      description: 'High expansive forehead, observant narrow eyes, and inquisitive tilt.',
      proportions: { faceWidth: 0.92, faceLength: 1.04, jawWidth: 0.88, jawShape: 0.72, chinLength: 1.0, chinWidth: 0.85, cheekboneHeight: 1.08, cheekboneWidth: 0.94, foreheadHeight: 1.12, eyeShape: 0.36, eyeSize: 1.01, eyeSpacing: 1.03, eyeDepth: 0.98, eyeAngle: 0.04, noseLength: 1.05, noseWidth: 0.88, bridgeHeight: 1.06, tipShape: 0.3, mouthWidth: 0.91, lipThickness: 0.94, browThickness: 0.9, browAngle: 0.02, earSize: 1.0, earAngle: 1.0 },
    },
    {
      id: 8,
      raceId: 'astral_human',
      name: 'Caravan Outlaw',
      archetype: 'Rogue',
      description: 'Asymmetric rugged grin, sharp cheekbones, and street-hardened squint.',
      proportions: { faceWidth: 0.95, faceLength: 0.99, jawWidth: 0.93, jawShape: 0.86, chinLength: 0.98, chinWidth: 0.88, cheekboneHeight: 1.11, cheekboneWidth: 0.98, foreheadHeight: 0.97, eyeShape: 0.34, eyeSize: 0.97, eyeSpacing: 0.98, eyeDepth: 1.06, eyeAngle: 0.14, noseLength: 0.99, noseWidth: 0.94, bridgeHeight: 1.01, tipShape: 0.36, mouthWidth: 0.96, lipThickness: 0.9, browThickness: 1.12, browAngle: 0.12, earSize: 1.0, earAngle: 1.0 },
    },
    {
      id: 9,
      raceId: 'astral_human',
      name: 'Sunland Mariner',
      archetype: 'Traveler',
      description: 'Sun-hardened bronze features with squint lines etched by ocean glare.',
      proportions: { faceWidth: 0.97, faceLength: 1.0, jawWidth: 0.95, jawShape: 0.82, chinLength: 1.0, chinWidth: 0.91, cheekboneHeight: 1.06, cheekboneWidth: 1.0, foreheadHeight: 0.99, eyeShape: 0.42, eyeSize: 0.99, eyeSpacing: 1.0, eyeDepth: 1.03, eyeAngle: 0.04, noseLength: 1.02, noseWidth: 0.95, bridgeHeight: 1.03, tipShape: 0.4, mouthWidth: 0.97, lipThickness: 0.96, browThickness: 1.08, browAngle: 0.06, earSize: 1.0, earAngle: 1.0 },
    },
    {
      id: 10,
      raceId: 'astral_human',
      name: 'Guild Master',
      archetype: 'Artisan',
      description: 'Robust, confident face with hearty chin and keen appraising expression.',
      proportions: { faceWidth: 1.01, faceLength: 1.01, jawWidth: 1.0, jawShape: 0.8, chinLength: 1.02, chinWidth: 0.95, cheekboneHeight: 1.05, cheekboneWidth: 1.02, foreheadHeight: 1.0, eyeShape: 0.44, eyeSize: 1.0, eyeSpacing: 1.01, eyeDepth: 0.99, eyeAngle: 0.02, noseLength: 1.01, noseWidth: 0.97, bridgeHeight: 1.02, tipShape: 0.42, mouthWidth: 0.99, lipThickness: 1.0, browThickness: 1.08, browAngle: 0.05, earSize: 1.0, earAngle: 1.0 },
    },
    {
      id: 11,
      raceId: 'astral_human',
      name: 'Northern Wanderer',
      archetype: 'Hardened',
      description: 'Severe frost-bitten cheekbones, heavy eyelids, and resolute downturned jaw.',
      proportions: { faceWidth: 0.99, faceLength: 1.03, jawWidth: 0.98, jawShape: 0.9, chinLength: 1.04, chinWidth: 0.94, cheekboneHeight: 1.08, cheekboneWidth: 1.01, foreheadHeight: 0.98, eyeShape: 0.38, eyeSize: 0.96, eyeSpacing: 0.98, eyeDepth: 1.08, eyeAngle: 0.09, noseLength: 1.04, noseWidth: 0.94, bridgeHeight: 1.05, tipShape: 0.36, mouthWidth: 0.97, lipThickness: 0.88, browThickness: 1.16, browAngle: 0.14, earSize: 1.0, earAngle: 1.0 },
    },
    {
      id: 12,
      raceId: 'astral_human',
      name: 'Crown Justiciar',
      archetype: 'Judge',
      description: 'Impassive, symmetrical bone structure projecting impartial bastion justice.',
      proportions: { faceWidth: 0.97, faceLength: 1.04, jawWidth: 0.96, jawShape: 0.89, chinLength: 1.05, chinWidth: 0.92, cheekboneHeight: 1.1, cheekboneWidth: 0.99, foreheadHeight: 1.04, eyeShape: 0.4, eyeSize: 0.99, eyeSpacing: 1.0, eyeDepth: 1.04, eyeAngle: 0.08, noseLength: 1.05, noseWidth: 0.92, bridgeHeight: 1.08, tipShape: 0.33, mouthWidth: 0.96, lipThickness: 0.91, browThickness: 1.12, browAngle: 0.11, earSize: 1.0, earAngle: 1.0 },
    },
  ],
};

// ============================================================================
// SCREEN 05: HAIRSTYLES (20 DISTINCT OPTIONS), COLORS, SCARS, TATTOOS
// ============================================================================

export interface HairstyleDefinition {
  id: string;
  name: string;
  category: 'Short' | 'Medium' | 'Long' | 'Braided' | 'Tied-Back' | 'Loose' | 'Undercut' | 'Warrior' | 'Travel-Ready';
  description: string;
}

export const HAIRSTYLE_LIBRARY: HairstyleDefinition[] = [
  { id: 'braided_crown', name: 'Braided Crown', category: 'Braided', description: 'Intricately woven halo braid worn by highborn nobility and battle priestesses.' },
  { id: 'flowing_long', name: 'Flowing Long', category: 'Long', description: 'Cascading locks falling past shoulders with subtle natural wave.' },
  { id: 'warrior_ponytail', name: 'Warrior Ponytail', category: 'Warrior', description: 'High, tightly bound combat ponytail designed to stay clear of plate gorgets.' },
  { id: 'topknot_undercut', name: 'Topknot Undercut', category: 'Undercut', description: 'Shaved sides and nape supporting a tightly bound vanguard knot.' },
  { id: 'cropped_crest', name: 'Cropped Crest', category: 'Short', description: 'Short, clean garrison cut with slight brushed texture along the crown.' },
  { id: 'swept_slick', name: 'Swept Back Slick', category: 'Medium', description: 'Slicked back aristocratic locks popular among sanctum envoys.' },
  { id: 'side_shaved_buzz', name: 'Side-Shaved Vanguard', category: 'Undercut', description: 'Close shave on left temple with textured sweep across the right.' },
  { id: 'noble_curls', name: 'Noble Waves', category: 'Medium', description: 'Shoulder-length sculpted waves common among city-state court chroniclers.' },
  { id: 'twin_braids', name: 'Twin Braided Plaits', category: 'Braided', description: 'Dual thick braids draped over shoulders, resilient against wind and march.' },
  { id: 'spiky_vanguard', name: 'Spiky Vanguard', category: 'Short', description: 'Short, textured spikes conditioned to hold under heavy helms.' },
  { id: 'messy_wanderer', name: 'Messy Wanderer', category: 'Travel-Ready', description: 'Unruly, wind-whipped strands parted naturally across the forehead.' },
  { id: 'half_up_bun', name: 'Half-Up Bastion Bun', category: 'Tied-Back', description: 'Upper half gathered into a functional bun while lower strands hang free.' },
  { id: 'warden_mane', name: 'Warden Wild Mane', category: 'Loose', description: 'Voluminous, untamed woodland hair crowned with natural volume.' },
  { id: 'ritual_dreads', name: 'Ritual Dreadlocks', category: 'Braided', description: 'Tightly coiled dreadlocks bound with silver rings and leather cords.' },
  { id: 'knotted_locs', name: 'Knotted Warrior Locs', category: 'Warrior', description: 'Thick warrior locs pulled back into a disciplined nape knot.' },
  { id: 'ashen_bob', name: 'Ashen Chiseled Bob', category: 'Short', description: 'Sharp chin-length angular cut accentuating jawline definition.' },
  { id: 'sylvan_tresses', name: 'Sylvan Vine Tresses', category: 'Loose', description: 'Long layered strands accented by tiny sylvan leaf twists.' },
  { id: 'coiled_crown', name: 'High Coiled Crown', category: 'Tied-Back', description: 'Dignified high coil perched squarely upon the crest of the skull.' },
  { id: 'frontier_braid', name: 'Frontier Long Braid', category: 'Travel-Ready', description: 'Single sturdy back braid reaching mid-spine, wrapped in rawhide.' },
  { id: 'shorn_buzz', name: 'Shorn Bastion Cut', category: 'Short', description: 'Minimalist pragmatic buzz cut suited to unrelenting siege duty.' },
];

export const HAIR_COLORS = [
  { label: 'Raven Black', hex: '#1c1b1f' },
  { label: 'Silver Ash', hex: '#d8d0c5' },
  { label: 'Auburn Copper', hex: '#8c432b' },
  { label: 'Chestnut Umber', hex: '#4f3728' },
  { label: 'Golden Flax', hex: '#c9a45c' },
  { label: 'Twilight Indigo', hex: '#2e334a' },
  { label: 'Bleached Platinum', hex: '#ede8e1' },
  { label: 'Deep Mahogany', hex: '#3d1d19' },
  { label: 'Sylvan Moss', hex: '#42543e' },
  { label: 'Infernal Burgundy', hex: '#632525' },
];

export const SECONDARY_HAIR_HIGHLIGHTS = [
  { label: 'None', hex: '#000000' },
  { label: 'Astral Silver', hex: '#dcd8e2' },
  { label: 'Ember Bronze', hex: '#d48446' },
  { label: 'Frost White', hex: '#ffffff' },
  { label: 'Sylvan Gold', hex: '#dfb76c' },
  { label: 'Blood Crimson', hex: '#8a2323' },
];

export const FACIAL_HAIR_OPTIONS = [
  { id: 'clean_shaven', label: 'Clean-Shaven', description: 'Smooth, clean-shaven jawline.' },
  { id: 'trimmed_stubble', label: 'Trimmed Stubble', description: 'Close-cropped rough stubble of frontier marches.' },
  { id: 'warrior_beard', label: 'Full Warrior Beard', description: 'Thick, disciplined beard covering jaw and chin.' },
  { id: 'braided_goatee', label: 'Braided Goatee', description: 'Pointed chin goatee bound with iron rings.' },
  { id: 'imperial_mustache', label: 'Imperial Handlebar', description: 'Pronounced mustache swept outwards.' },
  { id: 'frontier_beard', label: 'Frontier Bushy Beard', description: 'Full untrimmed wilderness beard of highland wardens.' },
  { id: 'chiseled_sideburns', label: 'Chiseled Sideburns', description: 'Prominent mutton chops framing a clean chin.' },
];

export const EYE_COLORS = [
  { label: 'Amber Gold', hex: '#e2b05a', type: 'natural' },
  { label: 'Sage Emerald', hex: '#7e9c82', type: 'natural' },
  { label: 'Astral Sapphire', hex: '#6d8ca3', type: 'natural' },
  { label: 'Slate Grey', hex: '#94a3b8', type: 'natural' },
  { label: 'Deep Hazel', hex: '#8a6845', type: 'natural' },
  { label: 'Dark Obsidian', hex: '#1e293b', type: 'natural' },
  { label: 'Fey Luminescent', hex: '#8ee3cf', type: 'fantasy' },
  { label: 'Smoldering Ember', hex: '#dc2626', type: 'fantasy' },
  { label: 'Astral Starlight', hex: '#c084fc', type: 'fantasy' },
  { label: 'Heartwood Verdant', hex: '#4ade80', type: 'fantasy' },
];

export const SCARS_LIBRARY = [
  { id: 'none', label: 'None', description: 'No visible combat scars.' },
  { id: 'brow_slash', label: 'Brow Slash', description: 'Vertical blade nick bisecting the left brow.' },
  { id: 'cheek_duel', label: 'Cheek Duelist Scar', description: 'Diagonal dueling cut across the right cheek.' },
  { id: 'jaw_slash', label: 'Jawline Jagged Slash', description: 'Rough scar along the lower jaw from a close parry.' },
  { id: 'eye_cleave', label: 'Battle-Tested Eye Scar', description: 'Faded cut crossing over one eye socket.' },
  { id: 'chest_brand', label: 'Ritual Brand', description: 'Old branded marking from sanctum vows.' },
];

export const TATTOOS_LIBRARY = [
  { id: 'none', label: 'None', description: 'No cosmetic ink or ritual brands.' },
  { id: 'covenant_sigil', label: 'Covenant Sigil', description: 'Silver Covenant heraldic emblem on collarbone.' },
  { id: 'sylvan_vine', label: 'Sylvan Vine', description: 'Sprouting thorn vine winding up the neck.' },
  { id: 'runic_brow', label: 'Runic Brow', description: 'Protective glyphs inked across the temples.' },
  { id: 'ashen_woad', label: 'Ashen Woad', description: 'Vanguard war woad bands on cheek and neck.' },
  { id: 'sunburst_emblem', label: 'Sunburst Brand', description: 'Dawn Warden radiant crest over shoulder.' },
];

export const MARKINGS_LIBRARY = [
  { id: 'none', label: 'None', description: 'No blemishes or pigmentation marks.' },
  { id: 'freckle_dust', label: 'Freckle Dust', description: 'Subtle sun-freckles across bridge and cheeks.' },
  { id: 'ash_mark', label: 'Ritual Ash Mark', description: 'Smudge of consecrated altar ash across brow.' },
  { id: 'starlight_brand', label: 'Starlight Brand', description: 'Faint luminous birthmark reflecting dusk light.' },
  { id: 'war_paint', label: 'War Paint Bands', description: 'Twin dark pigment stripes under both eyes.' },
  { id: 'birch_bark', label: 'Birch Bark Ridge', description: 'Natural bark pigmentation along temples (Sylvan).' },
];

export const TIEFLING_HORNS = [
  { id: 'swept_back', label: 'Classic Swept-Back', description: 'Smooth obsidian horns curving back along the skull.' },
  { id: 'ram_curved', label: 'Curved Bighorn Ram', description: 'Heavy spiraling horns framing the temples like a ram.' },
  { id: 'crowned_spires', label: 'Crowned Spires', description: 'Four vertical pointed spikes forming a menacing crest.' },
  { id: 'forward_blades', label: 'Forward Bladed Horns', description: 'Aggressive sweeping horns pointing forward over the brow.' },
  { id: 'obsidian_heavy', label: 'Heavy Obsidian Curved', description: 'Massive ribbed horns with blunt defensive tips.' },
];

export const HORN_COLORS = [
  { label: 'Obsidian Jet', hex: '#18181b' },
  { label: 'Charcoal Slate', hex: '#334155' },
  { label: 'Smoldering Crimson', hex: '#581c1c' },
  { label: 'Bleached Bone', hex: '#d6d3d1' },
  { label: 'Burnished Bronze', hex: '#78350f' },
];

// ============================================================================
// SCREEN 06: IDENTITY & ORIGINS (7 NARRATIVE BACKGROUNDS, 6 PERSONALITIES)
// ============================================================================

export interface NarrativeBackground {
  id: string;
  name: string;
  emblem: string; // Emoji / Icon descriptor
  lore: string;
  perspective: string;
  dialogueBenefits: string;
  mappedOriginChoice: 'Mercy' | 'Balance' | 'Dominion';
}

export const NARRATIVE_BACKGROUNDS: NarrativeBackground[] = [
  {
    id: 'the_dispossessed',
    name: 'The Dispossessed',
    emblem: '👑⚡',
    lore: 'You once held lands, title, or a storied manor before political betrayal and the planar fracture stripped away everything except your name and steel.',
    perspective: 'Regards fortresses and high thrones as fleeting illusions; places trust in deeds and loyal companions rather than parchment charters.',
    dialogueBenefits: 'Unlocks sympathetic dialogue with refugees and dethroned nobles; reads political deceits before they strike.',
    mappedOriginChoice: 'Balance',
  },
  {
    id: 'the_soldier',
    name: 'The Soldier',
    emblem: '⚔️🛡️',
    lore: 'Trained in the iron legions that manned the frontier bastions, your youth was defined by forced marches, shield walls, and orders barked through blood and rain.',
    perspective: 'Constantly evaluates rooms for choke points, elevation, and tactical retreats; respects decisive hierarchy and physical discipline.',
    dialogueBenefits: 'Commands instant respect from guards and mercenaries; anticipates enemy ambushes and formation traps.',
    mappedOriginChoice: 'Dominion',
  },
  {
    id: 'the_scholar',
    name: 'The Scholar',
    emblem: '📜✨',
    lore: 'Educated in the candlelit archives of the grand scriptoriums, you dedicated years to deciphering shattered oath fragments, ancient treaties, and planar geometry.',
    perspective: 'Understands that every crisis has historical roots; seeks understanding before swinging a blade and looks for ley-line patterns in chaos.',
    dialogueBenefits: 'Translates forgotten glyphs and ruins; deconstructs enemy alchemical tricks and uncovers diplomatic leverage.',
    mappedOriginChoice: 'Mercy',
  },
  {
    id: 'the_outcast',
    name: 'The Outcast',
    emblem: '⛓️🗡️',
    lore: 'Exiled beyond settlement palisades for an unforgiven deed or heritage, you learned to forage, hunt, and sleep with one eye open along the mist-choked trails.',
    perspective: 'Cynical of righteous sanctum platitudes; knows that survival belongs to the alert, the quiet, and the swift.',
    dialogueBenefits: 'Effortlessly detects illicit smugglers and hidden dead-drops; navigates underworld contacts without raising alarms.',
    mappedOriginChoice: 'Dominion',
  },
  {
    id: 'the_wanderer',
    name: 'The Wanderer',
    emblem: '🧭🌲',
    lore: 'With no ancestral hearth to call your own, you have traversed the long roads between mountain hamlets and overgrown ruins, under ever-shifting constellations.',
    perspective: 'Welcomes unfamiliar customs with effortless calm; values flexibility over stubborn pride and knows that roads reveal what cities hide.',
    dialogueBenefits: 'Recognizes regional weather omens, secret mountain crossings, and local folklore overlooked by settled folk.',
    mappedOriginChoice: 'Balance',
  },
  {
    id: 'the_devout',
    name: 'The Devout',
    emblem: '☀️🕯️',
    lore: 'Anointed at the dawnlight altar with vows of sanctuary, you dedicated yourself to shielding the defenseless and purifying corrupted sanctuaries from the rift blight.',
    perspective: 'Interprets the realm’s fracture not as meaningless catastrophe, but as a moral crucible that demands unyielding compassion and courage.',
    dialogueBenefits: 'Inspires demoralized townsfolk, mediates theological impasses, and rebukes zealots who exploit fear.',
    mappedOriginChoice: 'Mercy',
  },
  {
    id: 'the_survivor',
    name: 'The Survivor',
    emblem: '🔥🦅',
    lore: 'You alone walked out from a catastrophe that swallowed your comrades—a fortress leveled by planar rifts or an ambush where the sky turned to ash.',
    perspective: 'Carries an unshakable instinct for imminent peril; possesses stubborn resilience that refuses to yield even when overwhelmed.',
    dialogueBenefits: 'Identifies the signs of trauma and planar contamination in strangers; rallies panicked allies during desperate skirmishes.',
    mappedOriginChoice: 'Balance',
  },
];

export interface PersonalityOption {
  id: string;
  name: string;
  description: string;
  roleplayPrompt: string;
}

export const PERSONALITY_OPTIONS: PersonalityOption[] = [
  {
    id: 'compassionate',
    name: 'Compassionate',
    description: 'Motivated by empathy, protecting the vulnerable, and seeking de-escalation over bloodshed.',
    roleplayPrompt: 'Favors parley and mercy, but will wield wrath to safeguard those who cannot protect themselves.',
  },
  {
    id: 'pragmatic',
    name: 'Pragmatic',
    description: 'Focused on calculated efficiency, resource conservation, and realistic field outcomes.',
    roleplayPrompt: 'Weighs costs and advantages unemotionally; avoids pointless heroics when the objective can be won cleanly.',
  },
  {
    id: 'ambitious',
    name: 'Ambitious',
    description: 'Driven by the pursuit of renown, tactical dominance, and reclaiming shattered greatness.',
    roleplayPrompt: 'Seizes high ground and command; refuses to settle for survival when victory and legacy are attainable.',
  },
  {
    id: 'reserved',
    name: 'Reserved',
    description: 'Measured and observant in speech, guarding inner thoughts while quietly reading others.',
    roleplayPrompt: 'Speaks only when necessary, observing physical tells and maintaining a calm, unreadable exterior.',
  },
  {
    id: 'defiant',
    name: 'Defiant',
    description: 'Unyielding against oppressive tyrants, corrupt institutions, and overwhelming monsters.',
    roleplayPrompt: 'Never bends the knee; turns adversity into furious defiance when backed into a corner.',
  },
  {
    id: 'curious',
    name: 'Curious',
    description: 'Hungry to uncover forbidden lore, investigate arcane anomalies, and ask dangerous questions.',
    roleplayPrompt: 'Probes every strange artifact and rift ruin, fascinated by the mysteries underlying the shattered realm.',
  },
];

export interface VoiceOption {
  id: string;
  name: string;
  description: string;
}

export const VOICE_OPTIONS: VoiceOption[] = [
  { id: 'heroic_noble', name: 'Heroic Champion', description: 'Resolute, clear, and commanding with noble cadence.' },
  { id: 'weathered_veteran', name: 'Weathered Veteran', description: 'Low, gravelly, and steady, tested by frontline campaigns.' },
  { id: 'sylvan_mystic', name: 'Sylvan Mystic', description: 'Melodic, serene, and subtly echoing with ancient rhythm.' },
  { id: 'planar_resonant', name: 'Planar Resonant', description: 'Deep, crisp, and accented by faint astral overtones.' },
];

// ============================================================================
// SCREEN 07: FIVE PLAYABLE CLASSES & PROFILES
// ============================================================================

export interface PlayableClassProfile {
  archetypeId: ArchetypeClassId;
  name: string;
  title: string;
  icon: string;
  oneLineIdentity: string;
  mappedClassId: CharacterClassId;
  defaultSubclassId: CharacterSubclassId;
  combatRole: string;
  difficulty: 'Beginner' | 'Moderate' | 'Advanced';
  primaryAttributes: string;
  recommendedAllocation: { str: number; dex: number; int: number; cha: number };
  description: string;
  tacticalStrengths: string[];
  weaponIdentity: string;
  armorIdentity: string;
  compatibleSubclassIds: CharacterSubclassId[];
  startingEquipment: string[];
  startingAbilities: { id: string; name: string; summary: string }[];
}

export const PLAYABLE_CLASS_PROFILES: PlayableClassProfile[] = [
  {
    archetypeId: 'warrior',
    name: 'Warrior',
    title: 'Frontline Vanguard',
    icon: '⚔️',
    oneLineIdentity: 'Weapon Mastery & Frontline Defense',
    mappedClassId: 'paladin',
    defaultSubclassId: 'vengeance_knight',
    combatRole: 'Frontline Melee Vanguard & Formation Breaker',
    difficulty: 'Beginner',
    primaryAttributes: 'Strength (STR) · Charisma (CHA)',
    recommendedAllocation: { str: 2, dex: 1, int: 0, cha: 1 },
    description:
      'A disciplined frontline fighter who dominates the battlefield through weapon mastery, physical strength, and defensive technique.',
    tacticalStrengths: [
      'Dominates frontline choke points through weapon reach and crowd-cleaving maneuvers',
      'Exceptional physical poise resists posture break, knockdown, and displacement',
      'High physical weapon scaling maximizes strength-driven execution strikes',
    ],
    weaponIdentity: 'Bastion Greatswords, Cleaving Polearms & Heavy Bastion Steel',
    armorIdentity: 'Tempered Vanguard Half-Plate & Steel-Banded Mail',
    compatibleSubclassIds: ['vengeance_knight', 'ironbough_sentinel'],
    startingEquipment: [
      'Bastion Greatsword (1d10+STR Slash)',
      'Tempered Vanguard Half-Plate',
      'Steel-Banded Pauldrons & Gauntlets',
      'Field Whetstone & Rations',
    ],
    startingAbilities: [
      {
        id: 'sunblade_cleave',
        name: 'Sunblade Cleave',
        summary: 'Range 2 · Sweeping arc cleaves mutual adjacent foes & shoves 1 tile.',
      },
      {
        id: 'searing_smite',
        name: 'Oathbreaker Smite',
        summary: 'Range 2 · Gap-close leap, +6 Execution vs ≤50% HP & +1 AP on kill.',
      },
    ],
  },
  {
    archetypeId: 'mage',
    name: 'Mage',
    title: 'Arcane Elementalist',
    icon: '✨',
    oneLineIdentity: 'Arcane Spellcraft & Spatial Control',
    mappedClassId: 'arcanist',
    defaultSubclassId: 'crimson_savant',
    combatRole: 'Ranged Arcane Artillery & Ley-Line Controller',
    difficulty: 'Advanced',
    primaryAttributes: 'Intelligence (INT) · Dexterity (DEX)',
    recommendedAllocation: { str: 0, dex: 1, int: 2, cha: 1 },
    description:
      'A practitioner of arcane forces who manipulates magical energy, controls space, and reshapes encounters.',
    tacticalStrengths: [
      'Manipulates spatial geometry and detonates volatile environmental hazard casks',
      'Commands multi-target spell lances and high-burst pyromantic singularities',
      'Controls engagement range with spacetime pulls and positioning vacuums',
    ],
    weaponIdentity: 'Runed Staves, Grimoires & Astral Resonance Foci',
    armorIdentity: 'Ley-Woven Astral Mantles & Protective Silk Shrouds',
    compatibleSubclassIds: ['crimson_savant', 'rift_chronomancer'],
    startingEquipment: [
      'Runed Quarterstaff (1d6 Bludgeon + Arcane Focus)',
      'Ley-Woven Astral Mantle & Robes',
      'Astral Focus Grimoire & Runestones',
      'Flask of Volatile Alchemical Fire',
    ],
    startingAbilities: [
      {
        id: 'astral_soul_blade',
        name: 'Astral Soul-Blade',
        summary: 'Range 4 · Linear piercing fire-ray hits foes behind target & shoves 1.',
      },
      {
        id: 'searing_blood_nova',
        name: 'Searing Blood-Nova',
        summary: 'Range 5 · 3×3 firestorm (+5 Resonance vs Burning) & chain-ignites oil.',
      },
    ],
  },
  {
    archetypeId: 'rogue',
    name: 'Rogue',
    title: 'Shadow Infiltrator',
    icon: '🗡️',
    oneLineIdentity: 'Stealth Infiltration & Weakness Exploitation',
    mappedClassId: 'warden',
    defaultSubclassId: 'briar_stalker',
    combatRole: 'High-Initiative Flanker & Precision Striker',
    difficulty: 'Moderate',
    primaryAttributes: 'Dexterity (DEX) · Intelligence (INT)',
    recommendedAllocation: { str: 0, dex: 2, int: 1, cha: 1 },
    description:
      'A tactical infiltrator who relies on precision, mobility, deception, and exploiting enemy weaknesses.',
    tacticalStrengths: [
      'High turn initiative guarantees early combat tempo and vantage positioning',
      'Devastating critical strike multipliers against sundered, rooted, or isolated foes',
      'Superior mobility allows flanking maneuvers through impassable rough ground',
    ],
    weaponIdentity: 'Twin Shadow-Steel Daggers & Balanced Shortbows',
    armorIdentity: 'Supple Brigandine Jerkins & Shadow-Dappled Leather',
    compatibleSubclassIds: ['briar_stalker'],
    startingEquipment: [
      'Twin Shadow-Steel Daggers (1d4+DEX Piercing)',
      'Supple Brigandine Leather Jerkin',
      'Thieves’ Masterwork Lockpicks',
      'Caltrop Pouch & Smoke Phial',
    ],
    startingAbilities: [
      {
        id: 'briarfang_strike',
        name: 'Briarfang Strike',
        summary: 'Range 3 · +4 Predator DMG vs Rooted/Sundered & sprouts briar snare.',
      },
      {
        id: 'heart_briar_volley',
        name: 'Heart-Briar Volley',
        summary: 'Range 5 · +5 Isolated Ambush DMG & raises 3-tile briar wall.',
      },
    ],
  },
  {
    archetypeId: 'paladin',
    name: 'Paladin',
    title: 'Sanctified Bulwark',
    icon: '🛡️',
    oneLineIdentity: 'Martial Discipline & Sacred Protection',
    mappedClassId: 'paladin',
    defaultSubclassId: 'dawn_warden',
    combatRole: 'Armored Protector & Radiant Tactician',
    difficulty: 'Beginner',
    primaryAttributes: 'Strength (STR) · Charisma (CHA)',
    recommendedAllocation: { str: 2, dex: 0, int: 0, cha: 2 },
    description:
      'An oathbound protector who combines martial discipline with sacred power and battlefield protection.',
    tacticalStrengths: [
      'Heavy plate and sacred bulwarks establish an unyielding defensive frontline',
      'Consecrates battleground terrain to radiate persistent healing and status purge',
      'Combines high single-target smite burst with radiant party defense',
    ],
    weaponIdentity: 'Sanctified Warhammers & Crested Kite Shields',
    armorIdentity: 'Silver Covenant Full Plate & Heraldic Surcoats',
    compatibleSubclassIds: ['dawn_warden', 'vengeance_knight'],
    startingEquipment: [
      'Sanctified Warhammer (1d8+STR Bludgeon)',
      'Crested Heraldic Kite Shield (+2 AC)',
      'Silver Covenant Heavy Plate Mail',
      'Consecrated Reliquary Amulet',
    ],
    startingAbilities: [
      {
        id: 'dawnbreaker_judgment',
        name: 'Dawnbreaker Judgment',
        summary: 'Range 3 · Sunder foe & consecrate a 5-tile healing solar cross.',
      },
      {
        id: 'lay_on_hands',
        name: 'Dawnlight Mending',
        summary: 'Range 4 · Restore 14 HP, purge debuffs & sanctify ground.',
      },
    ],
  },
  {
    archetypeId: 'ranger',
    name: 'Ranger',
    title: 'Wilderness Skirmisher',
    icon: '🏹',
    oneLineIdentity: 'Precision Ranged Combat & Area Control',
    mappedClassId: 'warden',
    defaultSubclassId: 'ironbough_sentinel',
    combatRole: 'Versatile Skirmisher & Wilderness Warden',
    difficulty: 'Moderate',
    primaryAttributes: 'Dexterity (DEX) · Strength (STR)',
    recommendedAllocation: { str: 1, dex: 2, int: 1, cha: 0 },
    description:
      'A wilderness specialist who controls space through precision attacks, preparation, and ranged combat.',
    tacticalStrengths: [
      'Long-distance precision targeting punishes enemies before they reach melee range',
      'Commands living thornwood barricades and concealed snares to dictate movement',
      'Excels at controlling elevated sniper perches with bow and spear synergy',
    ],
    weaponIdentity: 'Ironwood Recurve Bows & Sylvan Hunting Spears',
    armorIdentity: 'Reinforced Sylvan Leather Cloaks & Flexible Scale',
    compatibleSubclassIds: ['ironbough_sentinel', 'briar_stalker'],
    startingEquipment: [
      'Ironwood Recurve Bow (1d8+DEX Piercing)',
      'Warden’s Ash Hunting Spear (1d6+STR)',
      'Reinforced Sylvan Leather Cloak',
      'Herbal Poultice & Field Kit',
    ],
    startingAbilities: [
      {
        id: 'briarfang_strike',
        name: 'Briarfang Strike',
        summary: 'Range 3 · +4 Predator DMG vs Rooted/Sundered & plants briars.',
      },
      {
        id: 'ironwood_tempest',
        name: 'Ironwood Tempest',
        summary: 'Range 3 · Sunder + adjacent shockwave & grants self Warded +2 AC.',
      },
    ],
  },
];

// ============================================================================
// SCREEN 08: ATTRIBUTES (STR, DEX, INT, CHA) & BUDGET RULES
// ============================================================================

export interface AttributeMeta {
  key: 'str' | 'dex' | 'int' | 'cha';
  name: string;
  short: string;
  description: string;
  tacticalEffects: string[];
}

export const ATTRIBUTE_METADATA: AttributeMeta[] = [
  {
    key: 'str',
    name: 'Strength',
    short: 'STR',
    description: 'Governs melee strike damage, greatsword accuracy, heavy armor poise, and shoving environmental monoliths or explosive casks.',
    tacticalEffects: [
      '+1 Melee Weapon Damage per +1 modifier',
      '+1 Shove distance and obstacle impact damage',
      'Enables heavier plate armor without movement penalties',
    ],
  },
  {
    key: 'dex',
    name: 'Dexterity',
    short: 'DEX',
    description: 'Governs ranged accuracy, turn initiative sequencing, reflex defense, and movement evasion across burning oil or brambles.',
    tacticalEffects: [
      '+1 Turn Initiative per +1 modifier',
      '+1 Ranged bow & dagger accuracy and critical chance',
      '+1 Reflex Evasion against area hazard blasts',
    ],
  },
  {
    key: 'int',
    name: 'Intelligence',
    short: 'INT',
    description: 'Governs arcane spell potency, ley-line manipulation, explosive hazard chain reactions, and historical dialogue insights.',
    tacticalEffects: [
      '+1 Arcane Spell & Singularity damage per +1 modifier',
      '+10% Chain-ignition area radius for oil & gas casks',
      'Unlocks forgotten lore parley options during encounters',
    ],
  },
  {
    key: 'cha',
    name: 'Charisma',
    short: 'CHA',
    description: 'Governs paladin radiant wards, companion combat synergy buffs, dialogue de-escalation checks, and leadership morale aura.',
    tacticalEffects: [
      '+2 Radiant healing & protective shield potency per +1 modifier',
      '+1 Companion Approval bonus on shared battlefield victories',
      'Enables compelling parley options to prevent bloodletting',
    ],
  },
];

export const ATTRIBUTE_POINT_BUDGET = 4;
export const MAX_ALLOC_PER_STAT = 3;

// ============================================================================
// SCREEN 09: COMBAT IDENTITY & SPECIALIZATION ROADMAP (6 SUBCLASSES PRESERVED)
// ============================================================================

export interface SpecializationRoadmapItem {
  id: CharacterSubclassId;
  name: string;
  parentClass: CharacterClassId;
  archetypes: ArchetypeClassId[];
  roleTitle: string;
  unlockLevel: number;
  lore: string;
  signatureSkillName: string;
  signatureSkillSummary: string;
}

export const SPECIALIZATION_ROADMAP: SpecializationRoadmapItem[] = [
  {
    id: 'dawn_warden',
    name: 'Dawn Warden',
    parentClass: 'paladin',
    archetypes: ['paladin'],
    roleTitle: 'Radiant Aegis & Sacred Sanctifier',
    unlockLevel: 3,
    lore: 'Anointed guardians who channel the unbroken starlight of the First Dawn to purge planar corruption and shield frontline allies.',
    signatureSkillName: 'Dawnbreaker Consecration',
    signatureSkillSummary: 'Consecrates a 5-tile solar cross that mends allies for 8 HP per round and burns encroaching foes.',
  },
  {
    id: 'vengeance_knight',
    name: 'Vengeance Knight',
    parentClass: 'paladin',
    archetypes: ['warrior', 'paladin'],
    roleTitle: 'Execution Vanguard & Relentless Striker',
    unlockLevel: 3,
    lore: 'Warriors who swore blood retribution when their sanctums burned, turning wrath into armor-cleaving force and execution leaps.',
    signatureSkillName: 'Oathbreaker Smite',
    signatureSkillSummary: 'High-impact leap strike that deals +6 Execution bonus against wounded targets and refunds 1 AP on kill.',
  },
  {
    id: 'crimson_savant',
    name: 'Crimson Savant',
    parentClass: 'arcanist',
    archetypes: ['mage'],
    roleTitle: 'Pyromantic Artillery & Thermal Resonator',
    unlockLevel: 3,
    lore: 'Dangerous planar pyromancers who sacrifice vital essence to ignite chain singularities and detonate combustible battlefield hazards.',
    signatureSkillName: 'Searing Blood-Nova',
    signatureSkillSummary: 'Explodes a 3×3 firestorm dealing heavy planar damage and chain-igniting oil pools or casks.',
  },
  {
    id: 'rift_chronomancer',
    name: 'Rift Chronomancer',
    parentClass: 'arcanist',
    archetypes: ['mage'],
    roleTitle: 'Spatial Weaver & Vacuum Manipulator',
    unlockLevel: 3,
    lore: 'Scholars who harness the torn planar fabric to fold space, vacuum foes into tight clusters, and manipulate turn initiative order.',
    signatureSkillName: 'Temporal Rift Collapse',
    signatureSkillSummary: 'Opens a gravitational rift pulling up to 4 enemies into a central tile and sundering their physical AC.',
  },
  {
    id: 'briar_stalker',
    name: 'Briar Stalker',
    parentClass: 'warden',
    archetypes: ['rogue', 'ranger'],
    roleTitle: 'Shadow Ambush & Sylvan Snare Specialist',
    unlockLevel: 3,
    lore: 'Infiltrators who move like mist through the underbrush, laying lethal briar traps and executing flanked targets from stealth.',
    signatureSkillName: 'Heart-Briar Volley',
    signatureSkillSummary: 'Rains thorned arrows that sprout an impenetrable 3-tile briar barrier and roots caught targets.',
  },
  {
    id: 'ironbough_sentinel',
    name: 'Ironbough Sentinel',
    parentClass: 'warden',
    archetypes: ['warrior', 'ranger'],
    roleTitle: 'Borderland Skirmisher & Fortress Archer',
    unlockLevel: 3,
    lore: 'Seasoned highland wardens who embody the unbending endurance of ancient ironwood, controlling vast distances with bow and spear.',
    signatureSkillName: 'Ironwood Tempest',
    signatureSkillSummary: 'Sweeping shockwave that sunders armor, shoves enemies backward, and grants the Sentinel +2 AC Warded.',
  },
];

// ============================================================================
// SCREEN 08: DETAILED SPECIALIZATION PROFILES & COMPARISON DATA
// ============================================================================

export interface SpecializationComparison {
  coreIdentity: string;
  combatRole: string;
  skillThemes: string[];
  defensiveStrengths: string;
  offensiveStrengths: string;
  utilityStrengths: string;
}

export interface SpecializationDetailedProfile {
  id: CharacterSubclassId;
  name: string;
  title: string;
  icon: string;
  shortIdentity: string;
  oneLineCombatDescription: string;
  availabilityState: string;
  loreDescription: string;
  combatIdentity: string;
  tacticalRole: string;
  equipmentCompatibility: string[];
  unlockRequirements: string;
  signatureSkill: {
    id: string;
    name: string;
    summary: string;
    apCost: number;
    cooldown: number;
    range: number;
    element: string;
  };
  specializationAbilities: {
    id: string;
    name: string;
    level: number;
    summary: string;
  }[];
  comparison: SpecializationComparison;
}

export const SPECIALIZATION_PROFILES: Record<CharacterSubclassId, SpecializationDetailedProfile> = {
  dawn_warden: {
    id: 'dawn_warden',
    name: 'Dawn Warden',
    title: 'Sanctified Bulwark & Radiant Aegis',
    icon: '☀️',
    shortIdentity: 'Radiant Guardian & Healer',
    oneLineCombatDescription: 'Channels solar conduits to heal allies, establish consecration zones, and protect the frontline.',
    availabilityState: 'Unlocks at Level 3 · Future Path',
    loreDescription:
      'Anointed champions sworn to the unbroken dawn of the First Covenant, wielding solar power to purge planar rift corruption and preserve the fragile balance of Dimraeth.',
    combatIdentity: 'Sustained Vanguard Support & Radiant Area Denial',
    tacticalRole: 'Frontline Tank, Healer & Consecrator',
    equipmentCompatibility: [
      'One-Handed Warhammers & Maces',
      'Kite Shields & Tower Shields',
      'Full Plate Mail & Blessed Surcoats',
    ],
    unlockRequirements: 'Reach Character Level 3 and swear the Dawn Warden Vow at a consecrated covenant shrine.',
    signatureSkill: {
      id: 'dawnbreaker_judgment',
      name: 'Dawnbreaker Judgment',
      summary: 'Call down a cruciform solar pillar (15–22 Radiant DMG + Sundered) that consecrates a 5-tile cross into Sanctified Ground, healing allies for +6 HP & Blessed.',
      apCost: 2,
      cooldown: 2,
      range: 3,
      element: 'Radiant',
    },
    specializationAbilities: [
      { id: 'solar_flare', name: 'Solar Flare', level: 5, summary: 'Unleash a searing solar burst across a 3x3 area, dealing 8–13 Radiant DMG and blinding foes (-3 to hit).' },
      { id: 'aegis_of_the_dawn', name: 'Aegis of the Dawn', level: 8, summary: 'Enfold an ally in protective dawnlight, granting 14 Temp HP and +2 AC for 2 turns.' },
      { id: 'consecrated_aura', name: 'Consecrated Aura', level: 11, summary: 'Passive 5-tile radius sanctuary aura that heals companions for 4 HP every combat turn.' },
      { id: 'avatar_of_the_sun', name: 'Avatar of the Sun', level: 20, summary: 'Ascend as the living Avatar of the Sun: gain 20 Temp HP, radiate 18–28 shockwaves, and regenerate party.' },
    ],
    comparison: {
      coreIdentity: 'Sacred Guardian & Healer',
      combatRole: 'Defensive Anchor & Area Denier',
      skillThemes: ['Solar Consecration', 'Radiant Cleansing', 'Bastion Shields'],
      defensiveStrengths: 'High natural Armor Class, persistent temp HP shields, and status cleansing.',
      offensiveStrengths: 'Radiant elemental damage, blinds to reduce enemy hit chance, and armor sundering.',
      utilityStrengths: 'Allied mending, sanctified ground creation, and area illumination.',
    },
  },

  vengeance_knight: {
    id: 'vengeance_knight',
    name: 'Vengeance Knight',
    title: 'Execution Vanguard & Retribution Striker',
    icon: '⚔️',
    shortIdentity: 'Relentless Heavy Executioner',
    oneLineCombatDescription: 'Sacrifices defensive restraint to deliver high-damage execution strikes that refund AP on kills.',
    availabilityState: 'Unlocks at Level 3 · Future Path',
    loreDescription:
      'Martial vanguards who broke away from passive sanctum doctrine when their strongholds fell, turning inner fury and shattered vows into lethal execution power.',
    combatIdentity: 'High-Risk High-Reward Frontline Breaker',
    tacticalRole: 'Execution Finisher & Gap-Closer',
    equipmentCompatibility: [
      'Bastion Greatswords & Greataxes',
      'Tempered Half-Plate & Heavy Spiked Pauldrons',
      'Two-Handed Cleaving Polearms',
    ],
    unlockRequirements: 'Reach Character Level 3 and claim the Shattered Oath insignia after surviving blood combat.',
    signatureSkill: {
      id: 'searing_smite',
      name: 'Oathbreaker Smite',
      summary: 'Leap into melee with fractured astral judgment (16–24 Radiant DMG + Sundered), dealing +6 Execution DMG against targets at ≤50% HP and refunding +1 AP on a kill.',
      apCost: 2,
      cooldown: 2,
      range: 2,
      element: 'Radiant / Physical',
    },
    specializationAbilities: [
      { id: 'retribution_strike', name: 'Retribution Strike', level: 5, summary: 'Strike with reckless wrath, dealing 10–16 physical DMG plus 1 additional damage for every 5% missing health.' },
      { id: 'spiteful_ward', name: 'Spiteful Ward', level: 8, summary: 'Assume a punitive stance for 1 turn: retaliate against melee attacks and reflect 50% damage taken.' },
      { id: 'blood_price_smite', name: 'Blood Price Smite', level: 11, summary: 'Sacrifice 6 HP to imbue greatsword with dark fire, dealing guaranteed critical burst (+10 DMG).' },
      { id: 'oath_of_total_ruin', name: 'Oath of Total Ruin', level: 20, summary: 'Unleash total ruin: gain 20 Temp HP, cause melee attacks to ignore enemy armor entirely, and shatter terrain.' },
    ],
    comparison: {
      coreIdentity: 'Retribution Vanguard',
      combatRole: 'Single-Target Execution & Armor Shatterer',
      skillThemes: ['Execution Smite', 'Low-HP Scaling', 'Damage Reflection'],
      defensiveStrengths: 'Emergency counter-stance and temp HP upon securing fatal strikes.',
      offensiveStrengths: 'Armor-piercing melee, bonus damage against bloodied foes, and AP refunds on kill.',
      utilityStrengths: 'Mobility leap across obstacles and formation-breaking shoves.',
    },
  },

  crimson_savant: {
    id: 'crimson_savant',
    name: 'Crimson Savant',
    title: 'Pyromantic Artillery & Blood-Sigil Weaver',
    icon: '🔥',
    shortIdentity: 'Combustible Firestorm Controller',
    oneLineCombatDescription: 'Channels vital essence to detonate environmental fire hazards and unleash 3x3 spell novas.',
    availabilityState: 'Unlocks at Level 3 · Future Path',
    loreDescription:
      'Scholars of forbidden blood-sigil planar geometry who draw upon vital lifeforce to spark chain reactions across combustible terrain and rift rifts.',
    combatIdentity: 'Long-Range Burst & Hazard Chain-Reaction',
    tacticalRole: 'Area-of-Effect Artillery & Pyromancer',
    equipmentCompatibility: [
      'Runed Arcane Staves & Blood Grimoires',
      'Ley-Woven Astral Robes',
      'Alchemical Phials & Catalyst Foci',
    ],
    unlockRequirements: 'Reach Character Level 3 and transcribe the Blood-Weave formula from ancient planar ruins.',
    signatureSkill: {
      id: 'searing_blood_nova',
      name: 'Searing Blood-Nova',
      summary: 'Detonate a 3×3 crimson firestorm at range 5 (16–23 Fire DMG, +5 Resonance vs Burning) that scorches surrounding foes for 6 Fire DMG and chain-ignites oil & barrels.',
      apCost: 2,
      cooldown: 2,
      range: 5,
      element: 'Fire / Arcane',
    },
    specializationAbilities: [
      { id: 'blood_siphon', name: 'Blood Siphon', level: 5, summary: 'Siphons life essence from afar, dealing 9–14 damage and healing the savant for 50% of damage dealt.' },
      { id: 'crimson_lance', name: 'Crimson Lance', level: 8, summary: 'Cast a piercing linear fire-spear through up to 4 tiles, igniting all flammable surfaces in its wake.' },
      { id: 'thermal_resonance', name: 'Thermal Resonance', level: 11, summary: 'Passive +25% fire damage against targets afflicted by Burning, causing fire damage to spread.' },
      { id: 'heartstop_sovereign', name: 'Heartstop Sovereign', level: 20, summary: 'Crush the target’s heart through sympathetic planar resonance, inflicting 25–36 DMG, stunning for 1 turn, and cursing adjacent foes.' },
    ],
    comparison: {
      coreIdentity: 'Pyromantic Scholar',
      combatRole: 'Mass Area Damage & Environmental Combustor',
      skillThemes: ['Thermal Hazard Detonation', 'Blood Siphoning', 'Piercing Lances'],
      defensiveStrengths: 'Self-healing through damage-siphoning conduits.',
      offensiveStrengths: 'Massive 3x3 burst radius, oil barrel chain-reactions, and burning status synergy.',
      utilityStrengths: 'Environmental ignition and long-range line-of-sight denial.',
    },
  },

  rift_chronomancer: {
    id: 'rift_chronomancer',
    name: 'Rift Chronomancer',
    title: 'Spacetime Weaver & Vacuum Manipulator',
    icon: '⏳',
    shortIdentity: 'Spacetime & Positioning Controller',
    oneLineCombatDescription: 'Bends temporal ley-lines to vacuum enemies into clusters, rewind positions, and root formations.',
    availabilityState: 'Unlocks at Level 3 · Future Path',
    loreDescription:
      'Researchers who study the tears left in reality by the Shattered Oath, manipulating time dilation and gravitational singularities to dictate the flow of battle.',
    combatIdentity: 'Crowd Control & Battlefield Manipulation',
    tacticalRole: 'Spacetime Controller & Tactical Disrupter',
    equipmentCompatibility: [
      'Chronomantic Astrolabes & Focal Orbs',
      'Astral Shrouds & Silk Mantles',
      'Planar Tuning Forks',
    ],
    unlockRequirements: 'Reach Character Level 3 and synchronize an astral tuning fork with a tear in the weave.',
    signatureSkill: {
      id: 'chrono_rift_collapse',
      name: 'Chrono-Rift Collapse',
      summary: 'Collapse a localized spacetime rift (14–21 Arcane DMG + Rooted) that vacuums all other enemies within 2 tiles inward toward the epicenter for 4 Arcane Warp DMG.',
      apCost: 2,
      cooldown: 2,
      range: 5,
      element: 'Arcane',
    },
    specializationAbilities: [
      { id: 'time_slip', name: 'Time Slip', level: 5, summary: 'Rewind an ally to their starting round position and refund 2 movement points with 6 Temp HP.' },
      { id: 'gravitational_singularity', name: 'Gravitational Singularity', level: 8, summary: 'Place a spatial rift that slows enemy initiative and pulls enemies toward hazardous tiles.' },
      { id: 'temporal_stasis', name: 'Temporal Stasis', level: 11, summary: 'Enclose a target in an impervious time-bubble for 1 turn, neutralizing their actions.' },
      { id: 'time_stop', name: 'Time Stop', level: 20, summary: 'Halt the universal clock: pause all other units on the battlefield and immediately take an uninterrupted bonus turn with 3 AP.' },
    ],
    comparison: {
      coreIdentity: 'Temporal Architect',
      combatRole: 'Crowd Positioning & Turn Sequencing',
      skillThemes: ['Gravitational Vacuum', 'Positional Rewind', 'Initiative Manipulation'],
      defensiveStrengths: 'Phasing through attacks, tactical teleportation, and rewind escapes.',
      offensiveStrengths: 'Arcane warp damage and clustering foes for ally area-of-effect combos.',
      utilityStrengths: 'Repositioning allies, pulling foes onto hazard tiles, and extra action economy.',
    },
  },

  briar_stalker: {
    id: 'briar_stalker',
    name: 'Briar Stalker',
    title: 'Gloom-Briar Stalker & Shadow Ambush Specialist',
    icon: '🌿',
    shortIdentity: 'Stealth Flanker & Thorn Snare Trapper',
    oneLineCombatDescription: 'Strikes from concealment with thorned shafts, erecting impassable briar walls and rooting priority targets.',
    availabilityState: 'Unlocks at Level 3 · Future Path',
    loreDescription:
      'Silent scouts attuned to the thorned underbrush of the ancient vales, who turn natural vegetation into choking barricades and lethal ambush choke points.',
    combatIdentity: 'Concealed Precision & Tactical Choke Creation',
    tacticalRole: 'Stealth Infiltrator & Terrain Trapper',
    equipmentCompatibility: [
      'Ironwood Hunting Bows & Recurves',
      'Twin Daggers & Poison Phials',
      'Supple Camouflage Brigandine',
    ],
    unlockRequirements: 'Reach Character Level 3 and bind living thorn-vines to your quiver in the Whispering Vale.',
    signatureSkill: {
      id: 'heart_briar_volley',
      name: 'Heart-Briar Volley',
      summary: 'Loose living ironwood thorns (15–22 Nature DMG, +5 Ambush DMG against isolated foes) that raise a 3-tile perpendicular wall of Bramble Snares across the grid.',
      apCost: 2,
      cooldown: 2,
      range: 5,
      element: 'Nature',
    },
    specializationAbilities: [
      { id: 'ambush_snare', name: 'Ambush Snare', level: 5, summary: 'Plant a hidden briar snare on a grid tile that roots and deals 8 Nature DMG to the first enemy stepping into it.' },
      { id: 'thorned_volley', name: 'Thorned Volley', level: 8, summary: 'Fire a wide fan of thorned arrows, inflicting bleeding and reducing enemy movement range by 2 tiles.' },
      { id: 'shadow_camouflage', name: 'Shadow Camouflage', level: 11, summary: 'Blend seamlessly into sylvan shadows, gaining temporary invisibility and +4 critical hit bonus.' },
      { id: 'wrath_of_the_primordial_grove', name: 'Wrath of the Primordial Grove', level: 20, summary: 'Summon ancient iron roots from beneath the earth, crushing all enemies in a 3x3 area for 24–36 Nature DMG and Rooting them.' },
    ],
    comparison: {
      coreIdentity: 'Shadow Woodsman',
      combatRole: 'Single-Target Ambush & Choke-Point Trapping',
      skillThemes: ['Briar Barricades', 'Stealth Infiltration', 'Entangling Snares'],
      defensiveStrengths: 'Evasion, stealth disengagement, and blocking enemy movement lines.',
      offensiveStrengths: 'High critical strike damage against isolated or rooted targets.',
      utilityStrengths: 'Creating physical barricades that block enemy line-of-sight and charge paths.',
    },
  },

  ironbough_sentinel: {
    id: 'ironbough_sentinel',
    name: 'Ironbough Sentinel',
    title: 'Living Bark Bulwark & Primal Counterstriker',
    icon: '🛡️',
    shortIdentity: 'Unyielding Living Bark Defender',
    oneLineCombatDescription: 'Anchors the frontline like ancient oak, shattering enemy armor with glaives and shielding allies.',
    availabilityState: 'Unlocks at Level 3 · Future Path',
    loreDescription:
      'Veterans who took root within the primeval groves, weaving living bark through their sinew to withstand catastrophic blows and cleave through ranks of foes.',
    combatIdentity: 'Immovable Frontline Tank & Shockwave Controller',
    tacticalRole: 'Sustained Melee Brawler & Armor Sunderer',
    equipmentCompatibility: [
      'Ironwood Glaives & Heavy Halberds',
      'Bark-Reinforced Scale Mail',
      'Tower Shields & Oak Staves',
    ],
    unlockRequirements: 'Reach Character Level 3 and drink sap from the Ironwood World-Tree heart.',
    signatureSkill: {
      id: 'ironwood_tempest',
      name: 'Ironwood Tempest',
      summary: 'Unleash an ironwood glaive tempest (15–22 Physical DMG + Sundered + Push 1) that batters orthogonal foes for 5 DMG and grants you Warded (+2 AC) & +5 Temp HP.',
      apCost: 2,
      cooldown: 2,
      range: 3,
      element: 'Physical / Nature',
    },
    specializationAbilities: [
      { id: 'ironwood_brace', name: 'Ironwood Brace', level: 5, summary: 'Roots feet into bedrock: Gains immunity to displacement, +3 AC, and absorbs up to 12 damage for 1 turn.' },
      { id: 'barkskin_resonance', name: 'Barkskin Resonance', level: 8, summary: 'Passive aura providing +2 AC to all adjacent companions while the sentinel remains unbroken.' },
      { id: 'seismic_cleave', name: 'Seismic Cleave', level: 11, summary: 'Heavy overhead strike that shatters ground, dealing 18–24 Physical DMG and shoving enemies 2 tiles.' },
      { id: 'avatar_of_the_ironwood', name: 'Avatar of the Ironwood', level: 20, summary: 'Transform into a living tree guardian: gain 25 Temp HP, +4 AC, and shockwave pulses on melee strikes.' },
    ],
    comparison: {
      coreIdentity: 'Living Bark Defender',
      combatRole: 'Melee Brawler & Formation Anchor',
      skillThemes: ['Armor Sundering', 'Displacement Immunity', 'Defensive Barkskin'],
      defensiveStrengths: 'Highest passive Armor Class, knockback immunity, and persistent temp HP.',
      offensiveStrengths: 'Shockwave sweeps, high physical posture break, and armor shattering.',
      utilityStrengths: 'Shielding nearby companions with protective bark auras and controlling choke points.',
    },
  },
};

/**
 * Returns only the specialization profiles compatible with the given archetype class.
 */
export function getCompatibleSpecializations(
  archetypeId: ArchetypeClassId
): SpecializationDetailedProfile[] {
  const classProf = PLAYABLE_CLASS_PROFILES.find((p) => p.archetypeId === archetypeId);
  if (!classProf) return [];
  return classProf.compatibleSubclassIds
    .map((subId) => SPECIALIZATION_PROFILES[subId])
    .filter(Boolean);
}

// ============================================================================
// COMPREHENSIVE DETAILED APPEARANCE STATE SCHEMA
// ============================================================================

export interface CharacterDetailedAppearance {
  // Body (Screen 03)
  bodyPreset: BodyPresetType;
  height: number;
  shoulderWidth: number;
  chest: number;
  waist: number;
  armThickness: number;
  legThickness: number;
  muscularity: number;
  posture: number;

  // Face (Screen 04)
  facePresetId: number;
  faceMode: 'presets' | 'advanced';
  faceWidth: number;
  faceLength: number;
  jawWidth: number;
  jawShape: number;
  chinLength: number;
  chinWidth: number;
  cheekboneHeight: number;
  cheekboneWidth: number;
  foreheadHeight: number;
  eyeShape: number;
  eyeSize: number;
  eyeSpacing: number;
  eyeDepth: number;
  eyeAngle: number;
  noseLength: number;
  noseWidth: number;
  bridgeHeight: number;
  tipShape: number;
  mouthWidth: number;
  lipThickness: number;
  browThickness: number;
  browAngle: number;
  earSize: number;
  earAngle: number;

  // Hair & Appearance (Screen 05)
  hairStyleId: string;
  hairPrimaryColor: string;
  hairSecondaryColor: string;
  facialHairStyle: string;
  facialHairColor: string;
  skinToneHex: string;
  skinUndertone: string;
  skinComplexion: string;
  eyeColorHex: string;
  scarId: string;
  tattooId: string;
  markingId: string;

  // Race-specific features
  hornStyle: string;
  hornLength: number;
  hornCurvature: number;
  hornColor: string;

  // Legacy string mappings for backward compatibility
  bodyType: CharacterAppearanceConfig['bodyType'];
  facePreset: CharacterAppearanceConfig['facePreset'];
  facialStructure: CharacterAppearanceConfig['facialStructure'];
  skinTone: string;
  hairStyle: CharacterAppearanceConfig['hairStyle'];
  hairColor: string;
  eyeColor: string;
  facialHair: CharacterAppearanceConfig['facialHair'];
  scarsAndMarkings: CharacterAppearanceConfig['scarsAndMarkings'];
  tattoos: CharacterAppearanceConfig['tattoos'];
  accessories: CharacterAppearanceConfig['accessories'];
}

export function createDefaultDetailedAppearance(raceId: CharacterRaceId): CharacterDetailedAppearance {
  const raceDetails = RACE_EXTENDED_DETAILS[raceId] ?? RACE_EXTENDED_DETAILS.half_elf;
  const skinTone = raceDetails.compatibleSkinTones[0]?.hex ?? '#e8cbb8';
  const skinUndertone = raceDetails.compatibleSkinTones[0]?.undertone ?? 'neutral';
  const facePreset = FACE_PRESETS_BY_RACE[raceId][0];

  return {
    bodyPreset: 'athletic',
    height: 1.0,
    shoulderWidth: 1.0,
    chest: 1.0,
    waist: 1.0,
    armThickness: 1.0,
    legThickness: 1.0,
    muscularity: 0.5,
    posture: 0.8,

    facePresetId: 1,
    faceMode: 'presets',
    ...facePreset.proportions,

    hairStyleId: 'braided_crown',
    hairPrimaryColor: HAIR_COLORS[1].hex,
    hairSecondaryColor: '#000000',
    facialHairStyle: 'clean_shaven',
    facialHairColor: HAIR_COLORS[1].hex,
    skinToneHex: skinTone,
    skinUndertone,
    skinComplexion: 'smooth',
    eyeColorHex: EYE_COLORS[0].hex,
    scarId: 'none',
    tattooId: 'none',
    markingId: 'none',

    hornStyle: 'swept_back',
    hornLength: 1.0,
    hornCurvature: 1.0,
    hornColor: HORN_COLORS[0].hex,

    // Legacy fields
    bodyType: 'Athletic',
    facePreset: 'Noble',
    facialStructure: 'High Cheekbones',
    skinTone,
    hairStyle: 'Braided Crown',
    hairColor: HAIR_COLORS[1].hex,
    eyeColor: EYE_COLORS[0].hex,
    facialHair: 'Clean-Shaven',
    scarsAndMarkings: 'None',
    tattoos: 'None',
    accessories: 'None',
  };
}

export function randomizeDetailedAppearance(raceId: CharacterRaceId): CharacterDetailedAppearance {
  const raceDetails = RACE_EXTENDED_DETAILS[raceId] ?? RACE_EXTENDED_DETAILS.half_elf;
  const skinToneObj = raceDetails.compatibleSkinTones[Math.floor(Math.random() * raceDetails.compatibleSkinTones.length)];
  const presets = FACE_PRESETS_BY_RACE[raceId];
  const randomFace = presets[Math.floor(Math.random() * presets.length)];
  const randomHair = HAIRSTYLE_LIBRARY[Math.floor(Math.random() * HAIRSTYLE_LIBRARY.length)];
  const randomHairColor = HAIR_COLORS[Math.floor(Math.random() * HAIR_COLORS.length)].hex;
  const randomEyeColor = EYE_COLORS[Math.floor(Math.random() * EYE_COLORS.length)].hex;
  const randomBeard = FACIAL_HAIR_OPTIONS[Math.floor(Math.random() * FACIAL_HAIR_OPTIONS.length)].id;
  const randomScar = SCARS_LIBRARY[Math.floor(Math.random() * SCARS_LIBRARY.length)].id;
  const randomTattoo = TATTOOS_LIBRARY[Math.floor(Math.random() * TATTOOS_LIBRARY.length)].id;
  const randomMarking = MARKINGS_LIBRARY[Math.floor(Math.random() * MARKINGS_LIBRARY.length)].id;
  const randomBody = BODY_PRESETS[Math.floor(Math.random() * BODY_PRESETS.length)];

  return {
    bodyPreset: randomBody.id,
    ...randomBody.proportions,

    facePresetId: randomFace.id,
    faceMode: 'presets',
    ...randomFace.proportions,

    hairStyleId: randomHair.id,
    hairPrimaryColor: randomHairColor,
    hairSecondaryColor: '#000000',
    facialHairStyle: randomBeard,
    facialHairColor: randomHairColor,
    skinToneHex: skinToneObj.hex,
    skinUndertone: skinToneObj.undertone,
    skinComplexion: 'smooth',
    eyeColorHex: randomEyeColor,
    scarId: randomScar,
    tattooId: randomTattoo,
    markingId: randomMarking,

    hornStyle: TIEFLING_HORNS[Math.floor(Math.random() * TIEFLING_HORNS.length)].id,
    hornLength: 0.9 + Math.random() * 0.3,
    hornCurvature: 0.9 + Math.random() * 0.3,
    hornColor: HORN_COLORS[Math.floor(Math.random() * HORN_COLORS.length)].hex,

    // Legacy fields
    bodyType: 'Athletic',
    facePreset: 'Noble',
    facialStructure: 'High Cheekbones',
    skinTone: skinToneObj.hex,
    hairStyle: 'Braided Crown',
    hairColor: randomHairColor,
    eyeColor: randomEyeColor,
    facialHair: 'Clean-Shaven',
    scarsAndMarkings: 'None',
    tattoos: 'None',
    accessories: 'None',
  };
}

// ============================================================================
// LEGACY COMPATIBILITY EXPORTS FOR EXISTING CODEBASE
// ============================================================================

export const CREATION_PROGRESS_STEPS = [
  { id: 'begin', stepNum: '01', label: 'Begin', subtitle: 'Begin Your Oath' },
  { id: 'ancestry', stepNum: '02', label: 'Ancestry', subtitle: 'Choose Your Ancestry' },
  { id: 'body', stepNum: '03', label: 'Body', subtitle: 'Define Your Physique' },
  { id: 'face', stepNum: '04', label: 'Face', subtitle: 'Define Your Features' },
  { id: 'appearance', stepNum: '05', label: 'Appearance', subtitle: 'Your Outward Identity' },
  { id: 'identity', stepNum: '06', label: 'Identity', subtitle: 'Who Were You Before The Oath?' },
  { id: 'class', stepNum: '07', label: 'Class', subtitle: 'Choose Your Path' },
  { id: 'subclass', stepNum: '08', label: 'Specialization', subtitle: 'Oath of Specialization' },
  { id: 'attributes', stepNum: '09', label: 'Attributes', subtitle: 'Define Your Abilities' },
  { id: 'combat_identity', stepNum: '10', label: 'Combat Loadout', subtitle: 'Prepare For The Journey' },
  { id: 'review', stepNum: '11', label: 'Review', subtitle: 'The Oath Begins' },
] as const;

export type CreationStepId = (typeof CREATION_PROGRESS_STEPS)[number]['id'];

export const APPEARANCE_CATEGORY_LIST = [
  { id: 'bodyType', label: 'Body Type' },
  { id: 'facePreset', label: 'Face Presets' },
  { id: 'facialStructure', label: 'Facial Structure' },
  { id: 'skinTone', label: 'Skin Tone' },
  { id: 'hairStyle', label: 'Hair Styles' },
  { id: 'hairColor', label: 'Hair Colors' },
  { id: 'eyeColor', label: 'Eye Colors' },
  { id: 'facialHair', label: 'Facial Hair' },
  { id: 'scarsAndMarkings', label: 'Scars and Markings' },
  { id: 'tattoos', label: 'Tattoos' },
  { id: 'accessories', label: 'Accessories' },
] as const;

export type AppearanceCategoryId = (typeof APPEARANCE_CATEGORY_LIST)[number]['id'];

export interface CharacterBackgroundOption {
  id: string;
  name: string;
  mappedOriginChoice: 'Mercy' | 'Balance' | 'Dominion';
  lore: string;
  proficiencies: string[];
  startingItemsAndBonuses: string[];
  dialogueBenefits: string;
}

export const CHARACTER_BACKGROUNDS: CharacterBackgroundOption[] = NARRATIVE_BACKGROUNDS.map((nb) => ({
  id: nb.id,
  name: nb.name,
  mappedOriginChoice: nb.mappedOriginChoice,
  lore: nb.lore,
  proficiencies: ['Tactical Resilience', 'Parley Insight'],
  startingItemsAndBonuses: ['Adventurer Pack', 'Sanctum Medallion'],
  dialogueBenefits: nb.dialogueBenefits,
}));

export interface PersistentCharacterConfiguration {
  character_name: string;
  race: CharacterRaceId;
  appearance: CharacterAppearanceConfig;
  detailedAppearance?: CharacterDetailedAppearance;
  class: ArchetypeClassId;
  background: string;
  personality?: string;
  voice?: string;
  attributes: {
    str: number;
    dex: number;
    int: number;
    cha: number;
  };
  starting_equipment: string[];
  starting_abilities: { name: string; summary: string }[];
}

export const CREATION_GAMEPLAY_TIPS = [
  'High ground tiles grant +2 Attack accuracy and extend ranged line-of-sight across the sanctum.',
  'Fire abilities ignite oil pools and detonate volatile casks—use terrain hazards to control choke points.',
  'Press [E] to parley with encounter leaders before blades are drawn; your attributes and background shape the outcome.',
  'Strong companion approval unlocks passive combat synergy bonuses when allies fight near your commander.',
];
