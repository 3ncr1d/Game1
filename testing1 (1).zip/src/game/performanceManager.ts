/**
 * DIMRAETH: THE SHATTERED OATH - PERFORMANCE & VARIABLE REFRESH RATE (VRR) MANAGER
 * Ensures silky-smooth, frame-rate independent gameplay across 60 FPS to 360 FPS displays.
 * 
 * Features:
 * 1. Target Frame Rate selection: Native/VRR, 60, 120, 144, 240, 360, Uncapped.
 * 2. Mathematically exact exponential damping helpers (eliminates lerp drift across frame rates).
 * 3. High-precision sub-millisecond rolling frame time & 1% low metrics recorder.
 * 4. Micro-stutter & garbage-collection defense (zero allocation helpers).
 * 5. Global live subscriber system for in-game Performance HUD (toggleable via F3 or Settings).
 */

export type TargetFpsMode =
  | 'native'
  | '60'
  | '120'
  | '144'
  | '240'
  | '360'
  | 'uncapped';

export interface PerformanceMetrics {
  currentFps: number;
  frameTimeMs: number;
  onePercentLowFps: number;
  jitterMs: number;
  targetMode: TargetFpsMode;
  targetFpsNumber: number;
  smoothnessRating: 'Ultra Smooth (360Hz)' | 'High Refresh (144-240Hz)' | 'Smooth (60-120Hz)' | 'Variable';
  isVsyncNative: boolean;
}

export const TARGET_FPS_OPTIONS: { id: TargetFpsMode; label: string; desc: string; hz: number }[] = [
  { id: 'native', label: 'Native Display (VRR)', desc: 'Matches monitor refresh rate (60–360Hz)', hz: 0 },
  { id: '60', label: '60 FPS', desc: 'Standard 60Hz lock (16.6ms)', hz: 60 },
  { id: '120', label: '120 FPS', desc: 'High-refresh 120Hz (8.3ms)', hz: 120 },
  { id: '144', label: '144 FPS', desc: 'Esports 144Hz (6.9ms)', hz: 144 },
  { id: '240', label: '240 FPS', desc: 'Ultra-fast 240Hz (4.1ms)', hz: 240 },
  { id: '360', label: '360 FPS', desc: 'Maximum 360Hz esports fluidity (2.7ms)', hz: 360 },
  { id: 'uncapped', label: 'Uncapped', desc: 'Maximum possible render throughput', hz: 0 },
];

const STORAGE_FPS_KEY = 'dimraeth_perf_target_fps';
const STORAGE_HUD_KEY = 'dimraeth_perf_hud_visible';

class PerformanceManager {
  private targetMode: TargetFpsMode = 'native';
  private hudVisible: boolean = false;
  private subscribers = new Set<(metrics: PerformanceMetrics) => void>();
  private visibilitySubscribers = new Set<(visible: boolean) => void>();

  // Rolling frame metrics
  private frameTimes: number[] = [];
  private readonly maxSamples = 60;
  private lastTimestamp = 0;
  private smoothedFps = 60;
  private smoothedFrameTime = 16.67;

  constructor() {
    if (typeof window !== 'undefined') {
      try {
        const storedMode = window.localStorage.getItem(STORAGE_FPS_KEY) as TargetFpsMode;
        if (storedMode && TARGET_FPS_OPTIONS.some((o) => o.id === storedMode)) {
          this.targetMode = storedMode;
        }
        const storedHud = window.localStorage.getItem(STORAGE_HUD_KEY);
        if (storedHud !== null) {
          this.hudVisible = storedHud === 'true';
        }
      } catch {
        // Storage access fallback
      }
    }
  }

  public getTargetMode(): TargetFpsMode {
    return this.targetMode;
  }

  public setTargetMode(mode: TargetFpsMode) {
    this.targetMode = mode;
    try {
      if (typeof window !== 'undefined') {
        window.localStorage.setItem(STORAGE_FPS_KEY, mode);
      }
    } catch {
      // Ignore storage errors
    }
    this.broadcastMetrics();
  }

  public getTargetFpsNumber(): number {
    switch (this.targetMode) {
      case '60':
        return 60;
      case '120':
        return 120;
      case '144':
        return 144;
      case '240':
        return 240;
      case '360':
        return 360;
      case 'native':
      case 'uncapped':
      default:
        return 0; // 0 indicates uncapped / native monitor refresh
    }
  }

  public isHudVisible(): boolean {
    return this.hudVisible;
  }

  public isFpsCounterVisible(): boolean {
    return this.hudVisible;
  }

  public setHudVisible(visible: boolean) {
    this.hudVisible = visible;
    try {
      if (typeof window !== 'undefined') {
        window.localStorage.setItem(STORAGE_HUD_KEY, String(visible));
      }
    } catch {
      // Ignore storage errors
    }
    this.visibilitySubscribers.forEach((fn) => fn(visible));
  }

  public setFpsCounterVisible(visible: boolean) {
    this.setHudVisible(visible);
  }

  public toggleHudVisible(): boolean {
    this.setHudVisible(!this.hudVisible);
    return this.hudVisible;
  }

  public subscribe(fn: (metrics: PerformanceMetrics) => void): () => void {
    this.subscribers.add(fn);
    return () => this.subscribers.delete(fn);
  }

  public subscribeVisibility(fn: (visible: boolean) => void): () => void {
    this.visibilitySubscribers.add(fn);
    return () => this.visibilitySubscribers.delete(fn);
  }

  /**
   * Evaluates if requestAnimationFrame should throttle based on target FPS.
   * Tolerates a 0.35ms margin so VSync and high refresh intervals do not skip frames.
   */
  public shouldThrottle(now: number, lastFrameTime: number): boolean {
    const target = this.getTargetFpsNumber();
    if (target <= 0) return false;
    const minInterval = 1000 / target;
    return now - lastFrameTime < minInterval - 0.35;
  }

  /**
   * Records a frame render event and calculates smoothed FPS, frame times, and 1% low.
   */
  public recordFrame(now: number): PerformanceMetrics {
    if (this.lastTimestamp > 0) {
      const deltaMs = Math.max(0.1, now - this.lastTimestamp);
      this.frameTimes.push(deltaMs);
      if (this.frameTimes.length > this.maxSamples) {
        this.frameTimes.shift();
      }

      // Exponential moving average for smooth display without jitter
      const instantFps = Math.min(1000, 1000 / deltaMs);
      this.smoothedFps = this.smoothedFps * 0.92 + instantFps * 0.08;
      this.smoothedFrameTime = this.smoothedFrameTime * 0.92 + deltaMs * 0.08;
    }
    this.lastTimestamp = now;

    // Periodically broadcast to active subscribers (e.g. HUD)
    const metrics = this.getCurrentMetrics();
    if (this.frameTimes.length % 6 === 0) {
      this.subscribers.forEach((fn) => fn(metrics));
    }
    return metrics;
  }

  public getCurrentMetrics(): PerformanceMetrics {
    const fps = Math.round(this.smoothedFps);
    const frameTimeMs = +this.smoothedFrameTime.toFixed(2);

    // Compute 1% low frame time if we have sufficient samples
    let onePercentLow = fps;
    let jitterMs = 0;
    if (this.frameTimes.length >= 15) {
      const sorted = [...this.frameTimes].sort((a, b) => b - a); // slowest first
      const p99Index = Math.max(0, Math.floor(sorted.length * 0.05));
      const worstTime = sorted[p99Index];
      onePercentLow = Math.round(Math.min(fps, 1000 / worstTime));

      const avg = this.frameTimes.reduce((acc, t) => acc + t, 0) / this.frameTimes.length;
      jitterMs = +(sorted[0] - avg).toFixed(2);
    }

    let smoothnessRating: PerformanceMetrics['smoothnessRating'] = 'Variable';
    if (fps >= 300) smoothnessRating = 'Ultra Smooth (360Hz)';
    else if (fps >= 135) smoothnessRating = 'High Refresh (144-240Hz)';
    else if (fps >= 55) smoothnessRating = 'Smooth (60-120Hz)';

    return {
      currentFps: fps,
      frameTimeMs,
      onePercentLowFps: onePercentLow,
      jitterMs,
      targetMode: this.targetMode,
      targetFpsNumber: this.getTargetFpsNumber(),
      smoothnessRating,
      isVsyncNative: this.targetMode === 'native',
    };
  }

  private broadcastMetrics() {
    const metrics = this.getCurrentMetrics();
    this.subscribers.forEach((fn) => fn(metrics));
  }
}

export const performanceManager = new PerformanceManager();

/**
 * Mathematically exact frame-rate independent exponential damping.
 * Returns the fraction (0..1) to interpolate toward target over delta time `dt`.
 * 
 * Unlike linear lerp `speed * dt`, exponential damping guarantees that an object
 * will cover the exact same distance and arrive at the exact same position over
 * 1.0 second whether rendered at 60 FPS (60 steps) or 360 FPS (360 steps).
 * 
 * Formula: factor = 1 - exp(-lambda * dt)
 */
export function exponentialDamp(lambda: number, dtSeconds: number): number {
  return 1 - Math.exp(-lambda * dtSeconds);
}

/**
 * Clamps delta time to prevent spiral of death on window unfocus or major stall,
 * while ensuring high refresh rates (up to 360Hz / dt = 0.00277s) are never lost.
 */
export function clampDeltaTime(rawDtSeconds: number, maxDt = 0.05): number {
  return Math.max(0.0001, Math.min(rawDtSeconds, maxDt));
}
