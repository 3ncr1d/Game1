import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  ALL_SKILLS_DATABASE,
  createInitialProgressionState,
} from './progressionData';
import {
  Ability,
  CombatUnit,
  createInitialWorldState,
  createInitialRelationships,
  generateTacticalGrid,
  resolveAbilityUse,
  resolveEnvironmentalInteraction,
  resolveMageDefensiveReactions,
  createMageTrialGroundsEncounter,
} from './rules';

test('1. Master Registry: exactly 12 authorized Mage Core Skills with exact parameters', () => {
  const authorizedMageSkills = [
    { id: 'infernal_orb', name: 'Infernal Orb', ap: 2, cd: 2, range: 4, category: 'pyromantic_detonation' },
    { id: 'glacial_lance', name: 'Glacial Lance', ap: 2, cd: 2, range: 4, category: 'piercing_ray' },
    { id: 'chain_lightning', name: 'Chain Lightning', ap: 2, cd: 3, range: 4, category: 'chain_lightning' },
    { id: 'blink_step', name: 'Blink Step', ap: 1, cd: 2, range: 4, category: 'teleport' },
    { id: 'gravitational_collapse', name: 'Gravitational Collapse', ap: 2, cd: 3, range: 4, category: 'vortex' },
    { id: 'arcane_disjunction', name: 'Arcane Disjunction', ap: 1, cd: 2, range: 4, category: 'dispel' },
    { id: 'aegis_ward', name: 'Aegis Ward', ap: 1, cd: 2, range: 3, category: 'barrier' },
    { id: 'counterspell', name: 'Counterspell', ap: 1, cd: 3, range: 1, category: 'counterspell' },
    { id: 'phase_veil', name: 'Phase Veil', ap: 1, cd: 3, range: 1, category: 'phase_shift' },
    { id: 'runic_mine', name: 'Runic Mine', ap: 1, cd: 2, range: 4, category: 'trap' },
    { id: 'astral_rift', name: 'Astral Rift', ap: 2, cd: 3, range: 4, category: 'hazard_field' },
    { id: 'prismatic_field', name: 'Prismatic Field', ap: 2, cd: 4, range: 4, category: 'prismatic_matrix' },
  ];

  for (const exp of authorizedMageSkills) {
    const skill = ALL_SKILLS_DATABASE[exp.id];
    assert.ok(skill, `Mage skill ${exp.id} must exist in ALL_SKILLS_DATABASE`);
    assert.equal(skill.classKey, 'mage');
    assert.equal(skill.apCost, exp.ap, `${exp.id} AP cost mismatch`);
    assert.equal(skill.cooldown, exp.cd, `${exp.id} cooldown mismatch`);
    assert.equal(skill.range, exp.range, `${exp.id} range mismatch`);
  }
});

test('2. Elemental Destruction — Infernal Orb AoE and Oil Pool Ignition', () => {
  const enc = createMageTrialGroundsEncounter(createInitialWorldState());
  const caster = enc.units.find((u) => u.id === 'seraphina')!;
  const ability = caster.abilities.find((a) => a.id === 'infernal_orb')!;
  assert.ok(ability);

  // Target oil pool at (4, 5) where Grunts stand
  const envResult = resolveEnvironmentalInteraction(
    caster,
    ability,
    4,
    5,
    enc.grid,
    enc.envObjects,
    enc.units
  );

  // Surface at (4,5) and (5,5) must ignite into fire_pool
  assert.equal(envResult.updatedGrid[4][5].surface, 'fire_pool');
  assert.equal(envResult.updatedGrid[5][5].surface, 'fire_pool');

  // Units in radius 1 take fire damage and burning status
  const hitGrunts = envResult.updatedUnits.filter(
    (u) => (u.gridX === 4 || u.gridX === 5) && (u.gridZ === 4 || u.gridZ === 5)
  );
  assert.ok(hitGrunts.length > 0);
  for (const g of hitGrunts) {
    assert.ok(g.statuses.some((s) => s.type === 'burning'));
  }
});

test('3. Elemental Destruction — Glacial Lance Piercing Ray & Chilled Bonus Damage', () => {
  const enc = createMageTrialGroundsEncounter(createInitialWorldState());
  const caster = enc.units.find((u) => u.id === 'seraphina')!;
  const ability = caster.abilities.find((a) => a.id === 'glacial_lance')!;
  assert.ok(ability);

  // Target enemy stalker at (3, 5) in direct line north of caster (3, 7)
  const stalker = enc.units.find((u) => u.id === 'trial_mage_stalker')!;
  const rels = createInitialRelationships();
  const world = createInitialWorldState();
  const hit1 = resolveAbilityUse(caster, stalker, ability, enc.units, rels, world, 16);
  assert.equal(hit1.hit, true);
  assert.equal(hit1.statusApplied, 'chilled');
  assert.ok(hit1.damage >= 10 && hit1.damage <= 14);

  // If target already chilled, bonus +4 damage is dealt
  const chilledStalker: CombatUnit = {
    ...stalker,
    statuses: [{ type: 'chilled', turnsLeft: 2 }],
  };
  const hit2 = resolveAbilityUse(caster, chilledStalker, ability, enc.units, rels, world, 16);
  assert.equal(hit2.hit, true);
  assert.ok(hit2.damage >= 14 && hit2.damage <= 22);
  assert.ok(hit2.summaryText.includes('Chilled Shatter'));
});

test('4. Elemental Destruction — Chain Lightning Deterministic Multi-Target Arcs', () => {
  const enc = createMageTrialGroundsEncounter(createInitialWorldState());
  const caster = enc.units.find((u) => u.id === 'seraphina')!;
  const ability = caster.abilities.find((a) => a.id === 'chain_lightning')!;
  assert.ok(ability);

  const primaryTarget = enc.units.find((u) => u.id === 'trial_mage_oil_grunt1')!;
  const envResult = resolveEnvironmentalInteraction(
    caster,
    ability,
    primaryTarget.gridX,
    primaryTarget.gridZ,
    enc.grid,
    enc.envObjects,
    enc.units,
    primaryTarget.id
  );

  // Must hit primary target (12 DMG) and chain to up to 2 other enemies (8 and 5 DMG)
  assert.ok(envResult.bonusDamageDealt > 0);
  assert.ok(envResult.triggeredEvents.some((e) => e.includes('CHAIN LIGHTNING')));

  // Never hits ally Kaelen
  const kaelen = envResult.updatedUnits.find((u) => u.id === 'kaelen')!;
  assert.equal(kaelen.hp, 32);
});

test('5. Arcane Manipulation — Blink Step Teleporting while Rooted', () => {
  const enc = createMageTrialGroundsEncounter(createInitialWorldState());
  const caster: CombatUnit = {
    ...enc.units.find((u) => u.id === 'seraphina')!,
    statuses: [{ type: 'rooted', turnsLeft: 2 }],
  };
  const ability = caster.abilities.find((a) => a.id === 'blink_step')!;
  assert.ok(ability);

  // Teleport across intervening space to empty tile (3, 3)
  const envResult = resolveEnvironmentalInteraction(
    caster,
    ability,
    3,
    3,
    enc.grid,
    enc.envObjects,
    [caster]
  );

  const movedCaster = envResult.updatedUnits.find((u) => u.id === caster.id)!;
  assert.equal(movedCaster.gridX, 3);
  assert.equal(movedCaster.gridZ, 3);
  assert.ok(envResult.triggeredEvents.some((e) => e.includes('BLINK STEP')));
});

test('6. Arcane Manipulation — Gravitational Collapse Suction & Obstacle Handling', () => {
  const enc = createMageTrialGroundsEncounter(createInitialWorldState());
  const caster = enc.units.find((u) => u.id === 'seraphina')!;
  const ability = ALL_SKILLS_DATABASE['gravitational_collapse'];
  assert.ok(ability);

  // Cast at center (4, 4)
  const abilityObj: Ability = {
    id: 'gravitational_collapse',
    name: 'Gravitational Collapse',
    key: '2',
    apCost: 2,
    cooldown: 3,
    range: 4,
    aoeRadius: 2,
    aoeShape: 'chebyshev_5x5',
    damageRange: [8, 8],
    element: 'arcane',
    targetType: 'ground',
  };

  const envResult = resolveEnvironmentalInteraction(
    caster,
    abilityObj,
    4,
    4,
    enc.grid,
    enc.envObjects,
    enc.units
  );

  assert.ok(envResult.triggeredEvents.some((e) => e.includes('GRAVITATIONAL COLLAPSE')));
  // Foes pulled 1 tile closer to center
  assert.ok(envResult.bonusDamageDealt > 0);
});

test('7. Arcane Manipulation — Arcane Disjunction Buff Purge and Bonus Damage', () => {
  const enc = createMageTrialGroundsEncounter(createInitialWorldState());
  const caster = enc.units.find((u) => u.id === 'seraphina')!;
  const abilityObj: Ability = {
    id: 'arcane_disjunction',
    name: 'Arcane Disjunction',
    key: '1',
    apCost: 1,
    cooldown: 2,
    range: 4,
    aoeShape: 'single',
    damageRange: [6, 6],
    element: 'arcane',
    targetType: 'enemy',
  };

  const inquisitor = enc.units.find((u) => u.id === 'trial_mage_inquisitor')!;
  assert.ok(inquisitor.tempHp > 0);
  assert.ok(inquisitor.statuses.some((s) => s.type === 'warded'));
  assert.ok(inquisitor.statuses.some((s) => s.type === 'blessed'));

  // Direct hit calculation includes +6 bonus damage for purges
  const hitRes = resolveAbilityUse(
    caster,
    inquisitor,
    abilityObj,
    enc.units,
    createInitialRelationships(),
    createInitialWorldState(),
    16
  );
  assert.equal(hitRes.hit, true);
  assert.ok(hitRes.damage >= 12 && hitRes.damage <= 18);
  assert.ok(hitRes.summaryText.includes('Disjunction Purge'));

  // Environmental purge resolution clears all defensive buffs
  const envResult = resolveEnvironmentalInteraction(
    caster,
    abilityObj,
    inquisitor.gridX,
    inquisitor.gridZ,
    enc.grid,
    enc.envObjects,
    enc.units,
    inquisitor.id
  );

  const purgedInquisitor = envResult.updatedUnits.find((u) => u.id === inquisitor.id)!;
  assert.equal(purgedInquisitor.tempHp, 0);
  assert.ok(!purgedInquisitor.statuses.some((s) => s.type === 'warded'));
  assert.ok(!purgedInquisitor.statuses.some((s) => s.type === 'blessed'));
});

test('8. Mystical Defense — Aegis Ward Barrier, +10 Temp HP, and Shockwave on Break', () => {
  const enc = createMageTrialGroundsEncounter(createInitialWorldState());
  const caster = enc.units.find((u) => u.id === 'seraphina')!;
  const abilityObj: Ability = {
    id: 'aegis_ward',
    name: 'Aegis Ward',
    key: '1',
    apCost: 1,
    cooldown: 3,
    range: 0,
    aoeShape: 'single',
    damageRange: [0, 0],
    grantTempHp: 10,
    element: 'arcane',
    targetType: 'self',
  };

  const envResult = resolveEnvironmentalInteraction(
    caster,
    abilityObj,
    caster.gridX,
    caster.gridZ,
    enc.grid,
    enc.envObjects,
    enc.units
  );

  const wardedCaster = envResult.updatedUnits.find((u) => u.id === caster.id)!;
  assert.equal(wardedCaster.tempHp, 10);
  assert.equal(wardedCaster.aegisWardActive, true);
  assert.ok(wardedCaster.statuses.some((s) => s.type === 'warded'));

  // Test defensive reaction on breaking Aegis Ward
  const adjacentEnemy: CombatUnit = {
    ...enc.units.find((u) => u.id === 'trial_mage_stalker')!,
    gridX: wardedCaster.gridX + 1,
    gridZ: wardedCaster.gridZ,
  };
  const attacker = enc.units.find((u) => u.id === 'trial_mage_oil_grunt1')!;

  const defReaction = resolveMageDefensiveReactions(
    attacker,
    wardedCaster,
    { id: 'strike', name: 'Strike', key: '1', apCost: 1, cooldown: 0, range: 1, aoeShape: 'single', damageRange: [12, 12], element: 'physical', targetType: 'enemy' },
    15, // Damage exceeds 10 Temp HP, breaking shield!
    [wardedCaster, adjacentEnemy]
  );

  assert.equal(defReaction.aegisWardShockwave, true);
  assert.equal(defReaction.shockwaveTargets.length, 1);
  assert.equal(defReaction.shockwaveTargets[0].damage, 6);
});

test('9. Mystical Defense — Counterspell Negation and 8 Arcane DMG Reflection', () => {
  const enc = createMageTrialGroundsEncounter(createInitialWorldState());
  const caster: CombatUnit = {
    ...enc.units.find((u) => u.id === 'seraphina')!,
    counterspellActive: true,
    counterspellTurns: 2,
  };

  const rangedAttacker = enc.units.find((u) => u.id === 'trial_mage_weaver')!;
  const incomingSpell: Ability = {
    id: 'arcane_volley',
    name: 'Arcane Volley',
    key: '1',
    apCost: 2,
    cooldown: 0,
    range: 4,
    aoeShape: 'single',
    damageRange: [14, 14],
    element: 'arcane',
    targetType: 'enemy',
  };

  const defReaction = resolveMageDefensiveReactions(
    rangedAttacker,
    caster,
    incomingSpell,
    14,
    [caster, rangedAttacker]
  );

  assert.equal(defReaction.counterspellTriggered, true);
  assert.equal(defReaction.finalDamage, 0); // Completely nullified
  assert.equal(defReaction.counterDamageToAttacker, 8); // 8 Arcane DMG reflected
  assert.ok(defReaction.reactionLog.some((l) => l.toLowerCase().includes('counterspell')));
});

test('10. Mystical Defense — Phase Veil Debuff Cleanse and 50% Mitigation', () => {
  const enc = createMageTrialGroundsEncounter(createInitialWorldState());
  const caster: CombatUnit = {
    ...enc.units.find((u) => u.id === 'seraphina')!,
    statuses: [
      { type: 'burning', turnsLeft: 2 },
      { type: 'rooted', turnsLeft: 2 },
      { type: 'sundered', turnsLeft: 2 },
      { type: 'chilled', turnsLeft: 2 },
    ],
  };

  const abilityObj: Ability = {
    id: 'phase_veil',
    name: 'Phase Veil',
    key: '1',
    apCost: 1,
    cooldown: 3,
    range: 0,
    aoeShape: 'single',
    damageRange: [0, 0],
    element: 'arcane',
    targetType: 'self',
  };

  const envResult = resolveEnvironmentalInteraction(
    caster,
    abilityObj,
    caster.gridX,
    caster.gridZ,
    enc.grid,
    enc.envObjects,
    [caster]
  );

  const veiledCaster = envResult.updatedUnits.find((u) => u.id === caster.id)!;
  // All debuffs purged
  assert.equal(veiledCaster.statuses.length, 0);
  assert.equal(veiledCaster.phaseVeilTurns, 2);
  assert.equal(veiledCaster.moveRange, caster.moveRange + 1);

  // Incoming physical attack mitigated by 50%
  const attacker = enc.units.find((u) => u.id === 'trial_mage_oil_grunt1')!;
  const physicalAttack: Ability = {
    id: 'cleave',
    name: 'Cleave',
    key: '1',
    apCost: 2,
    cooldown: 0,
    range: 1,
    aoeShape: 'single',
    damageRange: [16, 16],
    element: 'physical',
    targetType: 'enemy',
  };

  const defReaction = resolveMageDefensiveReactions(
    attacker,
    veiledCaster,
    physicalAttack,
    16,
    [veiledCaster, attacker]
  );

  assert.equal(defReaction.phaseVeilMitigated, true);
  assert.equal(defReaction.finalDamage, 8); // 50% of 16
});

test('11. Battlefield Control — Runic Mine Surface Trap Placement and Detonation', () => {
  const enc = createMageTrialGroundsEncounter(createInitialWorldState());
  const caster = enc.units.find((u) => u.id === 'seraphina')!;
  const abilityObj: Ability = {
    id: 'runic_mine',
    name: 'Runic Mine',
    key: '1',
    apCost: 1,
    cooldown: 2,
    range: 4,
    aoeShape: 'single',
    damageRange: [14, 14],
    element: 'arcane',
    targetType: 'ground',
  };

  // Place runic mine at empty tile (3, 6)
  const envResult = resolveEnvironmentalInteraction(
    caster,
    abilityObj,
    3,
    6,
    enc.grid,
    enc.envObjects,
    enc.units
  );

  assert.equal(envResult.updatedGrid[3][6].surface, 'runic_mine');
  assert.ok(envResult.triggeredEvents.some((e) => e.includes('RUNIC MINE')));
});

test('12. Battlefield Control — Astral Rift and Prismatic Field Surfaces', () => {
  const enc = createMageTrialGroundsEncounter(createInitialWorldState());
  const caster = enc.units.find((u) => u.id === 'seraphina')!;

  // Astral Rift creates 3x3 hazard surface that damages and sunders foes
  const riftAbility: Ability = {
    id: 'astral_rift',
    name: 'Astral Rift',
    key: '1',
    apCost: 2,
    cooldown: 3,
    range: 4,
    aoeRadius: 1,
    aoeShape: 'chebyshev_3x3',
    damageRange: [4, 4],
    element: 'arcane',
    targetType: 'ground',
  };

  const riftResult = resolveEnvironmentalInteraction(
    caster,
    riftAbility,
    4,
    4,
    enc.grid,
    enc.envObjects,
    enc.units
  );
  assert.equal(riftResult.updatedGrid[4][4].surface, 'astral_rift');

  // Prismatic Field creates harmonic matrix
  const fieldAbility: Ability = {
    id: 'prismatic_field',
    name: 'Prismatic Field',
    key: '1',
    apCost: 2,
    cooldown: 4,
    range: 3,
    aoeRadius: 1,
    aoeShape: 'chebyshev_3x3',
    damageRange: [0, 0],
    element: 'arcane',
    targetType: 'ground',
  };

  const fieldResult = resolveEnvironmentalInteraction(
    caster,
    fieldAbility,
    3,
    7,
    enc.grid,
    enc.envObjects,
    enc.units
  );
  assert.equal(fieldResult.updatedGrid[3][7].surface, 'prismatic_field');
});

test('13. Mage Trial Grounds Encounter Structure and Composition', () => {
  const enc = createMageTrialGroundsEncounter(createInitialWorldState());
  assert.ok(enc.grid.length === 10);
  assert.ok(enc.units.length >= 6);

  const commander = enc.units.find((u) => u.id === 'seraphina')!;
  assert.ok(commander);
  assert.equal(commander.characterClass, 'mage');
  assert.equal(commander.abilities.length, 4);

  const inquisitor = enc.units.find((u) => u.id === 'trial_mage_inquisitor')!;
  assert.ok(inquisitor);
  assert.equal(inquisitor.tempHp, 15);
  assert.ok(inquisitor.statuses.some((s) => s.type === 'warded'));
  assert.ok(inquisitor.statuses.some((s) => s.type === 'blessed'));

  const oilTile = enc.grid[4][5];
  assert.equal(oilTile.surface, 'oil_pool');
});
