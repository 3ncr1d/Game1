import {
  TowerDifficulty,
  TowerEncounterType,
  TowerEnemySlotConfig,
  TowerFloorDefinition,
  TowerGridPreset,
  TowerObjectiveConfig,
  TowerRegionId,
  TowerRegionMetadata,
} from './towerTypes';
import { TOWER_MAJOR_BOSSES, TOWER_MINI_BOSSES } from './towerBossesData';
import { Ability } from './rules';

/**
 * DIMRAETH: THE ASCENDANT TOWER
 * 10 Regions & 100-Floor Encounter Definitions
 */

export const TOWER_REGIONS: Record<TowerRegionId, TowerRegionMetadata> = {
  forgotten_threshold: {
    id: 'forgotten_threshold',
    regionNumber: 1,
    name: 'The Forgotten Threshold',
    floorRange: [1, 10],
    recommendedLevelRange: [1, 4],
    difficulty: 'Beginner',
    tagline: 'Ancient stone vestibule guarded by forgotten covenant sentries',
    loreDescription:
      'The moss-covered grand entrance of the Ascendant Tower. Stone pillars hold ancient braziers that still flicker with astral fire. Here, ancient constructs and oathbreaker remnants test those who dare step beyond mortal bounds.',
    visualTheme: 'Ancient Granite & Whispering Moss',
    ambientPreset: 'twilight_sanctum',
    signatureHazard: 'Collapsing Stone Pillars & Runic Braziers',
    primaryColors: {
      bg: '#171B19',
      border: '#5A4B38',
      accent: '#E2B05A',
      glow: '#7E9C82',
    },
  },
  withered_wilds: {
    id: 'withered_wilds',
    regionNumber: 2,
    name: 'The Withered Wilds',
    floorRange: [11, 20],
    recommendedLevelRange: [4, 6],
    difficulty: 'Easy',
    tagline: 'Overgrown sylvan groves twisted by subterranean corruption',
    loreDescription:
      'Where the roots of Whispering Vale pierced the tower walls, a petrified subterranean jungle formed. Toxic thorns, carnivorous briars, and fungal spores blanket the shattered flagstones.',
    visualTheme: 'Petrified Ironwood & Toxic Briars',
    ambientPreset: 'emerald_grove',
    signatureHazard: 'Bramble Snares & Spore Blooms',
    primaryColors: {
      bg: '#131C15',
      border: '#3D5E43',
      accent: '#7E9C82',
      glow: '#4CAF68',
    },
  },
  ember_foundry: {
    id: 'ember_foundry',
    regionNumber: 3,
    name: 'The Ember Foundry',
    floorRange: [21, 30],
    recommendedLevelRange: [6, 8],
    difficulty: 'Moderate',
    tagline: 'Volcanic smelting chambers and roaring crucible furnaces',
    loreDescription:
      'A vast industrial foundry where ancient astrarium metals were refined into godly armaments. Rivers of molten slag and superheated vents make footwork perilous.',
    visualTheme: 'Molten Slag & Black Iron',
    ambientPreset: 'crimson_rift',
    signatureHazard: 'Fire Pools & Volatile Slag Barrels',
    primaryColors: {
      bg: '#211512',
      border: '#7A3D29',
      accent: '#E26D38',
      glow: '#FF914D',
    },
  },
  frozen_reliquary: {
    id: 'frozen_reliquary',
    regionNumber: 4,
    name: 'The Frozen Reliquary',
    floorRange: [31, 40],
    recommendedLevelRange: [8, 10],
    difficulty: 'Moderate',
    tagline: 'Silent vaults of eternal diamond permafrost',
    loreDescription:
      'A deep crypt sealed in sub-zero frost. Diamond-ice crystals reflect eerie light, while glacial rifts threaten to swallow unwary skirmishers.',
    visualTheme: 'Diamond Ice & Crystalline Vaults',
    ambientPreset: 'twilight_sanctum',
    signatureHazard: 'Slippery Permafrost & Glacial Mirages',
    primaryColors: {
      bg: '#121A21',
      border: '#365C7A',
      accent: '#6DAFD6',
      glow: '#A8DBF5',
    },
  },
  astral_divide: {
    id: 'astral_divide',
    regionNumber: 5,
    name: 'The Astral Divide',
    floorRange: [41, 50],
    recommendedLevelRange: [10, 12],
    difficulty: 'Hard',
    tagline: 'Fractured space floating amidst starry cosmic voids',
    loreDescription:
      'Here, Euclidean geometry breaks down. Floating platforms drift over an infinite cosmic void, connected by shimmering phase conduits and gravitational vortices.',
    visualTheme: 'Floating Spire Platforms & Planar Rifts',
    ambientPreset: 'twilight_sanctum',
    signatureHazard: 'Astral Rifts & Gravity Wells',
    primaryColors: {
      bg: '#181426',
      border: '#563C82',
      accent: '#A672E8',
      glow: '#CBA8FF',
    },
  },
  drowned_kingdom: {
    id: 'drowned_kingdom',
    regionNumber: 6,
    name: 'The Drowned Kingdom',
    floorRange: [51, 60],
    recommendedLevelRange: [12, 14],
    difficulty: 'Hard',
    tagline: 'Sunken palace halls submerged in abyssal tides',
    loreDescription:
      'Remnants of a forgotten civilization flooded by planar oceans. Water surges across sunken battlements, and leviathan horrors lurk in the dark depths.',
    visualTheme: 'Sunken Marble & Abyssal Tides',
    ambientPreset: 'twilight_sanctum',
    signatureHazard: 'Flooded Tiles & Tidal Surges',
    primaryColors: {
      bg: '#101B21',
      border: '#2C5A6E',
      accent: '#479BB8',
      glow: '#78CCEB',
    },
  },
  crimson_covenant: {
    id: 'crimson_covenant',
    regionNumber: 7,
    name: 'The Crimson Covenant',
    floorRange: [61, 70],
    recommendedLevelRange: [14, 16],
    difficulty: 'Very Hard',
    tagline: 'Sanguine altars and cathedrals of blood sacrifice',
    loreDescription:
      'Gothic cathedrals dedicated to forbidden blood-weaving rites. Crimson tapestries and sacrificial runestones pool life essence to empower zealot inquisitors.',
    visualTheme: 'Crimson Alabaster & Blood Altars',
    ambientPreset: 'crimson_rift',
    signatureHazard: 'Sacrificial Blood Pools & Sanguine Brands',
    primaryColors: {
      bg: '#210F14',
      border: '#7A2438',
      accent: '#D43755',
      glow: '#FF6B8B',
    },
  },
  ashen_dominion: {
    id: 'ashen_dominion',
    regionNumber: 8,
    name: 'The Ashen Dominion',
    floorRange: [71, 80],
    recommendedLevelRange: [16, 18],
    difficulty: 'Very Hard',
    tagline: 'Fortified ramparts battered by perpetual siege',
    loreDescription:
      'The war-torn bastions of the legion. Iron barricades, fallen ballistas, and cratered stone testify to centuries of endless tactical siege warfare.',
    visualTheme: 'Cratered Bastions & Siege Barricades',
    ambientPreset: 'crimson_rift',
    signatureHazard: 'Siege Artillery Cratering & Spreading Embers',
    primaryColors: {
      bg: '#1C1916',
      border: '#69513C',
      accent: '#BA8957',
      glow: '#DEB281',
    },
  },
  shattered_expanse: {
    id: 'shattered_expanse',
    regionNumber: 9,
    name: 'The Shattered Expanse',
    floorRange: [81, 90],
    recommendedLevelRange: [18, 19],
    difficulty: 'Extreme',
    tagline: 'Unstable timeline shards suspended in temporal paradoxes',
    loreDescription:
      'A terrifying paradox zone where past, present, and alternate realities collide. Moving across the arena can trigger temporal echoes and reverse enemy actions.',
    visualTheme: 'Temporal Echoes & Mirror Chasm',
    ambientPreset: 'twilight_sanctum',
    signatureHazard: 'Temporal Paradox Rifts & Shifting Elevation',
    primaryColors: {
      bg: '#171B24',
      border: '#45597D',
      accent: '#6E91D1',
      glow: '#9EBCFA',
    },
  },
  throne_beyond: {
    id: 'throne_beyond',
    regionNumber: 10,
    name: 'The Throne Beyond',
    floorRange: [91, 100],
    recommendedLevelRange: [19, 20],
    difficulty: 'Legendary',
    tagline: 'The cosmic apex where the Architect weaves destiny',
    loreDescription:
      'The ultimate summit of the Ascendant Tower. Beyond the physical sky, pure planar starlight pours across celestial dias terraces. Here, the Architect of the Shattered Oath awaits the worthy.',
    visualTheme: 'Celestial Dais & Astral Apex',
    ambientPreset: 'twilight_sanctum',
    signatureHazard: 'Planar Conduits & Cosmic Novas',
    primaryColors: {
      bg: '#211E14',
      border: '#8F7738',
      accent: '#E6C65A',
      glow: '#FFF1A8',
    },
  },
};

const REGION_KEYS: TowerRegionId[] = [
  'forgotten_threshold',
  'withered_wilds',
  'ember_foundry',
  'frozen_reliquary',
  'astral_divide',
  'drowned_kingdom',
  'crimson_covenant',
  'ashen_dominion',
  'shattered_expanse',
  'throne_beyond',
];

/**
 * 100 Unique Floor Names, matching their atmospheric region and tactical identity
 */
const TOWER_FLOOR_NAMES: string[] = [
  // Region I (1–10)
  'The Vestibule of Whispers',
  'Covenant Guardpost',
  'The Collapsed Causeway',
  'Pillars of the Sworn',
  'Gatekeeper’s Redoubt',
  'The Forgotten Relic Hall',
  'Chamber of Broken Vows',
  'The High Bastion Steps',
  'Vanguard’s Trial',
  'Sanctuary of the Unbroken Warden',
  // Region II (11–20)
  'Root-Tangled Promenade',
  'The Fungal Cloister',
  'Ironwood Canopy Perch',
  'The Bramble Choke',
  'Lair of the Briar Behemoth',
  'Petrified Sylvan Grove',
  'The Spore-Chamber',
  'Thornguard Rampart',
  'The Hollow Heartwood',
  'Grove of the Rot-Mother',
  // Region III (21–30)
  'The Smelting Trench',
  'Slag-Forged Walkway',
  'Crucible of the Ashen Spark',
  'The Cooling Vents',
  'Anvil of Cinder Primus',
  'Bellows of Hephaestus',
  'The Magma Siphon',
  'Tempered Ironworks',
  'Furnace of Eternal Embers',
  'Crucible of the Molten Heart',
  // Region IV (31–40)
  'Glacial Mirror Gate',
  'Vault of Frost-Bound Lore',
  'The Crevasse Bridges',
  'Permafrost Gallery',
  'Den of the Glacial Reaver',
  'The Ice-Spire Skerry',
  'Chamber of Rime-Carved Sins',
  'The Blizzard Rampart',
  'Frozen Tears of the Covenant',
  'Throne of the Frost Sovereign',
  // Region V (41–50)
  'The Drifted Flagstones',
  'Singularity Causeway',
  'The Gravity Bridge',
  'Planar Tear Vista',
  'Sentry-Post of the Astral Shade',
  'The Phase-Conduit Corridor',
  'Void-Strider Sanctum',
  'The Inverted Pinnacle',
  'Event Horizon Threshold',
  'Heart of the Astral Divide',
  // Region VI (51–60)
  'Sunken Atrium of Spires',
  'The Coral Causeway',
  'Drowned Archon Vault',
  'The Submerged Siphon',
  'Reef of the Abyssal Siren',
  'The Flooded Amphitheater',
  'Trench of the Sea-Serpents',
  'Cascading Water-Gate',
  'The Abyssal Trench Perch',
  'Throne of the Sunken Spires',
  // Region VII (61–70)
  'Vestment of Sanguine Vows',
  'The Blood-Well Catacombs',
  'Chamber of the Flayed Seal',
  'The Sacrificial Balcony',
  'Gallows of the Crimson Cleaver',
  'Cathedral of Scarlet Embers',
  'The Blood-Weave Altar',
  'Ramparts of the Covenant Chalice',
  'The Sanguine Bastion',
  'Sanctum of the Blood Archon',
  // Region VIII (71–80)
  'The Cratered Forecourt',
  'Barricades of the Fallen Banner',
  'The Siege Trench',
  'Catapult Redoubt',
  'Command Post of Commander Rictus',
  'The Iron Garrison',
  'Avenue of Battered Shields',
  'The Ashen Bastion Steps',
  'The Juggernaut’s Gate',
  'Fortress of the Ashen Warmaster',
  // Region IX (81–90)
  'Chasm of Unwound Seconds',
  'The Shattered Parapet',
  'Mirror-Paradox Gallery',
  'The Echo Chamber',
  'Redoubt of the Paradox Mirage',
  'Fractured Spire Bridges',
  'The Timeline Rupture',
  'Chamber of Ten Thousand Deaths',
  'The Recursion Threshold',
  'Chamber of the Fractured Timelord',
  // Region X (91–100)
  'The Celestial Staircase',
  'Planar Starlight Terrace',
  'The Pillars of Destiny',
  'The Cosmic Causeway',
  'Gate of the Seraphic Oath',
  'Apex of the Nine Realms',
  'The Consecrated Spire',
  'Chamber of Transcendent Steel',
  'The Final Threshold',
  'The Throne of the Oath Architect',
];

function getEncounterTypeForFloor(floor: number): TowerEncounterType {
  if (floor % 10 === 0) return 'boss';
  if (floor % 10 === 5) return 'mini_boss';
  if (floor % 10 === 2 || floor % 10 === 7) return 'multi_wave';
  if (floor % 10 === 4 || floor % 10 === 9) return 'survival';
  if (floor % 10 === 3) return 'destruction';
  if (floor % 10 === 8) return 'defense';
  if (floor % 10 === 6) return 'puzzle';
  return 'standard';
}

function getRecommendedLevelForFloor(floor: number): number {
  if (floor <= 10) return Math.min(4, Math.max(1, Math.ceil(floor / 2.5)));
  if (floor <= 20) return 4 + Math.floor((floor - 11) / 5) * 1;
  if (floor <= 30) return 6 + Math.floor((floor - 21) / 5) * 1;
  if (floor <= 40) return 8 + Math.floor((floor - 31) / 5) * 1;
  if (floor <= 50) return 10 + Math.floor((floor - 41) / 5) * 1;
  if (floor <= 60) return 12 + Math.floor((floor - 51) / 5) * 1;
  if (floor <= 70) return 14 + Math.floor((floor - 61) / 5) * 1;
  if (floor <= 80) return 16 + Math.floor((floor - 71) / 5) * 1;
  if (floor <= 90) return 18;
  return floor >= 98 ? 20 : 19;
}

function getDifficultyForFloor(floor: number): TowerDifficulty {
  if (floor <= 10) return 'Beginner';
  if (floor <= 20) return 'Easy';
  if (floor <= 30) return 'Moderate';
  if (floor <= 40) return 'Moderate';
  if (floor <= 50) return 'Hard';
  if (floor <= 60) return 'Hard';
  if (floor <= 70) return 'Very Hard';
  if (floor <= 80) return 'Very Hard';
  if (floor <= 90) return 'Extreme';
  return 'Legendary';
}

function buildFloorGridPreset(floor: number, regionId: TowerRegionId): TowerGridPreset {
  const elevations: Record<string, number> = {};
  const customTerrains: Record<string, 'stone' | 'moss' | 'hazard_rift' | 'pillar' | 'bastion'> = {};
  const surfaces: Record<string, any> = {};
  const unwalkableTiles: { x: number; z: number }[] = [];
  const objects: any[] = [];

  // Elevation patterns: alternate between perimeter bastions, elevated bridges, central terraces
  if (floor % 3 === 0) {
    // High-ground bastions on North and East perimeters
    for (let x = 2; x <= 7; x++) {
      elevations[`${x},1`] = 1;
      customTerrains[`${x},1`] = 'bastion';
    }
  } else if (floor % 3 === 1) {
    // Central raised dias
    for (let x = 4; x <= 5; x++) {
      for (let z = 4; z <= 5; z++) {
        elevations[`${x},${z}`] = 1;
        customTerrains[`${x},${z}`] = 'bastion';
      }
    }
  } else {
    // Elevated crosswalk
    for (let i = 2; i <= 7; i++) {
      elevations[`${i},${i}`] = 1;
      customTerrains[`${i},${i}`] = 'bastion';
    }
  }

  // Region-specific surfaces & objects
  switch (regionId) {
    case 'forgotten_threshold':
      objects.push(
        { id: `obj_barrel_${floor}_1`, name: 'Runic Oil Barrel', kind: 'oil_barrel', x: 2, z: 4, pushable: true },
        { id: `obj_brazier_${floor}_1`, name: 'Stone Brazier', kind: 'runic_brazier', x: 7, z: 4 }
      );
      surfaces['3,4'] = 'oil_pool';
      break;
    case 'withered_wilds':
      surfaces['3,3'] = 'bramble_snare';
      surfaces['6,6'] = 'bramble_snare';
      objects.push({ id: `obj_monolith_${floor}`, name: 'Ironwood Trunk', kind: 'runestone_block', x: 5, z: 3, pushable: true });
      break;
    case 'ember_foundry':
      surfaces['4,4'] = 'fire_pool';
      surfaces['5,4'] = 'oil_pool';
      objects.push(
        { id: `obj_slag_${floor}_1`, name: 'Volatile Slag Keg', kind: 'oil_barrel', x: 3, z: 5, pushable: true },
        { id: `obj_brazier_${floor}`, name: 'Foundry Furnace', kind: 'runic_brazier', x: 6, z: 5 }
      );
      break;
    case 'frozen_reliquary':
      surfaces['2,5'] = 'sanctified_pool';
      unwalkableTiles.push({ x: 4, z: 4 }, { x: 5, z: 4 });
      objects.push({ id: `obj_block_${floor}`, name: 'Glacial Monolith', kind: 'runestone_block', x: 4, z: 3, pushable: true });
      break;
    case 'astral_divide':
      customTerrains['3,3'] = 'hazard_rift';
      customTerrains['6,6'] = 'hazard_rift';
      objects.push(
        { id: `obj_runestone_${floor}_1`, name: 'Astral Seal Stone', kind: 'runestone_block', x: 2, z: 3, pushable: true },
        { id: `obj_runestone_${floor}_2`, name: 'Astral Seal Stone', kind: 'runestone_block', x: 7, z: 6, pushable: true }
      );
      break;
    case 'drowned_kingdom':
      surfaces['1,4'] = 'sanctified_pool';
      surfaces['8,4'] = 'sanctified_pool';
      objects.push({ id: `obj_pillar_${floor}`, name: 'Drowned Pillar Block', kind: 'runestone_block', x: 5, z: 2, pushable: true });
      break;
    case 'crimson_covenant':
      surfaces['4,4'] = 'oil_pool';
      surfaces['5,5'] = 'fire_pool';
      objects.push(
        { id: `obj_altar_${floor}`, name: 'Sacrificial Brazier', kind: 'runic_brazier', x: 5, z: 2 },
        { id: `obj_keg_${floor}`, name: 'Volatile Blood Vessel', kind: 'oil_barrel', x: 3, z: 6, pushable: true }
      );
      break;
    case 'ashen_dominion':
      surfaces['2,4'] = 'oil_pool';
      surfaces['7,4'] = 'fire_pool';
      objects.push(
        { id: `obj_barricade_${floor}`, name: 'Iron Siege Barricade', kind: 'runestone_block', x: 4, z: 5, pushable: true },
        { id: `obj_powder_${floor}`, name: 'Siege Gunpowder Cask', kind: 'oil_barrel', x: 6, z: 3, pushable: true }
      );
      break;
    case 'shattered_expanse':
      customTerrains['4,4'] = 'hazard_rift';
      surfaces['5,5'] = 'sanctified_pool';
      objects.push({ id: `obj_paradox_${floor}`, name: 'Paradox Pillar', kind: 'runestone_block', x: 5, z: 3, pushable: true });
      break;
    case 'throne_beyond':
      surfaces['4,4'] = 'sanctified_pool';
      surfaces['5,5'] = 'sanctified_pool';
      objects.push(
        { id: `obj_throne_brazier_1`, name: 'Celestial Flame', kind: 'runic_brazier', x: 2, z: 2 },
        { id: `obj_throne_brazier_2`, name: 'Celestial Flame', kind: 'runic_brazier', x: 7, z: 7 }
      );
      break;
  }

  return {
    elevations,
    customTerrains,
    surfaces,
    unwalkableTiles,
    objects,
  };
}

function buildFloorEnemies(floor: number, regionId: TowerRegionId): TowerEnemySlotConfig[] {
  const isBoss = floor % 10 === 0;
  const isMini = floor % 10 === 5;
  const hpScale = 1 + floor * 0.055;
  const acBase = 11 + Math.min(8, Math.floor(floor / 14));
  const initBase = 12 + Math.min(8, Math.floor(floor / 15));

  if (isBoss) {
    const bossMeta = TOWER_MAJOR_BOSSES[floor];
    const bossHp = Math.round(75 + floor * 4.2);
    return [
      {
        id: `boss_${floor}`,
        name: bossMeta.name,
        title: bossMeta.epithet,
        archetype: 'champion',
        gridX: 5,
        gridZ: 7,
        elevation: 0,
        hp: bossHp,
        maxHp: bossHp,
        armorClass: acBase + 2,
        moveRange: 4,
        ap: 3,
        initiative: initBase + 4,
        stats: { str: 16 + Math.floor(floor / 10), dex: 14, int: 14, cha: 16 },
        abilities: [
          {
            id: `boss_ability_${floor}_1`,
            name: 'Cataclysmic Strike',
            key: '1',
            apCost: 1,
            cooldown: 0,
            range: 1,
            category: 'martial_cleave',
            damageRange: [10 + Math.floor(floor / 5), 16 + Math.floor(floor / 4)],
            targetType: 'enemy',
            roleClue: 'Cleave Strike',
            description: 'Devastating boss cleave hitting adjacent foes.',
          },
          {
            id: `boss_ability_${floor}_2`,
            name: 'Arena Shockwave',
            key: '2',
            apCost: 2,
            cooldown: 2,
            range: 3,
            category: 'seismic_glaive',
            damageRange: [12 + Math.floor(floor / 4), 20 + Math.floor(floor / 3)],
            pushDistance: 2,
            targetType: 'enemy',
            roleClue: 'Shockwave Push',
            description: 'Concussive ground wave that knocks targets back 2 tiles.',
          },
        ],
        isBoss: true,
      },
      {
        id: `boss_guard_${floor}_1`,
        name: 'Ascendant Vanguard Elite',
        title: 'Floor Guardian',
        archetype: 'bruiser',
        gridX: 3,
        gridZ: 6,
        hp: Math.round(30 + floor * 1.5),
        maxHp: Math.round(30 + floor * 1.5),
        armorClass: acBase,
        moveRange: 4,
        ap: 2,
        initiative: initBase,
        stats: { str: 14, dex: 12, int: 10, cha: 10 },
        abilities: [
          {
            id: 'elite_guard_strike',
            name: 'Heavy Mace Cleave',
            key: '1',
            apCost: 1,
            cooldown: 0,
            range: 1,
            category: 'martial_cleave',
            damageRange: [8, 14],
            targetType: 'enemy',
            roleClue: 'Cleave',
            description: 'Frontline smash.',
          },
        ],
      },
      {
        id: `boss_guard_${floor}_2`,
        name: 'Ascendant Weaver Acolyte',
        title: 'Tower Spellcaster',
        archetype: 'weaver',
        gridX: 7,
        gridZ: 6,
        hp: Math.round(24 + floor * 1.2),
        maxHp: Math.round(24 + floor * 1.2),
        armorClass: acBase - 1,
        moveRange: 4,
        ap: 2,
        initiative: initBase + 2,
        stats: { str: 10, dex: 14, int: 16, cha: 12 },
        abilities: [
          {
            id: 'elite_weaver_bolt',
            name: 'Astral Shock',
            key: '1',
            apCost: 1,
            cooldown: 0,
            range: 5,
            category: 'piercing_ray',
            damageRange: [8, 13],
            targetType: 'enemy',
            roleClue: 'Ray',
            description: 'Long-range magical beam.',
          },
        ],
      },
    ];
  }

  if (isMini) {
    const miniMeta = TOWER_MINI_BOSSES[floor];
    const miniHp = Math.round(50 + floor * 2.8);
    return [
      {
        id: `miniboss_${floor}`,
        name: miniMeta.name,
        title: miniMeta.title,
        archetype: (miniMeta.archetype as any) ?? 'bruiser',
        gridX: 5,
        gridZ: 6,
        hp: miniHp,
        maxHp: miniHp,
        armorClass: acBase + 1,
        moveRange: 4,
        ap: 2,
        initiative: initBase + 2,
        stats: { str: 15, dex: 14, int: 12, cha: 12 },
        abilities: [
          {
            id: `mini_ability_${floor}`,
            name: 'Brutal Execution',
            key: '1',
            apCost: 1,
            cooldown: 0,
            range: 1,
            category: 'execution_gapcloser',
            damageRange: [9 + Math.floor(floor / 6), 15 + Math.floor(floor / 5)],
            targetType: 'enemy',
            roleClue: 'Executioner',
            description: 'Heavy single-target attack.',
          },
        ],
        isMiniBoss: true,
      },
      {
        id: `miniboss_add_${floor}_1`,
        name: `${TOWER_REGIONS[regionId].visualTheme.split(' ')[0]} Skirmisher`,
        title: 'Chamber Guard',
        archetype: 'stalker',
        gridX: 2,
        gridZ: 5,
        hp: Math.round(22 + floor * 1.1),
        maxHp: Math.round(22 + floor * 1.1),
        armorClass: acBase,
        moveRange: 5,
        ap: 2,
        initiative: initBase + 3,
        stats: { str: 12, dex: 16, int: 10, cha: 10 },
        abilities: [
          {
            id: 'skirmish_strike',
            name: 'Barbed Dagger',
            key: '1',
            apCost: 1,
            cooldown: 0,
            range: 2,
            category: 'predator_strike',
            damageRange: [7, 12],
            targetType: 'enemy',
            roleClue: 'Stab',
            description: 'Quick puncture.',
          },
        ],
      },
    ];
  }

  // Standard or Multi-Wave Floor
  const baseEnemies: TowerEnemySlotConfig[] = [
    {
      id: `enemy_${floor}_1`,
      name: `${TOWER_REGIONS[regionId].name.split(' ')[1] ?? 'Tower'} Sentry`,
      title: 'Patrol Vanguard',
      archetype: floor % 2 === 0 ? 'bruiser' : 'inquisitor',
      gridX: 3,
      gridZ: 6,
      hp: Math.round(20 * hpScale),
      maxHp: Math.round(20 * hpScale),
      armorClass: acBase,
      moveRange: 4,
      ap: 2,
      initiative: initBase,
      stats: { str: 14, dex: 12, int: 10, cha: 10 },
      abilities: [
        {
          id: 'sentry_smash',
          name: 'Vanguard Strike',
          key: '1',
          apCost: 1,
          cooldown: 0,
          range: 1,
          category: 'martial_cleave',
          damageRange: [7 + Math.floor(floor / 8), 12 + Math.floor(floor / 6)],
          targetType: 'enemy',
          roleClue: 'Frontline',
          description: 'Basic martial strike.',
        },
      ],
    },
    {
      id: `enemy_${floor}_2`,
      name: `${TOWER_REGIONS[regionId].visualTheme.split(' ')[0]} Archer`,
      title: 'Chamber Sniper',
      archetype: 'stalker',
      gridX: 7,
      gridZ: 7,
      hp: Math.round(16 * hpScale),
      maxHp: Math.round(16 * hpScale),
      armorClass: acBase - 1,
      moveRange: 4,
      ap: 2,
      initiative: initBase + 2,
      stats: { str: 10, dex: 16, int: 10, cha: 10 },
      abilities: [
        {
          id: 'sniper_shot',
          name: 'Longbow Volley',
          key: '1',
          apCost: 1,
          cooldown: 0,
          range: 5,
          category: 'deadeye_snipe',
          damageRange: [6 + Math.floor(floor / 8), 11 + Math.floor(floor / 7)],
          targetType: 'enemy',
          roleClue: 'Ranged',
          description: 'Ranged piercing shot.',
        },
      ],
    },
  ];

  if (floor > 25) {
    baseEnemies.push({
      id: `enemy_${floor}_3`,
      name: `${TOWER_REGIONS[regionId].name.split(' ')[1] ?? 'Tower'} Weaver`,
      title: 'Spell Acolyte',
      archetype: 'weaver',
      gridX: 5,
      gridZ: 8,
      hp: Math.round(18 * hpScale),
      maxHp: Math.round(18 * hpScale),
      armorClass: acBase - 1,
      moveRange: 4,
      ap: 2,
      initiative: initBase + 1,
      stats: { str: 8, dex: 12, int: 16, cha: 14 },
      abilities: [
        {
          id: 'weaver_arcane_bolt',
          name: 'Planar Spark',
          key: '1',
          apCost: 1,
          cooldown: 0,
          range: 4,
          category: 'piercing_ray',
          damageRange: [8 + Math.floor(floor / 7), 13 + Math.floor(floor / 6)],
          targetType: 'enemy',
          roleClue: 'Spell',
          description: 'Magical spark.',
        },
      ],
    });
  }

  return baseEnemies;
}

function buildFloorObjective(floor: number, encType: TowerEncounterType): TowerObjectiveConfig {
  switch (encType) {
    case 'boss':
      return {
        type: 'boss',
        title: 'Defeat the Floor Guardian',
        description: `Eliminate the region boss to break the floor's ancient seal and secure the checkpoint.`,
        targetUnitIds: [`boss_${floor}`],
      };
    case 'mini_boss':
      return {
        type: 'mini_boss',
        title: 'Defeat the Chamber Champion',
        description: 'Slay the elite champion guarding the ascent to the upper ramparts.',
        targetUnitIds: [`miniboss_${floor}`],
      };
    case 'survival':
      return {
        type: 'survival',
        title: 'Survive the Gauntlet',
        description: 'Withstand the relentless onslaught for 4 full combat rounds without total party defeat.',
        surviveRounds: 4,
      };
    case 'multi_wave':
      return {
        type: 'multi_wave',
        title: 'Repel Multiple Waves',
        description: 'Defeat the initial vanguard and survive the arrival of the secondary reinforcement wave.',
      };
    case 'defense':
      return {
        type: 'defense',
        title: 'Defend the Covenant Relic',
        description: 'Prevent enemies from destroying the sacred runestone relic located at the center.',
        defendTargetId: `obj_monolith_${floor}`,
      };
    case 'destruction':
      return {
        type: 'destruction',
        title: 'Destroy Void Pylons',
        description: 'Shatter the dark pylon structures before they channel lethal spatial surges.',
        targetEnvObjectIds: [`obj_brazier_${floor}`, `obj_slag_${floor}_1`],
      };
    case 'puzzle':
      return {
        type: 'puzzle',
        title: 'Runestone Socket Puzzle',
        description: 'Push the runestone block into the glowing sanctified socket while surviving enemy pressure.',
        puzzleSockets: [{ objId: `obj_runestone_${floor}_1`, targetX: 3, targetZ: 3 }],
      };
    case 'trial':
      return {
        type: 'trial',
        title: 'Tactical Elevation Trial',
        description: 'Defeat all enemies while utilizing elevated bastions for tactical advantage.',
      };
    default:
      return {
        type: 'standard',
        title: 'Clear the Floor',
        description: 'Defeat all hostile guardians to unlock the staircase upward.',
      };
  }
}

function buildFloorRewards(floor: number, isBoss: boolean, isMini: boolean): any {
  const baseGold = 25 + floor * 8;
  const baseXp = isBoss ? 450 + floor * 15 : isMini ? 250 + floor * 10 : 80 + floor * 6;
  const shards = isBoss ? 25 : isMini ? 12 : floor % 5 === 0 ? 8 : 4;

  const loot: string[] = [];
  if (isBoss) {
    const boss = TOWER_MAJOR_BOSSES[floor];
    if (boss?.exclusiveArtifactReward) {
      loot.push(boss.exclusiveArtifactReward.name);
    }
  } else if (isMini) {
    const mini = TOWER_MINI_BOSSES[floor];
    if (mini?.rewardItem) {
      loot.push(mini.rewardItem);
    }
  } else if (floor % 4 === 0) {
    loot.push('Greater Elixir of Restitution');
  } else if (floor % 3 === 0) {
    loot.push('Tempered Whetstone of Prowess');
  }

  return {
    firstClearXp: baseXp,
    firstClearOathShards: shards,
    gold: baseGold,
    lootItemIds: loot,
    guaranteedItemName: loot[0],
  };
}

/**
 * Generates the complete canonical database of all 100 individual floors.
 */
function generateAll100Floors(): Record<number, TowerFloorDefinition> {
  const result: Record<number, TowerFloorDefinition> = {};

  for (let floor = 1; floor <= 100; floor++) {
    const regionIndex = Math.min(9, Math.floor((floor - 1) / 10));
    const regionId = REGION_KEYS[regionIndex];
    const name = TOWER_FLOOR_NAMES[floor - 1] ?? `Floor ${floor} Ascent`;
    const difficulty = getDifficultyForFloor(floor);
    const recommendedLevel = getRecommendedLevelForFloor(floor);
    const encounterType = getEncounterTypeForFloor(floor);
    const isBoss = floor % 10 === 0;
    const isMini = floor % 10 === 5;
    const isCheckpoint = floor % 10 === 0;
    const isSanctuary = floor % 10 === 0;

    const gridPreset = buildFloorGridPreset(floor, regionId);
    const enemyFormation = buildFloorEnemies(floor, regionId);
    const objective = buildFloorObjective(floor, encounterType);
    const rewards = buildFloorRewards(floor, isBoss, isMini);

    let reinforcementWaves: any[] | undefined;
    if (encounterType === 'multi_wave') {
      reinforcementWaves = [
        {
          triggerRound: 2,
          announceMessage: 'Wave 2 Incursion: Enemy reinforcements emerge from the shadows!',
          enemies: [
            {
              id: `wave2_en_${floor}_1`,
              name: 'Reinforcement Vanguard',
              title: 'Wave 2 Bruiser',
              archetype: 'bruiser',
              gridX: 4,
              gridZ: 8,
              hp: Math.round(25 + floor * 1.2),
              maxHp: Math.round(25 + floor * 1.2),
              armorClass: 13,
              moveRange: 4,
              ap: 2,
              initiative: 14,
              stats: { str: 14, dex: 12, int: 10, cha: 10 },
              abilities: [
                {
                  id: 'wave_strike',
                  name: 'Flanking Strike',
                  key: '1',
                  apCost: 1,
                  cooldown: 0,
                  range: 1,
                  category: 'martial_cleave',
                  damageRange: [8, 13],
                  targetType: 'enemy',
                  roleClue: 'Cleave',
                  description: 'Melee assault.',
                },
              ],
            },
          ],
        },
      ];
    }

    result[floor] = {
      floorNumber: floor,
      floorId: `tower_floor_${floor}`,
      regionId,
      name,
      difficulty,
      recommendedLevel,
      encounterType,
      specialFeature: `${TOWER_REGIONS[regionId].visualTheme} — ${objective.title}`,
      objective,
      gridPreset,
      enemyFormation,
      reinforcementWaves,
      rewards,
      isBossFloor: isBoss,
      isMiniBossFloor: isMini,
      isCheckpoint,
      isSanctuary,
    };
  }

  return result;
}

export const ALL_100_TOWER_FLOORS = generateAll100Floors();
