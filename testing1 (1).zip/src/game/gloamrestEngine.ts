import {
  CharacterCreationBuild,
  CombatUnit,
  CompanionId,
  CompanionRelationship,
  DialogueChoice,
  SkillCheckResult,
  getStatModifier,
  resolveSkillCheck,
} from './rules';
import {
  GloamrestSaveState,
  PartyInventoryState,
  QuestProgressEntry,
  TimeOfDayPhase,
  TownThreatPhase,
  UnitEquippedGear,
} from './gloamrestEngineTypes';
import {
  EquipmentSlot,
  GLOAMREST_ITEMS,
  GLOAMREST_MERCHANTS,
  GLOAMREST_QUESTS,
  ItemDefinition,
  MerchantId,
  QuestId,
} from './gloamrestItemsAndQuests';
import {
  DistrictId,
  GLOAMREST_DISTRICTS,
  GLOAMREST_INTERIORS,
  InteriorId,
  TownInteractiveObject,
  TownTile,
  createInitialGloamrestObjects,
  generateGloamrestExteriorGrid,
  generateInteriorGrid,
} from './gloamrestMapAndInteriors';
import {
  GLOAMREST_NPCS,
  TownDialogueActionEffect,
  TownDialogueChoice,
  getNpcActiveSchedule,
} from './gloamrestNpcsAndDialogue';

export const GLOAMREST_STORAGE_KEY = 'dimraeth_gloamrest_state_v1';

const TIME_ORDER: TimeOfDayPhase[] = ['morning', 'afternoon', 'evening', 'night'];

export function getNextTimeOfDay(current: TimeOfDayPhase): {
  nextPhase: TimeOfDayPhase;
  wrappedNewDay: boolean;
} {
  const idx = TIME_ORDER.indexOf(current);
  const nextIdx = (idx + 1) % TIME_ORDER.length;
  return {
    nextPhase: TIME_ORDER[nextIdx],
    wrappedNewDay: nextIdx === 0,
  };
}

/**
 * Adds an item stack cleanly without duplicating item definitions.
 */
export function addInventoryItem(
  inv: PartyInventoryState,
  itemId: string,
  quantity = 1
): PartyInventoryState {
  const def = GLOAMREST_ITEMS[itemId];
  if (!def || quantity <= 0) return inv;

  const nextItems = inv.items.map((st) => ({ ...st }));
  // Equipment with durability stacks individually if maxDurability is defined, otherwise stack together
  if (def.maxDurability) {
    for (let i = 0; i < quantity; i++) {
      nextItems.push({
        itemId,
        quantity: 1,
        durability: def.maxDurability,
      });
    }
  } else {
    const existing = nextItems.find((s) => s.itemId === itemId);
    if (existing) {
      existing.quantity += quantity;
    } else {
      nextItems.push({ itemId, quantity });
    }
  }

  return {
    ...inv,
    items: nextItems,
  };
}

export function removeInventoryItem(
  inv: PartyInventoryState,
  itemId: string,
  quantity = 1
): PartyInventoryState {
  if (quantity <= 0) return inv;
  let remainingToRemove = quantity;
  const nextItems: PartyInventoryState['items'] = [];

  for (const stack of inv.items) {
    if (stack.itemId !== itemId || remainingToRemove <= 0) {
      nextItems.push({ ...stack });
      continue;
    }
    if (stack.quantity > remainingToRemove) {
      nextItems.push({ ...stack, quantity: stack.quantity - remainingToRemove });
      remainingToRemove = 0;
    } else {
      remainingToRemove -= stack.quantity;
    }
  }

  return {
    ...inv,
    items: nextItems,
  };
}

/**
 * Creates a fresh, persistent Gloamrest settlement state seeded from the player's Character Creation build.
 */
export function createInitialGloamrestState(
  characterBuild: CharacterCreationBuild
): GloamrestSaveState {
  let inventory: PartyInventoryState = {
    gold: 65,
    items: [],
    equippedByUnit: {
      seraphina: {},
      kaelen: {},
      thorne: {},
    },
  };

  // Seed starting class gear & equip on commander (`seraphina` slot holds commander build in rules.ts)
  if (characterBuild.classId === 'paladin') {
    inventory = addInventoryItem(inventory, 'ironroot_longsword', 1);
    inventory = addInventoryItem(inventory, 'oak_heater_shield', 1);
    inventory = addInventoryItem(inventory, 'frontier_brigandine', 1);
    inventory.equippedByUnit.seraphina = {
      weapon: 'ironroot_longsword',
      shield: 'oak_heater_shield',
      armor: 'frontier_brigandine',
    };
  } else if (characterBuild.classId === 'arcanist') {
    inventory = addInventoryItem(inventory, 'ashwood_focus_staff', 1);
    inventory = addInventoryItem(inventory, 'woven_ley_mantle', 1);
    inventory.equippedByUnit.seraphina = {
      weapon: 'ashwood_focus_staff',
      armor: 'woven_ley_mantle',
    };
  } else {
    inventory = addInventoryItem(inventory, 'whisperwood_recurve', 1);
    inventory = addInventoryItem(inventory, 'frontier_brigandine', 1);
    inventory.equippedByUnit.seraphina = {
      weapon: 'whisperwood_recurve',
      armor: 'frontier_brigandine',
    };
  }

  // Seed background starting trinkets/supplies
  const bg = characterBuild.backgroundId ?? 'sanctum_acolyte';
  if (bg === 'sanctum_acolyte') {
    inventory = addInventoryItem(inventory, 'consecrated_censer', 1);
    inventory.equippedByUnit.seraphina.accessory = 'consecrated_censer';
  } else if (bg === 'borderland_outrider') {
    inventory = addInventoryItem(inventory, 'wayfinder_compass', 1);
    inventory.equippedByUnit.seraphina.accessory = 'wayfinder_compass';
  } else if (bg === 'ashen_exile') {
    inventory = addInventoryItem(inventory, 'obsidian_signet', 1);
    inventory.equippedByUnit.seraphina.accessory = 'obsidian_signet';
  } else if (bg === 'court_chronicler') {
    inventory = addInventoryItem(inventory, 'archivist_folio', 1);
    inventory.equippedByUnit.seraphina.accessory = 'archivist_folio';
  } else if (bg === 'guild_artisan') {
    inventory = addInventoryItem(inventory, 'artisan_repair_kit', 1);
    inventory = addInventoryItem(inventory, 'lamp_oil_flask', 1);
  }

  // Starting healing consumables
  inventory = addInventoryItem(inventory, 'silverleaf_healing_draught', 2);
  inventory = addInventoryItem(inventory, 'wayfarer_rations', 1);

  // Initialize merchant stocks
  const merchantStocks = {} as GloamrestSaveState['merchantStocks'];
  for (const mId of Object.keys(GLOAMREST_MERCHANTS) as MerchantId[]) {
    merchantStocks[mId] = GLOAMREST_MERCHANTS[mId].initialStock.map((s) => ({
      itemId: s.itemId,
      quantity: s.quantity,
    }));
  }

  // Initialize quests (MQ01 starts active upon arrival at Gloamrest's south pilgrim gate)
  const quests = {} as Record<QuestId, QuestProgressEntry>;
  for (const qId of Object.keys(GLOAMREST_QUESTS) as QuestId[]) {
    quests[qId] = {
      questId: qId,
      status: qId === 'mq01_stranger_at_gloamrest' ? 'active' : 'not_started',
      completedStepIds: qId === 'mq01_stranger_at_gloamrest' ? ['enter_town'] : [],
    };
  }

  return {
    version: 1,
    currentSceneId: 'exterior',
    playerPos: { x: 24, z: 43 },
    playerFacingRad: Math.PI, // Facing north up Pilgrim's Causeway toward Hearth Square
    timeOfDay: 'morning',
    dayCount: 1,
    townThreatPhase: 'peaceful',
    discoveredDistricts: ['hearth_square'],
    discoveredInteriors: [],
    unlockedObjectIds: [],
    lootedOrHarvestedIds: [],
    movedObjectPositions: {},
    storyFlags: [],
    npcTrust: {},
    talkedNpcIds: [],
    inventory,
    merchantStocks,
    quests,
    activeTrackedQuestId: 'mq01_stranger_at_gloamrest',
    journalFeed: [
      `Arrived at Gloamrest along the Whispering Vale pilgrim road. Follow the cobblestones north to Hearth Square.`,
    ],
  };
}

/**
 * Computes the dynamic TownThreatPhase from persistent quest and story progression.
 */
export function deriveTownThreatPhase(state: GloamrestSaveState): TownThreatPhase {
  const mq03Done = state.quests.mq03_shadows_beyond_gate?.status === 'completed';
  const sq02Done = state.quests.sq02_echoes_beneath_well?.status === 'completed';
  const writIssued =
    state.storyFlags.includes('aldric_issued_sanctum_writ') ||
    state.storyFlags.includes('sanctum_route_unlocked');

  if (mq03Done && writIssued) return 'fortified';
  if (sq02Done) return 'astral_resonance';
  if (mq03Done) return 'uneasy';
  return 'peaceful';
}

/**
 * Completes one or more quest steps, granting quest completion rewards automatically
 * when all required (non-optional) steps of a quest are satisfied.
 */
export function applyQuestStepUpdates(
  state: GloamrestSaveState,
  stepsToComplete: { questId: QuestId; stepId: string }[],
  questsToStart: QuestId[] = []
): { nextState: GloamrestSaveState; notifications: string[] } {
  let nextQuests = { ...state.quests };
  let nextInventory = state.inventory;
  const nextFeed = [...state.journalFeed];
  const notifications: string[] = [];
  let nextTracked = state.activeTrackedQuestId;

  for (const qId of questsToStart) {
    const existing = nextQuests[qId];
    if (existing && existing.status === 'not_started') {
      nextQuests[qId] = {
        ...existing,
        status: 'active',
      };
      const def = GLOAMREST_QUESTS[qId];
      notifications.push(`New Quest Started: ${def.title}`);
      nextFeed.unshift(`[Quest Started] ${def.code} — ${def.title}`);
      if (def.kind === 'main') {
        nextTracked = qId;
      }
    }
  }

  for (const { questId, stepId } of stepsToComplete) {
    const entry = nextQuests[questId];
    const def = GLOAMREST_QUESTS[questId];
    if (!entry || !def || entry.status === 'completed') continue;

    const alreadyHad = entry.completedStepIds.includes(stepId);
    const updatedSteps = alreadyHad
      ? entry.completedStepIds
      : [...entry.completedStepIds, stepId];
    const nextStatus = entry.status === 'not_started' ? 'active' : entry.status;

    const requiredSteps = def.steps.filter((s) => !s.optional);
    const allRequiredDone = requiredSteps.every((s) => updatedSteps.includes(s.id));

    if (allRequiredDone) {
      nextQuests[questId] = {
        ...entry,
        status: 'completed',
        completedStepIds: updatedSteps,
      };
      if (def.rewards.gold > 0) {
        nextInventory = {
          ...nextInventory,
          gold: nextInventory.gold + def.rewards.gold,
        };
      }
      if (def.rewards.items) {
        for (const rewardItem of def.rewards.items) {
          nextInventory = addInventoryItem(
            nextInventory,
            rewardItem.itemId,
            rewardItem.quantity
          );
        }
      }
      notifications.push(
        `Quest Completed: ${def.title} (+${def.rewards.gold}g${
          def.rewards.unlockNote ? ` · ${def.rewards.unlockNote}` : ''
        })`
      );
      nextFeed.unshift(`[Quest Completed] ${def.title} (+${def.rewards.gold}g)`);

      // Auto-advance activeTrackedQuestId to next active main quest
      const nextMain = (Object.keys(GLOAMREST_QUESTS) as QuestId[]).find(
        (id) =>
          id !== questId &&
          GLOAMREST_QUESTS[id].kind === 'main' &&
          nextQuests[id]?.status === 'active'
      );
      if (nextMain) nextTracked = nextMain;
    } else {
      nextQuests[questId] = {
        ...entry,
        status: nextStatus,
        completedStepIds: updatedSteps,
      };
      if (!alreadyHad) {
        const stepDef = def.steps.find((s) => s.id === stepId);
        if (stepDef) {
          notifications.push(`Objective Updated: ${stepDef.label}`);
        }
      }
    }
  }

  const draft: GloamrestSaveState = {
    ...state,
    quests: nextQuests,
    inventory: nextInventory,
    activeTrackedQuestId: nextTracked,
    journalFeed: nextFeed.slice(0, 30),
  };

  return {
    nextState: {
      ...draft,
      townThreatPhase: deriveTownThreatPhase(draft),
    },
    notifications,
  };
}

/**
 * Updates player position, discovers entered districts, and triggers spatial quest steps.
 */
export function movePlayerInGloamrest(
  state: GloamrestSaveState,
  nextX: number,
  nextZ: number,
  facingRad: number,
  exteriorGrid: TownTile[][]
): { nextState: GloamrestSaveState; notifications: string[] } {
  let updated: GloamrestSaveState = {
    ...state,
    playerPos: { x: nextX, z: nextZ },
    playerFacingRad: facingRad,
  };
  const stepUpdates: { questId: QuestId; stepId: string }[] = [];

  if (state.currentSceneId === 'exterior') {
    const tile = exteriorGrid[Math.round(nextX)]?.[Math.round(nextZ)];
    const distId = tile?.districtId;
    if (distId && !updated.discoveredDistricts.includes(distId)) {
      updated = {
        ...updated,
        discoveredDistricts: [...updated.discoveredDistricts, distId],
        journalFeed: [
          `Discovered ${GLOAMREST_DISTRICTS[distId].name} (${GLOAMREST_DISTRICTS[distId].subtitle}).`,
          ...updated.journalFeed,
        ].slice(0, 30),
      };
    }

    if (
      distId === 'hearth_square' &&
      !updated.quests.mq01_stranger_at_gloamrest.completedStepIds.includes('explore_square')
    ) {
      stepUpdates.push({
        questId: 'mq01_stranger_at_gloamrest',
        stepId: 'explore_square',
      });
    }
  }

  if (stepUpdates.length > 0) {
    return applyQuestStepUpdates(updated, stepUpdates);
  }
  return { nextState: updated, notifications: [] };
}

/**
 * Returns active, visible interactive objects in the current scene with live moved positions applied.
 */
export function getSceneInteractiveObjects(
  state: GloamrestSaveState,
  allBaseObjects: TownInteractiveObject[] = createInitialGloamrestObjects()
): TownInteractiveObject[] {
  const flags = new Set(state.storyFlags);
  return allBaseObjects
    .filter((obj) => {
      if (obj.sceneId !== state.currentSceneId) return false;
      if (obj.hiddenUntilFlag && !flags.has(obj.hiddenUntilFlag)) return false;
      return true;
    })
    .map((obj) => {
      const moved = state.movedObjectPositions[obj.id];
      if (moved) {
        return { ...obj, x: moved.x, z: moved.z };
      }
      return obj;
    });
}

export interface ObjectInteractionOutcome {
  nextState: GloamrestSaveState;
  bannerMessage: string;
  lorePopup?: { title: string; text: string };
  skillCheckResult?: {
    label: string;
    result: SkillCheckResult;
  };
  healPartyFull?: boolean;
  triggerAction?:
    | 'open_notice_board'
    | 'prompt_wilderness_gate'
    | 'start_outskirts_combat'
    | 'depart_act1_sanctum';
}

/**
 * Executes meaningful interaction behavior for doors, locked entrances, chests, herbs,
 * ancient well, supply cart, movable barrels, training targets, and secret manor mechanisms.
 */
export function interactWithGloamrestObject(
  state: GloamrestSaveState,
  objectId: string,
  units: CombatUnit[],
  relationships: Record<CompanionId, CompanionRelationship>,
  exteriorGrid?: TownTile[][]
): ObjectInteractionOutcome {
  const sceneObjects = getSceneInteractiveObjects(state);
  const obj = sceneObjects.find((o) => o.id === objectId);
  if (!obj) {
    return { nextState: state, bannerMessage: 'Nothing of note here.' };
  }

  // 1. DOORS & SECRET STAIRS (Enter / Exit Building Interiors)
  if (obj.kind === 'door_enter' || obj.kind === 'door_exit' || obj.kind === 'secret_stairs') {
    const isLocked =
      Boolean(obj.lockedByDefault) && !state.unlockedObjectIds.includes(obj.id);

    if (isLocked) {
      const hasKey =
        Boolean(obj.requiredKeyItemId) &&
        state.inventory.items.some(
          (s) => s.itemId === obj.requiredKeyItemId && s.quantity > 0
        );
      if (hasKey) {
        let nextState: GloamrestSaveState = {
          ...state,
          unlockedObjectIds: [...state.unlockedObjectIds, obj.id],
          currentSceneId: obj.targetSceneId ?? state.currentSceneId,
          playerPos: obj.targetSpawn ?? state.playerPos,
        };
        if (
          obj.targetSceneId &&
          obj.targetSceneId !== 'exterior' &&
          !nextState.discoveredInteriors.includes(obj.targetSceneId)
        ) {
          nextState = {
            ...nextState,
            discoveredInteriors: [...nextState.discoveredInteriors, obj.targetSceneId],
          };
        }
        const qUpd = applyQuestStepUpdates(
          nextState,
          [{ questId: 'opt01_manor_of_shattered_vows', stepId: 'unlock_manor_door' }],
          ['opt01_manor_of_shattered_vows']
        );
        return {
          nextState: qUpd.nextState,
          bannerMessage: `Unlocked ${obj.name} using the Tarnished Veyne Manor Key and stepped inside!`,
        };
      }

      // Attempt Lockpicking D20 DEX Check if player carries Tempered Picks!
      const hasPicks = state.inventory.items.some(
        (s) => s.itemId === 'iron_lockpicks' && s.quantity > 0
      );
      if (hasPicks && obj.lockpickDc) {
        const syntheticChoice: DialogueChoice = {
          id: 'lockpick_manor',
          text: 'Pick the rusted manor lock',
          skillCheck: {
            stat: 'dex',
            skillName: 'Insight',
            dc: Math.max(8, obj.lockpickDc - 2), // +2 tool advantage via -2 effective DC
            speakerId: 'thorne',
          },
          approvalDeltas: {},
          nextNodeId: 'END_PEACEFUL_BUFF',
          outcomeSummary: 'Picked the rusted lock.',
        };
        const roll = resolveSkillCheck(syntheticChoice, units, relationships);
        if (roll.success) {
          let nextState: GloamrestSaveState = {
            ...state,
            unlockedObjectIds: [...state.unlockedObjectIds, obj.id],
            currentSceneId: obj.targetSceneId ?? state.currentSceneId,
            playerPos: obj.targetSpawn ?? state.playerPos,
          };
          if (
            obj.targetSceneId &&
            obj.targetSceneId !== 'exterior' &&
            !nextState.discoveredInteriors.includes(obj.targetSceneId)
          ) {
            nextState = {
              ...nextState,
              discoveredInteriors: [...nextState.discoveredInteriors, obj.targetSceneId],
            };
          }
          const qUpd = applyQuestStepUpdates(
            nextState,
            [{ questId: 'opt01_manor_of_shattered_vows', stepId: 'unlock_manor_door' }],
            ['opt01_manor_of_shattered_vows']
          );
          return {
            nextState: qUpd.nextState,
            bannerMessage: `Lockpick Succeeded (${roll.total} vs DC ${roll.dc})! Unbarred the Abandoned Manor.`,
            skillCheckResult: { label: 'Dexterity Lockpick Check', result: roll },
          };
        } else {
          const consumed = removeInventoryItem(state.inventory, 'iron_lockpicks', 1);
          return {
            nextState: { ...state, inventory: consumed },
            bannerMessage: `Lockpick Snapped (${roll.total} vs DC ${roll.dc})! Search the overgrown garden sundial for the Manor Key or buy more picks from Tessa Reed.`,
            skillCheckResult: { label: 'Dexterity Lockpick Check', result: roll },
          };
        }
      }

      const qStart = applyQuestStepUpdates(state, [], ['opt01_manor_of_shattered_vows']);
      return {
        nextState: qStart.nextState,
        bannerMessage:
          'Locked tight with a rusted stag-crest ward. Search the overgrown manor garden for a key, or purchase Tempered Picks from Tessa Reed.',
      };
    }

    // Unlocked Door Transition!
    const destScene = obj.targetSceneId ?? state.currentSceneId;
    const destSpawn = obj.targetSpawn ?? state.playerPos;
    let nextState: GloamrestSaveState = {
      ...state,
      currentSceneId: destScene,
      playerPos: { ...destSpawn },
    };

    if (
      destScene !== 'exterior' &&
      !nextState.discoveredInteriors.includes(destScene as InteriorId)
    ) {
      nextState = {
        ...nextState,
        discoveredInteriors: [...nextState.discoveredInteriors, destScene as InteriorId],
      };
    }

    const autoSteps: { questId: QuestId; stepId: string }[] = [];
    if (destScene === 'tavern') {
      autoSteps.push({
        questId: 'mq01_stranger_at_gloamrest',
        stepId: 'visit_tavern',
      });
    }
    const qRes = autoSteps.length > 0 ? applyQuestStepUpdates(nextState, autoSteps) : { nextState };

    const locationTitle =
      destScene === 'exterior'
        ? 'Gloamrest Settlement Exterior'
        : GLOAMREST_INTERIORS[destScene].name;

    return {
      nextState: qRes.nextState,
      bannerMessage: `Entered ${locationTitle}.`,
    };
  }

  // 2. ANCIENT SACRED STONE WELL (Hearth Square Landmark & SQ02)
  if (obj.kind === 'ancient_well') {
    const alreadyHasRubbing = state.quests.sq02_echoes_beneath_well.completedStepIds.includes(
      'discover_well_symbol'
    );
    if (!alreadyHasRubbing) {
      const invWithRubbing = addInventoryItem(
        state.inventory,
        'well_rubbing_parchment',
        1
      );
      const qUpd = applyQuestStepUpdates(
        {
          ...state,
          inventory: invWithRubbing,
          storyFlags: Array.from(new Set([...state.storyFlags, 'inspected_ancient_well'])),
        },
        [{ questId: 'sq02_echoes_beneath_well', stepId: 'discover_well_symbol' }],
        ['sq02_echoes_beneath_well']
      );
      return {
        nextState: qUpd.nextState,
        bannerMessage:
          'Faint blue starlight ripples deep inside the well! You traced a Charcoal Rubbing of a submerged Covenant rune—consult Brother Cael at the Chapel.',
        lorePopup: {
          title: 'The Sacred Spring of Hearth Square',
          text: 'Beneath twenty feet of cold spring water, an ancient silver-inlaid rune pulses with a rhythmic azure glow—accompanied by a low metallic hum resonating from the north.',
        },
      };
    }

    // If spoke with Cael or Edrin and not yet passed check, allow direct Arcana D20 check at the well!
    if (
      state.quests.sq02_echoes_beneath_well.completedStepIds.includes('speak_brother_cael') &&
      !state.quests.sq02_echoes_beneath_well.completedStepIds.includes('pass_well_check')
    ) {
      const arcanaChoice: DialogueChoice = {
        id: 'well_arcana_decipher',
        text: 'Attune to the submerged well rune',
        skillCheck: {
          stat: 'int',
          skillName: 'Arcana',
          dc: 12,
          speakerId: 'kaelen',
        },
        approvalDeltas: {},
        nextNodeId: 'END_PEACEFUL_BUFF',
        outcomeSummary: 'Deciphered the subterranean aqueduct ward.',
      };
      const roll = resolveSkillCheck(arcanaChoice, units, relationships);
      if (roll.success) {
        const qUpd = applyQuestStepUpdates(state, [
          { questId: 'sq02_echoes_beneath_well', stepId: 'find_edrin_vale' },
          { questId: 'sq02_echoes_beneath_well', stepId: 'pass_well_check' },
        ]);
        return {
          nextState: qUpd.nextState,
          bannerMessage: `Arcana Check Succeeded (${roll.total} vs DC ${roll.dc})! The rune marks an underground aqueduct running straight to the Sanctum of the Shattered Oath. Inform Brother Cael!`,
          skillCheckResult: { label: 'Arcana Check (Well Sigil)', result: roll },
        };
      }
      return {
        nextState: state,
        bannerMessage: `Arcana Check Resisted (${roll.total} vs DC ${roll.dc}). Consult Scholar Edrin Vale in the Chapel Archive to translate the cipher together!`,
        skillCheckResult: { label: 'Arcana Check (Well Sigil)', result: roll },
      };
    }

    return {
      nextState: state,
      bannerMessage:
        state.townThreatPhase === 'astral_resonance' || state.townThreatPhase === 'fortified'
          ? 'Awakened Covenant wards shimmer vividly along the well stones, resonating with the distant Sanctum.'
          : 'Cold spring water glimmers faintly below. Brother Cael and Scholar Edrin Vale study its history.',
    };
  }

  // 3. NOTICE BOARD & TOWN BELL
  if (obj.kind === 'notice_board') {
    const qUpd = applyQuestStepUpdates(
      state,
      [],
      ['mq02_trouble_at_ironroot', 'sq01_bitter_remedy', 'mq03_shadows_beyond_gate']
    );
    return {
      nextState: qUpd.nextState,
      bannerMessage:
        'Posted Notices: [Ironroot Forge] Missing ore cart outside Whispering Gate · [Green Vessel] Medicinal herbs needed · [Town Watch] Missing travelers beyond north bridge.',
      lorePopup: {
        title: 'Hearth Square Public Notice Board',
        text: '1. BY ORDER OF ELDER VEYNE: No lone travel past Whispering Gate after dusk.\n2. IRONROOT FORGE: 40g reward for recovery of meteoric ironroot ingots lost near the gate ravine.\n3. THE GREEN VESSEL: Buying fresh Silverleaf & Vale Bitterroot for fever remedies.',
      },
    };
  }

  if (obj.kind === 'town_bell') {
    return {
      nextState: state,
      bannerMessage:
        state.townThreatPhase === 'peaceful'
          ? 'The heavy bronze Watch-Bell hangs silent over Hearth Square, rung only in times of peril.'
          : 'Frost-cold vibrations hum along the bronze bell-rim whenever the northern wind blows from Whispering Vale.',
    };
  }

  // 4. HERB PATCHES & RIFT NIGHTSHADE (Gathering System)
  if (obj.kind === 'herb_patch' || obj.kind === 'blight_herb_patch') {
    if (state.lootedOrHarvestedIds.includes(obj.id)) {
      return {
        nextState: state,
        bannerMessage: `${obj.name} has already been harvested.`,
      };
    }
    const itemId = obj.gatherItemId ?? 'silverleaf_herb';
    const itemDef = GLOAMREST_ITEMS[itemId];
    const nextInv = addInventoryItem(state.inventory, itemId, 1);
    const totalMedicinalHerbs =
      (nextInv.items.find((i) => i.itemId === 'silverleaf_herb')?.quantity ?? 0) +
      (nextInv.items.find((i) => i.itemId === 'bitterroot_stalk')?.quantity ?? 0);

    const steps: { questId: QuestId; stepId: string }[] = [];
    if (totalMedicinalHerbs >= 3) {
      steps.push({ questId: 'sq01_bitter_remedy', stepId: 'gather_herbs' });
    }
    if (obj.kind === 'blight_herb_patch') {
      steps.push({ questId: 'sq01_bitter_remedy', stepId: 'inspect_blight_herb' });
    }

    const qUpd = applyQuestStepUpdates(
      {
        ...state,
        inventory: nextInv,
        lootedOrHarvestedIds: [...state.lootedOrHarvestedIds, obj.id],
      },
      steps,
      ['sq01_bitter_remedy']
    );

    return {
      nextState: qUpd.nextState,
      bannerMessage: `Harvested ${itemDef?.name ?? itemId}! (${
        obj.kind === 'blight_herb_patch'
          ? 'Strange Astral corruption warms its roots!'
          : `Medicinal herbs in pack: ${totalMedicinalHerbs}/3`
      })`,
    };
  }

  // 5. DAMAGED SUPPLY CART & ROADSIDE RAVINE CACHE (Main Quest 02)
  if (obj.kind === 'damaged_cart') {
    const qUpd = applyQuestStepUpdates(
      state,
      [{ questId: 'mq02_trouble_at_ironroot', stepId: 'inspect_cart' }],
      ['mq02_trouble_at_ironroot']
    );
    return {
      nextState: qUpd.nextState,
      bannerMessage:
        'Splintered oak axle & deep iron-heavy drag marks lead just past the Whispering Gate stone bridge to the northeast ravine (42, 3)!',
      lorePopup: {
        title: 'Garron’s Ambushed Supply Wagon',
        text: 'Claw gouges and frost-singed splinters scar the sideboards. Whoever struck the wagon ignored the driver’s coin-pouch—and the heavy crate of Meteoric Ironroot Ingots slid down into the roadside ravine just outside Whispering Gate.',
      },
    };
  }

  // 6. LOOT CHESTS, GARDEN SUNDIAL & ROADSIDE CACHE
  if (
    obj.kind === 'chest' ||
    obj.kind === 'roadside_cache' ||
    obj.kind === 'garden_crypt'
  ) {
    if (state.lootedOrHarvestedIds.includes(obj.id)) {
      return {
        nextState: state,
        bannerMessage: `${obj.name} has already been searched.`,
      };
    }

    let nextInv = {
      ...state.inventory,
      gold: state.inventory.gold + (obj.lootGold ?? 0),
    };
    const lootedNames: string[] = [];
    for (const entry of obj.lootItems ?? []) {
      nextInv = addInventoryItem(nextInv, entry.itemId, entry.quantity);
      const def = GLOAMREST_ITEMS[entry.itemId];
      lootedNames.push(
        `${entry.quantity > 1 ? `${entry.quantity}× ` : ''}${def?.name ?? entry.itemId}`
      );
    }
    if ((obj.lootGold ?? 0) > 0) {
      lootedNames.push(`${obj.lootGold} Gold`);
    }

    const steps: { questId: QuestId; stepId: string }[] = [];
    const startQ: QuestId[] = [];
    if (obj.id === 'obj_roadside_ravine_cache') {
      startQ.push('mq02_trouble_at_ironroot');
      steps.push(
        { questId: 'mq02_trouble_at_ironroot', stepId: 'travel_roadside' },
        { questId: 'mq02_trouble_at_ironroot', stepId: 'recover_ingots' }
      );
    }
    if (obj.id === 'int_basement_reliquary_chest') {
      steps.push({
        questId: 'opt01_manor_of_shattered_vows',
        stepId: 'claim_manor_relic',
      });
    }

    const qUpd = applyQuestStepUpdates(
      {
        ...state,
        inventory: nextInv,
        lootedOrHarvestedIds: [...state.lootedOrHarvestedIds, obj.id],
      },
      steps,
      startQ
    );

    return {
      nextState: qUpd.nextState,
      bannerMessage: `Searched ${obj.name}: Found ${lootedNames.join(', ')}!`,
    };
  }

  // 7. FOREST CLUES & WHISPERING GATE WILDERNESS TRANSITION
  if (obj.kind === 'forest_clues') {
    const qUpd = applyQuestStepUpdates(
      state,
      [{ questId: 'mq03_shadows_beyond_gate', stepId: 'inspect_forest_clues' }],
      ['mq03_shadows_beyond_gate']
    );
    return {
      nextState: qUpd.nextState,
      bannerMessage:
        'Examined scorched Covenant waystone & booted ambush tracks! Speak with Scout Sera Wren or step onto the Whispering Vale Road to confront the ambushers.',
      lorePopup: {
        title: 'Wilderness Clues Beyond Whispering Gate',
        text: 'Three sets of iron-shod Covenant greaves and prowling stalker tracks converge around a shattered silver waymarker. Spilled lamp-oil pools glisten across the ruined stones ahead—ideal for tactical ignition.',
      },
    };
  }

  if (obj.kind === 'wilderness_gate') {
    return {
      nextState: state,
      bannerMessage: 'Whispering Vale Road — Choose your expedition destination.',
      triggerAction: 'prompt_wilderness_gate',
    };
  }

  // 8. TRAINING DUMMY & MOVABLE BARREL (Tactical Mechanics Demonstration)
  if (obj.kind === 'training_dummy') {
    const cmd = units.find((u) => u.faction === 'party') ?? units[0];
    const strMod = cmd ? getStatModifier(cmd.stats.str) : 2;
    const roll = Math.floor(Math.random() * 20) + 1;
    const total = roll + strMod + 2; // +2 High Ground / Flanking drill demonstration
    return {
      nextState: {
        ...state,
        storyFlags: Array.from(new Set([...state.storyFlags, 'practiced_training_dummy'])),
      },
      bannerMessage: `Practice Strike on Armored Target: D20 (${roll}) + Stat (${
        strMod >= 0 ? `+${strMod}` : strMod
      }) + Flanking (+2) = ${total} vs AC 12 — Clean Hit! Speak with Captain Roderic for a live sparring bout.`,
    };
  }

  if (obj.kind === 'movable_barrel') {
    const grid = exteriorGrid ?? generateGloamrestExteriorGrid();
    const dx = Math.sign(obj.x - Math.round(state.playerPos.x)) || 1;
    const dz = Math.sign(obj.z - Math.round(state.playerPos.z));
    const candX = obj.x + dx;
    const candZ = obj.z + dz;
    if (grid[candX]?.[candZ]?.walkable) {
      return {
        nextState: {
          ...state,
          movedObjectPositions: {
            ...state.movedObjectPositions,
            [obj.id]: { x: candX, z: candZ },
          },
        },
        bannerMessage: `Shoved ${obj.name} to (${candX}, ${candZ})! In combat, shoving oil casks or runestones reshapes battlefield hazards.`,
      };
    }
    return {
      nextState: state,
      bannerMessage: `${obj.name} is wedged against timber—step to another side to shove it.`,
    };
  }

  // 9. RESTING BEDS & CHAPEL SANCTUARY FONT
  if (obj.kind === 'rest_bed') {
    if (state.inventory.gold < 10) {
      return {
        nextState: state,
        bannerMessage:
          'Renting the upstairs guest room requires 10 Gold (or pray at the Chapel of the Last Light font for free healing).',
      };
    }
    const { nextPhase, wrappedNewDay } = getNextTimeOfDay(state.timeOfDay);
    const restedState: GloamrestSaveState = {
      ...state,
      timeOfDay: nextPhase,
      dayCount: state.dayCount + (wrappedNewDay ? 1 : 0),
      inventory: {
        ...state.inventory,
        gold: state.inventory.gold - 10,
      },
    };
    const qUpd =
      restedState.quests.mq04_road_to_whispering_vale.status === 'active'
        ? applyQuestStepUpdates(restedState, [
            { questId: 'mq04_road_to_whispering_vale', stepId: 'complete_preparations' },
          ])
        : { nextState: restedState };
    return {
      nextState: qUpd.nextState,
      healPartyFull: true,
      bannerMessage: `Rested soundly in the Wandering Stag (-10g). Party HP & AP fully restored; it is now ${nextPhase.toUpperCase()}.`,
    };
  }

  if (obj.kind === 'sanctuary_altar') {
    const qUpd =
      state.quests.mq04_road_to_whispering_vale.status === 'active'
        ? applyQuestStepUpdates(state, [
            { questId: 'mq04_road_to_whispering_vale', stepId: 'complete_preparations' },
          ])
        : { nextState: state };
    return {
      nextState: qUpd.nextState,
      healPartyFull: true,
      bannerMessage:
        'Consecrated spring water from the Font of the Last Light restores your entire party to full Vitality!',
    };
  }

  // 10. LORE BOOKSHELVES, INSCRIPTIONS & SECRET MANOR MECHANISM
  if (obj.kind === 'lore_bookshelf' || obj.kind === 'covenant_inscription') {
    let baseState = state;
    if (obj.id === 'int_manor_library_books') {
      const qUpd = applyQuestStepUpdates(
        state,
        [{ questId: 'opt01_manor_of_shattered_vows', stepId: 'search_library' }],
        ['opt01_manor_of_shattered_vows']
      );
      baseState = qUpd.nextState;
    }
    return {
      nextState: baseState,
      bannerMessage: `Read ${obj.name}.`,
      lorePopup: {
        title: obj.loreTitle ?? obj.name,
        text: obj.loreText ?? 'Weathered script describes the early watch-fires of Whispering Vale.',
      },
    };
  }

  if (obj.kind === 'secret_latch') {
    if (state.storyFlags.includes('manor_basement_revealed')) {
      return {
        nextState: state,
        bannerMessage:
          'The iron stag sconce has already been rotated—the hidden stairwell to the East (11, 3) stands open!',
      };
    }
    const nextWithFlag: GloamrestSaveState = {
      ...state,
      storyFlags: [...state.storyFlags, 'manor_basement_revealed'],
    };
    const qUpd = applyQuestStepUpdates(
      nextWithFlag,
      [
        { questId: 'opt01_manor_of_shattered_vows', stepId: 'search_library' },
        { questId: 'opt01_manor_of_shattered_vows', stepId: 'open_secret_basement' },
      ],
      ['opt01_manor_of_shattered_vows']
    );
    return {
      nextState: qUpd.nextState,
      bannerMessage:
        'Counterweights groan behind the Veyne family crest! A secret flagstone stairwell opens in the northeast parlor (11, 3)!',
    };
  }

  return {
    nextState: state,
    bannerMessage: `Inspected ${obj.name}.`,
  };
}

// ============================================================================
// DIALOGUE & D20 CHECK RESOLUTION
// ============================================================================

export interface TownDialogueResolutionResult {
  nextState: GloamrestSaveState;
  replyText: string;
  skillCheckResult?: SkillCheckResult;
  approvalDeltas?: Partial<Record<CompanionId, number>>;
  oathShift?: 'Mercy' | 'Dominion' | 'Balance';
  chronicleNote?: string;
  healPartyFull?: boolean;
  openMerchantId?: MerchantId;
  triggerAction?: TownDialogueActionEffect['triggerAction'];
  closesDialogue: boolean;
  notifications: string[];
}

export function resolveTownDialogueChoice(
  state: GloamrestSaveState,
  npcId: string,
  choice: TownDialogueChoice,
  units: CombatUnit[],
  relationships: Record<CompanionId, CompanionRelationship>
): TownDialogueResolutionResult {
  let rollResult: SkillCheckResult | undefined;
  let succeeded = true;

  if (choice.skillCheck) {
    const bonusVal = choice.skillCheck.contextualBonusValue ?? 0;
    const effectiveDc = Math.max(5, choice.skillCheck.dc - bonusVal);
    const ruleChoice: DialogueChoice = {
      id: choice.id,
      text: choice.text,
      skillCheck: {
        stat: choice.skillCheck.stat,
        skillName: choice.skillCheck.skillName,
        dc: effectiveDc,
        speakerId: choice.skillCheck.speakerId,
      },
      approvalDeltas: choice.onSuccess?.approvalDeltas ?? {},
      nextNodeId: 'END_PEACEFUL_BUFF',
      outcomeSummary: choice.successReply,
    };
    rollResult = resolveSkillCheck(ruleChoice, units, relationships);
    succeeded = rollResult.success;
  }

  const effect = succeeded ? choice.onSuccess : choice.onFailure;
  let working: GloamrestSaveState = {
    ...state,
    talkedNpcIds: Array.from(new Set([...state.talkedNpcIds, npcId])),
  };

  if (effect) {
    if (effect.addFlags) {
      working = {
        ...working,
        storyFlags: Array.from(new Set([...working.storyFlags, ...effect.addFlags])),
      };
    }
    if (effect.goldDelta) {
      working = {
        ...working,
        inventory: {
          ...working.inventory,
          gold: Math.max(0, working.inventory.gold + effect.goldDelta),
        },
      };
    }
    if (effect.removeItems) {
      let inv = working.inventory;
      for (const rem of effect.removeItems) {
        inv = removeInventoryItem(inv, rem.itemId, rem.quantity);
      }
      working = { ...working, inventory: inv };
    }
    if (effect.giveItems) {
      let inv = working.inventory;
      for (const give of effect.giveItems) {
        inv = addInventoryItem(inv, give.itemId, give.quantity);
      }
      working = { ...working, inventory: inv };
    }
    if (effect.npcTrustDelta) {
      working = {
        ...working,
        npcTrust: {
          ...working.npcTrust,
          [npcId]: (working.npcTrust[npcId] ?? 50) + effect.npcTrustDelta,
        },
      };
    }
    if (effect.advanceTimePhase) {
      const { nextPhase, wrappedNewDay } = getNextTimeOfDay(working.timeOfDay);
      working = {
        ...working,
        timeOfDay: nextPhase,
        dayCount: working.dayCount + (wrappedNewDay ? 1 : 0),
      };
    }
  }

  const qRes = applyQuestStepUpdates(
    working,
    effect?.completeQuestSteps ?? [],
    effect?.startQuests ?? []
  );

  return {
    nextState: qRes.nextState,
    replyText: succeeded ? choice.successReply : choice.failureReply ?? choice.successReply,
    skillCheckResult: rollResult,
    approvalDeltas: effect?.approvalDeltas,
    oathShift: effect?.oathShift,
    chronicleNote: effect?.chronicleNote,
    healPartyFull: effect?.healPartyFull,
    openMerchantId: effect?.openMerchantId,
    triggerAction: effect?.triggerAction,
    closesDialogue: Boolean(choice.closesDialogue),
    notifications: qRes.notifications,
  };
}

// ============================================================================
// MERCHANT ECONOMY, INVENTORY EQUIPPING & COMBAT STAT INTEGRATION
// ============================================================================

export function getAvailableMerchantStock(
  state: GloamrestSaveState,
  merchantId: MerchantId
): { item: ItemDefinition; quantity: number; buyPrice: number }[] {
  const merchDef = GLOAMREST_MERCHANTS[merchantId];
  const currentStock = state.merchantStocks[merchantId] ?? [];
  const flags = new Set(state.storyFlags);

  const visible: { item: ItemDefinition; quantity: number; buyPrice: number }[] = [];
  for (const specEntry of merchDef.initialStock) {
    if (specEntry.unlockedByFlag && !flags.has(specEntry.unlockedByFlag)) continue;
    const item = GLOAMREST_ITEMS[specEntry.itemId];
    if (!item) continue;
    const liveQty =
      currentStock.find((s) => s.itemId === specEntry.itemId)?.quantity ?? 0;
    visible.push({
      item,
      quantity: liveQty,
      buyPrice: item.value,
    });
  }
  return visible;
}

export function getItemSellPrice(item: ItemDefinition): number {
  if (item.questItem || item.value <= 0) return 0;
  return Math.max(1, Math.round(item.value * 0.55));
}

export function buyFromMerchant(
  state: GloamrestSaveState,
  merchantId: MerchantId,
  itemId: string
): { nextState: GloamrestSaveState; message: string; ok: boolean } {
  const item = GLOAMREST_ITEMS[itemId];
  if (!item) return { nextState: state, message: 'Unknown item.', ok: false };

  const stockList = state.merchantStocks[merchantId] ?? [];
  const entry = stockList.find((s) => s.itemId === itemId);
  if (!entry || entry.quantity <= 0) {
    return { nextState: state, message: `${item.name} is out of stock.`, ok: false };
  }
  if (state.inventory.gold < item.value) {
    return {
      nextState: state,
      message: `Not enough gold (${item.value}g required; you carry ${state.inventory.gold}g).`,
      ok: false,
    };
  }

  const nextStocks = {
    ...state.merchantStocks,
    [merchantId]: stockList.map((s) =>
      s.itemId === itemId ? { ...s, quantity: s.quantity - 1 } : s
    ),
  };

  let nextInv = addInventoryItem(state.inventory, itemId, 1);
  nextInv = { ...nextInv, gold: nextInv.gold - item.value };

  let working: GloamrestSaveState = {
    ...state,
    inventory: nextInv,
    merchantStocks: nextStocks,
  };

  if (working.quests.mq04_road_to_whispering_vale.status === 'active') {
    working = applyQuestStepUpdates(working, [
      { questId: 'mq04_road_to_whispering_vale', stepId: 'prepare_equipment' },
    ]).nextState;
  }

  return {
    nextState: working,
    message: `Purchased ${item.name} for ${item.value}g.`,
    ok: true,
  };
}

export function sellToMerchant(
  state: GloamrestSaveState,
  merchantId: MerchantId,
  itemId: string
): { nextState: GloamrestSaveState; message: string; ok: boolean } {
  const item = GLOAMREST_ITEMS[itemId];
  if (!item || item.questItem) {
    return { nextState: state, message: 'Quest items cannot be sold.', ok: false };
  }

  // Prevent selling an item if all owned copies are currently equipped
  const ownedCount = state.inventory.items
    .filter((s) => s.itemId === itemId)
    .reduce((sum, s) => sum + s.quantity, 0);
  const equippedCount = (Object.values(state.inventory.equippedByUnit) as UnitEquippedGear[]).filter(
    (g) =>
      g.weapon === itemId ||
      g.armor === itemId ||
      g.shield === itemId ||
      g.accessory === itemId
  ).length;

  if (ownedCount <= equippedCount) {
    return {
      nextState: state,
      message: `Unequip ${item.name} before selling it.`,
      ok: false,
    };
  }

  const sellVal = getItemSellPrice(item);
  let nextInv = removeInventoryItem(state.inventory, itemId, 1);
  nextInv = { ...nextInv, gold: nextInv.gold + sellVal };

  const curStock = state.merchantStocks[merchantId] ?? [];
  const hasEntry = curStock.some((s) => s.itemId === itemId);
  const nextStocks = {
    ...state.merchantStocks,
    [merchantId]: hasEntry
      ? curStock.map((s) =>
          s.itemId === itemId ? { ...s, quantity: s.quantity + 1 } : s
        )
      : [...curStock, { itemId, quantity: 1 }],
  };

  return {
    nextState: {
      ...state,
      inventory: nextInv,
      merchantStocks: nextStocks,
    },
    message: `Sold ${item.name} for ${sellVal}g.`,
    ok: true,
  };
}

export function equipItemOnPartyMember(
  state: GloamrestSaveState,
  unitId: string,
  itemId: string
): { nextState: GloamrestSaveState; message: string; ok: boolean } {
  const item = GLOAMREST_ITEMS[itemId];
  if (!item || !item.equipSlot) {
    return { nextState: state, message: 'This item cannot be equipped.', ok: false };
  }

  const slot: EquipmentSlot = item.equipSlot;
  const currentUnitGear = state.inventory.equippedByUnit[unitId] ?? {};
  const isAlreadyEquipped = currentUnitGear[slot] === itemId;

  const nextEquippedByUnit: Record<string, UnitEquippedGear> = {
    ...state.inventory.equippedByUnit,
  };

  // If another companion was wearing this unique item and we only own 1 copy, move it cleanly
  const ownedCopies = state.inventory.items
    .filter((s) => s.itemId === itemId)
    .reduce((sum, s) => sum + s.quantity, 0);
  if (!isAlreadyEquipped && ownedCopies <= 1) {
    for (const [otherUid, gear] of Object.entries(nextEquippedByUnit)) {
      if (otherUid !== unitId && gear[slot] === itemId) {
        nextEquippedByUnit[otherUid] = { ...gear, [slot]: undefined };
      }
    }
  }

  nextEquippedByUnit[unitId] = {
    ...currentUnitGear,
    [slot]: isAlreadyEquipped ? undefined : itemId,
  };

  let working: GloamrestSaveState = {
    ...state,
    inventory: {
      ...state.inventory,
      equippedByUnit: nextEquippedByUnit,
    },
  };

  if (!isAlreadyEquipped) {
    working = applyQuestStepUpdates(working, [
      { questId: 'mq04_road_to_whispering_vale', stepId: 'prepare_equipment' },
    ]).nextState;
  }

  return {
    nextState: working,
    message: isAlreadyEquipped
      ? `Unequipped ${item.name}.`
      : `Equipped ${item.name} (${slot.toUpperCase()}).`,
    ok: true,
  };
}

/**
 * Applies equipped Gloamrest weapons, armor, shields, and accessories directly onto
 * party CombatUnit statistics without mutating enemies or breaking rules.ts formulas.
 */
export function computeUnitGearBonuses(gear?: UnitEquippedGear): {
  acBonus: number;
  maxHpBonus: number;
  damageBonus: number;
  attackBonus: number;
  statBonus: { str: number; dex: number; int: number; cha: number };
} {
  const total = {
    acBonus: 0,
    maxHpBonus: 0,
    damageBonus: 0,
    attackBonus: 0,
    statBonus: { str: 0, dex: 0, int: 0, cha: 0 },
  };
  if (!gear) return total;

  for (const itemId of [gear.weapon, gear.armor, gear.shield, gear.accessory]) {
    if (!itemId) continue;
    const def = GLOAMREST_ITEMS[itemId];
    if (!def?.stats) continue;
    total.acBonus += def.stats.acBonus ?? 0;
    total.maxHpBonus += def.stats.maxHpBonus ?? 0;
    total.damageBonus += def.stats.damageBonus ?? 0;
    total.attackBonus += def.stats.attackBonus ?? 0;
    if (def.stats.statBonus) {
      total.statBonus.str += def.stats.statBonus.str ?? 0;
      total.statBonus.dex += def.stats.statBonus.dex ?? 0;
      total.statBonus.int += def.stats.statBonus.int ?? 0;
      total.statBonus.cha += def.stats.statBonus.cha ?? 0;
    }
  }
  return total;
}

export function applyEquippedGearToPartyUnits(
  baseUnits: CombatUnit[],
  equippedByUnit: Record<string, UnitEquippedGear>
): CombatUnit[] {
  return baseUnits.map((u) => {
    if (u.faction !== 'party') return u;
    const bonus = computeUnitGearBonuses(equippedByUnit[u.id]);
    const hpRatio = u.maxHp > 0 ? u.hp / u.maxHp : 1;
    const nextMaxHp = u.maxHp + bonus.maxHpBonus;
    const nextHp = Math.min(nextMaxHp, Math.max(1, Math.round(hpRatio * nextMaxHp)));

    return {
      ...u,
      maxHp: nextMaxHp,
      hp: nextHp,
      armorClass: u.armorClass + bonus.acBonus,
      stats: {
        str: u.stats.str + bonus.statBonus.str,
        dex: u.stats.dex + bonus.statBonus.dex,
        int: u.stats.int + bonus.statBonus.int,
        cha: u.stats.cha + bonus.statBonus.cha,
      },
      abilities: u.abilities.map((ab) =>
        ab.damageRange[1] > 0 && bonus.damageBonus > 0
          ? {
              ...ab,
              damageRange: [
                ab.damageRange[0] + bonus.damageBonus,
                ab.damageRange[1] + bonus.damageBonus,
              ] as [number, number],
            }
          : ab
      ),
    };
  });
}

/**
 * Resolves the post-victory transition when returning to Gloamrest from the
 * Main Quest 03 Whispering Outskirts Tactical Combat encounter!
 */
export function completeOutskirtsWildernessEncounter(
  state: GloamrestSaveState
): { nextState: GloamrestSaveState; notifications: string[] } {
  const withFlag: GloamrestSaveState = {
    ...state,
    currentSceneId: 'exterior',
    playerPos: { x: 37, z: 9 }, // Just inside Whispering Gate upon victorious return!
    playerFacingRad: 0,
    storyFlags: Array.from(
      new Set([...state.storyFlags, 'completed_outskirts_skirmish'])
    ),
  };

  const res = applyQuestStepUpdates(
    withFlag,
    [
      { questId: 'mq03_shadows_beyond_gate', stepId: 'speak_sera' },
      { questId: 'mq03_shadows_beyond_gate', stepId: 'inspect_forest_clues' },
      { questId: 'mq03_shadows_beyond_gate', stepId: 'leave_through_gate' },
      { questId: 'mq03_shadows_beyond_gate', stepId: 'win_outskirts_combat' },
      { questId: 'mq03_shadows_beyond_gate', stepId: 'return_to_town' },
    ],
    ['mq04_road_to_whispering_vale']
  );

  return res;
}

/**
 * Checks which NPCs are currently active in `state.currentSceneId` and computes their live position
 * along their scheduled patrol/work waypoints.
 */
export function getActiveSceneNpcs(
  state: GloamrestSaveState,
  walkTick = 0
): {
  npc: (typeof GLOAMREST_NPCS)[number];
  x: number;
  z: number;
  activityLabel: string;
}[] {
  const active: {
    npc: (typeof GLOAMREST_NPCS)[number];
    x: number;
    z: number;
    activityLabel: string;
  }[] = [];

  for (let i = 0; i < GLOAMREST_NPCS.length; i++) {
    const npc = GLOAMREST_NPCS[i];
    const slot = getNpcActiveSchedule(npc, state.timeOfDay, state.townThreatPhase);
    if (slot.sceneId !== state.currentSceneId) continue;
    const pts = slot.waypoints;
    const wp =
      pts.length > 1 ? pts[(walkTick + i) % pts.length] : pts[0] ?? { x: 24, z: 26 };
    active.push({
      npc,
      x: wp.x,
      z: wp.z,
      activityLabel: slot.activityLabel,
    });
  }

  return active;
}

export function saveGloamrestStateToStorage(state: GloamrestSaveState) {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(GLOAMREST_STORAGE_KEY, JSON.stringify(state));
  } catch {
    // Ignore storage errors
  }
}

export function loadGloamrestStateFromStorage(): GloamrestSaveState | null {
  if (typeof window === 'undefined') return null;
  try {
    const raw = window.localStorage.getItem(GLOAMREST_STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as GloamrestSaveState;
    if (parsed && parsed.version === 1 && parsed.quests && parsed.inventory) {
      return parsed;
    }
    return null;
  } catch {
    return null;
  }
}

export function useConsumableFromInventory(
  state: GloamrestSaveState,
  itemId: string,
  targetUnitId: string,
  units: CombatUnit[]
): {
  nextState: GloamrestSaveState;
  updatedUnits: CombatUnit[];
  message: string;
  ok: boolean;
} {
  const item = GLOAMREST_ITEMS[itemId];
  if (!item || item.category !== 'consumable' || !item.consumableEffect) {
    return {
      nextState: state,
      updatedUnits: units,
      message: 'This item cannot be consumed.',
      ok: false,
    };
  }
  const hasStack = state.inventory.items.some(
    (s) => s.itemId === itemId && s.quantity > 0
  );
  if (!hasStack) {
    return {
      nextState: state,
      updatedUnits: units,
      message: `No ${item.name} remaining.`,
      ok: false,
    };
  }

  const eff = item.consumableEffect;
  const nextUnits = units.map((u) => {
    if (u.faction !== 'party') return u;
    if (!eff.partyWide && u.id !== targetUnitId) return u;
    const nextHp = Math.min(u.maxHp, u.hp + (eff.healHp ?? 0));
    const nextTemp = Math.max(u.tempHp, eff.grantTempHp ?? 0);
    const nextStatuses = eff.cleanseDebuffs
      ? u.statuses.filter(
          (s) => s.type !== 'burning' && s.type !== 'rooted' && s.type !== 'sundered'
        )
      : u.statuses;
    return {
      ...u,
      hp: nextHp,
      tempHp: nextTemp,
      isKO: nextHp <= 0,
      statuses: nextStatuses,
    };
  });

  const nextInv = removeInventoryItem(state.inventory, itemId, 1);
  return {
    nextState: {
      ...state,
      inventory: nextInv,
    },
    updatedUnits: nextUnits,
    message: eff.partyWide
      ? `Used ${item.name}: Restored party vitality!`
      : `Used ${item.name}!`,
    ok: true,
  };
}

export function repairPartyEquipment(
  state: GloamrestSaveState,
  repairFee = 8
): { nextState: GloamrestSaveState; message: string; ok: boolean } {
  const hasKit = state.inventory.items.some(
    (s) => s.itemId === 'artisan_repair_kit' && s.quantity > 0
  );

  if (!hasKit && state.inventory.gold < repairFee) {
    return {
      nextState: state,
      message: `Repairing equipment requires ${repairFee}g or a Smith’s Repair Kit.`,
      ok: false,
    };
  }

  let nextInv = hasKit
    ? removeInventoryItem(state.inventory, 'artisan_repair_kit', 1)
    : { ...state.inventory, gold: state.inventory.gold - repairFee };

  nextInv = {
    ...nextInv,
    items: nextInv.items.map((st) => {
      const def = GLOAMREST_ITEMS[st.itemId];
      if (def?.maxDurability) {
        return { ...st, durability: def.maxDurability };
      }
      return st;
    }),
  };

  return {
    nextState: {
      ...state,
      inventory: nextInv,
    },
    message: hasKit
      ? 'Used Smith’s Whetting & Repair Kit — all equipment honed to 100% durability!'
      : `Garron Holt tempered and repaired all party equipment (${repairFee}g).`,
    ok: true,
  };
}

export function getActiveGridForScene(sceneId: GloamrestSaveState['currentSceneId']): TownTile[][] {
  if (sceneId === 'exterior') {
    return generateGloamrestExteriorGrid();
  }
  return generateInteriorGrid(sceneId);
}
