import {
  CharacterRaceId,
  CharacterClassId,
  CharacterSubclassId,
  CompanionId,
  CompanionRelationship,
  WorldReactivityState,
} from './rules';
import { ArchetypeClassId } from '../components/CharacterPixelPreviewCanvas';
import { PersistentCharacterConfiguration } from './characterCreationData';
import {
  CharacterProgressionState,
  migrateLegacySkillId,
  sanitizeEquippedSkills,
} from './progressionData';

export const SAVE_STORAGE_KEY = 'fantasy_rpg_save_slots_v1';

export interface SavedAdventureSlot {
  id: string;
  commanderName: string;
  level: number;
  raceId: CharacterRaceId;
  classId: CharacterClassId;
  subclassId: CharacterSubclassId;
  archetypeClass?: ArchetypeClassId;
  backgroundId?: string;
  allocatedStats?: { str: number; dex: number; int: number; cha: number };
  originChoice: 'Mercy' | 'Dominion' | 'Balance';
  stageId: number;
  playtime: string;
  saveDate: string;
  timestamp: number;
  fullConfig?: PersistentCharacterConfiguration;
  inGloamrest?: boolean;
  locationLabel?: string;
  gloamrestState?: GloamrestSaveState;
  savedWorldState?: WorldReactivityState;
  savedRelationships?: Record<CompanionId, CompanionRelationship>;
  progressionState?: CharacterProgressionState;
  towerState?: TowerProgressionState;
}

export const DEFAULT_SAMPLE_SAVES: SavedAdventureSlot[] = [
  {
    id: 'slot-1',
    commanderName: 'Seraphina Vane',
    level: 4,
    raceId: 'half_elf',
    classId: 'paladin',
    subclassId: 'dawn_warden',
    archetypeClass: 'paladin',
    backgroundId: 'sanctum_acolyte',
    originChoice: 'Mercy',
    stageId: 1,
    playtime: '06h 42m',
    saveDate: '2026-10-31 21:18',
    timestamp: 1793456280000,
  },
  {
    id: 'slot-2',
    commanderName: 'Mordecai Ashveil',
    level: 3,
    raceId: 'tiefling',
    classId: 'arcanist',
    subclassId: 'crimson_savant',
    archetypeClass: 'mage',
    backgroundId: 'ashen_exile',
    originChoice: 'Dominion',
    stageId: 0,
    playtime: '03h 15m',
    saveDate: '2026-10-29 19:04',
    timestamp: 1793275440000,
  },
];

export function loadSavedSlots(): SavedAdventureSlot[] {
  try {
    const raw = window.localStorage.getItem(SAVE_STORAGE_KEY);
    if (!raw) return DEFAULT_SAMPLE_SAVES;
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return DEFAULT_SAMPLE_SAVES;

    // Migrate any legacy skill IDs in saved progressionState
    return parsed.map((slot: SavedAdventureSlot) => {
      if (!slot.progressionState) return slot;
      const prog = slot.progressionState;
      const cleanLearned = prog.learnedSkillIds.map((id) =>
        migrateLegacySkillId(id)
      );
      const cleanEquipped = sanitizeEquippedSkills(prog.equippedSkillIds);
      return {
        ...slot,
        progressionState: {
          ...prog,
          learnedSkillIds: cleanLearned,
          equippedSkillIds: cleanEquipped,
        },
      };
    });
  } catch {
    return DEFAULT_SAMPLE_SAVES;
  }
}

export function persistSavedSlots(slots: SavedAdventureSlot[]) {
  try {
    window.localStorage.setItem(SAVE_STORAGE_KEY, JSON.stringify(slots));
  } catch {
    // Ignore storage quota errors
  }
}

export function upsertAdventureSaveSlot(slot: SavedAdventureSlot): void {
  const existing = loadSavedSlots().filter((s) => s.id !== slot.id);
  const next = [slot, ...existing].slice(0, 6);
  persistSavedSlots(next);
}
