import {
  Ability,
  AbilityAoeShape,
  AbilityCategory,
  CHARACTER_CLASSES,
  CHARACTER_SUBCLASSES,
  CharacterClassId,
  CharacterCreationBuild,
  CharacterSubclassId,
  CombatUnit,
  CompanionId,
  CompanionRelationship,
  GridTile,
  GRID_SIZE,
  TacticalEnvObject,
  WorldReactivityState,
  applyCharacterBuildToParty,
  buildUnitInspectProfile,
  createEncounterUnits,
  createInitialRelationships,
  getStatusEffectTooltipData,
  isLastStandConditionMet,
  manhattanDistance,
} from './rules';

export type SkillSlotVisualState =
  | 'selected'
  | 'locked'
  | 'cooldown'
  | 'insufficient_ap'
  | 'out_of_range'
  | 'disabled'
  | 'available';

export interface SkillSlotEvaluation {
  state: SkillSlotVisualState;
  canSelect: boolean;
  canActivate: boolean;
  cooldownRemaining: number;
  apShortfall: number;
  hasTargetInRange: boolean;
  nearestValidDistance: number | null;
  statusBadgeLabel: string;
  restrictionReason: string | null;
}

export type SkillMenuCategoryId =
  | 'all'
  | 'equipped'
  | 'attacks'
  | 'defenses'
  | 'control'
  | 'mobility'
  | 'support'
  | 'subclass'
  | 'passive';

export interface SkillMenuCategoryOption {
  id: SkillMenuCategoryId;
  label: string;
  count: number;
}

export interface UnitSkillCatalogEntry {
  ability: Ability;
  classId: CharacterClassId;
  className: string;
  subclassId?: CharacterSubclassId;
  subclassName?: string;
  primaryCategoryLabel: 'Attack' | 'Defense' | 'Control' | 'Mobility' | 'Support';
  specialtyLabel: string;
  categories: SkillMenuCategoryId[];
  equippedSlotKey: '1' | '2' | '3' | '4' | null;
  isLocked: boolean;
  unlockRequirement?: string;
}

export interface SkillStatPropertyRow {
  label: string;
  value: string;
  tone?: 'gold' | 'positive' | 'danger' | 'neutral';
}

export interface SkillEffectRow {
  id: string;
  kind: 'damage' | 'heal' | 'shield' | 'movement' | 'cleanse' | 'mechanic' | 'status';
  title: string;
  detail: string;
  statusType?: 'blessed' | 'burning' | 'rooted' | 'sundered' | 'warded';
  durationLabel?: string;
}

export interface SkillTacticalGuide {
  whenToUse: string;
  bestTargets: string;
  positioningAndTerrain: string;
  limitations: string;
}

export interface SkillDetailViewModel {
  entry: UnitSkillCatalogEntry;
  slotEvaluation: SkillSlotEvaluation;
  flavorText: string;
  mechanicalDescription: string;
  combatStats: SkillStatPropertyRow[];
  effects: SkillEffectRow[];
  tacticalUse: SkillTacticalGuide;
}

const SPECIALTY_LABELS: Record<AbilityCategory, string> = {
  martial_cleave: 'Martial Cleave',
  consecration_judgment: 'Solar Consecration',
  execution_gapcloser: 'Execution Smite',
  cleansing_mend: 'Sanctified Triage',
  bastion_aura: 'Bastion Phalanx',
  piercing_ray: 'Piercing Starlight',
  pyromantic_detonation: 'Pyromantic Blast',
  spacetime_implosion: 'Chrono Singularity',
  telekinetic_tether: 'Gravity Control',
  phase_transfusion: 'Ley-Line Conduit',
  deadeye_snipe: 'Precision Longshot',
  predator_strike: 'Sylvan Spear-Strike',
  briar_barricade: 'Briar Barricade',
  seismic_glaive: 'Ironbough Shockwave',
  trap_snare: 'Choke-Point Snare',
  evasive_barrage: 'Evasive Volley',
  barkskin_poultice: 'Vale Poultice',
  enemy_maneuver: 'Adversary Technique',
  control: 'Crowd Control & Shackle',
  support: 'Tactical Support & Utility',
};

const AOE_SHAPE_LABELS: Partial<Record<AbilityAoeShape, string>> = {
  sweeping_arc: 'Sweeping Vanguard Arc (Primary + Mutual Adjacent)',
  solar_cross: '5-Tile Cruciform Cross',
  bastion_aura: 'Radius-2 Squad Aura',
  piercing_ray: 'Linear Ray (Pierces 2 Tiles Behind)',
  chebyshev_3x3: '3×3 Chebyshev Blast',
  vacuum_implosion: 'Radius-2 Gravitational Vacuum',
  tether_pull: '1-Tile Caster Tether',
  briar_wall_3: '3-Tile Perpendicular Briar Wall',
  shockwave_ring: 'Orthogonal Seismic Ring',
  trap_tile: '1-Tile Persistent Snare',
};

const SKILL_FLAVOR_TEXT: Record<string, string> = {
  sunblade_cleave:
    'Even after an oath is fractured, tempered covenant steel remembers the warmth of first dawn.',
  dawnbreaker_judgment:
    'A solemn decree etched in zenith sunlight, turning corrupted stone into a sanctuary for the faithful.',
  searing_smite:
    'Forsaking mercy, the knight channels broken vows into a single falling star of judgment.',
  lay_on_hands:
    'A quiet invocation of golden grace that burns away venom, flame, and iron-shattering curses alike.',
  aegis_bulwark:
    'When the shield wall locks, one bearer’s resolve becomes armor for every comrade at their shoulder.',
  astral_bolt:
    'Drawn from cold constellations beyond the Rift, the lance passes through flesh and plate without slowing.',
  astral_soul_blade:
    'Neither wholly steel nor wholly spell, its edge leaves a ribbon of burning starlight across the stones.',
  crimson_tempest:
    'Forbidden Blood-Weave runes spiral inward until the air itself ignites in a roaring crimson vortex.',
  searing_blood_nova:
    'The Savant’s signature cataclysm—unleashing stored vital heat in an inescapable three-by-three furnace.',
  chrono_rift_collapse:
    'Time buckles around a fractured chronometer shard, dragging nearby foes toward the silent epicenter.',
  gravity_shackle:
    'Invisible chains of bent weight hook high-ground archers and haul them crashing down to earth.',
  arcane_conduit:
    'A surge of raw ley-line current threads beneath an ally’s boots, carrying them effortlessly into position.',
  heartseeker_shot:
    'Loosed from a six-foot ironwood bow, the shaft accelerates as it crosses the open killing ground.',
  briarfang_strike:
    'Where armor cracks or roots entangle, the Warden’s barbed spear finds the gap with lethal certainty.',
  heart_briar_volley:
    'A single whistling shaft splits mid-flight, seeding an instant palisade of iron-hard thorns.',
  ironwood_tempest:
    'Carved from ancient Vale heartwood, the glaive’s impact hardens the bearer’s stance like living bark.',
  bramble_snare:
    'Dormant Vale seeds burst through flagstone seams the instant an enemy boot crosses the choke point.',
  viper_twinshot:
    'Two ember-tipped shafts fly forward on the same breath that carries the archer safely out of reach.',
  warden_salve:
    'Crushed silver-moss and ironwood resin cool seared flesh while binding cracked plates tighter than steel.',
  inquisitor_mace:
    'Weighted obsidian flanges designed by the Silver Covenant to buckle shields in a single overhead blow.',
  void_barrage:
    'Jagged splinters of the Astral Rift hurled from elevated sanctuaries to bathe the valley in flame.',
  shadow_lunge:
    'Twin dusk-forged blades that strike hardest when the quarry is already bleeding or off-balance.',
  sundering_strike:
    'Forged to split heavy covenant plate, the downward arc finds the weakest seam in any shield.',
  guarded_stance:
    'An old frontier drill: plant the rear boot in stone, lock the greatshield, and let the storm break against iron.',
  whirlwind_assault:
    'When surrounded in the breach, a seasoned vanguard turns the weight of their own steel into a perimeter of blades.',
  driving_assault:
    'Full plate in motion becomes a battering ram—shattering frontlines before a single sword is drawn.',
  weapon_parry:
    'True mastery of heavy steel lies not only in the swing, but in the angled crossguard that turns a killing blow aside.',
  crippling_blow:
    'A calculated low sweep across greave and tendon that strips even the fastest stalker of their stride.',
  unbreakable_resolve:
    'Even when iron cracks under strain, riveted bands of sheer will hold the warrior’s heart together.',
  earthsplitter:
    'Driven point-first into flagstone, the blade sends a jagged tremor racing down the corridor.',
  relentless_pursuit:
    'No archer outruns a vanguard who has locked eyes across the ashes of the field.',
  iron_reprisal:
    'Every dent hammered into the breastplate is a debt repaid in full upon the next swing.',
  battlefield_commander:
    'One raised standard above the din turns scattered survivors back into an unbroken regiment.',
  last_stand:
    'One blade planted upright in the ruin—a silent vow that this ground will not be yielded while breath remains.',
};

const SKILL_TACTICAL_GUIDES: Record<string, SkillTacticalGuide> = {
  sunblade_cleave: {
    whenToUse: 'Use as an efficient 1 AP frontline strike when two enemies stand adjacent to both you and each other.',
    bestTargets: 'Clustered Inquisitors and Stalkers, or flammable oil pools and pushable braziers.',
    positioningAndTerrain: 'Align your attack vector to shove foes into walls (+4 DMG), Astral Rifts, or off High Ground; ignites connected oil slicks.',
    limitations: 'Short Range 2 reach; secondary arc damage only triggers on enemies touching both caster and primary target.',
  },
  dawnbreaker_judgment: {
    whenToUse: 'Commit 2 AP when a frontline ally is trading blows next to a high-AC enemy or standing on corrupted ground.',
    bestTargets: 'High-AC Inquisitors engaged near wounded party frontliners.',
    positioningAndTerrain: 'Consecrates a 5-tile (+) cross into Sanctified Ground, sealing Astral Rifts and extinguishing fire pools while healing allies in the cross.',
    limitations: 'Costs 2 AP with a 2-turn cooldown; Range 3 requires mid-frontline positioning.',
  },
  searing_smite: {
    whenToUse: 'Hold until a dangerous adversary drops to 50% HP or lower to trigger +6 Execution damage and refund +1 AP on a kill.',
    bestTargets: 'Wounded Inquisitors or isolated backline Weavers within 2 tiles.',
    positioningAndTerrain: 'Automatically leaps into an open adjacent melee tile from Range 2 and purifies corrupted surfaces beneath the target.',
    limitations: '2 AP cost and 2-turn cooldown; gap-close leap is prevented if the Paladin is Rooted.',
  },
  lay_on_hands: {
    whenToUse: 'Cast immediately when a teammate is crippled by Sundered (-2 AC), Rooted (0 Move), or Burning (-3 HP/turn).',
    bestTargets: 'Afflicted or low-HP party companions within 4 tiles (including self).',
    positioningAndTerrain: 'Transforms the target’s tile into a Sanctified Pool (+4 HP & Blessed on entry) and seals Astral Rifts.',
    limitations: '2-turn cooldown; single-target heal does not shield adjacent allies.',
  },
  aegis_bulwark: {
    whenToUse: 'Activate before absorbing a telegraphed enemy burst or when two companions stand within 2 tiles of you.',
    bestTargets: 'Self and squadmates grouped within a 2-tile phalanx radius.',
    positioningAndTerrain: 'Grants +8 Self Temp HP, +2 AC (Warded), and +4 Temp HP + Burn extinguish to allies within 2 tiles.',
    limitations: '2-turn cooldown; squad barrier requires teammates to stay within 2 tiles.',
  },
  astral_bolt: {
    whenToUse: 'Fire down straight rows or columns when a secondary foe stands 1–2 tiles directly behind your primary target.',
    bestTargets: 'Backline Weavers sheltering behind frontline Inquisitors.',
    positioningAndTerrain: 'Gain High Ground (+2 Hit / +2 DMG) on bastion ledges; shoves primary target 1 tile and can push Runestone Blocks.',
    limitations: 'Piercing ray strictly follows cardinal/diagonal alignment behind the primary target.',
  },
  astral_soul_blade: {
    whenToUse: 'Use at mid-range (4 tiles) to pierce lined-up enemies while simultaneously igniting oil slicks behind the vanguard.',
    bestTargets: 'Grouped melee rushers and targets standing in front of oil pools or volatile casks.',
    positioningAndTerrain: 'Combines linear ray piercing with Fire surface ignition and 1-tile knockback.',
    limitations: 'Shorter Range 4 than Astral Lance, requiring closer skirmish spacing.',
  },
  crimson_tempest: {
    whenToUse: 'Detonate on tightly packed enemies—especially after priming the primary target with Burning for +5 Thermal Resonance.',
    bestTargets: 'Clustered enemy squads and targets standing near Oil Barrels or Braziers.',
    positioningAndTerrain: 'Hits a full 3×3 Chebyshev square (up to 9 tiles), chain-igniting oil pools and detonating explosive objects.',
    limitations: 'Costs 2 AP and enters a 2-turn cooldown; avoid igniting oil beneath your own frontline.',
  },
  searing_blood_nova: {
    whenToUse: 'Unleash as your primary 2 AP AoE nuke once enemies are vacuumed together or afflicted with Burning.',
    bestTargets: 'Burning bosses, clustered frontline packs, and explosive barrel formations.',
    positioningAndTerrain: 'Maximizes output from High Ground (+2 Hit / +2 DMG) and triggers +5 Thermal Resonance on Burning foes.',
    limitations: 'High 2 AP commitment and 2-turn cooldown leave no AP for follow-up casts without prior setup.',
  },
  chrono_rift_collapse: {
    whenToUse: 'Cast first in a round to drag scattered enemies inward into a tight cluster for allied AoE follow-ups.',
    bestTargets: 'Spread-out Stalkers and Weavers within 2 tiles of the chosen epicenter.',
    positioningAndTerrain: 'Pulls enemies within Radius 2 one tile toward the target and Roots the epicenter target.',
    limitations: '2 AP cost and 2-turn cooldown; pulled enemies stop if an obstacle blocks the inward tile.',
  },
  gravity_shackle: {
    whenToUse: 'Use for 1 AP to yank an elevated enemy caster off High Ground or immobilize a rushing Stalker.',
    bestTargets: 'High-Ground Weavers (triggers +4 Drop Shear DMG) and mobile melee flankers.',
    positioningAndTerrain: 'Pulls target 1 tile toward the Arcanist; pulling onto an Astral Rift or off elevation deals +4 bonus Arcane DMG.',
    limitations: '2-turn cooldown; single-target control.',
  },
  arcane_conduit: {
    whenToUse: 'Cast on an ally who has already moved this turn so they immediately gain a second full Movement Phase.',
    bestTargets: 'Melee vanguards needing gap-close reach or trapped allies held by Rooted / Bramble Snares.',
    positioningAndTerrain: 'Breaks Rooted, clears underfoot bramble/rift hazards, weaves +5 Temp HP, and grants Blessed (+2 Hit).',
    limitations: '2-turn cooldown; refreshes Movement Phase rather than Action Points.',
  },
  heartseeker_shot: {
    whenToUse: 'Maintain 4 to 6 tiles of separation from your target to trigger the +3 Deadeye Sniper damage bonus.',
    bestTargets: 'Exposed backline Weavers and approaching Stalkers across open sightlines.',
    positioningAndTerrain: 'Stacks Deadeye (+3 DMG at ≥4 tiles) with High Ground (+2 Hit / +2 DMG) and 1-tile knockback.',
    limitations: 'Loses the +3 Deadeye bonus if enemies close within 3 tiles.',
  },
  briarfang_strike: {
    whenToUse: 'Strike immediately after an enemy is Rooted or Sundered to trigger +4 Predator Exploit damage.',
    bestTargets: 'Rooted Stalkers or Sundered Inquisitors within 3 tiles.',
    positioningAndTerrain: 'Sprouts a Bramble Snare beneath the target without pushing them out of existing AoE zones.',
    limitations: 'Range 3 skirmish reach; requires pre-existing Rooted or Sundered status for peak damage.',
  },
  heart_briar_volley: {
    whenToUse: 'Target an enemy with no adjacent allies for +5 Isolated Ambush damage, or seal a 3-tile corridor with thorns.',
    bestTargets: 'Isolated High-Ground Weavers or lone flanking Stalkers.',
    positioningAndTerrain: 'Grows a 3-tile perpendicular wall of Bramble Snares across the target tile to block enemy pursuit.',
    limitations: '2 AP cost and 2-turn cooldown; +5 Ambush bonus does not apply if another enemy stands adjacent.',
  },
  ironwood_tempest: {
    whenToUse: 'Wade into close quarters to strike a primary foe, shockwave orthogonal enemies, and fortify yourself in one move.',
    bestTargets: 'Frontline melee packs surrounding bastion chokepoints.',
    positioningAndTerrain: 'Grants self Warded (+2 AC) and +5 Temp HP while dealing 5 Nature DMG to orthogonally adjacent foes.',
    limitations: 'Range 2 melee-skirmish reach and 2 AP cost (2-turn cooldown).',
  },
  bramble_snare: {
    whenToUse: 'Fire directly at an approaching rusher to Root them, or target an empty walkable tile to pre-mine a choke point.',
    bestTargets: 'Fast Stalkers, narrow stairways, and bastion approaches.',
    positioningAndTerrain: 'Creates a persistent Bramble Snare surface (3 Nature DMG + Rooted when stepped on).',
    limitations: '2-turn cooldown; non-walkable pillars cannot hold snares.',
  },
  viper_twinshot: {
    whenToUse: 'Use when a melee enemy closes in—shred their armor (-2 AC) while automatically vaulting 1 tile backward to safety.',
    bestTargets: 'Armored Inquisitors (Sundered -2 AC) and aggressive flankers; also ignites oil pools.',
    positioningAndTerrain: 'Automatically repositions the Warden 1 tile further from the target onto an open walkable tile.',
    limitations: 'Costs 2 AP (2-turn cooldown); the 1-tile backstep is blocked if the Warden is Rooted or backed against a wall.',
  },
  warden_salve: {
    whenToUse: 'Apply to a frontline tank suffering from Sundered (-2 AC) or Burning—delivering a +4 net AC swing via Warded (+2 AC).',
    bestTargets: 'Armor-shredded or burning party frontliners within 4 tiles.',
    positioningAndTerrain: 'Neutralizes Fire Pools, Oil Pools, and Astral Rifts under the ally into safe verdant moss.',
    limitations: '2-turn cooldown; cleanses Burning and Sundered (use Dawnlight Mending or Weave Transfusion to cleanse Rooted).',
  },
  sundering_strike: {
    whenToUse: 'Open every duel against high-AC frontline knights with Sundering Strike to drop their Armor Class by 2.',
    bestTargets: 'High-defense Inquisitors, Bastion Juggernauts, and bosses.',
    positioningAndTerrain: 'Adjacent melee reach (Range 1); deals +3 bonus cleave damage if the target is already Sundered.',
    limitations: 'Single-target melee reach; enemies with Sundered immunity take full damage but resist the AC penalty.',
  },
  guarded_stance: {
    whenToUse: 'Activate before ending your turn in a choke point or when an enemy telegraphs a heavy physical blow.',
    bestTargets: 'Self (frontline anchor posture).',
    positioningAndTerrain: 'Grants Warded (+2 AC), +6 Temp HP, 25% physical damage reduction, and immunity to forced knockback/pulls.',
    limitations: 'Reduces movement range by -1 while active; re-activating refreshes duration rather than stacking.',
  },
  whirlwind_assault: {
    whenToUse: 'Trigger when 2 or more enemies surround your tile to cleave all adjacent foes simultaneously.',
    bestTargets: 'Clustered melee rushers and flanking Stalkers within 1 tile.',
    positioningAndTerrain: 'Hits all enemies within Chebyshev distance 1 once each with zero friendly fire while holding your current tile.',
    limitations: 'Costs 2 AP with a 2-turn cooldown; does not move the Warrior or displace targets.',
  },
  driving_assault: {
    whenToUse: 'Use to close a 2–3 tile gap in a straight rush while shoving the target 2 tiles backward into walls or hazards.',
    bestTargets: 'Enemies positioned in front of stone pillars, walls, fire pools, or Astral Rifts.',
    positioningAndTerrain: 'Moves Warrior adjacent to the first enemy struck and pushes them 2 tiles back (+4 impact DMG on wall collision).',
    limitations: 'Cannot be used while Rooted; enemies with Displacement Immunity or Guarded Stance resist the knockback.',
  },
  weapon_parry: {
    whenToUse: 'Prepare when an adjacent melee enemy or boss is telegraphing a physical strike against you.',
    bestTargets: 'Self (defensive melee reaction).',
    positioningAndTerrain: 'Grants +8 Temp HP, Warded (+2 AC), and deflects the next qualifying melee attack while dealing 8 Counter DMG.',
    limitations: 'Only parries melee attacks (range <= 2); cannot parry ranged projectiles or area explosions.',
  },
  crippling_blow: {
    whenToUse: 'Strike high-mobility skirmishers or fleeing ranged units to lock their movement at 0 for 2 turns.',
    bestTargets: 'Fast Stalkers, Wind-Runners, and kiting Weavers.',
    positioningAndTerrain: 'Adjacent melee cut that inflicts Rooted (0 Movement) for 2 turns.',
    limitations: 'Enemies with Rooted/movement-impairment immunity still take full damage but are not immobilized.',
  },
  unbreakable_resolve: {
    whenToUse: 'Use immediately when afflicted by Rooted, Burning, or Sundered to cleanse all debuffs and gain a 12 Temp HP buffer.',
    bestTargets: 'Self (emergency endurance brace).',
    positioningAndTerrain: 'Clears Burning, Rooted, and Sundered in place so you can resume charging or holding the line.',
    limitations: '3-turn cooldown; refreshes Temp HP buffer up to 12 rather than stacking indefinitely.',
  },
  earthsplitter: {
    whenToUse: 'Align yourself with 2 or 3 enemies in a straight directional line to fracture the stone beneath all of them.',
    bestTargets: 'Lined-up frontline and backline enemies within 3 tiles.',
    positioningAndTerrain: 'Projects a 3-tile linear ground fissure that deals physical damage and Sunders (-2 AC) every enemy on the line.',
    limitations: '2 AP cost and 3-turn cooldown; the ground fissure stops immediately if blocked by an impassable stone pillar.',
  },
  relentless_pursuit: {
    whenToUse: 'Pursue a distant enemy up to 4 tiles away to close into melee and strike without knocking them away.',
    bestTargets: 'Backline ranged Weavers and bloodied enemies (<=40% HP refunds +1 AP).',
    positioningAndTerrain: 'Moves Warrior along an open path to an adjacent tile and executes a controlled follow-up slash.',
    limitations: 'Cannot be used while Rooted or if no open walkable tile exists adjacent to the target.',
  },
  iron_reprisal: {
    whenToUse: 'Unleash after absorbing enemy hits to deal +6 bonus vengeance damage and arm a 1-round melee counter-strike.',
    bestTargets: 'Aggressive melee duelists and bosses trading blows with the Warrior.',
    positioningAndTerrain: 'Deals heavy melee damage (+6 bonus if wounded/struck) and retaliates once for 9 DMG when hit in melee.',
    limitations: '2 AP cost and 3-turn cooldown; counter-retaliation triggers once per qualifying melee hit with no recursive loops.',
  },
  battlefield_commander: {
    whenToUse: 'Activate when your companions are within 4 tiles to grant the entire squad +10 Temp HP and Blessed (+2 Hit).',
    bestTargets: 'Self and all conscious party allies within a 4-tile command radius.',
    positioningAndTerrain: 'Radius-4 leadership aura that coordinates frontline and backline companions simultaneously.',
    limitations: '2 AP cost and 4-turn cooldown; allies beyond 4 tiles or incapacitated (KO) do not receive the buff.',
  },
  last_stand: {
    whenToUse: 'Trigger in a dire emergency when at <=45% HP, surrounded by 2+ enemies, or standing as the last conscious party member.',
    bestTargets: 'Self (critical survival defiance).',
    positioningAndTerrain: 'Grants +20 Temp HP, Warded (+2 AC), and prevents your HP from dropping below 1 for 2 turns.',
    limitations: 'Requires a critical survival condition and can only be activated once per combat encounter.',
  },
};

export function getUnitClassIdentity(
  unit: CombatUnit,
  characterBuild?: CharacterCreationBuild
): {
  classId: CharacterClassId;
  className: string;
  shortClassName: string;
  subclassId: CharacterSubclassId;
  subclassName: string;
  shortSubclassName: string;
} {
  if (unit.id === 'seraphina' && characterBuild) {
    const classDef = CHARACTER_CLASSES[characterBuild.classId] ?? CHARACTER_CLASSES.paladin;
    const validSubId = classDef.subclasses.includes(characterBuild.subclassId)
      ? characterBuild.subclassId
      : classDef.subclasses[0];
    const subDef = CHARACTER_SUBCLASSES[validSubId];
    return {
      classId: classDef.id,
      className: classDef.name,
      shortClassName:
        classDef.id === 'paladin'
          ? 'Paladin'
          : classDef.id === 'arcanist'
          ? 'Arcanist'
          : 'Warden',
      subclassId: subDef.id,
      subclassName: subDef.name,
      shortSubclassName: subDef.titleSuffix,
    };
  }

  if (unit.companionId === 'kaelen' || unit.title.toLowerCase().includes('arcanist') || unit.title.toLowerCase().includes('chronomancer')) {
    const subId: CharacterSubclassId = unit.title.toLowerCase().includes('chronomancer')
      ? 'rift_chronomancer'
      : 'crimson_savant';
    const subDef = CHARACTER_SUBCLASSES[subId];
    return {
      classId: 'arcanist',
      className: CHARACTER_CLASSES.arcanist.name,
      shortClassName: 'Arcanist',
      subclassId: subId,
      subclassName: subDef.name,
      shortSubclassName: subDef.titleSuffix,
    };
  }

  if (unit.companionId === 'thorne' || unit.title.toLowerCase().includes('warden') || unit.title.toLowerCase().includes('stalker') || unit.title.toLowerCase().includes('sentinel')) {
    if (unit.faction === 'party') {
      const subId: CharacterSubclassId = unit.title.toLowerCase().includes('ironbough')
        ? 'ironbough_sentinel'
        : 'briar_stalker';
      const subDef = CHARACTER_SUBCLASSES[subId];
      return {
        classId: 'warden',
        className: CHARACTER_CLASSES.warden.name,
        shortClassName: 'Warden',
        subclassId: subId,
        subclassName: subDef.name,
        shortSubclassName: subDef.titleSuffix,
      };
    }
  }

  const palSubId: CharacterSubclassId = unit.title.toLowerCase().includes('dawn warden')
    ? 'dawn_warden'
    : 'vengeance_knight';
  const palSub = CHARACTER_SUBCLASSES[palSubId];
  return {
    classId: 'paladin',
    className: CHARACTER_CLASSES.paladin.name,
    shortClassName: 'Paladin',
    subclassId: palSubId,
    subclassName: palSub.name,
    shortSubclassName: palSub.titleSuffix,
  };
}

function deriveSkillCategories(
  ability: Ability,
  isEquipped: boolean,
  isSubclassSkill: boolean
): {
  primaryCategoryLabel: 'Attack' | 'Defense' | 'Control' | 'Mobility' | 'Support';
  categories: SkillMenuCategoryId[];
} {
  const cats = new Set<SkillMenuCategoryId>(['all']);
  if (isEquipped) cats.add('equipped');
  if (isSubclassSkill) cats.add('subclass');

  let primary: 'Attack' | 'Defense' | 'Control' | 'Mobility' | 'Support' = 'Attack';

  if (
    ability.id === 'aegis_bulwark' ||
    ability.id === 'guarded_stance' ||
    ability.id === 'weapon_parry' ||
    ability.id === 'unbreakable_resolve' ||
    ability.id === 'last_stand'
  ) {
    primary = 'Defense';
    cats.add('defenses');
    if (ability.id === 'aegis_bulwark' || ability.id === 'unbreakable_resolve') {
      cats.add('support');
    }
  } else if (ability.id === 'ironwood_tempest' || ability.id === 'iron_reprisal') {
    primary = 'Defense';
    cats.add('defenses');
    cats.add('attacks');
  } else if (ability.id === 'lay_on_hands' || ability.id === 'battlefield_commander') {
    primary = 'Support';
    cats.add('support');
  } else if (ability.id === 'warden_salve') {
    primary = 'Support';
    cats.add('support');
    cats.add('defenses');
  } else if (ability.id === 'arcane_conduit') {
    primary = 'Mobility';
    cats.add('mobility');
    cats.add('support');
  } else if (
    ability.id === 'viper_twinshot' ||
    ability.id === 'driving_assault' ||
    ability.id === 'relentless_pursuit'
  ) {
    primary = 'Mobility';
    cats.add('mobility');
    cats.add('attacks');
  } else if (
    ability.id === 'gravity_shackle' ||
    ability.id === 'chrono_rift_collapse' ||
    ability.id === 'bramble_snare' ||
    ability.id === 'crippling_blow'
  ) {
    primary = 'Control';
    cats.add('control');
    if (ability.id === 'crippling_blow') cats.add('attacks');
  } else {
    primary = 'Attack';
    cats.add('attacks');
    if (ability.selfReposition) cats.add('mobility');
    if (
      ability.id === 'briarfang_strike' ||
      ability.id === 'heart_briar_volley' ||
      ability.id === 'sundering_strike' ||
      ability.id === 'earthsplitter'
    ) {
      cats.add('control');
    }
    if (ability.id === 'dawnbreaker_judgment') {
      cats.add('support');
    }
  }

  return {
    primaryCategoryLabel: primary,
    categories: Array.from(cats),
  };
}

/**
 * Evaluates the exact live combat state of a skill slot or card:
 * AVAILABLE | SELECTED | INSUFFICIENT AP | COOLDOWN | LOCKED | OUT OF RANGE | DISABLED
 */
export function evaluateSkillSlotState(
  unit: CombatUnit,
  ability: Ability,
  allUnits: CombatUnit[],
  grid: GridTile[][],
  envObjects: TacticalEnvObject[],
  options?: {
    isSelected?: boolean;
    isLocked?: boolean;
    unlockRequirement?: string;
  }
): SkillSlotEvaluation {
  const cdRem = unit.cooldowns[ability.id] ?? 0;
  const apShortfall = Math.max(0, ability.apCost - unit.ap);

  if (options?.isLocked) {
    const req = options.unlockRequirement ?? 'Locked by current subclass oath.';
    return {
      state: 'locked',
      canSelect: false,
      canActivate: false,
      cooldownRemaining: cdRem,
      apShortfall,
      hasTargetInRange: false,
      nearestValidDistance: null,
      statusBadgeLabel: 'LOCKED',
      restrictionReason: req,
    };
  }

  if (unit.isKO || unit.faction !== 'party') {
    return {
      state: 'disabled',
      canSelect: false,
      canActivate: false,
      cooldownRemaining: cdRem,
      apShortfall,
      hasTargetInRange: false,
      nearestValidDistance: null,
      statusBadgeLabel: 'DISABLED',
      restrictionReason: unit.isKO
        ? 'Character is incapacitated (0 HP).'
        : 'Cannot command skills during an adversary turn.',
    };
  }

  if (cdRem > 0) {
    return {
      state: 'cooldown',
      canSelect: false,
      canActivate: false,
      cooldownRemaining: cdRem,
      apShortfall,
      hasTargetInRange: false,
      nearestValidDistance: null,
      statusBadgeLabel: `CD ${cdRem}T`,
      restrictionReason: `Cooling down — ready in ${cdRem} ${cdRem === 1 ? 'turn' : 'turns'}.`,
    };
  }

  if (apShortfall > 0) {
    return {
      state: 'insufficient_ap',
      canSelect: false,
      canActivate: false,
      cooldownRemaining: 0,
      apShortfall,
      hasTargetInRange: false,
      nearestValidDistance: null,
      statusBadgeLabel: 'LOW AP',
      restrictionReason: `Insufficient Action Points: requires ${ability.apCost} AP (${unit.ap} AP remaining).`,
    };
  }

  if (ability.id === 'last_stand') {
    const cond = isLastStandConditionMet(unit, allUnits);
    if (!cond.allowed) {
      return {
        state: 'disabled',
        canSelect: false,
        canActivate: false,
        cooldownRemaining: 0,
        apShortfall: 0,
        hasTargetInRange: false,
        nearestValidDistance: 0,
        statusBadgeLabel: unit.usedLastStand ? 'SPENT' : 'CONDITION',
        restrictionReason: cond.reason,
      };
    }
  }

  if (
    (ability.id === 'driving_assault' || ability.id === 'relentless_pursuit') &&
    unit.statuses.some((s) => s.type === 'rooted') &&
    manhattanDistance(
      unit.gridX,
      unit.gridZ,
      allUnits.find((u) => !u.isKO && u.faction === 'enemy')?.gridX ?? unit.gridX,
      allUnits.find((u) => !u.isKO && u.faction === 'enemy')?.gridZ ?? unit.gridZ
    ) > 1
  ) {
    return {
      state: 'disabled',
      canSelect: false,
      canActivate: false,
      cooldownRemaining: 0,
      apShortfall: 0,
      hasTargetInRange: false,
      nearestValidDistance: null,
      statusBadgeLabel: 'ROOTED',
      restrictionReason: `Cannot execute ${ability.name} movement while Rooted (cleanse with Unbreakable Resolve first).`,
    };
  }

  // Compute target / environmental range reachability
  let hasTargetInRange = false;
  let nearestEnemyDist: number | null = null;

  if (ability.targetType === 'self') {
    hasTargetInRange = true;
    nearestEnemyDist = 0;
  } else if (ability.targetType === 'ally') {
    const partyDistances = allUnits
      .filter((u) => !u.isKO && u.faction === 'party')
      .map((u) => manhattanDistance(unit.gridX, unit.gridZ, u.gridX, u.gridZ));
    const minAlly = partyDistances.length > 0 ? Math.min(...partyDistances) : null;
    nearestEnemyDist = minAlly;
    hasTargetInRange = minAlly !== null && minAlly <= ability.range;
  } else {
    const enemyDistances = allUnits
      .filter((u) => !u.isKO && u.faction === 'enemy')
      .map((u) => manhattanDistance(unit.gridX, unit.gridZ, u.gridX, u.gridZ));
    nearestEnemyDist = enemyDistances.length > 0 ? Math.min(...enemyDistances) : null;
    const enemyInRange = nearestEnemyDist !== null && nearestEnemyDist <= ability.range;

    let envTargetInRange = false;
    if (ability.id === 'bramble_snare') {
      // Trap skill can target any walkable tile within range
      for (let x = 0; x < GRID_SIZE && !envTargetInRange; x++) {
        for (let z = 0; z < GRID_SIZE && !envTargetInRange; z++) {
          if (
            grid[x]?.[z]?.walkable &&
            manhattanDistance(unit.gridX, unit.gridZ, x, z) <= ability.range
          ) {
            envTargetInRange = true;
          }
        }
      }
    } else {
      const isFire = ability.element === 'fire' || ability.statusEffect === 'burning';
      const isRadiant = ability.element === 'radiant';
      const canPush = (ability.pushDistance ?? 0) > 0;

      for (const obj of envObjects) {
        if (obj.destroyed) continue;
        const d = manhattanDistance(unit.gridX, unit.gridZ, obj.gridX, obj.gridZ);
        if (d <= ability.range) {
          if (
            (isFire && (obj.kind === 'oil_barrel' || obj.kind === 'runic_brazier')) ||
            (canPush && obj.pushable)
          ) {
            envTargetInRange = true;
            break;
          }
        }
      }

      if (!envTargetInRange && (isFire || isRadiant)) {
        for (let x = 0; x < GRID_SIZE && !envTargetInRange; x++) {
          for (let z = 0; z < GRID_SIZE && !envTargetInRange; z++) {
            const tile = grid[x]?.[z];
            if (!tile || !tile.walkable) continue;
            const d = manhattanDistance(unit.gridX, unit.gridZ, x, z);
            if (d > ability.range) continue;
            if (isFire && tile.surface === 'oil_pool') envTargetInRange = true;
            if (
              isRadiant &&
              (tile.surface === 'oil_pool' ||
                tile.surface === 'fire_pool' ||
                tile.terrain === 'hazard_rift')
            ) {
              envTargetInRange = true;
            }
          }
        }
      }
    }

    hasTargetInRange = enemyInRange || envTargetInRange;
  }

  if (options?.isSelected) {
    return {
      state: 'selected',
      canSelect: true,
      canActivate: hasTargetInRange,
      cooldownRemaining: 0,
      apShortfall: 0,
      hasTargetInRange,
      nearestValidDistance: nearestEnemyDist,
      statusBadgeLabel: 'SELECTED',
      restrictionReason: hasTargetInRange
        ? null
        : `No valid target within Range ${ability.range}${
            nearestEnemyDist !== null ? ` (nearest enemy is ${nearestEnemyDist} tiles away)` : ''
          }. Move closer before striking.`,
    };
  }

  if (!hasTargetInRange) {
    return {
      state: 'out_of_range',
      canSelect: true,
      canActivate: false,
      cooldownRemaining: 0,
      apShortfall: 0,
      hasTargetInRange: false,
      nearestValidDistance: nearestEnemyDist,
      statusBadgeLabel: 'OUT OF RANGE',
      restrictionReason: `No valid target within Range ${ability.range}${
        nearestEnemyDist !== null ? ` (nearest enemy: ${nearestEnemyDist} tiles)` : ''
      }. Move closer first, or click to preview range.`,
    };
  }

  return {
    state: 'available',
    canSelect: true,
    canActivate: true,
    cooldownRemaining: 0,
    apShortfall: 0,
    hasTargetInRange: true,
    nearestValidDistance: nearestEnemyDist,
    statusBadgeLabel: 'AVAILABLE',
    restrictionReason: null,
  };
}

/**
 * Builds the canonical, zero-duplicate skill catalog for a unit directly from the
 * existing combat engine definitions in rules.ts.
 */
export function getUnitSkillCatalog(
  unit: CombatUnit,
  worldState: WorldReactivityState,
  characterBuild?: CharacterCreationBuild
): UnitSkillCatalogEntry[] {
  const identity = getUnitClassIdentity(unit, characterBuild);
  const baseTemplateUnits = createEncounterUnits(0, worldState);
  const rels = createInitialRelationships();

  const equippedBySkillId = new Map<string, '1' | '2' | '3' | '4'>();
  const equippedSkillMap = new Map<string, Ability>();
  for (const ab of unit.abilities) {
    equippedBySkillId.set(ab.id, ab.key);
    equippedSkillMap.set(ab.id, ab);
  }

  // Collect canonical class abilities from rules.ts templates
  const poolMap = new Map<
    string,
    {
      ability: Ability;
      subclassId?: CharacterSubclassId;
      isLocked: boolean;
      unlockRequirement?: string;
    }
  >();

  const registerAbility = (
    ab: Ability,
    meta?: {
      subclassId?: CharacterSubclassId;
      isLocked?: boolean;
      unlockRequirement?: string;
    }
  ) => {
    const liveEquipped = equippedSkillMap.get(ab.id);
    const resolvedAbility = liveEquipped ? { ...liveEquipped } : { ...ab };
    const existing = poolMap.get(ab.id);
    if (!existing) {
      poolMap.set(ab.id, {
        ability: resolvedAbility,
        subclassId: meta?.subclassId,
        isLocked: Boolean(meta?.isLocked) && !liveEquipped,
        unlockRequirement: meta?.unlockRequirement,
      });
    }
  };

  if (unit.faction !== 'party') {
    for (const ab of unit.abilities) {
      registerAbility(ab);
    }
  } else if (identity.classId === 'paladin') {
    const seraTemplate = baseTemplateUnits.find((u) => u.id === 'seraphina')!;
    // Slot 1 core cleave
    const cleave = seraTemplate.abilities.find((a) => a.id === 'sunblade_cleave');
    if (cleave) registerAbility(cleave);

    // Active subclass signature first (unlocked), then opposing subclass signature (locked)
    const palSubIds: CharacterSubclassId[] = ['dawn_warden', 'vengeance_knight'];
    const orderedSubs = [
      identity.subclassId,
      ...palSubIds.filter((id) => id !== identity.subclassId),
    ];
    for (const subId of orderedSubs) {
      const subOpt = CHARACTER_SUBCLASSES[subId];
      const isCurrentSub = subId === identity.subclassId;
      registerAbility(subOpt.signatureAbility, {
        subclassId: subId,
        isLocked: !isCurrentSub,
        unlockRequirement: !isCurrentSub ? `Requires ${subOpt.name} Subclass` : undefined,
      });
    }

    // Core support & defense
    const mend = seraTemplate.abilities.find((a) => a.id === 'lay_on_hands');
    const aegis = seraTemplate.abilities.find((a) => a.id === 'aegis_bulwark');
    if (mend) registerAbility(mend);
    if (aegis) registerAbility(aegis);
  } else if (identity.classId === 'arcanist') {
    const kaelenTemplate = baseTemplateUnits.find((u) => u.id === 'kaelen')!;
    const arcCmd = applyCharacterBuildToParty(baseTemplateUnits, rels, {
      commanderName: unit.name,
      raceId: 'tiefling',
      classId: 'arcanist',
      subclassId: identity.subclassId,
    }).units.find((u) => u.id === 'seraphina')!;

    // Core Arcanist attacks (`astral_bolt`, `astral_soul_blade`, `crimson_tempest`)
    const lance = kaelenTemplate.abilities.find((a) => a.id === 'astral_bolt');
    const soulBlade = arcCmd.abilities.find((a) => a.id === 'astral_soul_blade');
    const tempest = kaelenTemplate.abilities.find((a) => a.id === 'crimson_tempest');
    if (lance) registerAbility(lance);
    if (soulBlade) registerAbility(soulBlade);
    if (tempest) registerAbility(tempest);

    // Subclass signatures (`searing_blood_nova`, `chrono_rift_collapse`)
    const arcSubIds: CharacterSubclassId[] = ['crimson_savant', 'rift_chronomancer'];
    const orderedSubs = [
      identity.subclassId,
      ...arcSubIds.filter((id) => id !== identity.subclassId),
    ];
    for (const subId of orderedSubs) {
      const subOpt = CHARACTER_SUBCLASSES[subId];
      const isCurrentSub = subId === identity.subclassId;
      registerAbility(subOpt.signatureAbility, {
        subclassId: subId,
        isLocked: !isCurrentSub,
        unlockRequirement: !isCurrentSub ? `Requires ${subOpt.name} Subclass` : undefined,
      });
    }

    // Core Arcanist control & mobility/support
    const shackle = kaelenTemplate.abilities.find((a) => a.id === 'gravity_shackle');
    const conduit = kaelenTemplate.abilities.find((a) => a.id === 'arcane_conduit');
    if (shackle) registerAbility(shackle);
    if (conduit) registerAbility(conduit);
  } else {
    // Sylvan Warden
    const thorneTemplate = baseTemplateUnits.find((u) => u.id === 'thorne')!;
    const warCmd = applyCharacterBuildToParty(baseTemplateUnits, rels, {
      commanderName: unit.name,
      raceId: 'wood_kin',
      classId: 'warden',
      subclassId: identity.subclassId,
    }).units.find((u) => u.id === 'seraphina')!;

    const heartseeker = thorneTemplate.abilities.find((a) => a.id === 'heartseeker_shot');
    const briarfang = warCmd.abilities.find((a) => a.id === 'briarfang_strike');
    const snare = thorneTemplate.abilities.find((a) => a.id === 'bramble_snare');
    if (heartseeker) registerAbility(heartseeker);
    if (briarfang) registerAbility(briarfang);
    if (snare) registerAbility(snare);

    const warSubIds: CharacterSubclassId[] = ['briar_stalker', 'ironbough_sentinel'];
    const orderedSubs = [
      identity.subclassId,
      ...warSubIds.filter((id) => id !== identity.subclassId),
    ];
    for (const subId of orderedSubs) {
      const subOpt = CHARACTER_SUBCLASSES[subId];
      const isCurrentSub = subId === identity.subclassId;
      registerAbility(subOpt.signatureAbility, {
        subclassId: subId,
        isLocked: !isCurrentSub,
        unlockRequirement: !isCurrentSub ? `Requires ${subOpt.name} Subclass` : undefined,
      });
    }

    const twinshot = thorneTemplate.abilities.find((a) => a.id === 'viper_twinshot');
    const salve = thorneTemplate.abilities.find((a) => a.id === 'warden_salve');
    if (twinshot) registerAbility(twinshot);
    if (salve) registerAbility(salve);
  }

  // Ensure any custom equipped ability on the unit is always included
  for (const ab of unit.abilities) {
    registerAbility(ab);
  }

  const catalog: UnitSkillCatalogEntry[] = [];
  for (const item of poolMap.values()) {
    const equippedSlotKey = equippedBySkillId.get(item.ability.id) ?? null;
    const isSubclassSkill = Boolean(item.subclassId);
    const { primaryCategoryLabel, categories } = deriveSkillCategories(
      item.ability,
      equippedSlotKey !== null,
      isSubclassSkill
    );
    const subDef = item.subclassId ? CHARACTER_SUBCLASSES[item.subclassId] : undefined;
    catalog.push({
      ability: item.ability,
      classId: identity.classId,
      className: identity.className,
      subclassId: item.subclassId,
      subclassName: subDef?.name,
      primaryCategoryLabel,
      specialtyLabel: item.ability.category
        ? SPECIALTY_LABELS[item.ability.category]
        : primaryCategoryLabel,
      categories,
      equippedSlotKey,
      isLocked: item.isLocked,
      unlockRequirement: item.unlockRequirement,
    });
  }

  return catalog;
}

const ALL_CATEGORY_DEFINITIONS: { id: SkillMenuCategoryId; label: string }[] = [
  { id: 'all', label: 'All Skills' },
  { id: 'equipped', label: 'Equipped' },
  { id: 'attacks', label: 'Attacks' },
  { id: 'defenses', label: 'Defenses' },
  { id: 'control', label: 'Control' },
  { id: 'mobility', label: 'Mobility' },
  { id: 'support', label: 'Support' },
  { id: 'subclass', label: 'Subclass Skills' },
  { id: 'passive', label: 'Passive Abilities' },
];

/**
 * Returns only categories that actually contain relevant skills for the character.
 */
export function getAvailableSkillCategories(
  catalog: UnitSkillCatalogEntry[]
): SkillMenuCategoryOption[] {
  return ALL_CATEGORY_DEFINITIONS.map((def) => ({
    id: def.id,
    label: def.label,
    count: catalog.filter((entry) => entry.categories.includes(def.id)).length,
  })).filter((cat) => cat.count > 0);
}

/**
 * Builds the complete Part 5 Skill Detail ViewModel directly from rules.ts combat data.
 */
export function buildSkillDetailViewModel(
  unit: CombatUnit,
  entry: UnitSkillCatalogEntry,
  allUnits: CombatUnit[],
  relationships: Record<CompanionId, CompanionRelationship>,
  worldState: WorldReactivityState,
  grid: GridTile[][],
  envObjects: TacticalEnvObject[],
  selectedAbilityKey?: '1' | '2' | '3' | '4' | null
): SkillDetailViewModel {
  const { ability } = entry;
  const slotEvaluation = evaluateSkillSlotState(unit, ability, allUnits, grid, envObjects, {
    isSelected: entry.equippedSlotKey !== null && selectedAbilityKey === entry.equippedSlotKey,
    isLocked: entry.isLocked,
    unlockRequirement: entry.unlockRequirement,
  });

  // Compute live combat profile using a synthetic unit copy that includes this ability so unequipped skills also get exact live scaling!
  const unitWithAbility: CombatUnit = unit.abilities.some((a) => a.id === ability.id)
    ? unit
    : { ...unit, abilities: [...unit.abilities, ability] };
  const inspectProfile = buildUnitInspectProfile(unitWithAbility, relationships, worldState);
  const inspectedAb = inspectProfile.abilities.find((a) => a.id === ability.id);

  // Applicable Combat Information Table (Part 5C)
  const combatStats: SkillStatPropertyRow[] = [
    {
      label: 'AP Cost',
      value: `${ability.apCost} AP`,
      tone: slotEvaluation.state === 'insufficient_ap' ? 'danger' : 'gold',
    },
    {
      label: 'Cooldown',
      value:
        ability.cooldown > 0
          ? slotEvaluation.cooldownRemaining > 0
            ? `${ability.cooldown} Turns (${slotEvaluation.cooldownRemaining}t remaining)`
            : `${ability.cooldown} Turns`
          : 'None (At-Will)',
      tone: slotEvaluation.cooldownRemaining > 0 ? 'danger' : 'neutral',
    },
    {
      label: 'Range',
      value:
        ability.targetType === 'self'
          ? 'Self'
          : `${ability.range} ${ability.range === 1 ? 'Tile' : 'Tiles'}`,
      tone: slotEvaluation.state === 'out_of_range' ? 'danger' : 'neutral',
    },
    {
      label: 'Target',
      value:
        ability.targetType === 'self'
          ? (ability.allyAuraTempHp ?? 0) > 0
            ? 'Self & Nearby Allies'
            : 'Self'
          : ability.targetType === 'ally'
          ? 'Party Ally (or Self)'
          : ability.id === 'bramble_snare'
          ? 'Enemy or Empty Tile'
          : ability.element === 'fire' || (ability.pushDistance ?? 0) > 0
          ? 'Enemies & Battlefield Objects'
          : 'Enemies',
    },
  ];

  if (ability.aoeShape && ability.aoeShape !== 'single' && AOE_SHAPE_LABELS[ability.aoeShape]) {
    combatStats.push({
      label: 'Area',
      value: AOE_SHAPE_LABELS[ability.aoeShape]!,
    });
  }

  if (ability.damageRange[1] > 0 && inspectedAb) {
    combatStats.push({
      label: 'Damage',
      value: `${inspectedAb.effectiveOutputLabel} (${inspectedAb.diceFormula})`,
      tone: 'gold',
    });
  }

  if ((ability.healAmount ?? 0) > 0 && inspectedAb) {
    combatStats.push({
      label: 'Healing',
      value: `${inspectedAb.effectiveOutputLabel} (${inspectedAb.diceFormula})`,
      tone: 'positive',
    });
  }

  if ((ability.grantTempHp ?? 0) > 0) {
    combatStats.push({
      label: 'Barrier',
      value:
        (ability.allyAuraTempHp ?? 0) > 0
          ? `+${ability.grantTempHp} Self Temp HP · +${ability.allyAuraTempHp} Squad Temp HP`
          : `+${ability.grantTempHp} Temporary HP`,
      tone: 'positive',
    });
  }

  combatStats.push({
    label: 'Scaling',
    value:
      ability.targetType === 'ally' || ability.targetType === 'self'
        ? worldState.oathAlignment === 'Mercy'
          ? 'Auto-Hit Conduit (+3 HP Mercy Oath)'
          : 'Auto-Hit Allied Conduit'
        : `${inspectProfile.primaryStatLabel} · ${inspectProfile.attackRollFormula}`,
  });

  // Actual Skill Effects List (Part 5D — never show unrelated effects)
  const effects: SkillEffectRow[] = [];
  const elemTitle = ability.element
    ? `${ability.element.charAt(0).toUpperCase() + ability.element.slice(1)} Damage`
    : 'Physical Damage';

  if (ability.damageRange[1] > 0 && inspectedAb) {
    effects.push({
      id: 'direct-damage',
      kind: 'damage',
      title: elemTitle,
      detail: `Deals ${inspectedAb.effectiveOutputLabel} on hit against target Effective AC.`,
    });
  }

  if ((ability.healAmount ?? 0) > 0 && inspectedAb) {
    effects.push({
      id: 'direct-heal',
      kind: 'heal',
      title: 'Vitality Healing',
      detail: `Restores ${inspectedAb.effectiveOutputLabel} immediately without requiring an attack roll.`,
    });
  }

  if ((ability.grantTempHp ?? 0) > 0) {
    effects.push({
      id: 'temp-hp',
      kind: 'shield',
      title: 'Protective Ward Barrier',
      detail:
        (ability.allyAuraTempHp ?? 0) > 0
          ? `Grants +${ability.grantTempHp} Temp HP to self and +${ability.allyAuraTempHp} Temp HP (plus Burn extinguish) to allies within 2 tiles.`
          : `Weaves +${ability.grantTempHp} Temporary HP that absorbs incoming damage before Vitality.`,
    });
  }

  if ((ability.pushDistance ?? 0) > 0) {
    effects.push({
      id: 'knockback',
      kind: 'movement',
      title: `Knockback (${ability.pushDistance} Tile)`,
      detail: `Shoves hit enemy or pushable object ${ability.pushDistance} tile away; deals +4 Collision DMG if blocked by walls or units.`,
    });
  }

  if ((ability.pullDistance ?? 0) > 0) {
    effects.push({
      id: 'pull',
      kind: 'movement',
      title: `Forced Pull (${ability.pullDistance} Tile)`,
      detail:
        ability.id === 'chrono_rift_collapse'
          ? 'Pulls enemies within Radius 2 one tile inward toward the singularity epicenter (+4 Arcane DMG).'
          : 'Yanks the target 1 tile toward the caster (+4 Arcane Shear DMG if pulled off High Ground or onto a Rift).',
    });
  }

  if (ability.selfReposition === 'leap_adjacent') {
    effects.push({
      id: 'self-leap',
      kind: 'movement',
      title: 'Gap-Close Leap',
      detail: 'Vaults into an open adjacent melee tile before delivering the strike (blocked while Rooted).',
    });
  } else if (ability.selfReposition === 'backstep_1') {
    effects.push({
      id: 'self-backstep',
      kind: 'movement',
      title: 'Evasive Backstep (1 Tile)',
      detail: 'Automatically vaults 1 tile away from the target after firing (blocked while Rooted).',
    });
  }

  if (ability.resetTargetMove) {
    effects.push({
      id: 'move-reset',
      kind: 'movement',
      title: 'Movement Phase Reset',
      detail: 'Refreshes the target ally’s stride so they can move again during the current round.',
    });
  }

  if ((ability.refundApOnKO ?? 0) > 0) {
    effects.push({
      id: 'ap-refund',
      kind: 'mechanic',
      title: `Execution Momentum (+${ability.refundApOnKO} AP)`,
      detail: `Refunds +${ability.refundApOnKO} Action Point immediately if this strike reduces the target to 0 HP.`,
    });
  }

  if (ability.cleanseStatuses && ability.cleanseStatuses.length > 0) {
    const purgedNames = ability.cleanseStatuses.map(
      (st) => getStatusEffectTooltipData(st, 2).label
    );
    effects.push({
      id: 'cleanse',
      kind: 'cleanse',
      title: 'Affliction Purge',
      detail: `Immediately removes ${purgedNames.join(', ')} from the target ally.`,
    });
  }

  if (ability.uniqueMechanicLabel) {
    effects.push({
      id: 'signature-mechanic',
      kind: 'mechanic',
      title: 'Signature Tactical Mechanic',
      detail: ability.uniqueMechanicLabel,
    });
  }

  // Status effects applied directly or via signature secondary effect
  const statusList: ('blessed' | 'burning' | 'rooted' | 'sundered' | 'warded')[] = [];
  if (ability.statusEffect) {
    statusList.push(ability.statusEffect);
  }
  if (
    (ability.id === 'sunblade_cleave' || ability.id === 'astral_soul_blade') &&
    !statusList.includes('burning')
  ) {
    statusList.push('burning');
  }
  if (ability.id === 'dawnbreaker_judgment' && !statusList.includes('blessed')) {
    statusList.push('blessed');
  }
  if (ability.id === 'ironwood_tempest' && !statusList.includes('warded')) {
    statusList.push('warded');
  }

  for (const st of statusList) {
    const stMeta = getStatusEffectTooltipData(st, 2);
    effects.push({
      id: `status-${st}`,
      kind: 'status',
      title: stMeta.label,
      detail: stMeta.mechanicalEffect,
      statusType: st,
      durationLabel: '2 Turns',
    });
  }

  const tacticalUse: SkillTacticalGuide = SKILL_TACTICAL_GUIDES[ability.id] ?? {
    whenToUse: 'Use when enemy positioning aligns with your weapon range and Action Point budget.',
    bestTargets: 'Exposed adversaries within effective range.',
    positioningAndTerrain: 'Seek High Ground (+2 Hit / +2 DMG) and allied flanking angles (+2 Hit).',
    limitations: `Requires ${ability.apCost} AP and Range ${ability.range}.`,
  };

  return {
    entry,
    slotEvaluation,
    flavorText:
      SKILL_FLAVOR_TEXT[ability.id] ??
      'An ancient martial discipline preserved across the shattered marches of Dimraeth.',
    mechanicalDescription: ability.description,
    combatStats,
    effects,
    tacticalUse,
  };
}

export interface AssignSkillResult {
  updatedUnit: CombatUnit;
  replacedAbility: Ability | null;
  swappedFromSlot: '1' | '2' | '3' | '4' | null;
  changed: boolean;
}

/**
 * Safely assigns an unlocked catalog skill to Slot 1..4 on a party unit.
 * - Prevents duplicate active skills across multiple slots by swapping if already equipped elsewhere.
 * - Preserves all 4 slots, preserves cooldowns keyed by skill ID, and never corrupts abilities.
 */
export function assignUnitSkillToSlot(
  unit: CombatUnit,
  catalogEntry: UnitSkillCatalogEntry,
  targetSlotKey: '1' | '2' | '3' | '4'
): AssignSkillResult {
  if (catalogEntry.isLocked || unit.faction !== 'party') {
    return {
      updatedUnit: unit,
      replacedAbility: null,
      swappedFromSlot: null,
      changed: false,
    };
  }

  const currentInTargetSlot = unit.abilities.find((a) => a.key === targetSlotKey) ?? null;
  if (currentInTargetSlot && currentInTargetSlot.id === catalogEntry.ability.id) {
    return {
      updatedUnit: unit,
      replacedAbility: null,
      swappedFromSlot: null,
      changed: false,
    };
  }

  const existingEquipped = unit.abilities.find((a) => a.id === catalogEntry.ability.id) ?? null;
  const swappedFromSlot = existingEquipped ? existingEquipped.key : null;

  const slotOrder: ('1' | '2' | '3' | '4')[] = ['1', '2', '3', '4'];
  const nextAbilities: Ability[] = slotOrder
    .map((slotKey) => {
      if (slotKey === targetSlotKey) {
        return {
          ...catalogEntry.ability,
          key: targetSlotKey,
        };
      }
      if (swappedFromSlot && slotKey === swappedFromSlot) {
        return currentInTargetSlot
          ? {
              ...currentInTargetSlot,
              key: swappedFromSlot,
            }
          : undefined;
      }
      const existing = unit.abilities.find((a) => a.key === slotKey);
      if (existing && existing.id === catalogEntry.ability.id) {
        return undefined;
      }
      return existing ? { ...existing } : undefined;
    })
    .filter((a): a is Ability => Boolean(a));

  return {
    updatedUnit: {
      ...unit,
      abilities: nextAbilities,
    },
    replacedAbility: currentInTargetSlot,
    swappedFromSlot,
    changed: true,
  };
}
