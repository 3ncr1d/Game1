import { AnimationPhase, RigTransform, SkillAnimationConfig } from './types';

function easeOutQuad(t: number): number {
  return 1 - (1 - t) * (1 - t);
}
function easeInQuad(t: number): number {
  return t * t;
}
function easeInOutQuad(t: number): number {
  return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
}
function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

export const PALADIN_ANIMATIONS: Record<string, SkillAnimationConfig> = {
  // 1. Consecrated Strike: Two-handed overhead golden warhammer cleave
  consecrated_strike: {
    skillId: 'consecrated_strike',
    name: 'Consecrated Strike',
    animationId: 'anim_paladin_consecrated_strike',
    anticipationDuration: 0.24,
    executionDuration: 0.32,
    impactTiming: 0.44,
    recoveryDuration: 0.34,
    totalDuration: 0.9,
    weaponTrail: {
      enabled: true,
      colorHex: 0xf59e0b,
      trailType: 'holy_cleave',
      intensity: 0.95,
    },
    vfx: {
      particleCount: 28,
      particleColorHex: 0xf59e0b,
      dustBurst: true,
      sparkBurst: true,
      shockwaveRadius: 1.8,
    },
    soundMethod: 'playConsecratedStrike',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'forward_step',
    cancellationRules: 'Uninterruptible once overhead momentum passes apex.',
    combatEventSync: 'Infuses hammer with radiant fire, converts tile to sanctified ground.',
    samplePose: (progress, phase, isMiss) => {
      if (phase === 'anticipation') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, 0.08 * t, -0.1 * t],
          bodyRot: [-0.2 * t, 0, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [0.1 * t, 0.7 * t, -0.25 * t],
          weaponRot: [-0.8 * t, 0, 0],
          shieldPos: [-0.15 * t, 0.1 * t, 0],
          shieldRot: [0, 0.3 * t, 0],
        };
      }
      if (phase === 'execution') {
        const t = easeInQuad(progress);
        const missOffset = isMiss ? 0.3 : 0;
        return {
          bodyPos: [0, lerp(0.08, -0.15, t), lerp(-0.1, 0.35, t)],
          bodyRot: [lerp(-0.2, 0.45, t), missOffset, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [lerp(0.1, 0.25, t), lerp(0.7, -0.3, t), lerp(-0.25, 0.85, t)],
          weaponRot: [lerp(-0.8, 1.1, t), 0, 0],
          shieldPos: [lerp(-0.15, -0.25, t), lerp(0.1, -0.1, t), 0.2 * t],
          shieldRot: [0, 0.3, 0],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, -0.18, 0.38],
          bodyRot: [0.48, 0, 0],
          bodyScale: [1.08, 0.92, 1.08],
          weaponPos: [0.28, -0.35, 0.9],
          weaponRot: [1.15, 0, 0],
          shieldPos: [-0.28, -0.12, 0.22],
          shieldRot: [0, 0.32, 0],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(-0.18, 0, t), lerp(0.38, 0, t)],
        bodyRot: [lerp(0.48, 0, t), 0, 0],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(0.28, 0, t), lerp(-0.35, 0, t), lerp(0.9, 0, t)],
        weaponRot: [lerp(1.15, 0, t), 0, 0],
        shieldPos: [lerp(-0.28, 0, t), lerp(-0.12, 0, t), lerp(0.22, 0, t)],
        shieldRot: [0, lerp(0.32, 0, t), 0],
      };
    },
  },

  // 2. Oathward: High kite shield projection of radiant aegis
  oathward: {
    skillId: 'oathward',
    name: 'Oathward',
    animationId: 'anim_paladin_oathward',
    anticipationDuration: 0.18,
    executionDuration: 0.26,
    impactTiming: 0.36,
    recoveryDuration: 0.3,
    totalDuration: 0.74,
    weaponTrail: {
      enabled: false,
      colorHex: 0xfbbf24,
      trailType: 'shield_aegis',
      intensity: 0.7,
    },
    vfx: {
      particleCount: 22,
      particleColorHex: 0xfbbf24,
      dustBurst: false,
      sparkBurst: true,
      allyPulse: true,
    },
    soundMethod: 'playOathward',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Aegis barrier projected instantly.',
    combatEventSync: 'Grants Warded (+2 AC) and absorbs up to 8 incoming damage.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, -0.05 * t, -0.08 * t],
          bodyRot: [0.1 * t, 0.25 * t, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [0.15 * t, 0, -0.1 * t],
          weaponRot: [0.3 * t, 0, 0],
          shieldPos: [-0.2 * t, 0.25 * t, 0.15 * t],
          shieldRot: [0.2 * t, -0.4 * t, 0],
        };
      }
      if (phase === 'execution') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, -0.05, lerp(-0.08, 0.15, t)],
          bodyRot: [0.1, lerp(0.25, -0.15, t), 0],
          bodyScale: [1, 1, 1],
          weaponPos: [0.15, 0, 0],
          weaponRot: [0.3, 0, 0],
          shieldPos: [lerp(-0.2, -0.05, t), lerp(0.25, 0.4, t), lerp(0.15, 0.65, t)],
          shieldRot: [lerp(0.2, 0.35, t), lerp(-0.4, 0.1, t), 0],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, -0.06, 0.18],
          bodyRot: [0.12, -0.18, 0],
          bodyScale: [1.04, 1.04, 1.04],
          weaponPos: [0.15, 0, 0],
          weaponRot: [0.3, 0, 0],
          shieldPos: [-0.02, 0.42, 0.7],
          shieldRot: [0.38, 0.12, 0],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(-0.06, 0, t), lerp(0.18, 0, t)],
        bodyRot: [lerp(0.12, 0, t), lerp(-0.18, 0, t), 0],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(0.15, 0, t), 0, 0],
        weaponRot: [lerp(0.3, 0, t), 0, 0],
        shieldPos: [lerp(-0.02, 0, t), lerp(0.42, 0, t), lerp(0.7, 0, t)],
        shieldRot: [lerp(0.38, 0, t), lerp(0.12, 0, t), 0],
      };
    },
  },

  // 3. Sanctuary Ring: Hammer butt planted into earth, prayer benediction
  sanctuary_ring: {
    skillId: 'sanctuary_ring',
    name: 'Sanctuary Ring',
    animationId: 'anim_paladin_sanctuary_ring',
    anticipationDuration: 0.22,
    executionDuration: 0.3,
    impactTiming: 0.42,
    recoveryDuration: 0.32,
    totalDuration: 0.84,
    weaponTrail: {
      enabled: false,
      colorHex: 0xfde047,
      trailType: 'sanctuary_ring',
      intensity: 0.8,
    },
    vfx: {
      particleCount: 26,
      particleColorHex: 0xfde047,
      dustBurst: true,
      sparkBurst: false,
      shockwaveRadius: 2.5,
      allyPulse: true,
    },
    soundMethod: 'playSanctuaryRing',
    targetFacingBehavior: 'maintain_facing',
    movementBehavior: 'in_place',
    cancellationRules: 'Blessed sanctuary ring locked on ground contact.',
    combatEventSync: 'Creates blessed ring: Allies gain +2 AC and regenerate 3 HP.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, -0.08 * t, 0],
          bodyRot: [0.15 * t, 0, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [0, 0.4 * t, 0.1 * t],
          weaponRot: [-0.4 * t, 0, 0],
        };
      }
      if (phase === 'execution') {
        const t = easeInQuad(progress);
        return {
          bodyPos: [0, lerp(-0.08, -0.22, t), 0.1 * t],
          bodyRot: [lerp(0.15, 0.32, t), 0, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [0, lerp(0.4, -0.4, t), lerp(0.1, 0.55, t)],
          weaponRot: [lerp(-0.4, 0.7, t), 0, 0],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, -0.24, 0.12],
          bodyRot: [0.35, 0, 0],
          bodyScale: [1.06, 0.94, 1.06],
          weaponPos: [0, -0.42, 0.58],
          weaponRot: [0.75, 0, 0],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(-0.24, 0, t), lerp(0.12, 0, t)],
        bodyRot: [lerp(0.35, 0, t), 0, 0],
        bodyScale: [1, 1, 1],
        weaponPos: [0, lerp(-0.42, 0, t), lerp(0.58, 0, t)],
        weaponRot: [lerp(0.75, 0, t), 0, 0],
      };
    },
  },

  // 4. Judgment Mark: Hammer extended straight pointing like inquisitor gavel
  judgment_mark: {
    skillId: 'judgment_mark',
    name: 'Judgment Mark',
    animationId: 'anim_paladin_judgment_mark',
    anticipationDuration: 0.18,
    executionDuration: 0.24,
    impactTiming: 0.32,
    recoveryDuration: 0.26,
    totalDuration: 0.68,
    weaponTrail: {
      enabled: true,
      colorHex: 0xf59e0b,
      trailType: 'judgment_brand',
      intensity: 0.85,
    },
    vfx: {
      particleCount: 20,
      particleColorHex: 0xf59e0b,
      dustBurst: false,
      sparkBurst: true,
    },
    soundMethod: 'playJudgmentMark',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Mark condemns enemy with radiant retribution.',
    combatEventSync: 'Reflects 50% damage back to target when ally is struck.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, 0, -0.06 * t],
          bodyRot: [-0.1 * t, -0.2 * t, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [0.1 * t, 0.2 * t, -0.15 * t],
          weaponRot: [-0.4 * t, 0.2 * t, 0],
        };
      }
      if (phase === 'execution') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, 0, lerp(-0.06, 0.15, t)],
          bodyRot: [lerp(-0.1, 0.12, t), lerp(-0.2, 0.25, t), 0],
          bodyScale: [1, 1, 1],
          weaponPos: [lerp(0.1, 0.32, t), lerp(0.2, 0.25, t), lerp(-0.15, 0.85, t)],
          weaponRot: [lerp(-0.4, -0.15, t), lerp(0.2, 0.35, t), 0],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, 0, 0.18],
          bodyRot: [0.14, 0.28, 0],
          bodyScale: [1.02, 1.02, 1.02],
          weaponPos: [0.35, 0.28, 0.92],
          weaponRot: [-0.18, 0.4, 0],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, 0, lerp(0.18, 0, t)],
        bodyRot: [lerp(0.14, 0, t), lerp(0.28, 0, t), 0],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(0.35, 0, t), lerp(0.28, 0, t), lerp(0.92, 0, t)],
        weaponRot: [lerp(-0.18, 0, t), lerp(0.4, 0, t), 0],
      };
    },
  },

  // 5. Radiant Mend: Hand to chest, healing dawnlight channel to ally
  radiant_mend: {
    skillId: 'radiant_mend',
    name: 'Radiant Mend',
    animationId: 'anim_paladin_radiant_mend',
    anticipationDuration: 0.2,
    executionDuration: 0.28,
    impactTiming: 0.38,
    recoveryDuration: 0.28,
    totalDuration: 0.76,
    weaponTrail: {
      enabled: false,
      colorHex: 0xfef08a,
      trailType: 'holy_glow',
      intensity: 0.7,
    },
    vfx: {
      particleCount: 22,
      particleColorHex: 0xfef08a,
      dustBurst: false,
      sparkBurst: false,
      allyPulse: true,
    },
    soundMethod: 'playRadiantMend',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Healing flow purges status conditions at apex.',
    combatEventSync: 'Restores 14 HP to ally and purges burning/rooted/sundered.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, 0.05 * t, 0],
          bodyRot: [-0.12 * t, 0, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [0.1 * t, 0.15 * t, 0],
          weaponRot: [0.2 * t, 0, 0.2 * t],
        };
      }
      if (phase === 'execution') {
        const t = easeInOutQuad(progress);
        return {
          bodyPos: [0, lerp(0.05, 0.12, t), 0],
          bodyRot: [lerp(-0.12, -0.22, t), 0, 0],
          bodyScale: [1, 1.03, 1],
          weaponPos: [lerp(0.1, 0.2, t), lerp(0.15, 0.45, t), 0.1 * t],
          weaponRot: [lerp(0.2, 0.4, t), 0, lerp(0.2, 0.5, t)],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, 0.14, 0],
          bodyRot: [-0.25, 0, 0],
          bodyScale: [1.04, 1.04, 1.04],
          weaponPos: [0.22, 0.48, 0.12],
          weaponRot: [0.45, 0, 0.55],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(0.14, 0, t), 0],
        bodyRot: [lerp(-0.25, 0, t), 0, 0],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(0.22, 0, t), lerp(0.48, 0, t), lerp(0.12, 0, t)],
        weaponRot: [lerp(0.45, 0, t), 0, lerp(0.55, 0, t)],
      };
    },
  },

  // 6. Shield of Conviction: Massive forward lunging shield bash
  shield_of_conviction: {
    skillId: 'shield_of_conviction',
    name: 'Shield of Conviction',
    animationId: 'anim_paladin_shield_of_conviction',
    anticipationDuration: 0.18,
    executionDuration: 0.26,
    impactTiming: 0.34,
    recoveryDuration: 0.28,
    totalDuration: 0.72,
    weaponTrail: {
      enabled: true,
      colorHex: 0xf59e0b,
      trailType: 'shield_bash',
      intensity: 0.9,
    },
    vfx: {
      particleCount: 24,
      particleColorHex: 0xf59e0b,
      dustBurst: true,
      sparkBurst: true,
      shockwaveRadius: 1.6,
    },
    soundMethod: 'playShieldOfConviction',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'forward_step',
    cancellationRules: 'Uninterruptible concussive shield rush.',
    combatEventSync: 'Deals 9-14 damage, shoves enemy 2 tiles back.',
    samplePose: (progress, phase, isMiss) => {
      if (phase === 'anticipation') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, -0.08 * t, -0.15 * t],
          bodyRot: [0.15 * t, 0.35 * t, 0],
          bodyScale: [1, 1, 1],
          shieldPos: [-0.15 * t, 0.1 * t, -0.15 * t],
          shieldRot: [0.1 * t, -0.5 * t, 0],
          weaponPos: [0.2 * t, 0, -0.1 * t],
          weaponRot: [0.3 * t, 0, 0],
        };
      }
      if (phase === 'execution') {
        const t = easeOutQuad(progress);
        const missOffset = isMiss ? 0.25 : 0;
        return {
          bodyPos: [0, 0, lerp(-0.15, 0.45, t)],
          bodyRot: [0.15, lerp(0.35, -0.2 + missOffset, t), 0],
          bodyScale: [1, 1, 1],
          shieldPos: [lerp(-0.15, 0.1, t), lerp(0.1, 0.25, t), lerp(-0.15, 0.85, t)],
          shieldRot: [0.1, lerp(-0.5, 0.2, t), 0],
          weaponPos: [0.2, 0, 0],
          weaponRot: [0.3, 0, 0],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, 0, 0.48],
          bodyRot: [0.18, -0.22, 0],
          bodyScale: [1.06, 1.06, 1.06],
          shieldPos: [0.12, 0.28, 0.92],
          shieldRot: [0.12, 0.25, 0],
          weaponPos: [0.2, 0, 0],
          weaponRot: [0.3, 0, 0],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, 0, lerp(0.48, 0, t)],
        bodyRot: [lerp(0.18, 0, t), lerp(-0.22, 0, t), 0],
        bodyScale: [1, 1, 1],
        shieldPos: [lerp(0.12, 0, t), lerp(0.28, 0, t), lerp(0.92, 0, t)],
        shieldRot: [lerp(0.12, 0, t), lerp(0.25, 0, t), 0],
        weaponPos: [lerp(0.2, 0, t), 0, 0],
        weaponRot: [lerp(0.3, 0, t), 0, 0],
      };
    },
  },

  // 7. Oath of Restraint: Raising hammer to pull down celestial chains
  oath_of_restraint: {
    skillId: 'oath_of_restraint',
    name: 'Oath of Restraint',
    animationId: 'anim_paladin_oath_of_restraint',
    anticipationDuration: 0.22,
    executionDuration: 0.3,
    impactTiming: 0.42,
    recoveryDuration: 0.3,
    totalDuration: 0.82,
    weaponTrail: {
      enabled: true,
      colorHex: 0xf59e0b,
      trailType: 'golden_chains',
      intensity: 0.85,
    },
    vfx: {
      particleCount: 26,
      particleColorHex: 0xf59e0b,
      dustBurst: false,
      sparkBurst: true,
    },
    soundMethod: 'playOathOfRestraint',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Celestial chains bind target on impact.',
    combatEventSync: 'Reduces enemy AP by 1 and restricts movement to 0 for 2 turns.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, 0.08 * t, -0.05 * t],
          bodyRot: [-0.2 * t, 0, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [0.1 * t, 0.65 * t, -0.15 * t],
          weaponRot: [-0.7 * t, 0, 0],
        };
      }
      if (phase === 'execution') {
        const t = easeInQuad(progress);
        return {
          bodyPos: [0, lerp(0.08, -0.05, t), lerp(-0.05, 0.15, t)],
          bodyRot: [lerp(-0.2, 0.32, t), 0, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [lerp(0.1, 0.25, t), lerp(0.65, 0.05, t), lerp(-0.15, 0.75, t)],
          weaponRot: [lerp(-0.7, 0.5, t), 0, 0],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, -0.06, 0.18],
          bodyRot: [0.35, 0, 0],
          bodyScale: [1.04, 0.98, 1.04],
          weaponPos: [0.28, 0.02, 0.82],
          weaponRot: [0.55, 0, 0],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(-0.06, 0, t), lerp(0.18, 0, t)],
        bodyRot: [lerp(0.35, 0, t), 0, 0],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(0.28, 0, t), lerp(0.02, 0, t), lerp(0.82, 0, t)],
        weaponRot: [lerp(0.55, 0, t), 0, 0],
      };
    },
  },

  // 8. Sacred Ground: High arc jump and hammer plunge carving 5-tile cross
  sacred_ground: {
    skillId: 'sacred_ground',
    name: 'Sacred Ground',
    animationId: 'anim_paladin_sacred_ground',
    anticipationDuration: 0.26,
    executionDuration: 0.34,
    impactTiming: 0.48,
    recoveryDuration: 0.36,
    totalDuration: 0.96,
    weaponTrail: {
      enabled: true,
      colorHex: 0xf59e0b,
      trailType: 'solar_cross',
      intensity: 0.95,
    },
    vfx: {
      particleCount: 36,
      particleColorHex: 0xf59e0b,
      dustBurst: true,
      sparkBurst: true,
      shockwaveRadius: 2.8,
    },
    soundMethod: 'playSacredGround',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Consecration carved deep into terrain.',
    combatEventSync: 'Consecrates 5-tile solar cross: Damages foes, heals allies 8 HP.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, 0.15 * t, -0.1 * t],
          bodyRot: [-0.35 * t, 0, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [0, 0.75 * t, -0.2 * t],
          weaponRot: [-0.85 * t, 0, 0],
        };
      }
      if (phase === 'execution') {
        const t = easeInQuad(progress);
        return {
          bodyPos: [0, lerp(0.15, -0.2, t), lerp(-0.1, 0.2, t)],
          bodyRot: [lerp(-0.35, 0.5, t), 0, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [0, lerp(0.75, -0.45, t), lerp(-0.2, 0.7, t)],
          weaponRot: [lerp(-0.85, 1.15, t), 0, 0],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, -0.22, 0.25],
          bodyRot: [0.55, 0, 0],
          bodyScale: [1.1, 0.9, 1.1],
          weaponPos: [0, -0.48, 0.75],
          weaponRot: [1.2, 0, 0],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(-0.22, 0, t), lerp(0.25, 0, t)],
        bodyRot: [lerp(0.55, 0, t), 0, 0],
        bodyScale: [1, 1, 1],
        weaponPos: [0, lerp(-0.48, 0, t), lerp(0.75, 0, t)],
        weaponRot: [lerp(1.2, 0, t), 0, 0],
      };
    },
  },

  // 9. Burden of Sin: Open palm pushing down with crushing divine moral gravity
  burden_of_sin: {
    skillId: 'burden_of_sin',
    name: 'Burden of Sin',
    animationId: 'anim_paladin_burden_of_sin',
    anticipationDuration: 0.2,
    executionDuration: 0.26,
    impactTiming: 0.36,
    recoveryDuration: 0.28,
    totalDuration: 0.74,
    weaponTrail: {
      enabled: false,
      colorHex: 0xa855f7,
      trailType: 'sin_gravity',
      intensity: 0.7,
    },
    vfx: {
      particleCount: 22,
      particleColorHex: 0xa855f7,
      dustBurst: true,
      sparkBurst: false,
      shockwaveRadius: 1.5,
    },
    soundMethod: 'playBurdenOfSin',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Guilt gravity anchors target.',
    combatEventSync: 'Reduces attack damage by -4 and halves movement for 2 turns.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, 0.08 * t, -0.05 * t],
          bodyRot: [-0.15 * t, 0, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [0.1 * t, 0.35 * t, 0],
          weaponRot: [-0.3 * t, 0, 0],
        };
      }
      if (phase === 'execution') {
        const t = easeInQuad(progress);
        return {
          bodyPos: [0, lerp(0.08, -0.1, t), 0.1 * t],
          bodyRot: [lerp(-0.15, 0.28, t), 0, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [lerp(0.1, 0.2, t), lerp(0.35, -0.2, t), lerp(0, 0.6, t)],
          weaponRot: [lerp(-0.3, 0.6, t), 0, 0],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, -0.12, 0.12],
          bodyRot: [0.32, 0, 0],
          bodyScale: [1.04, 0.96, 1.04],
          weaponPos: [0.22, -0.22, 0.65],
          weaponRot: [0.65, 0, 0],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(-0.12, 0, t), lerp(0.12, 0, t)],
        bodyRot: [lerp(0.32, 0, t), 0, 0],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(0.22, 0, t), lerp(-0.22, 0, t), lerp(0.65, 0, t)],
        weaponRot: [lerp(0.65, 0, t), 0, 0],
      };
    },
  },

  // 10. Beacon of Hope: Hammer held aloft like banner, radiant golden chest flare
  beacon_of_hope: {
    skillId: 'beacon_of_hope',
    name: 'Beacon of Hope',
    animationId: 'anim_paladin_beacon_of_hope',
    anticipationDuration: 0.22,
    executionDuration: 0.32,
    impactTiming: 0.44,
    recoveryDuration: 0.32,
    totalDuration: 0.86,
    weaponTrail: {
      enabled: false,
      colorHex: 0xf59e0b,
      trailType: 'beacon_standard',
      intensity: 0.8,
    },
    vfx: {
      particleCount: 28,
      particleColorHex: 0xf59e0b,
      dustBurst: false,
      sparkBurst: true,
      allyPulse: true,
    },
    soundMethod: 'playBeaconOfHope',
    targetFacingBehavior: 'maintain_facing',
    movementBehavior: 'in_place',
    cancellationRules: 'Beacon aura projects to all nearby allies.',
    combatEventSync: 'Allies below 30% HP gain 10 Temp HP and Blessed status.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, 0.08 * t, 0],
          bodyRot: [-0.15 * t, 0, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [0.1 * t, 0.5 * t, 0],
          weaponRot: [0.1 * t, 0, 0.2 * t],
        };
      }
      if (phase === 'execution') {
        const t = easeInOutQuad(progress);
        return {
          bodyPos: [0, lerp(0.08, 0.2, t), 0],
          bodyRot: [lerp(-0.15, -0.28, t), 0, 0],
          bodyScale: [1, 1.04, 1],
          weaponPos: [lerp(0.1, 0.25, t), lerp(0.5, 0.85, t), 0.1 * t],
          weaponRot: [lerp(0.1, 0.25, t), 0, lerp(0.2, 0.4, t)],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, 0.22, 0],
          bodyRot: [-0.3, 0, 0],
          bodyScale: [1.06, 1.06, 1.06],
          weaponPos: [0.28, 0.9, 0.12],
          weaponRot: [0.28, 0, 0.45],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(0.22, 0, t), 0],
        bodyRot: [lerp(-0.3, 0, t), 0, 0],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(0.28, 0, t), lerp(0.9, 0, t), lerp(0.12, 0, t)],
        weaponRot: [lerp(0.28, 0, t), 0, lerp(0.45, 0, t)],
      };
    },
  },

  // 11. Divine Intercession: Holy leap adjacent to imperiled ally with shield intercept
  divine_intercession: {
    skillId: 'divine_intercession',
    name: 'Divine Intercession',
    animationId: 'anim_paladin_divine_intercession',
    anticipationDuration: 0.16,
    executionDuration: 0.26,
    impactTiming: 0.32,
    recoveryDuration: 0.3,
    totalDuration: 0.72,
    weaponTrail: {
      enabled: true,
      colorHex: 0xfde047,
      trailType: 'holy_rush',
      intensity: 0.9,
    },
    vfx: {
      particleCount: 26,
      particleColorHex: 0xfde047,
      dustBurst: true,
      sparkBurst: true,
      allyPulse: true,
    },
    soundMethod: 'playDivineIntercession',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'phase_blink',
    cancellationRules: 'Sacred intervention shields ally from fatal blow.',
    combatEventSync: 'Blinks to ally, heals them for 18 HP, and redirects next attack.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        const t = easeInQuad(progress);
        return {
          bodyPos: [0, -0.1 * t, 0],
          bodyRot: [0.2 * t, 0, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [0.15 * t, 0, -0.1 * t],
          weaponRot: [0.3 * t, 0, 0],
          shieldPos: [-0.15 * t, 0.2 * t, 0.1 * t],
          shieldRot: [0, 0.3 * t, 0],
        };
      }
      if (phase === 'execution') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, 0, lerp(0, 0.45, t)],
          bodyRot: [0.2, 0, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [0.15, 0, 0],
          weaponRot: [0.3, 0, 0],
          shieldPos: [-0.15, lerp(0.2, 0.35, t), lerp(0.1, 0.75, t)],
          shieldRot: [0, 0.3, 0],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, 0, 0.48],
          bodyRot: [0.22, 0, 0],
          bodyScale: [1.06, 1.06, 1.06],
          weaponPos: [0.15, 0, 0],
          weaponRot: [0.3, 0, 0],
          shieldPos: [-0.12, 0.38, 0.8],
          shieldRot: [0, 0.32, 0],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, 0, lerp(0.48, 0, t)],
        bodyRot: [lerp(0.22, 0, t), 0, 0],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(0.15, 0, t), 0, 0],
        weaponRot: [lerp(0.3, 0, t), 0, 0],
        shieldPos: [lerp(-0.12, 0, t), lerp(0.38, 0, t), lerp(0.8, 0, t)],
        shieldRot: [0, lerp(0.32, 0, t), 0],
      };
    },
  },

  // 12. Final Judgment: 360 spinning hammer windup into apocalyptic celestial pillar
  final_judgment: {
    skillId: 'final_judgment',
    name: 'Final Judgment',
    animationId: 'anim_paladin_final_judgment',
    anticipationDuration: 0.3,
    executionDuration: 0.42,
    impactTiming: 0.6,
    recoveryDuration: 0.44,
    totalDuration: 1.16,
    weaponTrail: {
      enabled: true,
      colorHex: 0xf59e0b,
      trailType: 'divine_wrath',
      intensity: 1.0,
    },
    vfx: {
      particleCount: 50,
      particleColorHex: 0xf59e0b,
      dustBurst: true,
      sparkBurst: true,
      shockwaveRadius: 3.6,
    },
    soundMethod: 'playFinalJudgment',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'leaping_stride',
    cancellationRules: 'Ultimate holy wrath cannot be halted.',
    combatEventSync: 'Deals 26-38 Radiant damage in 3x3, heals allies for 15, and consecrates all tiles.',
    samplePose: (progress, phase, isMiss) => {
      if (phase === 'anticipation') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, 0.2 * t, -0.15 * t],
          bodyRot: [-0.3 * t, -1.2 * t, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [-0.25 * t, 0.7 * t, -0.3 * t],
          weaponRot: [-0.7 * t, -1.57 * t, 0.4 * t],
        };
      }
      if (phase === 'execution') {
        const t = easeInQuad(progress);
        const missOffset = isMiss ? 0.35 : 0;
        return {
          bodyPos: [0, lerp(0.2, -0.22, t), lerp(-0.15, 0.5, t)],
          bodyRot: [lerp(-0.3, 0.55, t), lerp(-1.2, 3.14 + missOffset, t), 0],
          bodyScale: [1, 1, 1],
          weaponPos: [lerp(-0.25, 0.4, t), lerp(0.7, -0.45, t), lerp(-0.3, 0.95, t)],
          weaponRot: [lerp(-0.7, 1.25, t), lerp(-1.57, 3.14, t), lerp(0.4, -0.5, t)],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, -0.25, 0.55],
          bodyRot: [0.6, 3.14, 0],
          bodyScale: [1.12, 0.88, 1.12],
          weaponPos: [0.42, -0.5, 1.05],
          weaponRot: [1.3, 3.14, -0.55],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(-0.25, 0, t), lerp(0.55, 0, t)],
        bodyRot: [lerp(0.6, 0, t), lerp(3.14, 0, t), 0],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(0.42, 0, t), lerp(-0.5, 0, t), lerp(1.05, 0, t)],
        weaponRot: [lerp(1.3, 0, t), lerp(3.14, 0, t), lerp(-0.55, 0, t)],
      };
    },
  },
};
