import { AnimationPhase, RigTransform, SkillAnimationConfig } from './types';

function easeOutQuad(t: number): number {
  return 1 - (1 - t) * (1 - t);
}
function easeInQuad(t: number): number {
  return t * t;
}
function easeInOutQuad(t: number): number {
  return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
}
function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

export const MAGE_ANIMATIONS: Record<string, SkillAnimationConfig> = {
  // 1. Infernal Orb: Two-handed overhead staff gathering of pyromantic solar fireball, sweeping forward thrust
  infernal_orb: {
    skillId: 'infernal_orb',
    name: 'Infernal Orb',
    animationId: 'anim_mage_infernal_orb',
    anticipationDuration: 0.18,
    executionDuration: 0.22,
    impactTiming: 0.32,
    recoveryDuration: 0.28,
    totalDuration: 0.68,
    weaponTrail: {
      enabled: true,
      colorHex: 0xf97316,
      trailType: 'fire_arc',
      intensity: 0.95,
    },
    vfx: {
      particleCount: 24,
      particleColorHex: 0xf97316,
      dustBurst: true,
      sparkBurst: true,
      shockwaveRadius: 1.5,
    },
    soundMethod: 'playInfernalOrb',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Uninterruptible after 0.18s ignition.',
    combatEventSync: 'Detonates roaring pyromantic fireball on impact timing.',
    samplePose: (progress, phase, isMiss) => {
      const missOffset = isMiss ? 0.25 : 0;
      if (phase === 'anticipation') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, 0, -0.08 * t],
          bodyRot: [-0.12 * t, 0.18 * t, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [lerp(0, 0.28, t), lerp(0, 0.65, t), lerp(0, -0.15, t)],
          weaponRot: [lerp(0, 0.55, t), lerp(0, -0.25, t), lerp(0, 0.15, t)],
          shieldPos: [-0.22 * t, 0.45 * t, 0.15 * t],
          shieldRot: [0.1 * t, 0.3 * t, 0],
          leftLegRot: [-0.15 * t, 0, 0],
          rightLegRot: [0.18 * t, 0, 0],
        };
      }
      if (phase === 'execution') {
        const t = easeInOutQuad(progress);
        return {
          bodyPos: [0, 0, lerp(-0.08, 0.15, t)],
          bodyRot: [lerp(-0.12, 0.18, t), lerp(0.18, -0.05 + missOffset, t), 0],
          bodyScale: [1, 1, 1],
          weaponPos: [lerp(0.28, 0.32, t), lerp(0.65, 0.45, t), lerp(-0.15, 0.88, t)],
          weaponRot: [lerp(0.55, -0.42, t), lerp(-0.25, 0.15, t), lerp(0.15, -0.08, t)],
          shieldPos: [lerp(-0.22, -0.25, t), lerp(0.45, 0.65, t), lerp(0.15, 0.45, t)],
          shieldRot: [lerp(0.1, 0.2, t), lerp(0.3, 0.5, t), 0],
          leftLegRot: [lerp(-0.15, 0.22, t), 0, 0],
          rightLegRot: [lerp(0.18, -0.28, t), 0, 0],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, 0, 0.15],
          bodyRot: [0.18, -0.05, 0],
          bodyScale: [1.04, 1.04, 1.04],
          weaponPos: [0.32, 0.45, 0.88],
          weaponRot: [-0.42, 0.15, -0.08],
          shieldPos: [-0.25, 0.65, 0.45],
          shieldRot: [0.2, 0.5, 0],
          leftLegRot: [0.22, 0, 0],
          rightLegRot: [-0.28, 0, 0],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, 0, lerp(0.15, 0, t)],
        bodyRot: [lerp(0.18, 0, t), lerp(-0.05, 0, t), 0],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(0.32, 0, t), lerp(0.45, 0, t), lerp(0.88, 0, t)],
        weaponRot: [lerp(-0.42, 0, t), lerp(0.15, 0, t), lerp(-0.08, 0, t)],
        shieldPos: [lerp(-0.25, 0, t), lerp(0.65, 0, t), lerp(0.45, 0, t)],
        shieldRot: [lerp(0.2, 0, t), lerp(0.5, 0, t), 0],
        leftLegRot: [lerp(0.22, 0, t), 0, 0],
        rightLegRot: [lerp(-0.28, 0, t), 0, 0],
      };
    },
  },

  // 2. Glacial Lance: Low piercing posture, staff leveled like a lance, left leg lunging forward, sharp linear frost thrust
  glacial_lance: {
    skillId: 'glacial_lance',
    name: 'Glacial Lance',
    animationId: 'anim_mage_glacial_lance',
    anticipationDuration: 0.15,
    executionDuration: 0.2,
    impactTiming: 0.28,
    recoveryDuration: 0.25,
    totalDuration: 0.6,
    weaponTrail: {
      enabled: true,
      colorHex: 0x38bdf8,
      trailType: 'frost_spike',
      intensity: 0.9,
    },
    vfx: {
      particleCount: 20,
      particleColorHex: 0x38bdf8,
      dustBurst: false,
      sparkBurst: true,
    },
    soundMethod: 'playGlacialLance',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'forward_step',
    cancellationRules: 'Uninterruptible after 0.15s thrust.',
    combatEventSync: 'Projects directional piercing ray on impact timing.',
    samplePose: (progress, phase, isMiss) => {
      const missOffset = isMiss ? 0.3 : 0;
      if (phase === 'anticipation') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, -0.03 * t, -0.06 * t],
          bodyRot: [0.08 * t, -0.12 * t, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [lerp(0, 0.15, t), lerp(0, 0.18, t), lerp(0, -0.22, t)],
          weaponRot: [lerp(0, -0.15, t), lerp(0, 0.05, t), 0],
          shieldPos: [-0.28 * t, 0.35 * t, 0.12 * t],
          shieldRot: [0.2 * t, -0.1 * t, 0],
          leftLegRot: [0.25 * t, 0, 0],
          rightLegRot: [-0.25 * t, 0, 0],
        };
      }
      if (phase === 'execution') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, lerp(-0.03, -0.06, t), lerp(-0.06, 0.24, t)],
          bodyRot: [lerp(0.08, 0.26, t), lerp(-0.12, 0.08 + missOffset, t), 0],
          bodyScale: [1, 1, 1],
          weaponPos: [lerp(0.15, 0.18, t), lerp(0.18, 0.22, t), lerp(-0.22, 1.15, t)],
          weaponRot: [lerp(-0.15, -0.08, t), lerp(0.05, 0.04, t), 0],
          shieldPos: [lerp(-0.28, -0.35, t), lerp(0.35, 0.38, t), lerp(0.12, 0.32, t)],
          shieldRot: [lerp(0.2, 0.4, t), lerp(-0.1, -0.2, t), 0],
          leftLegRot: [lerp(0.25, 0.45, t), 0, 0],
          rightLegRot: [lerp(-0.25, -0.45, t), 0, 0],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, -0.06, 0.24],
          bodyRot: [0.26, 0.08, 0],
          bodyScale: [1.02, 1.02, 1.02],
          weaponPos: [0.18, 0.22, 1.15],
          weaponRot: [-0.08, 0.04, 0.02],
          shieldPos: [-0.35, 0.38, 0.32],
          shieldRot: [0.4, -0.2, 0],
          leftLegRot: [0.45, 0, 0],
          rightLegRot: [-0.45, 0, 0],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(-0.06, 0, t), lerp(0.24, 0, t)],
        bodyRot: [lerp(0.26, 0, t), lerp(0.08, 0, t), 0],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(0.18, 0, t), lerp(0.22, 0, t), lerp(1.15, 0, t)],
        weaponRot: [lerp(-0.08, 0, t), lerp(0.04, 0, t), lerp(0.02, 0, t)],
        shieldPos: [lerp(-0.35, 0, t), lerp(0.38, 0, t), lerp(0.32, 0, t)],
        shieldRot: [lerp(0.4, 0, t), lerp(-0.2, 0, t), 0],
        leftLegRot: [lerp(0.45, 0, t), 0, 0],
        rightLegRot: [lerp(-0.45, 0, t), 0, 0],
      };
    },
  },

  // 3. Chain Lightning: Staff raised high in right hand, left hand pointing forward, electric recoil
  chain_lightning: {
    skillId: 'chain_lightning',
    name: 'Chain Lightning',
    animationId: 'anim_mage_chain_lightning',
    anticipationDuration: 0.16,
    executionDuration: 0.22,
    impactTiming: 0.3,
    recoveryDuration: 0.24,
    totalDuration: 0.62,
    weaponTrail: {
      enabled: true,
      colorHex: 0xa855f7,
      trailType: 'lightning_spark',
      intensity: 0.92,
    },
    vfx: {
      particleCount: 28,
      particleColorHex: 0xa855f7,
      dustBurst: false,
      sparkBurst: true,
      shockwaveRadius: 1.2,
    },
    soundMethod: 'playChainLightning',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Uninterruptible after 0.16s charge.',
    combatEventSync: 'Discharges cascading electric arcs on impact timing.',
    samplePose: (progress, phase, isMiss) => {
      const missOffset = isMiss ? 0.2 : 0;
      if (phase === 'anticipation') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, 0.04 * t, -0.04 * t],
          bodyRot: [-0.08 * t, 0.12 * t, 0.02 * t],
          bodyScale: [1, 1, 1],
          weaponPos: [lerp(0, 0.38, t), lerp(0, 0.72, t), lerp(0, 0.45, t)],
          weaponRot: [lerp(0, 0.25, t), lerp(0, 0.12, t), lerp(0, -0.15, t)],
          shieldPos: [-0.35 * t, 0.62 * t, 0.42 * t],
          shieldRot: [0.4 * t, 0.3 * t, 0],
          leftLegRot: [-0.1 * t, 0, 0],
          rightLegRot: [0.08 * t, 0, 0],
        };
      }
      if (phase === 'execution') {
        const t = easeInOutQuad(progress);
        return {
          bodyPos: [0, lerp(0.04, 0.08, t), lerp(-0.04, -0.08, t)],
          bodyRot: [lerp(-0.08, -0.14, t), lerp(0.12, 0.22 + missOffset, t), lerp(0.02, 0.05, t)],
          bodyScale: [1, 1, 1],
          weaponPos: [lerp(0.38, 0.44, t), lerp(0.72, 0.82, t), lerp(0.45, 0.65, t)],
          weaponRot: [lerp(0.25, 0.35, t), lerp(0.12, 0.18, t), lerp(-0.15, -0.25, t)],
          shieldPos: [lerp(-0.35, -0.42, t), lerp(0.62, 0.72, t), lerp(0.42, 0.55, t)],
          shieldRot: [lerp(0.4, 0.8, t), lerp(0.3, 0.6, t), lerp(0, 0.1, t)],
          leftLegRot: [lerp(-0.1, -0.15, t), 0, 0],
          rightLegRot: [lerp(0.08, 0.12, t), 0, 0],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, 0.08, -0.08],
          bodyRot: [-0.14, 0.22, 0.05],
          bodyScale: [1.03, 1.03, 1.03],
          weaponPos: [0.44, 0.82, 0.65],
          weaponRot: [0.35, 0.18, -0.25],
          shieldPos: [-0.42, 0.72, 0.55],
          shieldRot: [0.8, 0.6, 0.1],
          leftLegRot: [-0.15, 0, 0],
          rightLegRot: [0.12, 0, 0],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(0.08, 0, t), lerp(-0.08, 0, t)],
        bodyRot: [lerp(-0.14, 0, t), lerp(0.22, 0, t), lerp(0.05, 0, t)],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(0.44, 0, t), lerp(0.82, 0, t), lerp(0.65, 0, t)],
        weaponRot: [lerp(0.35, 0, t), lerp(0.18, 0, t), lerp(-0.25, 0, t)],
        shieldPos: [lerp(-0.42, 0, t), lerp(0.72, 0, t), lerp(0.55, 0, t)],
        shieldRot: [lerp(0.8, 0, t), lerp(0.6, 0, t), lerp(0.1, 0, t)],
        leftLegRot: [lerp(-0.15, 0, t), 0, 0],
        rightLegRot: [lerp(0.12, 0, t), 0, 0],
      };
    },
  },

  // 4. Blink Step: Upward floating astral phase, staff held vertically close to body, dissolving compression
  blink_step: {
    skillId: 'blink_step',
    name: 'Blink Step',
    animationId: 'anim_mage_blink_step',
    anticipationDuration: 0.12,
    executionDuration: 0.18,
    impactTiming: 0.22,
    recoveryDuration: 0.2,
    totalDuration: 0.5,
    weaponTrail: {
      enabled: true,
      colorHex: 0x6366f1,
      trailType: 'phase_fade',
      intensity: 0.85,
    },
    vfx: {
      particleCount: 18,
      particleColorHex: 0x6366f1,
      dustBurst: false,
      sparkBurst: false,
      shockwaveRadius: 0.8,
    },
    soundMethod: 'playBlinkStep',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'phase_blink',
    cancellationRules: 'Instant uninterruptible spacetime fold.',
    combatEventSync: 'Displaces unit coordinates through astral fold on impact timing.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        const t = easeInQuad(progress);
        return {
          bodyPos: [0, 0.15 * t, 0.01 * t],
          bodyRot: [-0.02 * t, 0.01 * t, 0],
          bodyScale: [lerp(1, 0.85, t), lerp(1, 1.25, t), lerp(1, 0.85, t)],
          weaponPos: [lerp(0, 0.08, t), lerp(0, 0.35, t), lerp(0, 0.12, t)],
          weaponRot: [lerp(0, 0.03, t), lerp(0, -0.06, t), lerp(0, 0.04, t)],
          shieldPos: [-0.12 * t, 0.55 * t, 0.08 * t],
          shieldRot: [0.6 * t, 0.2 * t, -0.15 * t],
          leftLegRot: [-0.04 * t, 0, 0],
          rightLegRot: [-0.04 * t, 0, 0],
        };
      }
      if (phase === 'execution') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, lerp(0.15, 0.28, t), 0.02],
          bodyRot: [-0.05, 0.02, 0],
          bodyScale: [lerp(0.85, 0.4, t), lerp(1.25, 1.6, t), lerp(0.85, 0.4, t)],
          weaponPos: [lerp(0.08, 0.12, t), lerp(0.35, 0.55, t), lerp(0.12, 0.18, t)],
          weaponRot: [0.05, -0.12, 0.08],
          shieldPos: [lerp(-0.12, -0.18, t), lerp(0.55, 0.85, t), lerp(0.08, 0.12, t)],
          shieldRot: [lerp(0.6, 1.2, t), lerp(0.2, 0.4, t), lerp(-0.15, -0.3, t)],
          leftLegRot: [-0.08, 0, 0],
          rightLegRot: [-0.08, 0, 0],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, 0.28, 0.02],
          bodyRot: [-0.05, 0.02, 0],
          bodyScale: [0.98, 1.05, 0.98],
          weaponPos: [0.12, 0.55, 0.18],
          weaponRot: [0.05, -0.12, 0.08],
          shieldPos: [-0.18, 0.85, 0.12],
          shieldRot: [1.2, 0.4, -0.3],
          leftLegRot: [-0.08, 0, 0],
          rightLegRot: [-0.08, 0, 0],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(0.28, 0, t), lerp(0.02, 0, t)],
        bodyRot: [lerp(-0.05, 0, t), lerp(0.02, 0, t), 0],
        bodyScale: [lerp(0.98, 1, t), lerp(1.05, 1, t), lerp(0.98, 1, t)],
        weaponPos: [lerp(0.12, 0, t), lerp(0.55, 0, t), lerp(0.18, 0, t)],
        weaponRot: [lerp(0.05, 0, t), lerp(-0.12, 0, t), lerp(0.08, 0, t)],
        shieldPos: [lerp(-0.18, 0, t), lerp(0.85, 0, t), lerp(0.12, 0, t)],
        shieldRot: [lerp(1.2, 0, t), lerp(0.4, 0, t), lerp(-0.3, 0, t)],
        leftLegRot: [lerp(-0.08, 0, t), 0, 0],
        rightLegRot: [lerp(-0.08, 0, t), 0, 0],
      };
    },
  },

  // 5. Gravitational Collapse: Two-handed staff slam toward ground, orb swirling inward, torso crouched low
  gravitational_collapse: {
    skillId: 'gravitational_collapse',
    name: 'Gravitational Collapse',
    animationId: 'anim_mage_gravitational_collapse',
    anticipationDuration: 0.2,
    executionDuration: 0.25,
    impactTiming: 0.35,
    recoveryDuration: 0.28,
    totalDuration: 0.73,
    weaponTrail: {
      enabled: true,
      colorHex: 0x4f46e5,
      trailType: 'vortex_swirl',
      intensity: 0.95,
    },
    vfx: {
      particleCount: 32,
      particleColorHex: 0x4f46e5,
      dustBurst: true,
      sparkBurst: false,
      shockwaveRadius: 2.2,
    },
    soundMethod: 'playGravitationalCollapse',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Uninterruptible after 0.2s vortex arming.',
    combatEventSync: 'Collapses spacetime singularity pulling enemies 1 tile inward.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, 0.08 * t, -0.05 * t],
          bodyRot: [-0.2 * t, 0.1 * t, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [lerp(0, 0.22, t), lerp(0, 0.85, t), lerp(0, 0.35, t)],
          weaponRot: [lerp(0, 0.45, t), lerp(0, 0.2, t), 0],
          shieldPos: [-0.3 * t, 0.5 * t, 0.3 * t],
          shieldRot: [0.7 * t, 0.4 * t, 0],
          leftLegRot: [-0.15 * t, 0, 0],
          rightLegRot: [0.15 * t, 0, 0],
        };
      }
      if (phase === 'execution') {
        const t = easeInQuad(progress);
        return {
          bodyPos: [0, lerp(0.08, -0.18, t), lerp(-0.05, 0.18, t)],
          bodyRot: [lerp(-0.2, 0.38, t), lerp(0.1, -0.12, t), 0],
          bodyScale: [1, 1, 1],
          weaponPos: [lerp(0.22, 0.15, t), lerp(0.85, -0.08, t), lerp(0.35, 0.72, t)],
          weaponRot: [lerp(0.45, -0.75, t), lerp(0.2, 0.08, t), 0],
          shieldPos: [lerp(-0.3, -0.22, t), lerp(0.5, 0.15, t), lerp(0.3, 0.65, t)],
          shieldRot: [lerp(0.7, 1.5, t), lerp(0.4, 0.8, t), 0],
          leftLegRot: [lerp(-0.15, 0.35, t), 0, 0],
          rightLegRot: [lerp(0.15, 0.35, t), 0, 0],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, -0.18, 0.18],
          bodyRot: [0.38, -0.12, 0],
          bodyScale: [1.05, 1.05, 1.05],
          weaponPos: [0.15, -0.08, 0.72],
          weaponRot: [-0.75, 0.08, 0],
          shieldPos: [-0.22, 0.15, 0.65],
          shieldRot: [1.5, 0.8, 0],
          leftLegRot: [0.35, 0, 0],
          rightLegRot: [0.35, 0, 0],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(-0.18, 0, t), lerp(0.18, 0, t)],
        bodyRot: [lerp(0.38, 0, t), lerp(-0.12, 0, t), 0],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(0.15, 0, t), lerp(-0.08, 0, t), lerp(0.72, 0, t)],
        weaponRot: [lerp(-0.75, 0, t), lerp(0.08, 0, t), 0],
        shieldPos: [lerp(-0.22, 0, t), lerp(0.15, 0, t), lerp(0.65, 0, t)],
        shieldRot: [lerp(1.5, 0, t), lerp(0.8, 0, t), 0],
        leftLegRot: [lerp(0.35, 0, t), 0, 0],
        rightLegRot: [lerp(0.35, 0, t), 0, 0],
      };
    },
  },

  // 6. Arcane Disjunction: High cross-sweep unraveling glyphs, staff cutting across horizontally from left to right
  arcane_disjunction: {
    skillId: 'arcane_disjunction',
    name: 'Arcane Disjunction',
    animationId: 'anim_mage_arcane_disjunction',
    anticipationDuration: 0.14,
    executionDuration: 0.18,
    impactTiming: 0.25,
    recoveryDuration: 0.22,
    totalDuration: 0.54,
    weaponTrail: {
      enabled: true,
      colorHex: 0xec4899,
      trailType: 'glyph_shatter',
      intensity: 0.88,
    },
    vfx: {
      particleCount: 22,
      particleColorHex: 0xec4899,
      dustBurst: false,
      sparkBurst: true,
    },
    soundMethod: 'playArcaneDisjunction',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Uninterruptible after 0.14s initiation.',
    combatEventSync: 'Strips magical shields and buffs on impact timing.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, 0, -0.05 * t],
          bodyRot: [0.04 * t, 0.35 * t, -0.05 * t],
          bodyScale: [1, 1, 1],
          weaponPos: [lerp(0, 0.42, t), lerp(0, 0.45, t), lerp(0, -0.12, t)],
          weaponRot: [lerp(0, -0.15, t), lerp(0, -0.55, t), lerp(0, -0.2, t)],
          shieldPos: [-0.35 * t, 0.4 * t, 0.18 * t],
          shieldRot: [-0.3 * t, 0.15 * t, 0.1 * t],
          leftLegRot: [0.1 * t, 0, 0],
          rightLegRot: [-0.15 * t, 0, 0],
        };
      }
      if (phase === 'execution') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, 0.02 * t, lerp(-0.05, 0.1, t)],
          bodyRot: [lerp(0.04, 0.08, t), lerp(0.35, -0.45, t), lerp(-0.05, 0.12, t)],
          bodyScale: [1, 1, 1],
          weaponPos: [lerp(0.42, -0.15, t), lerp(0.45, 0.58, t), lerp(-0.12, 0.78, t)],
          weaponRot: [lerp(-0.15, -0.22, t), lerp(-0.55, 0.85, t), lerp(-0.2, 0.45, t)],
          shieldPos: [lerp(-0.35, -0.48, t), lerp(0.4, 0.52, t), lerp(0.18, 0.25, t)],
          shieldRot: [lerp(-0.3, -0.6, t), lerp(0.15, 0.3, t), lerp(0.1, 0.2, t)],
          leftLegRot: [lerp(0.1, 0.18, t), 0, 0],
          rightLegRot: [lerp(-0.15, -0.22, t), 0, 0],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, 0.02, 0.1],
          bodyRot: [0.08, -0.45, 0.12],
          bodyScale: [1.02, 1.02, 1.02],
          weaponPos: [-0.15, 0.58, 0.78],
          weaponRot: [-0.22, 0.85, 0.45],
          shieldPos: [-0.48, 0.52, 0.25],
          shieldRot: [-0.6, 0.3, 0.2],
          leftLegRot: [0.18, 0, 0],
          rightLegRot: [-0.22, 0, 0],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(0.02, 0, t), lerp(0.1, 0, t)],
        bodyRot: [lerp(0.08, 0, t), lerp(-0.45, 0, t), lerp(0.12, 0, t)],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(-0.15, 0, t), lerp(0.58, 0, t), lerp(0.78, 0, t)],
        weaponRot: [lerp(-0.22, 0, t), lerp(0.85, 0, t), lerp(0.45, 0, t)],
        shieldPos: [lerp(-0.48, 0, t), lerp(0.52, 0, t), lerp(0.25, 0, t)],
        shieldRot: [lerp(-0.6, 0, t), lerp(0.3, 0, t), lerp(0.2, 0, t)],
        leftLegRot: [lerp(0.18, 0, t), 0, 0],
        rightLegRot: [lerp(-0.22, 0, t), 0, 0],
      };
    },
  },

  // 7. Aegis Ward: Staff grounded at side, left hand raised in shielding ward gesture, spherical boundary pulsing outward
  aegis_ward: {
    skillId: 'aegis_ward',
    name: 'Aegis Ward',
    animationId: 'anim_mage_aegis_ward',
    anticipationDuration: 0.15,
    executionDuration: 0.2,
    impactTiming: 0.26,
    recoveryDuration: 0.25,
    totalDuration: 0.6,
    weaponTrail: {
      enabled: false,
      colorHex: 0x38bdf8,
      trailType: 'none',
      intensity: 0,
    },
    vfx: {
      particleCount: 20,
      particleColorHex: 0x38bdf8,
      dustBurst: false,
      sparkBurst: false,
      allyPulse: true,
      shockwaveRadius: 1.8,
    },
    soundMethod: 'playAegisWard',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Uninterruptible after 0.15s ward formation.',
    combatEventSync: 'Applies protective temporary health shield and backlash trigger.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, -0.02 * t, -0.03 * t],
          bodyRot: [-0.04 * t, 0.08 * t, -0.02 * t],
          bodyScale: [1, 1, 1],
          weaponPos: [lerp(0, 0.38, t), lerp(0, 0.04, t), lerp(0, 0.15, t)],
          weaponRot: [0, 0, 0.08 * t],
          shieldPos: [-0.25 * t, 0.45 * t, 0.35 * t],
          shieldRot: [0.05 * t, 0.1 * t, 0],
          leftLegRot: [-0.08 * t, 0, 0],
          rightLegRot: [0.1 * t, 0, 0],
        };
      }
      if (phase === 'execution') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, lerp(-0.02, -0.04, t), -0.05],
          bodyRot: [lerp(-0.04, -0.08, t), 0.12, -0.05],
          bodyScale: [1, 1, 1],
          weaponPos: [lerp(0.38, 0.42, t), lerp(0.04, 0.08, t), lerp(0.15, 0.25, t)],
          weaponRot: [0.05, -0.08, 0.12],
          shieldPos: [lerp(-0.25, -0.38, t), lerp(0.45, 0.75, t), lerp(0.35, 0.62, t)],
          shieldRot: [0.1, 0.2, 0.05],
          leftLegRot: [lerp(-0.08, -0.12, t), 0, 0],
          rightLegRot: [lerp(0.1, 0.18, t), 0, 0],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, -0.04, -0.05],
          bodyRot: [-0.08, 0.12, -0.05],
          bodyScale: [1.02, 1.02, 1.02],
          weaponPos: [0.42, 0.08, 0.25],
          weaponRot: [0.05, -0.08, 0.12],
          shieldPos: [-0.38, 0.75, 0.62],
          shieldRot: [0.1, 0.2, 0.05],
          leftLegRot: [-0.12, 0, 0],
          rightLegRot: [0.18, 0, 0],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(-0.04, 0, t), lerp(-0.05, 0, t)],
        bodyRot: [lerp(-0.08, 0, t), lerp(0.12, 0, t), lerp(-0.05, 0, t)],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(0.42, 0, t), lerp(0.08, 0, t), lerp(0.25, 0, t)],
        weaponRot: [lerp(0.05, 0, t), lerp(-0.08, 0, t), lerp(0.12, 0, t)],
        shieldPos: [lerp(-0.38, 0, t), lerp(0.75, 0, t), lerp(0.62, 0, t)],
        shieldRot: [lerp(0.1, 0, t), lerp(0.2, 0, t), lerp(0.05, 0, t)],
        leftLegRot: [lerp(-0.12, 0, t), 0, 0],
        rightLegRot: [lerp(0.18, 0, t), 0, 0],
      };
    },
  },

  // 8. Counterspell: Poised reactive deflection posture, staff held diagonally across chest forming a mirror ward plane
  counterspell: {
    skillId: 'counterspell',
    name: 'Counterspell',
    animationId: 'anim_mage_counterspell',
    anticipationDuration: 0.14,
    executionDuration: 0.18,
    impactTiming: 0.24,
    recoveryDuration: 0.22,
    totalDuration: 0.54,
    weaponTrail: {
      enabled: true,
      colorHex: 0x818cf8,
      trailType: 'mirror_refract',
      intensity: 0.9,
    },
    vfx: {
      particleCount: 24,
      particleColorHex: 0x818cf8,
      dustBurst: false,
      sparkBurst: true,
      shockwaveRadius: 1.0,
    },
    soundMethod: 'playCounterspell',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Uninterruptible after 0.14s readiness.',
    combatEventSync: 'Arms reflective spell counter-reaction on impact timing.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, 0.02 * t, -0.06 * t],
          bodyRot: [-0.1 * t, 0.18 * t, -0.05 * t],
          bodyScale: [1, 1, 1],
          weaponPos: [lerp(0, 0.15, t), lerp(0, 0.45, t), lerp(0, 0.25, t)],
          weaponRot: [lerp(0, 0.25, t), lerp(0, 0.45, t), lerp(0, -0.4, t)],
          shieldPos: [-0.18 * t, 0.48 * t, 0.35 * t],
          shieldRot: [0.25 * t, 0.5 * t, -0.1 * t],
          leftLegRot: [-0.12 * t, 0, 0],
          rightLegRot: [0.15 * t, 0, 0],
        };
      }
      if (phase === 'execution') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, lerp(0.02, 0.04, t), lerp(-0.06, -0.12, t)],
          bodyRot: [lerp(-0.1, -0.18, t), lerp(0.18, 0.28, t), -0.1],
          bodyScale: [1, 1, 1],
          weaponPos: [lerp(0.15, 0.05, t), lerp(0.45, 0.62, t), lerp(0.25, 0.42, t)],
          weaponRot: [lerp(0.25, 0.45, t), lerp(0.45, 0.72, t), lerp(-0.4, -0.65, t)],
          shieldPos: [lerp(-0.18, -0.25, t), lerp(0.48, 0.68, t), lerp(0.35, 0.58, t)],
          shieldRot: [lerp(0.25, 0.5, t), lerp(0.5, 0.9, t), -0.2],
          leftLegRot: [lerp(-0.12, -0.22, t), 0, 0],
          rightLegRot: [lerp(0.15, 0.25, t), 0, 0],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, 0.04, -0.12],
          bodyRot: [-0.18, 0.28, -0.1],
          bodyScale: [1.02, 1.02, 1.02],
          weaponPos: [0.05, 0.62, 0.42],
          weaponRot: [0.45, 0.72, -0.65],
          shieldPos: [-0.25, 0.68, 0.58],
          shieldRot: [0.5, 0.9, -0.2],
          leftLegRot: [-0.22, 0, 0],
          rightLegRot: [0.25, 0, 0],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(0.04, 0, t), lerp(-0.12, 0, t)],
        bodyRot: [lerp(-0.18, 0, t), lerp(0.28, 0, t), lerp(-0.1, 0, t)],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(0.05, 0, t), lerp(0.62, 0, t), lerp(0.42, 0, t)],
        weaponRot: [lerp(0.45, 0, t), lerp(0.72, 0, t), lerp(-0.65, 0, t)],
        shieldPos: [lerp(-0.25, 0, t), lerp(0.68, 0, t), lerp(0.58, 0, t)],
        shieldRot: [lerp(0.5, 0, t), lerp(0.9, 0, t), lerp(-0.2, 0, t)],
        leftLegRot: [lerp(-0.22, 0, t), 0, 0],
        rightLegRot: [lerp(0.25, 0, t), 0, 0],
      };
    },
  },

  // 9. Phase Veil: Fluid ethereal back-lean with staff sweeping overhead in a protective arc, ethereal shroud
  phase_veil: {
    skillId: 'phase_veil',
    name: 'Phase Veil',
    animationId: 'anim_mage_phase_veil',
    anticipationDuration: 0.16,
    executionDuration: 0.2,
    impactTiming: 0.28,
    recoveryDuration: 0.24,
    totalDuration: 0.6,
    weaponTrail: {
      enabled: true,
      colorHex: 0x34d399,
      trailType: 'veil_glow',
      intensity: 0.82,
    },
    vfx: {
      particleCount: 22,
      particleColorHex: 0x34d399,
      dustBurst: false,
      sparkBurst: false,
      allyPulse: true,
    },
    soundMethod: 'playPhaseVeil',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Uninterruptible after 0.16s veil shroud.',
    combatEventSync: 'Purges physical and status crowd controls on impact timing.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, 0.05 * t, -0.08 * t],
          bodyRot: [-0.12 * t, -0.08 * t, 0.04 * t],
          bodyScale: [1, 1, 1],
          weaponPos: [lerp(0, 0.25, t), lerp(0, 0.65, t), lerp(0, 0.08, t)],
          weaponRot: [lerp(0, 0.35, t), lerp(0, -0.18, t), lerp(0, 0.15, t)],
          shieldPos: [-0.22 * t, 0.65 * t, -0.02 * t],
          shieldRot: [-0.2 * t, 0.6 * t, 0.15 * t],
          leftLegRot: [-0.15 * t, 0, 0],
          rightLegRot: [0.02 * t, 0, 0],
        };
      }
      if (phase === 'execution') {
        const t = easeInOutQuad(progress);
        return {
          bodyPos: [0, lerp(0.05, 0.12, t), lerp(-0.08, -0.15, t)],
          bodyRot: [lerp(-0.12, -0.24, t), lerp(-0.08, -0.18, t), lerp(0.04, 0.08, t)],
          bodyScale: [1, 1, 1],
          weaponPos: [lerp(0.25, 0.35, t), lerp(0.65, 0.92, t), lerp(0.08, 0.15, t)],
          weaponRot: [lerp(0.35, 0.65, t), lerp(-0.18, -0.35, t), lerp(0.15, 0.28, t)],
          shieldPos: [lerp(-0.22, -0.32, t), lerp(0.65, 0.95, t), -0.05],
          shieldRot: [lerp(-0.2, -0.4, t), lerp(0.6, 1.2, t), lerp(0.15, 0.3, t)],
          leftLegRot: [lerp(-0.15, -0.3, t), 0, 0],
          rightLegRot: [lerp(0.02, 0.05, t), 0, 0],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, 0.12, -0.15],
          bodyRot: [-0.24, -0.18, 0.08],
          bodyScale: [1.02, 1.02, 1.02],
          weaponPos: [0.35, 0.92, 0.15],
          weaponRot: [0.65, -0.35, 0.28],
          shieldPos: [-0.32, 0.95, -0.05],
          shieldRot: [-0.4, 1.2, 0.3],
          leftLegRot: [-0.3, 0, 0],
          rightLegRot: [0.05, 0, 0],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(0.12, 0, t), lerp(-0.15, 0, t)],
        bodyRot: [lerp(-0.24, 0, t), lerp(-0.18, 0, t), lerp(0.08, 0, t)],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(0.35, 0, t), lerp(0.92, 0, t), lerp(0.15, 0, t)],
        weaponRot: [lerp(0.65, 0, t), lerp(-0.35, 0, t), lerp(0.28, 0, t)],
        shieldPos: [lerp(-0.32, 0, t), lerp(0.95, 0, t), lerp(-0.05, 0, t)],
        shieldRot: [lerp(-0.4, 0, t), lerp(1.2, 0, t), lerp(0.3, 0, t)],
        leftLegRot: [lerp(-0.3, 0, t), 0, 0],
        rightLegRot: [lerp(0.05, 0, t), 0, 0],
      };
    },
  },

  // 10. Runic Mine: Low kneeling posture, staff tip touching floor inscribing geometric runic trap
  runic_mine: {
    skillId: 'runic_mine',
    name: 'Runic Mine',
    animationId: 'anim_mage_runic_mine',
    anticipationDuration: 0.18,
    executionDuration: 0.22,
    impactTiming: 0.32,
    recoveryDuration: 0.26,
    totalDuration: 0.66,
    weaponTrail: {
      enabled: true,
      colorHex: 0xf59e0b,
      trailType: 'rune_glow',
      intensity: 0.85,
    },
    vfx: {
      particleCount: 26,
      particleColorHex: 0xf59e0b,
      dustBurst: true,
      sparkBurst: true,
      shockwaveRadius: 1.4,
    },
    soundMethod: 'playRunicMine',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Uninterruptible after 0.18s inscription.',
    combatEventSync: 'Inscribes dormant arcane trigger on target tile.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, -0.1 * t, 0.05 * t],
          bodyRot: [0.25 * t, 0.02 * t, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [lerp(0, 0.18, t), lerp(0, -0.1, t), lerp(0, 0.35, t)],
          weaponRot: [lerp(0, -0.5, t), 0, 0],
          shieldPos: [-0.1 * t, 0.1 * t, 0.28 * t],
          shieldRot: [0.4 * t, -0.2 * t, 0],
          leftLegRot: [0.35 * t, 0, 0],
          rightLegRot: [0.3 * t, 0, 0],
        };
      }
      if (phase === 'execution') {
        const t = easeInQuad(progress);
        return {
          bodyPos: [0, lerp(-0.1, -0.22, t), lerp(0.05, 0.12, t)],
          bodyRot: [lerp(0.25, 0.48, t), 0.05, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [lerp(0.18, 0.22, t), lerp(-0.1, -0.25, t), lerp(0.35, 0.55, t)],
          weaponRot: [lerp(-0.5, -0.92, t), 0.05, 0],
          shieldPos: [lerp(-0.1, -0.15, t), lerp(0.1, -0.05, t), lerp(0.28, 0.48, t)],
          shieldRot: [lerp(0.4, 0.8, t), lerp(-0.2, -0.4, t), 0],
          leftLegRot: [lerp(0.35, 0.6, t), 0, 0],
          rightLegRot: [lerp(0.3, 0.55, t), 0, 0],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, -0.22, 0.12],
          bodyRot: [0.48, 0.05, 0],
          bodyScale: [1.02, 1.02, 1.02],
          weaponPos: [0.22, -0.25, 0.55],
          weaponRot: [-0.92, 0.05, 0],
          shieldPos: [-0.15, -0.05, 0.48],
          shieldRot: [0.8, -0.4, 0],
          leftLegRot: [0.6, 0, 0],
          rightLegRot: [0.55, 0, 0],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(-0.22, 0, t), lerp(0.12, 0, t)],
        bodyRot: [lerp(0.48, 0, t), lerp(0.05, 0, t), 0],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(0.22, 0, t), lerp(-0.25, 0, t), lerp(0.55, 0, t)],
        weaponRot: [lerp(-0.92, 0, t), lerp(0.05, 0, t), 0],
        shieldPos: [lerp(-0.15, 0, t), lerp(-0.05, 0, t), lerp(0.48, 0, t)],
        shieldRot: [lerp(0.8, 0, t), lerp(-0.4, 0, t), 0],
        leftLegRot: [lerp(0.6, 0, t), 0, 0],
        rightLegRot: [lerp(0.55, 0, t), 0, 0],
      };
    },
  },

  // 11. Astral Rift: Violent dual-arm tear motion, staff pulled hard to right while left hand rips planar fabric open
  astral_rift: {
    skillId: 'astral_rift',
    name: 'Astral Rift',
    animationId: 'anim_mage_astral_rift',
    anticipationDuration: 0.18,
    executionDuration: 0.24,
    impactTiming: 0.34,
    recoveryDuration: 0.28,
    totalDuration: 0.7,
    weaponTrail: {
      enabled: true,
      colorHex: 0x9333ea,
      trailType: 'void_tear',
      intensity: 0.95,
    },
    vfx: {
      particleCount: 36,
      particleColorHex: 0x9333ea,
      dustBurst: true,
      sparkBurst: true,
      shockwaveRadius: 2.0,
    },
    soundMethod: 'playAstralRift',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Uninterruptible after 0.18s rift tear.',
    combatEventSync: 'Rips open hazardous planar chasm on target tile.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, 0.02 * t, 0.04 * t],
          bodyRot: [0.05 * t, 0.25 * t, -0.1 * t],
          bodyScale: [1, 1, 1],
          weaponPos: [lerp(0, 0.45, t), lerp(0, 0.55, t), lerp(0, 0.32, t)],
          weaponRot: [lerp(0, -0.15, t), lerp(0, -0.35, t), lerp(0, 0.25, t)],
          shieldPos: [-0.35 * t, 0.35 * t, 0.45 * t],
          shieldRot: [0.6 * t, -0.4 * t, 0.2 * t],
          leftLegRot: [0.15 * t, 0, 0],
          rightLegRot: [-0.18 * t, 0, 0],
        };
      }
      if (phase === 'execution') {
        const t = easeInOutQuad(progress);
        return {
          bodyPos: [0, lerp(0.02, 0.06, t), lerp(0.04, 0.08, t)],
          bodyRot: [lerp(0.05, 0.12, t), lerp(0.25, 0.52, t), lerp(-0.1, -0.22, t)],
          bodyScale: [1, 1, 1],
          weaponPos: [lerp(0.45, 0.68, t), lerp(0.55, 0.42, t), lerp(0.32, 0.52, t)],
          weaponRot: [lerp(-0.15, -0.32, t), lerp(-0.35, -0.68, t), lerp(0.25, 0.48, t)],
          shieldPos: [lerp(-0.35, -0.55, t), lerp(0.35, 0.45, t), lerp(0.45, 0.65, t)],
          shieldRot: [lerp(0.6, 1.1, t), lerp(-0.4, -0.8, t), lerp(0.2, 0.4, t)],
          leftLegRot: [lerp(0.15, 0.28, t), 0, 0],
          rightLegRot: [lerp(-0.18, -0.35, t), 0, 0],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, 0.06, 0.08],
          bodyRot: [0.12, 0.52, -0.22],
          bodyScale: [1.04, 1.04, 1.04],
          weaponPos: [0.68, 0.42, 0.52],
          weaponRot: [-0.32, -0.68, 0.48],
          shieldPos: [-0.55, 0.45, 0.65],
          shieldRot: [1.1, -0.8, 0.4],
          leftLegRot: [0.28, 0, 0],
          rightLegRot: [-0.35, 0, 0],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(0.06, 0, t), lerp(0.08, 0, t)],
        bodyRot: [lerp(0.12, 0, t), lerp(0.52, 0, t), lerp(-0.22, 0, t)],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(0.68, 0, t), lerp(0.42, 0, t), lerp(0.52, 0, t)],
        weaponRot: [lerp(-0.32, 0, t), lerp(-0.68, 0, t), lerp(0.48, 0, t)],
        shieldPos: [lerp(-0.55, 0, t), lerp(0.45, 0, t), lerp(0.65, 0, t)],
        shieldRot: [lerp(1.1, 0, t), lerp(-0.8, 0, t), lerp(0.4, 0, t)],
        leftLegRot: [lerp(0.28, 0, t), 0, 0],
        rightLegRot: [lerp(-0.35, 0, t), 0, 0],
      };
    },
  },

  // 12. Prismatic Field: Elevated dual-handed ascension, staff held horizontally overhead channeling geometric matrix
  prismatic_field: {
    skillId: 'prismatic_field',
    name: 'Prismatic Field',
    animationId: 'anim_mage_prismatic_field',
    anticipationDuration: 0.2,
    executionDuration: 0.25,
    impactTiming: 0.36,
    recoveryDuration: 0.3,
    totalDuration: 0.75,
    weaponTrail: {
      enabled: true,
      colorHex: 0x38bdf8,
      trailType: 'prismatic_lattice',
      intensity: 1.0,
    },
    vfx: {
      particleCount: 40,
      particleColorHex: 0x38bdf8,
      dustBurst: false,
      sparkBurst: true,
      allyPulse: true,
      shockwaveRadius: 3.0,
    },
    soundMethod: 'playPrismaticField',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Uninterruptible after 0.2s matrix alignment.',
    combatEventSync: 'Erects 3x3 harmonic matrix zone on impact timing.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, 0.12 * t, 0],
          bodyRot: [-0.06 * t, 0, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [lerp(0, 0.01, t), lerp(0, 0.75, t), lerp(0, 0.15, t)],
          weaponRot: [0.04 * t, 0, 0.8 * t],
          shieldPos: [-0.25 * t, 0.65 * t, 0.2 * t],
          shieldRot: [0, 0.8 * t, 0],
          leftLegRot: [-0.08 * t, 0, 0],
          rightLegRot: [-0.08 * t, 0, 0],
        };
      }
      if (phase === 'execution') {
        const t = easeInOutQuad(progress);
        return {
          bodyPos: [0, lerp(0.12, 0.22, t), 0],
          bodyRot: [lerp(-0.06, -0.12, t), 0, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [lerp(0.01, 0.02, t), lerp(0.75, 1.18, t), lerp(0.15, 0.22, t)],
          weaponRot: [0.08, 0, lerp(0.8, 1.57, t)],
          shieldPos: [lerp(-0.25, -0.48, t), lerp(0.65, 1.05, t), lerp(0.2, 0.35, t)],
          shieldRot: [0, lerp(0.8, 1.57, t), 0],
          leftLegRot: [-0.15, 0, 0],
          rightLegRot: [-0.15, 0, 0],
        };
      }
      if (phase === 'impact') {
        return {
          bodyPos: [0, 0.22, 0],
          bodyRot: [-0.12, 0, 0],
          bodyScale: [1.05, 1.05, 1.05],
          weaponPos: [0.02, 1.18, 0.22],
          weaponRot: [0.08, 0, 1.57],
          shieldPos: [-0.48, 1.05, 0.35],
          shieldRot: [0, 1.57, 0],
          leftLegRot: [-0.15, 0, 0],
          rightLegRot: [-0.15, 0, 0],
        };
      }
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(0.22, 0, t), 0],
        bodyRot: [lerp(-0.12, 0, t), 0, 0],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(0.02, 0, t), lerp(1.18, 0, t), lerp(0.22, 0, t)],
        weaponRot: [lerp(0.08, 0, t), 0, lerp(1.57, 0, t)],
        shieldPos: [lerp(-0.48, 0, t), lerp(1.05, 0, t), lerp(0.35, 0, t)],
        shieldRot: [0, lerp(1.57, 0, t), 0],
        leftLegRot: [lerp(-0.15, 0, t), 0, 0],
        rightLegRot: [lerp(-0.15, 0, t), 0, 0],
      };
    },
  },
};
