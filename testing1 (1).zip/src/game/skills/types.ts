import { SkillProgressionDefinition, PlayableClassKey } from '../progressionData';
import { CharacterSubclassId } from '../rules';

export type AnimationPhase = 'anticipation' | 'execution' | 'impact' | 'recovery';

export interface RigTransform {
  bodyPos: [number, number, number];
  bodyRot: [number, number, number];
  bodyScale: [number, number, number];
  weaponPos: [number, number, number];
  weaponRot: [number, number, number];
  shieldPos?: [number, number, number];
  shieldRot?: [number, number, number];
  leftLegRot?: [number, number, number];
  rightLegRot?: [number, number, number];
}

export type TargetFacingBehavior = 'face_target' | 'maintain_facing' | 'rotate_360';
export type MovementBehavior =
  | 'in_place'
  | 'forward_step'
  | 'rush_forward'
  | 'leaping_stride'
  | 'tactical_tumble'
  | 'phase_blink';

export interface SkillAnimationConfig {
  skillId: string;
  name: string;
  animationId: string;
  anticipationDuration: number;
  executionDuration: number;
  impactTiming: number;
  recoveryDuration: number;
  sustainDuration?: number;
  totalDuration: number;
  weaponTrail: {
    enabled: boolean;
    colorHex: number;
    trailType: string;
    intensity: number;
  };
  vfx: {
    particleCount: number;
    particleColorHex: number;
    dustBurst: boolean;
    sparkBurst: boolean;
    shockwaveRadius?: number;
    allyPulse?: boolean;
    customEffect?: string;
  };
  soundMethod: string;
  targetFacingBehavior: TargetFacingBehavior;
  movementBehavior: MovementBehavior;
  cancellationRules: string;
  combatEventSync: string;
  samplePose: (progress: number, phase: AnimationPhase, isMiss?: boolean) => RigTransform;
}

export interface MasterSkillEntry {
  id: string;
  name: string;
  classKey: PlayableClassKey;
  specializationKey?: CharacterSubclassId;
  definition: SkillProgressionDefinition;
  iconReference: string;
  iconAssetPath: string;
  animationReference: string;
  animationConfig: SkillAnimationConfig;
  audioMethod: string;
  centralMechanic: string;
  tacticalExplanation: string;
  vfxSummary: {
    particleCount: number;
    particleColorHex: number;
    shockwaveRadius?: number;
    allyPulse?: boolean;
  };
}
