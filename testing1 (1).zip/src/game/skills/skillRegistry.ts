import {
  ALL_SKILLS_DATABASE,
  PlayableClassKey,
  SkillProgressionDefinition,
} from '../progressionData';
import { CharacterSubclassId } from '../rules';
import { resolveSkillIconAssetPath } from '../skillIconResolver';
import { MASTER_ANIMATION_REGISTRY } from './masterAnimationRegistry';
import { MasterSkillEntry, SkillAnimationConfig } from './types';

/**
 * DIMRAETH: THE SHATTERED OATH
 * Central 96-Skill Master Registry
 *
 * Unites every skill definition, icon asset path, procedural animation config,
 * sound method, and central mechanic under a single typed query system.
 */
function buildMasterSkillRegistry(): Record<string, MasterSkillEntry> {
  const registry: Record<string, MasterSkillEntry> = {};

  Object.values(ALL_SKILLS_DATABASE).forEach((def) => {
    const animConfig: SkillAnimationConfig =
      MASTER_ANIMATION_REGISTRY[def.id] ??
      MASTER_ANIMATION_REGISTRY.sundering_strike;

    const iconAssetPath = resolveSkillIconAssetPath(def.id, def.name);

    registry[def.id] = {
      id: def.id,
      name: def.name,
      classKey: def.classKey,
      specializationKey: def.specializationKey,
      definition: def,
      iconReference: def.iconReference,
      iconAssetPath,
      animationReference: def.animationReference,
      animationConfig: animConfig,
      audioMethod: animConfig.soundMethod,
      centralMechanic: def.centralMechanic,
      tacticalExplanation: def.tacticalExplanation,
      vfxSummary: {
        particleCount: animConfig.vfx.particleCount,
        particleColorHex: animConfig.vfx.particleColorHex,
        shockwaveRadius: animConfig.vfx.shockwaveRadius,
        allyPulse: animConfig.vfx.allyPulse,
      },
    };
  });

  return registry;
}

export const MASTER_SKILL_REGISTRY: Record<string, MasterSkillEntry> = buildMasterSkillRegistry();

export function getMasterSkill(skillId: string): MasterSkillEntry | undefined {
  return MASTER_SKILL_REGISTRY[skillId];
}

export function getAllMasterSkills(): MasterSkillEntry[] {
  return Object.values(MASTER_SKILL_REGISTRY);
}

export function getMasterSkillsByClass(classKey: PlayableClassKey): MasterSkillEntry[] {
  return Object.values(MASTER_SKILL_REGISTRY).filter((s) => s.classKey === classKey && !s.specializationKey);
}

export function getMasterSkillsBySpecialization(specKey: CharacterSubclassId): MasterSkillEntry[] {
  return Object.values(MASTER_SKILL_REGISTRY).filter((s) => s.specializationKey === specKey);
}

/**
 * Validation function verifying the three non-negotiable rules:
 * 1. NO REPEATED SKILL MECHANICS
 * 2. NO REPEATED ICON ARTWORK / ASSET PATHS
 * 3. NO REPEATED SKILL ANIMATIONS
 */
export function validateMasterSkillSystem(): {
  isValid: boolean;
  totalSkills: number;
  duplicateIds: string[];
  duplicateAnimationIds: string[];
  duplicateIconReferences: string[];
  duplicateMechanics: string[];
  missingAnimationConfigs: string[];
} {
  const skills = getAllMasterSkills();
  const seenIds = new Set<string>();
  const duplicateIds: string[] = [];

  const seenAnimIds = new Set<string>();
  const duplicateAnimationIds: string[] = [];

  const seenIcons = new Set<string>();
  const duplicateIconReferences: string[] = [];

  const seenMechanics = new Set<string>();
  const duplicateMechanics: string[] = [];

  const missingAnimationConfigs: string[] = [];

  skills.forEach((s) => {
    // 1. Skill ID
    if (seenIds.has(s.id)) {
      duplicateIds.push(s.id);
    }
    seenIds.add(s.id);

    // 2. Animation ID
    if (seenAnimIds.has(s.animationConfig.animationId)) {
      duplicateAnimationIds.push(s.animationConfig.animationId);
    }
    seenAnimIds.add(s.animationConfig.animationId);

    // Check if missing from master registry directly
    if (!MASTER_ANIMATION_REGISTRY[s.id]) {
      missingAnimationConfigs.push(s.id);
    }

    // 3. Icon Reference
    if (seenIcons.has(s.iconReference)) {
      duplicateIconReferences.push(s.iconReference);
    }
    seenIcons.add(s.iconReference);

    // 4. Central Mechanic
    const trimmedMech = s.centralMechanic.trim().toLowerCase();
    if (seenMechanics.has(trimmedMech)) {
      duplicateMechanics.push(s.centralMechanic);
    }
    seenMechanics.add(trimmedMech);
  });

  const isValid =
    skills.length === 96 &&
    duplicateIds.length === 0 &&
    duplicateAnimationIds.length === 0 &&
    duplicateIconReferences.length === 0 &&
    duplicateMechanics.length === 0 &&
    missingAnimationConfigs.length === 0;

  return {
    isValid,
    totalSkills: skills.length,
    duplicateIds,
    duplicateAnimationIds,
    duplicateIconReferences,
    duplicateMechanics,
    missingAnimationConfigs,
  };
}
