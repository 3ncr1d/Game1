import { AnimationPhase, RigTransform, SkillAnimationConfig } from './types';

function easeOutQuad(t: number): number {
  return 1 - (1 - t) * (1 - t);
}
function easeInQuad(t: number): number {
  return t * t;
}
function easeInOutQuad(t: number): number {
  return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
}
function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

export const SPECIALIZATION_ANIMATIONS: Record<string, SkillAnimationConfig> = {
  // ================= DAWN WARDEN (6) =================
  solar_flare: {
    skillId: 'solar_flare',
    name: 'Solar Flare',
    animationId: 'anim_dawn_solar_flare',
    anticipationDuration: 0.16,
    executionDuration: 0.22,
    impactTiming: 0.28,
    recoveryDuration: 0.26,
    totalDuration: 0.64,
    weaponTrail: { enabled: true, colorHex: 0xfbbf24, trailType: 'solar_flash', intensity: 0.95 },
    vfx: { particleCount: 30, particleColorHex: 0xfef08a, dustBurst: false, sparkBurst: true, shockwaveRadius: 2.2 },
    soundMethod: 'playSolarFlare',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Blinding flash bursts instantaneously.',
    combatEventSync: 'Imposes -3 on attack rolls and reveals hidden units.',
    samplePose: (p, ph) => {
      if (ph === 'anticipation') {
        const t = easeOutQuad(p);
        return {
          bodyPos: [0, -0.05 * t, -0.05 * t], bodyRot: [0.1 * t, 0.2 * t, 0], bodyScale: [1, 1, 1],
          shieldPos: [-0.15 * t, 0.15 * t, 0.1 * t], shieldRot: [0.2 * t, -0.3 * t, 0], weaponPos: [0.1 * t, 0, -0.1 * t], weaponRot: [0, 0, 0]
        };
      }
      if (ph === 'execution') {
        const t = easeOutQuad(p);
        return {
          bodyPos: [0, 0, 0.12 * t], bodyRot: [0.1, lerp(0.2, -0.15, t), 0], bodyScale: [1, 1, 1],
          shieldPos: [lerp(-0.15, 0.05, t), lerp(0.15, 0.35, t), lerp(0.1, 0.65, t)], shieldRot: [0.2, lerp(-0.3, 0.15, t), 0],
          weaponPos: [0.1, 0, 0], weaponRot: [0, 0, 0]
        };
      }
      if (ph === 'impact') {
        return {
          bodyPos: [0, 0, 0.15], bodyRot: [0.12, -0.18, 0], bodyScale: [1.05, 1.05, 1.05],
          shieldPos: [0.08, 0.38, 0.7], shieldRot: [0.22, 0.18, 0], weaponPos: [0.1, 0, 0], weaponRot: [0, 0, 0]
        };
      }
      const t = easeOutQuad(p);
      return {
        bodyPos: [0, 0, lerp(0.15, 0, t)], bodyRot: [lerp(0.12, 0, t), lerp(-0.18, 0, t), 0], bodyScale: [1, 1, 1],
        shieldPos: [lerp(0.08, 0, t), lerp(0.38, 0, t), lerp(0.7, 0, t)], shieldRot: [lerp(0.22, 0, t), lerp(0.18, 0, t), 0],
        weaponPos: [lerp(0.1, 0, t), 0, 0], weaponRot: [0, 0, 0]
      };
    }
  },

  aegis_of_the_dawn: {
    skillId: 'aegis_of_the_dawn',
    name: 'Aegis of the Dawn',
    animationId: 'anim_dawn_aegis_of_the_dawn',
    anticipationDuration: 0.2,
    executionDuration: 0.28,
    impactTiming: 0.38,
    recoveryDuration: 0.28,
    totalDuration: 0.76,
    weaponTrail: { enabled: false, colorHex: 0xf59e0b, trailType: 'dawn_pavilion', intensity: 0.8 },
    vfx: { particleCount: 26, particleColorHex: 0xf59e0b, dustBurst: false, sparkBurst: true, allyPulse: true },
    soundMethod: 'playAegisOfTheDawn',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Barrier explodes in radiant light upon destruction.',
    combatEventSync: 'Envelops ally in a solar barrier absorbing 15 damage.',
    samplePose: (p, ph) => {
      if (ph === 'anticipation') {
        const t = easeOutQuad(p);
        return { bodyPos: [0, 0.05 * t, 0], bodyRot: [-0.12 * t, 0, 0], bodyScale: [1, 1, 1], weaponPos: [0.1 * t, 0.4 * t, 0], weaponRot: [-0.3 * t, 0, 0] };
      }
      if (ph === 'execution') {
        const t = easeInOutQuad(p);
        return { bodyPos: [0, lerp(0.05, 0.15, t), 0], bodyRot: [lerp(-0.12, -0.25, t), 0, 0], bodyScale: [1, 1.03, 1], weaponPos: [0.1, lerp(0.4, 0.75, t), 0.1 * t], weaponRot: [lerp(-0.3, 0.1, t), 0, 0.2 * t] };
      }
      if (ph === 'impact') {
        return { bodyPos: [0, 0.18, 0], bodyRot: [-0.28, 0, 0], bodyScale: [1.05, 1.05, 1.05], weaponPos: [0.12, 0.8, 0.12], weaponRot: [0.15, 0, 0.25] };
      }
      const t = easeOutQuad(p);
      return { bodyPos: [0, lerp(0.18, 0, t), 0], bodyRot: [lerp(-0.28, 0, t), 0, 0], bodyScale: [1, 1, 1], weaponPos: [lerp(0.12, 0, t), lerp(0.8, 0, t), lerp(0.12, 0, t)], weaponRot: [lerp(0.15, 0, t), 0, lerp(0.25, 0, t)] };
    }
  },

  daybreak_smite: {
    skillId: 'daybreak_smite',
    name: 'Daybreak Smite',
    animationId: 'anim_dawn_daybreak_smite',
    anticipationDuration: 0.22,
    executionDuration: 0.3,
    impactTiming: 0.4,
    recoveryDuration: 0.3,
    totalDuration: 0.82,
    weaponTrail: { enabled: true, colorHex: 0xf59e0b, trailType: 'solar_uppercut', intensity: 0.95 },
    vfx: { particleCount: 32, particleColorHex: 0xf59e0b, dustBurst: true, sparkBurst: true, shockwaveRadius: 1.8 },
    soundMethod: 'playDaybreakSmite',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'forward_step',
    cancellationRules: 'Ascending solar uppercut carries through.',
    combatEventSync: 'Purifies tile and deals massive radiant damage to corrupted foes.',
    samplePose: (p, ph, isMiss) => {
      if (ph === 'anticipation') {
        const t = easeOutQuad(p);
        return { bodyPos: [0, -0.15 * t, -0.1 * t], bodyRot: [0.25 * t, -0.3 * t, 0], bodyScale: [1, 1, 1], weaponPos: [0.1 * t, -0.3 * t, -0.15 * t], weaponRot: [0.8 * t, -0.5 * t, 0] };
      }
      if (ph === 'execution') {
        const t = easeOutQuad(p);
        const missOffset = isMiss ? 0.3 : 0;
        return { bodyPos: [0, lerp(-0.15, 0.1, t), lerp(-0.1, 0.35, t)], bodyRot: [lerp(0.25, -0.35, t), lerp(-0.3, 0.4 + missOffset, t), 0], bodyScale: [1, 1, 1], weaponPos: [lerp(0.1, 0.35, t), lerp(-0.3, 0.75, t), lerp(-0.15, 0.85, t)], weaponRot: [lerp(0.8, -0.85, t), lerp(-0.5, 0.6, t), 0] };
      }
      if (ph === 'impact') {
        return { bodyPos: [0, 0.12, 0.38], bodyRot: [-0.38, 0.45, 0], bodyScale: [1.06, 1.06, 1.06], weaponPos: [0.38, 0.8, 0.9], weaponRot: [-0.9, 0.65, 0] };
      }
      const t = easeOutQuad(p);
      return { bodyPos: [0, lerp(0.12, 0, t), lerp(0.38, 0, t)], bodyRot: [lerp(-0.38, 0, t), lerp(0.45, 0, t), 0], bodyScale: [1, 1, 1], weaponPos: [lerp(0.38, 0, t), lerp(0.8, 0, t), lerp(0.9, 0, t)], weaponRot: [lerp(-0.9, 0, t), lerp(0.65, 0, t), 0] };
    }
  },

  sunwell_aura: {
    skillId: 'sunwell_aura',
    name: 'Sunwell Aura',
    animationId: 'anim_dawn_sunwell_aura',
    anticipationDuration: 0.2,
    executionDuration: 0.28,
    impactTiming: 0.38,
    recoveryDuration: 0.28,
    totalDuration: 0.76,
    weaponTrail: { enabled: false, colorHex: 0xfde047, trailType: 'sunwell_ripple', intensity: 0.75 },
    vfx: { particleCount: 26, particleColorHex: 0xfde047, dustBurst: false, sparkBurst: false, shockwaveRadius: 2.6, allyPulse: true },
    soundMethod: 'playSunwellAura',
    targetFacingBehavior: 'maintain_facing',
    movementBehavior: 'in_place',
    cancellationRules: 'Sanctified pools ripple persistently.',
    combatEventSync: 'Party members in sanctified pools gain +5 Temp HP & +1 AP.',
    samplePose: (p, ph) => {
      if (ph === 'anticipation') {
        const t = easeOutQuad(p);
        return { bodyPos: [0, -0.06 * t, 0], bodyRot: [0.1 * t, 0, 0], bodyScale: [1, 1, 1], weaponPos: [0.1 * t, 0.2 * t, 0], weaponRot: [0.2 * t, 0, 0] };
      }
      if (ph === 'execution') {
        const t = easeInOutQuad(p);
        return { bodyPos: [0, lerp(-0.06, -0.18, t), 0], bodyRot: [lerp(0.1, 0.25, t), 0, 0], bodyScale: [1.04, 0.94, 1.04], weaponPos: [0.1, lerp(0.2, -0.35, t), 0.2 * t], weaponRot: [lerp(0.2, 0.6, t), 0, 0] };
      }
      if (ph === 'impact') {
        return { bodyPos: [0, -0.2, 0], bodyRot: [0.28, 0, 0], bodyScale: [1.06, 0.92, 1.06], weaponPos: [0.1, -0.38, 0.25], weaponRot: [0.65, 0, 0] };
      }
      const t = easeOutQuad(p);
      return { bodyPos: [0, lerp(-0.2, 0, t), 0], bodyRot: [lerp(0.28, 0, t), 0, 0], bodyScale: [1, 1, 1], weaponPos: [lerp(0.1, 0, t), lerp(-0.38, 0, t), lerp(0.25, 0, t)], weaponRot: [lerp(0.65, 0, t), 0, 0] };
    }
  },

  radiant_bastion: {
    skillId: 'radiant_bastion',
    name: 'Radiant Bastion',
    animationId: 'anim_dawn_radiant_bastion',
    anticipationDuration: 0.24,
    executionDuration: 0.32,
    impactTiming: 0.44,
    recoveryDuration: 0.32,
    totalDuration: 0.88,
    weaponTrail: { enabled: true, colorHex: 0xf59e0b, trailType: 'bastion_fortress', intensity: 0.9 },
    vfx: { particleCount: 34, particleColorHex: 0xf59e0b, dustBurst: true, sparkBurst: true, shockwaveRadius: 3.0, allyPulse: true },
    soundMethod: 'playRadiantBastion',
    targetFacingBehavior: 'maintain_facing',
    movementBehavior: 'in_place',
    cancellationRules: 'Gleaming pavilion gives complete debuff immunity for 2 turns.',
    combatEventSync: 'Erects pavilion: Party members gain +3 AC and debuff immunity.',
    samplePose: (p, ph) => {
      if (ph === 'anticipation') {
        const t = easeOutQuad(p);
        return { bodyPos: [0, 0.1 * t, -0.1 * t], bodyRot: [-0.25 * t, 0, 0], bodyScale: [1, 1, 1], weaponPos: [0.1 * t, 0.65 * t, -0.2 * t], weaponRot: [-0.6 * t, 0, 0], shieldPos: [-0.15 * t, 0.3 * t, 0], shieldRot: [0, 0.3 * t, 0] };
      }
      if (ph === 'execution') {
        const t = easeInQuad(p);
        return { bodyPos: [0, lerp(0.1, -0.18, t), 0.15 * t], bodyRot: [lerp(-0.25, 0.45, t), 0, 0], bodyScale: [1, 1, 1], weaponPos: [0.1, lerp(0.65, -0.4, t), lerp(-0.2, 0.65, t)], weaponRot: [lerp(-0.6, 0.9, t), 0, 0], shieldPos: [-0.15, lerp(0.3, -0.1, t), 0.2 * t], shieldRot: [0, 0.3, 0] };
      }
      if (ph === 'impact') {
        return { bodyPos: [0, -0.2, 0.18], bodyRot: [0.5, 0, 0], bodyScale: [1.08, 0.92, 1.08], weaponPos: [0.1, -0.45, 0.7], weaponRot: [0.95, 0, 0], shieldPos: [-0.15, -0.12, 0.25], shieldRot: [0, 0.35, 0] };
      }
      const t = easeOutQuad(p);
      return { bodyPos: [0, lerp(-0.2, 0, t), lerp(0.18, 0, t)], bodyRot: [lerp(0.5, 0, t), 0, 0], bodyScale: [1, 1, 1], weaponPos: [lerp(0.1, 0, t), lerp(-0.45, 0, t), lerp(0.7, 0, t)], weaponRot: [lerp(0.95, 0, t), 0, 0], shieldPos: [lerp(-0.15, 0, t), lerp(-0.12, 0, t), lerp(0.25, 0, t)], shieldRot: [0, lerp(0.35, 0, t), 0] };
    }
  },

  avatar_of_the_sun: {
    skillId: 'avatar_of_the_sun',
    name: 'Avatar of the Sun',
    animationId: 'anim_dawn_avatar_of_the_sun',
    anticipationDuration: 0.28,
    executionDuration: 0.4,
    impactTiming: 0.56,
    recoveryDuration: 0.44,
    totalDuration: 1.12,
    weaponTrail: { enabled: false, colorHex: 0xfef08a, trailType: 'avatar_ascension', intensity: 1.0 },
    vfx: { particleCount: 48, particleColorHex: 0xfef08a, dustBurst: false, sparkBurst: true, shockwaveRadius: 3.5, allyPulse: true },
    soundMethod: 'playAvatarOfTheSun',
    targetFacingBehavior: 'maintain_facing',
    movementBehavior: 'in_place',
    cancellationRules: 'Living incarnation of the Dawn transformation cannot be stopped.',
    combatEventSync: 'Transforms into Avatar of Dawn: Radiant shockwaves, +8 DMG, party regen.',
    samplePose: (p, ph) => {
      if (ph === 'anticipation') {
        const t = easeOutQuad(p);
        return { bodyPos: [0, 0.15 * t, 0], bodyRot: [-0.2 * t, 0, 0], bodyScale: [1, 1, 1], weaponPos: [0.2 * t, 0.5 * t, 0], weaponRot: [0.2 * t, 0, 0.3 * t] };
      }
      if (ph === 'execution') {
        const t = easeInOutQuad(p);
        return { bodyPos: [0, lerp(0.15, 0.35, t), 0], bodyRot: [lerp(-0.2, -0.38, t), 0, 0], bodyScale: [1, 1.06, 1], weaponPos: [lerp(0.2, 0.35, t), lerp(0.5, 0.95, t), 0.1 * t], weaponRot: [lerp(0.2, 0.35, t), 0, lerp(0.3, 0.6, t)] };
      }
      if (ph === 'impact') {
        return { bodyPos: [0, 0.38, 0], bodyRot: [-0.4, 0, 0], bodyScale: [1.1, 1.1, 1.1], weaponPos: [0.38, 1.0, 0.12], weaponRot: [0.38, 0, 0.65] };
      }
      const t = easeOutQuad(p);
      return { bodyPos: [0, lerp(0.38, 0, t), 0], bodyRot: [lerp(-0.4, 0, t), 0, 0], bodyScale: [1, 1, 1], weaponPos: [lerp(0.38, 0, t), lerp(1.0, 0, t), lerp(0.12, 0, t)], weaponRot: [lerp(0.38, 0, t), 0, lerp(0.65, 0, t)] };
    }
  },

  // ================= VENGEANCE KNIGHT (6) =================
  retribution_strike: {
    skillId: 'retribution_strike',
    name: 'Retribution Strike',
    animationId: 'anim_vengeance_retribution_strike',
    anticipationDuration: 0.18,
    executionDuration: 0.28,
    impactTiming: 0.36,
    recoveryDuration: 0.28,
    totalDuration: 0.74,
    weaponTrail: { enabled: true, colorHex: 0xef4444, trailType: 'fury_slash', intensity: 0.95 },
    vfx: { particleCount: 26, particleColorHex: 0xdc2626, dustBurst: true, sparkBurst: true },
    soundMethod: 'playRetributionStrike',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'forward_step',
    cancellationRules: 'Fury-fueled strike commits fully.',
    combatEventSync: 'Deals +1 bonus damage for every 5% missing health.',
    samplePose: (p, ph, isMiss) => {
      if (ph === 'anticipation') {
        const t = easeOutQuad(p);
        return { bodyPos: [0, -0.08 * t, -0.12 * t], bodyRot: [0.2 * t, -0.4 * t, 0], bodyScale: [1, 1, 1], weaponPos: [-0.2 * t, 0.2 * t, -0.2 * t], weaponRot: [-0.4 * t, -0.6 * t, 0.3 * t] };
      }
      if (ph === 'execution') {
        const t = easeOutQuad(p);
        const missOffset = isMiss ? 0.3 : 0;
        return { bodyPos: [0, 0, lerp(-0.12, 0.38, t)], bodyRot: [0.2, lerp(-0.4, 0.65 + missOffset, t), 0], bodyScale: [1, 1, 1], weaponPos: [lerp(-0.2, 0.45, t), lerp(0.2, 0.18, t), lerp(-0.2, 0.9, t)], weaponRot: [lerp(-0.4, 0.2, t), lerp(-0.6, 1.25, t), lerp(0.3, -0.4, t)] };
      }
      if (ph === 'impact') {
        return { bodyPos: [0, 0, 0.42], bodyRot: [0.22, 0.7, 0], bodyScale: [1.05, 1.05, 1.05], weaponPos: [0.48, 0.2, 0.95], weaponRot: [0.22, 1.3, -0.45] };
      }
      const t = easeOutQuad(p);
      return { bodyPos: [0, 0, lerp(0.42, 0, t)], bodyRot: [lerp(0.22, 0, t), lerp(0.7, 0, t), 0], bodyScale: [1, 1, 1], weaponPos: [lerp(0.48, 0, t), lerp(0.2, 0, t), lerp(0.95, 0, t)], weaponRot: [lerp(0.22, 0, t), lerp(1.3, 0, t), lerp(-0.45, 0, t)] };
    }
  },

  spiteful_ward: {
    skillId: 'spiteful_ward',
    name: 'Spiteful Ward',
    animationId: 'anim_vengeance_spiteful_ward',
    anticipationDuration: 0.18,
    executionDuration: 0.24,
    impactTiming: 0.32,
    recoveryDuration: 0.26,
    totalDuration: 0.68,
    weaponTrail: { enabled: false, colorHex: 0x991b1b, trailType: 'spiked_ward', intensity: 0.7 },
    vfx: { particleCount: 20, particleColorHex: 0x991b1b, dustBurst: false, sparkBurst: true },
    soundMethod: 'playSpitefulWard',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Spiked ward reflects melee damage and inflicts Sundered.',
    combatEventSync: 'When struck, reflects 6 physical damage and sunders attacker.',
    samplePose: (p, ph) => {
      if (ph === 'anticipation') {
        const t = easeOutQuad(p);
        return { bodyPos: [0, -0.05 * t, -0.06 * t], bodyRot: [0.1 * t, 0.2 * t, 0], bodyScale: [1, 1, 1], shieldPos: [-0.15 * t, 0.1 * t, 0.1 * t], shieldRot: [0.2 * t, -0.3 * t, 0], weaponPos: [0.15 * t, 0, -0.1 * t], weaponRot: [0.3 * t, 0, 0] };
      }
      if (ph === 'execution') {
        const t = easeOutQuad(p);
        return { bodyPos: [0, -0.05, 0.15 * t], bodyRot: [0.1, lerp(0.2, -0.15, t), 0], bodyScale: [1, 1, 1], shieldPos: [lerp(-0.15, 0.05, t), lerp(0.1, 0.3, t), lerp(0.1, 0.65, t)], shieldRot: [0.2, lerp(-0.3, 0.15, t), 0], weaponPos: [0.15, 0, 0], weaponRot: [0.3, 0, 0] };
      }
      if (ph === 'impact') {
        return { bodyPos: [0, -0.05, 0.18], bodyRot: [0.12, -0.18, 0], bodyScale: [1.04, 1.04, 1.04], shieldPos: [0.08, 0.32, 0.7], shieldRot: [0.22, 0.18, 0], weaponPos: [0.15, 0, 0], weaponRot: [0.3, 0, 0] };
      }
      const t = easeOutQuad(p);
      return { bodyPos: [0, lerp(-0.05, 0, t), lerp(0.18, 0, t)], bodyRot: [lerp(0.12, 0, t), lerp(-0.18, 0, t), 0], bodyScale: [1, 1, 1], shieldPos: [lerp(0.08, 0, t), lerp(0.32, 0, t), lerp(0.7, 0, t)], shieldRot: [lerp(0.22, 0, t), lerp(0.18, 0, t), 0], weaponPos: [lerp(0.15, 0, t), 0, 0], weaponRot: [lerp(0.3, 0, t), 0, 0] };
    }
  },

  dread_inscription: {
    skillId: 'dread_inscription',
    name: 'Dread Inscription',
    animationId: 'anim_vengeance_dread_inscription',
    anticipationDuration: 0.18,
    executionDuration: 0.24,
    impactTiming: 0.32,
    recoveryDuration: 0.26,
    totalDuration: 0.68,
    weaponTrail: { enabled: true, colorHex: 0xdc2626, trailType: 'blood_carve', intensity: 0.85 },
    vfx: { particleCount: 22, particleColorHex: 0xdc2626, dustBurst: false, sparkBurst: true },
    soundMethod: 'playDreadInscription',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Blood vow inscribed on target in air.',
    combatEventSync: 'Gains +2 Move toward foe; attacks deal +5 bonus damage.',
    samplePose: (p, ph) => {
      if (ph === 'anticipation') {
        const t = easeOutQuad(p);
        return { bodyPos: [0, 0, -0.05 * t], bodyRot: [-0.08 * t, -0.2 * t, 0], bodyScale: [1, 1, 1], weaponPos: [0.1 * t, 0.25 * t, -0.1 * t], weaponRot: [-0.3 * t, 0.2 * t, 0] };
      }
      if (ph === 'execution') {
        const t = easeOutQuad(p);
        return { bodyPos: [0, 0, 0.15 * t], bodyRot: [lerp(-0.08, 0.12, t), lerp(-0.2, 0.25, t), 0], bodyScale: [1, 1, 1], weaponPos: [lerp(0.1, 0.35, t), lerp(0.25, 0.28, t), lerp(-0.1, 0.85, t)], weaponRot: [lerp(-0.3, -0.15, t), lerp(0.2, 0.4, t), 0] };
      }
      if (ph === 'impact') {
        return { bodyPos: [0, 0, 0.18], bodyRot: [0.14, 0.28, 0], bodyScale: [1.02, 1.02, 1.02], weaponPos: [0.38, 0.3, 0.92], weaponRot: [-0.18, 0.45, 0] };
      }
      const t = easeOutQuad(p);
      return { bodyPos: [0, 0, lerp(0.18, 0, t)], bodyRot: [lerp(0.14, 0, t), lerp(0.28, 0, t), 0], bodyScale: [1, 1, 1], weaponPos: [lerp(0.38, 0, t), lerp(0.3, 0, t), lerp(0.92, 0, t)], weaponRot: [lerp(-0.18, 0, t), lerp(0.45, 0, t), 0] };
    }
  },

  unrelenting_vengeance: {
    skillId: 'unrelenting_vengeance',
    name: 'Unrelenting Vengeance',
    animationId: 'anim_vengeance_unrelenting_vengeance',
    anticipationDuration: 0.2,
    executionDuration: 0.28,
    impactTiming: 0.38,
    recoveryDuration: 0.28,
    totalDuration: 0.76,
    weaponTrail: { enabled: false, colorHex: 0x991b1b, trailType: 'frenzy_glow', intensity: 0.8 },
    vfx: { particleCount: 26, particleColorHex: 0x991b1b, dustBurst: false, sparkBurst: true, allyPulse: true },
    soundMethod: 'playUnrelentingVengeance',
    targetFacingBehavior: 'maintain_facing',
    movementBehavior: 'in_place',
    cancellationRules: 'Crimson rage surges when ally is imperiled.',
    combatEventSync: 'When companion drops below 20% HP or downed: +2 AP & +3 STR next turn.',
    samplePose: (p, ph) => {
      if (ph === 'anticipation') {
        const t = easeOutQuad(p);
        return { bodyPos: [0, 0.08 * t, 0], bodyRot: [-0.2 * t, 0, 0], bodyScale: [1, 1, 1], weaponPos: [0.1 * t, 0.35 * t, 0], weaponRot: [0.2 * t, 0, 0] };
      }
      if (ph === 'execution') {
        const t = easeInOutQuad(p);
        return { bodyPos: [0, lerp(0.08, 0.15, t), 0], bodyRot: [lerp(-0.2, -0.32, t), 0, 0], bodyScale: [1.05, 1.05, 1.05], weaponPos: [0.1, lerp(0.35, 0.65, t), 0.1 * t], weaponRot: [lerp(0.2, 0.35, t), 0, 0] };
      }
      if (ph === 'impact') {
        return { bodyPos: [0, 0.18, 0], bodyRot: [-0.35, 0, 0], bodyScale: [1.08, 1.08, 1.08], weaponPos: [0.12, 0.7, 0.12], weaponRot: [0.38, 0, 0] };
      }
      const t = easeOutQuad(p);
      return { bodyPos: [0, lerp(0.18, 0, t), 0], bodyRot: [lerp(-0.35, 0, t), 0, 0], bodyScale: [1, 1, 1], weaponPos: [lerp(0.12, 0, t), lerp(0.7, 0, t), lerp(0.12, 0, t)], weaponRot: [lerp(0.38, 0, t), 0, 0] };
    }
  },

  executioners_wrath: {
    skillId: 'executioners_wrath',
    name: 'Executioner\'s Wrath',
    animationId: 'anim_vengeance_executioners_wrath',
    anticipationDuration: 0.24,
    executionDuration: 0.32,
    impactTiming: 0.44,
    recoveryDuration: 0.34,
    totalDuration: 0.9,
    weaponTrail: { enabled: true, colorHex: 0xdc2626, trailType: 'guillotine_chop', intensity: 1.0 },
    vfx: { particleCount: 36, particleColorHex: 0xdc2626, dustBurst: true, sparkBurst: true, shockwaveRadius: 2.0 },
    soundMethod: 'playExecutionersWrath',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'forward_step',
    cancellationRules: 'Guillotine execution chop commits fully.',
    combatEventSync: 'Double damage if target is below 40% HP; knocks back 2 tiles.',
    samplePose: (p, ph, isMiss) => {
      if (ph === 'anticipation') {
        const t = easeOutQuad(p);
        return { bodyPos: [0, 0.12 * t, -0.15 * t], bodyRot: [-0.3 * t, 0, 0], bodyScale: [1, 1, 1], weaponPos: [0.1 * t, 0.75 * t, -0.25 * t], weaponRot: [-0.85 * t, 0, 0] };
      }
      if (ph === 'execution') {
        const t = easeInQuad(p);
        const missOffset = isMiss ? 0.3 : 0;
        return { bodyPos: [0, lerp(0.12, -0.18, t), lerp(-0.15, 0.4, t)], bodyRot: [lerp(-0.3, 0.5, t), missOffset, 0], bodyScale: [1, 1, 1], weaponPos: [lerp(0.1, 0.3, t), lerp(0.75, -0.35, t), lerp(-0.25, 0.9, t)], weaponRot: [lerp(-0.85, 1.2, t), 0, 0] };
      }
      if (ph === 'impact') {
        return { bodyPos: [0, -0.2, 0.45], bodyRot: [0.55, 0, 0], bodyScale: [1.1, 0.9, 1.1], weaponPos: [0.32, -0.4, 0.95], weaponRot: [1.25, 0, 0] };
      }
      const t = easeOutQuad(p);
      return { bodyPos: [0, lerp(-0.2, 0, t), lerp(0.45, 0, t)], bodyRot: [lerp(0.55, 0, t), 0, 0], bodyScale: [1, 1, 1], weaponPos: [lerp(0.32, 0, t), lerp(-0.4, 0, t), lerp(0.95, 0, t)], weaponRot: [lerp(1.25, 0, t), 0, 0] };
    }
  },

  oath_of_total_ruin: {
    skillId: 'oath_of_total_ruin',
    name: 'Oath of Total Ruin',
    animationId: 'anim_vengeance_oath_of_total_ruin',
    anticipationDuration: 0.28,
    executionDuration: 0.38,
    impactTiming: 0.52,
    recoveryDuration: 0.4,
    totalDuration: 1.06,
    weaponTrail: { enabled: true, colorHex: 0x991b1b, trailType: 'total_ruin', intensity: 1.0 },
    vfx: { particleCount: 46, particleColorHex: 0x991b1b, dustBurst: true, sparkBurst: true, shockwaveRadius: 3.4 },
    soundMethod: 'playOathOfTotalRuin',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Unchains total destructive vengeance across battlefield.',
    combatEventSync: 'Attacks ignore armor, trigger shockwaves, grants 20 Temp HP.',
    samplePose: (p, ph) => {
      if (ph === 'anticipation') {
        const t = easeOutQuad(p);
        return { bodyPos: [0, 0.15 * t, -0.1 * t], bodyRot: [-0.35 * t, 0, 0], bodyScale: [1, 1, 1], weaponPos: [0, 0.7 * t, -0.2 * t], weaponRot: [-0.8 * t, 0, 0] };
      }
      if (ph === 'execution') {
        const t = easeInQuad(p);
        return { bodyPos: [0, lerp(0.15, -0.22, t), 0.2 * t], bodyRot: [lerp(-0.35, 0.55, t), 0, 0], bodyScale: [1, 1, 1], weaponPos: [0, lerp(0.7, -0.45, t), lerp(-0.2, 0.75, t)], weaponRot: [lerp(-0.8, 1.25, t), 0, 0] };
      }
      if (ph === 'impact') {
        return { bodyPos: [0, -0.25, 0.25], bodyRot: [0.6, 0, 0], bodyScale: [1.12, 0.88, 1.12], weaponPos: [0, -0.5, 0.8], weaponRot: [1.3, 0, 0] };
      }
      const t = easeOutQuad(p);
      return { bodyPos: [0, lerp(-0.25, 0, t), lerp(0.25, 0, t)], bodyRot: [lerp(0.6, 0, t), 0, 0], bodyScale: [1, 1, 1], weaponPos: [0, lerp(-0.5, 0, t), lerp(0.8, 0, t)], weaponRot: [lerp(1.3, 0, t), 0, 0] };
    }
  },

  // ================= CRIMSON SAVANT (6) =================
  blood_siphon: {
    skillId: 'blood_siphon',
    name: 'Blood Siphon',
    animationId: 'anim_crimson_blood_siphon',
    anticipationDuration: 0.18,
    executionDuration: 0.26,
    impactTiming: 0.34,
    recoveryDuration: 0.28,
    totalDuration: 0.72,
    weaponTrail: { enabled: true, colorHex: 0xdc2626, trailType: 'siphon_stream', intensity: 0.85 },
    vfx: { particleCount: 24, particleColorHex: 0xdc2626, dustBurst: false, sparkBurst: true },
    soundMethod: 'playBloodSiphon',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Life essence siphons through astral conduits.',
    combatEventSync: 'Deals necrotic damage and heals savant for 50% of damage dealt.',
    samplePose: (p, ph) => {
      if (ph === 'anticipation') {
        const t = easeOutQuad(p);
        return { bodyPos: [0, 0, -0.06 * t], bodyRot: [-0.1 * t, -0.2 * t, 0], bodyScale: [1, 1, 1], weaponPos: [0.15 * t, 0.2 * t, -0.1 * t], weaponRot: [-0.3 * t, 0.2 * t, 0] };
      }
      if (ph === 'execution') {
        const t = easeOutQuad(p);
        return { bodyPos: [0, 0, 0.12 * t], bodyRot: [lerp(-0.1, 0.14, t), lerp(-0.2, 0.25, t), 0], bodyScale: [1, 1, 1], weaponPos: [lerp(0.15, 0.35, t), lerp(0.2, 0.3, t), lerp(-0.1, 0.85, t)], weaponRot: [lerp(-0.3, -0.15, t), lerp(0.2, 0.45, t), 0] };
      }
      if (ph === 'impact') {
        return { bodyPos: [0, 0, 0.15], bodyRot: [0.16, 0.28, 0], bodyScale: [1.03, 1.03, 1.03], weaponPos: [0.38, 0.32, 0.92], weaponRot: [-0.18, 0.5, 0] };
      }
      const t = easeOutQuad(p);
      return { bodyPos: [0, 0, lerp(0.15, 0, t)], bodyRot: [lerp(0.16, 0, t), lerp(0.28, 0, t), 0], bodyScale: [1, 1, 1], weaponPos: [lerp(0.38, 0, t), lerp(0.32, 0, t), lerp(0.92, 0, t)], weaponRot: [lerp(-0.18, 0, t), lerp(0.5, 0, t), 0] };
    }
  },

  boiling_veins: {
    skillId: 'boiling_veins',
    name: 'Boiling Veins',
    animationId: 'anim_crimson_boiling_veins',
    anticipationDuration: 0.16,
    executionDuration: 0.22,
    impactTiming: 0.28,
    recoveryDuration: 0.26,
    totalDuration: 0.64,
    weaponTrail: { enabled: true, colorHex: 0xf97316, trailType: 'boil_ignite', intensity: 0.9 },
    vfx: { particleCount: 22, particleColorHex: 0xf97316, dustBurst: false, sparkBurst: true },
    soundMethod: 'playBoilingVeins',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Target blood ignites from within.',
    combatEventSync: 'Inflicts Burning; movement deals extra damage and creates fire tiles.',
    samplePose: (p, ph) => {
      if (ph === 'anticipation') {
        const t = easeOutQuad(p);
        return { bodyPos: [0, 0, -0.05 * t], bodyRot: [0.1 * t, -0.3 * t, 0], bodyScale: [1, 1, 1], weaponPos: [-0.1 * t, 0.1 * t, -0.15 * t], weaponRot: [0.3 * t, -0.4 * t, 0] };
      }
      if (ph === 'execution') {
        const t = easeOutQuad(p);
        return { bodyPos: [0, 0, 0.15 * t], bodyRot: [0.1, lerp(-0.3, 0.35, t), 0], bodyScale: [1, 1, 1], weaponPos: [lerp(-0.1, 0.35, t), lerp(0.1, 0.25, t), lerp(-0.15, 0.8, t)], weaponRot: [lerp(0.3, -0.2, t), lerp(-0.4, 0.6, t), 0] };
      }
      if (ph === 'impact') {
        return { bodyPos: [0, 0, 0.18], bodyRot: [0.12, 0.4, 0], bodyScale: [1.02, 1.02, 1.02], weaponPos: [0.38, 0.28, 0.88], weaponRot: [-0.22, 0.65, 0] };
      }
      const t = easeOutQuad(p);
      return { bodyPos: [0, 0, lerp(0.18, 0, t)], bodyRot: [lerp(0.12, 0, t), lerp(0.4, 0, t), 0], bodyScale: [1, 1, 1], weaponPos: [lerp(0.38, 0, t), lerp(0.28, 0, t), lerp(0.88, 0, t)], weaponRot: [lerp(-0.22, 0, t), lerp(0.65, 0, t), 0] };
    }
  },

  sanguine_transfusion: {
    skillId: 'sanguine_transfusion',
    name: 'Sanguine Transfusion',
    animationId: 'anim_crimson_sanguine_transfusion',
    anticipationDuration: 0.2,
    executionDuration: 0.28,
    impactTiming: 0.38,
    recoveryDuration: 0.28,
    totalDuration: 0.76,
    weaponTrail: { enabled: false, colorHex: 0xdc2626, trailType: 'transfusion_arc', intensity: 0.75 },
    vfx: { particleCount: 24, particleColorHex: 0xdc2626, dustBurst: false, sparkBurst: false, allyPulse: true },
    soundMethod: 'playSanguineTransfusion',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Sacrifices 6 HP to restore 16 HP to ally.',
    combatEventSync: 'Sacrifices 6 HP: Restores 16 HP to ally and grants +1 AP next turn.',
    samplePose: (p, ph) => {
      if (ph === 'anticipation') {
        const t = easeOutQuad(p);
        return { bodyPos: [0, -0.05 * t, 0], bodyRot: [0.15 * t, 0, 0], bodyScale: [1, 1, 1], weaponPos: [-0.1 * t, 0.2 * t, 0], weaponRot: [0.3 * t, 0, 0] };
      }
      if (ph === 'execution') {
        const t = easeInOutQuad(p);
        return { bodyPos: [0, 0, 0.12 * t], bodyRot: [lerp(0.15, -0.2, t), 0, 0], bodyScale: [1, 1.02, 1], weaponPos: [lerp(-0.1, 0.25, t), lerp(0.2, 0.45, t), 0.1 * t], weaponRot: [lerp(0.3, 0.1, t), 0, 0] };
      }
      if (ph === 'impact') {
        return { bodyPos: [0, 0, 0.15], bodyRot: [-0.22, 0, 0], bodyScale: [1.04, 1.04, 1.04], weaponPos: [0.28, 0.48, 0.12], weaponRot: [0.12, 0, 0] };
      }
      const t = easeOutQuad(p);
      return { bodyPos: [0, 0, lerp(0.15, 0, t)], bodyRot: [lerp(-0.22, 0, t), 0, 0], bodyScale: [1, 1, 1], weaponPos: [lerp(0.28, 0, t), lerp(0.48, 0, t), lerp(0.12, 0, t)], weaponRot: [lerp(0.12, 0, t), 0, 0] };
    }
  },

  hemorrhage_curse: {
    skillId: 'hemorrhage_curse',
    name: 'Hemorrhage Curse',
    animationId: 'anim_crimson_hemorrhage_curse',
    anticipationDuration: 0.18,
    executionDuration: 0.26,
    impactTiming: 0.34,
    recoveryDuration: 0.26,
    totalDuration: 0.7,
    weaponTrail: { enabled: true, colorHex: 0x991b1b, trailType: 'curse_seal', intensity: 0.8 },
    vfx: { particleCount: 22, particleColorHex: 0x991b1b, dustBurst: false, sparkBurst: true },
    soundMethod: 'playHemorrhageCurse',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Curse seal amplifies subsequent strikes.',
    combatEventSync: 'Enemies with Burning take +4 extra damage from arcane/shadow strikes.',
    samplePose: (p, ph) => {
      if (ph === 'anticipation') {
        const t = easeOutQuad(p);
        return { bodyPos: [0, 0, -0.05 * t], bodyRot: [0, -0.25 * t, 0], bodyScale: [1, 1, 1], weaponPos: [0.1 * t, 0.3 * t, -0.1 * t], weaponRot: [-0.3 * t, 0.3 * t, 0] };
      }
      if (ph === 'execution') {
        const t = easeOutQuad(p);
        return { bodyPos: [0, 0, 0.12 * t], bodyRot: [0, lerp(-0.25, 0.3, t), 0], bodyScale: [1, 1, 1], weaponPos: [lerp(0.1, 0.35, t), lerp(0.3, 0.25, t), lerp(-0.1, 0.8, t)], weaponRot: [lerp(-0.3, -0.1, t), lerp(0.3, 0.5, t), 0] };
      }
      if (ph === 'impact') {
        return { bodyPos: [0, 0, 0.15], bodyRot: [0, 0.35, 0], bodyScale: [1.02, 1.02, 1.02], weaponPos: [0.38, 0.28, 0.85], weaponRot: [-0.12, 0.55, 0] };
      }
      const t = easeOutQuad(p);
      return { bodyPos: [0, 0, lerp(0.15, 0, t)], bodyRot: [0, lerp(0.35, 0, t), 0], bodyScale: [1, 1, 1], weaponPos: [lerp(0.38, 0, t), lerp(0.28, 0, t), lerp(0.85, 0, t)], weaponRot: [lerp(-0.12, 0, t), lerp(0.55, 0, t), 0] };
    }
  },

  crimson_maelstrom: {
    skillId: 'crimson_maelstrom',
    name: 'Crimson Maelstrom',
    animationId: 'anim_crimson_crimson_maelstrom',
    anticipationDuration: 0.24,
    executionDuration: 0.34,
    impactTiming: 0.46,
    recoveryDuration: 0.34,
    totalDuration: 0.92,
    weaponTrail: { enabled: true, colorHex: 0xdc2626, trailType: 'blood_vortex', intensity: 0.95 },
    vfx: { particleCount: 38, particleColorHex: 0xdc2626, dustBurst: true, sparkBurst: true, shockwaveRadius: 2.6 },
    soundMethod: 'playCrimsonMaelstrom',
    targetFacingBehavior: 'rotate_360',
    movementBehavior: 'in_place',
    cancellationRules: 'Swirling blood vortex draws enemies inward.',
    combatEventSync: 'Pulls foes 1 tile inward, inflicts Burning, detonates oil hazards.',
    samplePose: (p, ph) => {
      if (ph === 'anticipation') {
        const t = easeOutQuad(p);
        return { bodyPos: [0, -0.08 * t, 0], bodyRot: [0.1 * t, -1.2 * t, 0], bodyScale: [1, 1, 1], weaponPos: [-0.25 * t, 0.2 * t, -0.2 * t], weaponRot: [0.2 * t, -1.57 * t, 0.3 * t] };
      }
      if (ph === 'execution') {
        const t = easeInOutQuad(p);
        return { bodyPos: [0, 0, 0], bodyRot: [0, lerp(-1.2, 5.0, t), 0], bodyScale: [1, 1, 1], weaponPos: [0.35, 0.25, 0.4], weaponRot: [0.2, lerp(-1.57, 5.0, t), 0] };
      }
      if (ph === 'impact') {
        return { bodyPos: [0, 0, 0.1], bodyRot: [0, 6.28, 0], bodyScale: [1.06, 1.06, 1.06], weaponPos: [0.4, 0.25, 0.5], weaponRot: [0.2, 6.28, 0] };
      }
      const t = easeOutQuad(p);
      return { bodyPos: [0, 0, lerp(0.1, 0, t)], bodyRot: [0, 0, 0], bodyScale: [1, 1, 1], weaponPos: [lerp(0.4, 0, t), lerp(0.25, 0, t), lerp(0.5, 0, t)], weaponRot: [0, 0, 0] };
    }
  },

  heartstop_sovereign: {
    skillId: 'heartstop_sovereign',
    name: 'Heartstop Sovereign',
    animationId: 'anim_crimson_heartstop_sovereign',
    anticipationDuration: 0.26,
    executionDuration: 0.34,
    impactTiming: 0.48,
    recoveryDuration: 0.36,
    totalDuration: 0.96,
    weaponTrail: { enabled: true, colorHex: 0x991b1b, trailType: 'heart_crush', intensity: 1.0 },
    vfx: { particleCount: 42, particleColorHex: 0x991b1b, dustBurst: false, sparkBurst: true, shockwaveRadius: 2.2 },
    soundMethod: 'playHeartstopSovereign',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Internal cardiac crush cannot be resisted.',
    combatEventSync: 'Deals 25-36 necrotic damage, stuns target for 1 turn, spreads curse.',
    samplePose: (p, ph) => {
      if (ph === 'anticipation') {
        const t = easeOutQuad(p);
        return { bodyPos: [0, 0, -0.08 * t], bodyRot: [0.15 * t, 0, 0], bodyScale: [1, 1, 1], weaponPos: [0.1 * t, 0.3 * t, 0.1 * t], weaponRot: [0.3 * t, 0, 0] };
      }
      if (ph === 'execution') {
        const t = easeInQuad(p);
        return { bodyPos: [0, 0, 0.15 * t], bodyRot: [lerp(0.15, -0.2, t), 0, 0], bodyScale: [1, 1.04, 1], weaponPos: [lerp(0.1, 0.35, t), lerp(0.3, 0.45, t), lerp(0.1, 0.85, t)], weaponRot: [lerp(0.3, -0.2, t), 0, 0] };
      }
      if (ph === 'impact') {
        return { bodyPos: [0, 0, 0.18], bodyRot: [-0.25, 0, 0], bodyScale: [1.08, 1.08, 1.08], weaponPos: [0.38, 0.48, 0.92], weaponRot: [-0.25, 0, 0] };
      }
      const t = easeOutQuad(p);
      return { bodyPos: [0, 0, lerp(0.18, 0, t)], bodyRot: [lerp(-0.25, 0, t), 0, 0], bodyScale: [1, 1, 1], weaponPos: [lerp(0.38, 0, t), lerp(0.48, 0, t), lerp(0.92, 0, t)], weaponRot: [lerp(-0.25, 0, t), 0, 0] };
    }
  },

  // ================= RIFT CHRONOMANCER (6) =================
  time_slip: {
    skillId: 'time_slip',
    name: 'Time Slip',
    animationId: 'anim_chrono_time_slip',
    anticipationDuration: 0.16,
    executionDuration: 0.22,
    impactTiming: 0.28,
    recoveryDuration: 0.24,
    totalDuration: 0.62,
    weaponTrail: { enabled: true, colorHex: 0x06b6d4, trailType: 'time_slip', intensity: 0.85 },
    vfx: { particleCount: 22, particleColorHex: 0x06b6d4, dustBurst: false, sparkBurst: true },
    soundMethod: 'playTimeSlip',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'phase_blink',
    cancellationRules: 'Shifts target back along their timeline.',
    combatEventSync: 'Blinks target back to tile at start of turn and refunds 2 move.',
    samplePose: (p, ph) => {
      if (ph === 'anticipation') {
        const t = easeInQuad(p);
        return { bodyPos: [0, -0.08 * t, 0], bodyRot: [0, 0.8 * t, 0], bodyScale: [lerp(1, 0.6, t), 1, lerp(1, 0.6, t)], weaponPos: [0, 0.1 * t, 0], weaponRot: [0, 0.8 * t, 0] };
      }
      if (ph === 'execution') {
        const t = easeInOutQuad(p);
        return { bodyPos: [0, 0, lerp(0, 0.4, t)], bodyRot: [0, lerp(0.8, 3.14, t), 0], bodyScale: [lerp(0.6, 1.1, t), 1, lerp(0.6, 1.1, t)], weaponPos: [0.1 * t, 0.2 * t, 0.2 * t], weaponRot: [0, 3.14, 0] };
      }
      if (ph === 'impact') {
        return { bodyPos: [0, 0, 0.42], bodyRot: [0, 3.14, 0], bodyScale: [1.05, 1.05, 1.05], weaponPos: [0.12, 0.22, 0.25], weaponRot: [0, 3.14, 0] };
      }
      const t = easeOutQuad(p);
      return { bodyPos: [0, 0, lerp(0.42, 0, t)], bodyRot: [0, lerp(3.14, 0, t), 0], bodyScale: [1, 1, 1], weaponPos: [lerp(0.12, 0, t), lerp(0.22, 0, t), lerp(0.25, 0, t)], weaponRot: [0, 0, 0] };
    }
  },

  chronostasis: {
    skillId: 'chronostasis',
    name: 'Chronostasis',
    animationId: 'anim_chrono_chronostasis',
    anticipationDuration: 0.2,
    executionDuration: 0.26,
    impactTiming: 0.36,
    recoveryDuration: 0.28,
    totalDuration: 0.74,
    weaponTrail: { enabled: true, colorHex: 0x06b6d4, trailType: 'stasis_freeze', intensity: 0.9 },
    vfx: { particleCount: 26, particleColorHex: 0x06b6d4, dustBurst: false, sparkBurst: true, shockwaveRadius: 1.6 },
    soundMethod: 'playChronostasis',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Suspends target in temporal bubble.',
    combatEventSync: 'Target cannot take actions, move, or receive buffs for 1 turn.',
    samplePose: (p, ph) => {
      if (ph === 'anticipation') {
        const t = easeOutQuad(p);
        return { bodyPos: [0, 0.05 * t, -0.05 * t], bodyRot: [-0.15 * t, 0, 0], bodyScale: [1, 1, 1], weaponPos: [0.1 * t, 0.35 * t, -0.1 * t], weaponRot: [-0.4 * t, 0, 0] };
      }
      if (ph === 'execution') {
        const t = easeInQuad(p);
        return { bodyPos: [0, 0, 0.15 * t], bodyRot: [lerp(-0.15, 0.2, t), 0, 0], bodyScale: [1, 1, 1], weaponPos: [lerp(0.1, 0.3, t), lerp(0.35, 0.2, t), lerp(-0.1, 0.8, t)], weaponRot: [lerp(-0.4, 0.2, t), 0, 0] };
      }
      if (ph === 'impact') {
        return { bodyPos: [0, 0, 0.18], bodyRot: [0.25, 0, 0], bodyScale: [1.04, 1.04, 1.04], weaponPos: [0.35, 0.22, 0.85], weaponRot: [0.25, 0, 0] };
      }
      const t = easeOutQuad(p);
      return { bodyPos: [0, 0, lerp(0.18, 0, t)], bodyRot: [lerp(0.25, 0, t), 0, 0], bodyScale: [1, 1, 1], weaponPos: [lerp(0.35, 0, t), lerp(0.22, 0, t), lerp(0.85, 0, t)], weaponRot: [lerp(0.25, 0, t), 0, 0] };
    }
  },

  accelerate_flow: {
    skillId: 'accelerate_flow',
    name: 'Accelerate Flow',
    animationId: 'anim_chrono_accelerate_flow',
    anticipationDuration: 0.16,
    executionDuration: 0.22,
    impactTiming: 0.28,
    recoveryDuration: 0.24,
    totalDuration: 0.62,
    weaponTrail: { enabled: true, colorHex: 0x38bdf8, trailType: 'accelerate_flow', intensity: 0.85 },
    vfx: { particleCount: 20, particleColorHex: 0x38bdf8, dustBurst: false, sparkBurst: true, allyPulse: true },
    soundMethod: 'playAccelerateFlow',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Hastens temporal flow for ally.',
    combatEventSync: 'Target companion gains +1 AP and +2 Move Range next turn.',
    samplePose: (p, ph) => {
      if (ph === 'anticipation') {
        const t = easeOutQuad(p);
        return { bodyPos: [0, 0, -0.05 * t], bodyRot: [0, -0.2 * t, 0], bodyScale: [1, 1, 1], weaponPos: [-0.1 * t, 0.15 * t, -0.1 * t], weaponRot: [0.2 * t, -0.3 * t, 0] };
      }
      if (ph === 'execution') {
        const t = easeOutQuad(p);
        return { bodyPos: [0, 0, 0.12 * t], bodyRot: [0, lerp(-0.2, 0.3, t), 0], bodyScale: [1, 1, 1], weaponPos: [lerp(-0.1, 0.32, t), lerp(0.15, 0.25, t), lerp(-0.1, 0.8, t)], weaponRot: [lerp(0.2, -0.1, t), lerp(-0.3, 0.45, t), 0] };
      }
      if (ph === 'impact') {
        return { bodyPos: [0, 0, 0.15], bodyRot: [0, 0.32, 0], bodyScale: [1.02, 1.02, 1.02], weaponPos: [0.35, 0.28, 0.85], weaponRot: [-0.12, 0.5, 0] };
      }
      const t = easeOutQuad(p);
      return { bodyPos: [0, 0, lerp(0.15, 0, t)], bodyRot: [0, lerp(0.32, 0, t), 0], bodyScale: [1, 1, 1], weaponPos: [lerp(0.35, 0, t), lerp(0.28, 0, t), lerp(0.85, 0, t)], weaponRot: [lerp(-0.12, 0, t), lerp(0.5, 0, t), 0] };
    }
  },

  echoes_of_eternity: {
    skillId: 'echoes_of_eternity',
    name: 'Echoes of Eternity',
    animationId: 'anim_chrono_echoes_of_eternity',
    anticipationDuration: 0.18,
    executionDuration: 0.26,
    impactTiming: 0.34,
    recoveryDuration: 0.26,
    totalDuration: 0.7,
    weaponTrail: { enabled: false, colorHex: 0x818cf8, trailType: 'echo_split', intensity: 0.75 },
    vfx: { particleCount: 24, particleColorHex: 0x818cf8, dustBurst: false, sparkBurst: true },
    soundMethod: 'playEchoesOfEternity',
    targetFacingBehavior: 'maintain_facing',
    movementBehavior: 'in_place',
    cancellationRules: 'Cooldown reduction recursion engaged.',
    combatEventSync: '30% chance to immediately reduce any triggered cooldown by 1 turn.',
    samplePose: (p, ph) => {
      if (ph === 'anticipation') {
        const t = easeOutQuad(p);
        return { bodyPos: [0, 0.05 * t, 0], bodyRot: [-0.1 * t, 0, 0], bodyScale: [1, 1, 1], weaponPos: [0.1 * t, 0.3 * t, 0], weaponRot: [0.2 * t, 0, 0.3 * t] };
      }
      if (ph === 'execution') {
        const t = easeInOutQuad(p);
        return { bodyPos: [0, lerp(0.05, 0.15, t), 0], bodyRot: [lerp(-0.1, -0.22, t), 0, 0], bodyScale: [1, 1.03, 1], weaponPos: [0.1, lerp(0.3, 0.6, t), 0.1 * t], weaponRot: [lerp(0.2, 0.3, t), 0, lerp(0.3, 0.5, t)] };
      }
      if (ph === 'impact') {
        return { bodyPos: [0, 0.18, 0], bodyRot: [-0.25, 0, 0], bodyScale: [1.05, 1.05, 1.05], weaponPos: [0.12, 0.65, 0.12], weaponRot: [0.35, 0, 0.55] };
      }
      const t = easeOutQuad(p);
      return { bodyPos: [0, lerp(0.18, 0, t), 0], bodyRot: [lerp(-0.25, 0, t), 0, 0], bodyScale: [1, 1, 1], weaponPos: [lerp(0.12, 0, t), lerp(0.65, 0, t), lerp(0.12, 0, t)], weaponRot: [lerp(0.35, 0, t), 0, lerp(0.55, 0, t)] };
    }
  },

  paradox_nova: {
    skillId: 'paradox_nova',
    name: 'Paradox Nova',
    animationId: 'anim_chrono_paradox_nova',
    anticipationDuration: 0.24,
    executionDuration: 0.34,
    impactTiming: 0.46,
    recoveryDuration: 0.34,
    totalDuration: 0.92,
    weaponTrail: { enabled: true, colorHex: 0x06b6d4, trailType: 'paradox_burst', intensity: 0.95 },
    vfx: { particleCount: 38, particleColorHex: 0x06b6d4, dustBurst: true, sparkBurst: true, shockwaveRadius: 2.8 },
    soundMethod: 'playParadoxNova',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Dual-timeline collision detonates across 3x3.',
    combatEventSync: 'Deals 16-24 damage, strips enemy buffs, reduces enemy initiative.',
    samplePose: (p, ph) => {
      if (ph === 'anticipation') {
        const t = easeOutQuad(p);
        return { bodyPos: [0, 0.1 * t, -0.1 * t], bodyRot: [-0.25 * t, 0, 0], bodyScale: [1, 1, 1], weaponPos: [0.1 * t, 0.65 * t, -0.2 * t], weaponRot: [-0.6 * t, 0, 0] };
      }
      if (ph === 'execution') {
        const t = easeInQuad(p);
        return { bodyPos: [0, lerp(0.1, -0.15, t), 0.15 * t], bodyRot: [lerp(-0.25, 0.45, t), 0, 0], bodyScale: [1, 1, 1], weaponPos: [0.1, lerp(0.65, -0.35, t), lerp(-0.2, 0.7, t)], weaponRot: [lerp(-0.6, 0.85, t), 0, 0] };
      }
      if (ph === 'impact') {
        return { bodyPos: [0, -0.18, 0.18], bodyRot: [0.5, 0, 0], bodyScale: [1.08, 0.92, 1.08], weaponPos: [0.1, -0.4, 0.75], weaponRot: [0.9, 0, 0] };
      }
      const t = easeOutQuad(p);
      return { bodyPos: [0, lerp(-0.18, 0, t), lerp(0.18, 0, t)], bodyRot: [lerp(0.5, 0, t), 0, 0], bodyScale: [1, 1, 1], weaponPos: [lerp(0.1, 0, t), lerp(-0.4, 0, t), lerp(0.75, 0, t)], weaponRot: [lerp(0.9, 0, t), 0, 0] };
    }
  },

  time_stop: {
    skillId: 'time_stop',
    name: 'Time Stop',
    animationId: 'anim_chrono_time_stop',
    anticipationDuration: 0.28,
    executionDuration: 0.38,
    impactTiming: 0.52,
    recoveryDuration: 0.4,
    totalDuration: 1.06,
    weaponTrail: { enabled: false, colorHex: 0x38bdf8, trailType: 'time_freeze', intensity: 1.0 },
    vfx: { particleCount: 45, particleColorHex: 0x38bdf8, dustBurst: false, sparkBurst: true, shockwaveRadius: 3.5 },
    soundMethod: 'playTimeStop',
    targetFacingBehavior: 'maintain_facing',
    movementBehavior: 'in_place',
    cancellationRules: 'Freezes all external time for bonus full turn.',
    combatEventSync: 'Chronomancer gains bonus full turn with 3 AP while all units pause.',
    samplePose: (p, ph) => {
      if (ph === 'anticipation') {
        const t = easeOutQuad(p);
        return { bodyPos: [0, 0.1 * t, 0], bodyRot: [-0.15 * t, 0, 0], bodyScale: [1, 1, 1], weaponPos: [0.1 * t, 0.4 * t, 0], weaponRot: [-0.2 * t, 0, 0] };
      }
      if (ph === 'execution') {
        const t = easeInOutQuad(p);
        return { bodyPos: [0, lerp(0.1, 0.25, t), 0], bodyRot: [lerp(-0.15, -0.3, t), 0, 0], bodyScale: [1, 1.05, 1], weaponPos: [0.1, lerp(0.4, 0.8, t), 0.1 * t], weaponRot: [lerp(-0.2, 0.1, t), 0, 0] };
      }
      if (ph === 'impact') {
        return { bodyPos: [0, 0.28, 0], bodyRot: [-0.35, 0, 0], bodyScale: [1.08, 1.08, 1.08], weaponPos: [0.12, 0.85, 0.12], weaponRot: [0.15, 0, 0] };
      }
      const t = easeOutQuad(p);
      return { bodyPos: [0, lerp(0.28, 0, t), 0], bodyRot: [lerp(-0.35, 0, t), 0, 0], bodyScale: [1, 1, 1], weaponPos: [lerp(0.12, 0, t), lerp(0.85, 0, t), lerp(0.12, 0, t)], weaponRot: [lerp(0.15, 0, t), 0, 0] };
    }
  },

  // ================= BRIAR STALKER (6) =================
  ambush_snare: {
    skillId: 'ambush_snare',
    name: 'Ambush Snare',
    animationId: 'anim_briar_ambush_snare',
    anticipationDuration: 0.18,
    executionDuration: 0.26,
    impactTiming: 0.36,
    recoveryDuration: 0.28,
    totalDuration: 0.72,
    weaponTrail: { enabled: false, colorHex: 0x15803d, trailType: 'root_snare', intensity: 0.7 },
    vfx: { particleCount: 22, particleColorHex: 0x15803d, dustBurst: true, sparkBurst: false },
    soundMethod: 'playAmbushSnare',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Root snare armed on ground tile.',
    combatEventSync: 'Deploys snare: First enemy takes 9-15 Nature DMG, Rooted & Sundered.',
    samplePose: (p, ph) => {
      if (ph === 'anticipation') {
        const t = easeOutQuad(p);
        return { bodyPos: [0, -0.15 * t, 0.05 * t], bodyRot: [0.3 * t, 0, 0], bodyScale: [1, 1, 1], weaponPos: [0, -0.25 * t, 0.2 * t], weaponRot: [0.6 * t, 0, 0] };
      }
      if (ph === 'execution') {
        const t = easeInQuad(p);
        return { bodyPos: [0, lerp(-0.15, -0.38, t), lerp(0.05, 0.18, t)], bodyRot: [lerp(0.3, 0.52, t), 0, 0], bodyScale: [1, 1, 1], weaponPos: [0, lerp(-0.25, -0.52, t), lerp(0.2, 0.48, t)], weaponRot: [lerp(0.6, 1.05, t), 0, 0] };
      }
      if (ph === 'impact') {
        return { bodyPos: [0, -0.4, 0.2], bodyRot: [0.58, 0, 0], bodyScale: [1.05, 0.88, 1.05], weaponPos: [0, -0.55, 0.52], weaponRot: [1.1, 0, 0] };
      }
      const t = easeOutQuad(p);
      return { bodyPos: [0, lerp(-0.4, 0, t), lerp(0.2, 0, t)], bodyRot: [lerp(0.58, 0, t), 0, 0], bodyScale: [1, 1, 1], weaponPos: [0, lerp(-0.55, 0, t), lerp(0.52, 0, t)], weaponRot: [lerp(1.1, 0, t), 0, 0] };
    }
  },

  shadow_thorn: {
    skillId: 'shadow_thorn',
    name: 'Shadow Thorn',
    animationId: 'anim_briar_shadow_thorn',
    anticipationDuration: 0.14,
    executionDuration: 0.18,
    impactTiming: 0.22,
    recoveryDuration: 0.24,
    totalDuration: 0.56,
    weaponTrail: { enabled: true, colorHex: 0x16a34a, trailType: 'thorn_dart', intensity: 0.9 },
    vfx: { particleCount: 16, particleColorHex: 0x16a34a, dustBurst: false, sparkBurst: true },
    soundMethod: 'playShadowThorn',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Spine dart released from shadows.',
    combatEventSync: '+5 bonus damage from stealth; prevents healing for 2 turns.',
    samplePose: (p, ph, isMiss) => {
      if (ph === 'anticipation') {
        const t = easeOutQuad(p);
        return { bodyPos: [0, -0.05 * t, -0.06 * t], bodyRot: [0.1 * t, -0.3 * t, 0], bodyScale: [1, 1, 1], weaponPos: [-0.15 * t, 0.1 * t, -0.15 * t], weaponRot: [0.3 * t, -0.4 * t, 0] };
      }
      if (ph === 'execution') {
        const t = easeOutQuad(p);
        const missOffset = isMiss ? 0.25 : 0;
        return { bodyPos: [0, 0, lerp(-0.06, 0.14, t)], bodyRot: [0.1, lerp(-0.3, 0.35 + missOffset, t), 0], bodyScale: [1, 1, 1], weaponPos: [lerp(-0.15, 0.35, t), lerp(0.1, 0.2, t), lerp(-0.15, 0.85, t)], weaponRot: [lerp(0.3, -0.2, t), lerp(-0.4, 0.55, t), 0] };
      }
      if (ph === 'impact') {
        return { bodyPos: [0, 0, 0.16], bodyRot: [0.12, 0.38, 0], bodyScale: [1.02, 1.02, 1.02], weaponPos: [0.38, 0.22, 0.9], weaponRot: [-0.22, 0.6, 0] };
      }
      const t = easeOutQuad(p);
      return { bodyPos: [0, 0, lerp(0.16, 0, t)], bodyRot: [lerp(0.12, 0, t), lerp(0.38, 0, t), 0], bodyScale: [1, 1, 1], weaponPos: [lerp(0.38, 0, t), lerp(0.22, 0, t), lerp(0.9, 0, t)], weaponRot: [lerp(-0.22, 0, t), lerp(0.6, 0, t), 0] };
    }
  },

  bramble_stride: {
    skillId: 'bramble_stride',
    name: 'Bramble Stride',
    animationId: 'anim_briar_bramble_stride',
    anticipationDuration: 0.14,
    executionDuration: 0.24,
    impactTiming: 0.26,
    recoveryDuration: 0.24,
    totalDuration: 0.62,
    weaponTrail: { enabled: false, colorHex: 0x4ade80, trailType: 'thorn_glide', intensity: 0.7 },
    vfx: { particleCount: 20, particleColorHex: 0x4ade80, dustBurst: false, sparkBurst: false },
    soundMethod: 'playBrambleStride',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'rush_forward',
    cancellationRules: 'Unimpeded movement across rough terrain.',
    combatEventSync: 'Moves across rough terrain with 0 penalty, regenerates 2 HP per tile.',
    samplePose: (p, ph) => {
      if (ph === 'anticipation') {
        const t = easeOutQuad(p);
        return { bodyPos: [0, -0.08 * t, -0.1 * t], bodyRot: [0.25 * t, 0, 0], bodyScale: [1, 1, 1], weaponPos: [0, 0.1 * t, -0.15 * t], weaponRot: [0.3 * t, 0, 0] };
      }
      if (ph === 'execution') {
        const t = easeOutQuad(p);
        return { bodyPos: [0, 0, lerp(-0.1, 0.45, t)], bodyRot: [0.25, 0, 0], bodyScale: [1, 1, 1], weaponPos: [0, 0.15 * t, lerp(-0.15, 0.65, t)], weaponRot: [0.3, 0, 0] };
      }
      if (ph === 'impact') {
        return { bodyPos: [0, 0, 0.48], bodyRot: [0.28, 0, 0], bodyScale: [1.04, 1.04, 1.04], weaponPos: [0, 0.18, 0.7], weaponRot: [0.3, 0, 0] };
      }
      const t = easeOutQuad(p);
      return { bodyPos: [0, 0, lerp(0.48, 0, t)], bodyRot: [lerp(0.28, 0, t), 0, 0], bodyScale: [1, 1, 1], weaponPos: [0, lerp(0.18, 0, t), lerp(0.7, 0, t)], weaponRot: [lerp(0.3, 0, t), 0, 0] };
    }
  },

  venomous_bramble: {
    skillId: 'venomous_bramble',
    name: 'Venomous Bramble',
    animationId: 'anim_briar_venomous_bramble',
    anticipationDuration: 0.2,
    executionDuration: 0.26,
    impactTiming: 0.36,
    recoveryDuration: 0.28,
    totalDuration: 0.74,
    weaponTrail: { enabled: true, colorHex: 0x16a34a, trailType: 'toxic_briar', intensity: 0.85 },
    vfx: { particleCount: 28, particleColorHex: 0x16a34a, dustBurst: true, sparkBurst: true, shockwaveRadius: 2.4 },
    soundMethod: 'playVenomousBramble',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Sprouts toxic thorns across 3x3 area.',
    combatEventSync: 'Sprouts toxic thorns: Deals Nature damage and poisons units starting turn.',
    samplePose: (p, ph) => {
      if (ph === 'anticipation') {
        const t = easeOutQuad(p);
        return { bodyPos: [0, -0.12 * t, 0], bodyRot: [0.2 * t, 0, 0], bodyScale: [1, 1, 1], weaponPos: [0, -0.2 * t, 0.1 * t], weaponRot: [0.5 * t, 0, 0] };
      }
      if (ph === 'execution') {
        const t = easeInQuad(p);
        return { bodyPos: [0, lerp(-0.12, -0.25, t), 0.15 * t], bodyRot: [lerp(0.2, 0.45, t), 0, 0], bodyScale: [1, 1, 1], weaponPos: [0, lerp(-0.2, -0.45, t), lerp(0.1, 0.65, t)], weaponRot: [lerp(0.5, 0.95, t), 0, 0] };
      }
      if (ph === 'impact') {
        return { bodyPos: [0, -0.28, 0.18], bodyRot: [0.5, 0, 0], bodyScale: [1.06, 0.9, 1.06], weaponPos: [0, -0.48, 0.7], weaponRot: [1.0, 0, 0] };
      }
      const t = easeOutQuad(p);
      return { bodyPos: [0, lerp(-0.28, 0, t), lerp(0.18, 0, t)], bodyRot: [lerp(0.5, 0, t), 0, 0], bodyScale: [1, 1, 1], weaponPos: [0, lerp(-0.48, 0, t), lerp(0.7, 0, t)], weaponRot: [lerp(1.0, 0, t), 0, 0] };
    }
  },

  lurker_in_the_foliage: {
    skillId: 'lurker_in_the_foliage',
    name: 'Lurker in the Foliage',
    animationId: 'anim_briar_lurker_in_the_foliage',
    anticipationDuration: 0.16,
    executionDuration: 0.24,
    impactTiming: 0.3,
    recoveryDuration: 0.26,
    totalDuration: 0.66,
    weaponTrail: { enabled: false, colorHex: 0x15803d, trailType: 'foliage_meld', intensity: 0.7 },
    vfx: { particleCount: 22, particleColorHex: 0x15803d, dustBurst: false, sparkBurst: false },
    soundMethod: 'playLurkerInTheFoliage',
    targetFacingBehavior: 'maintain_facing',
    movementBehavior: 'in_place',
    cancellationRules: 'Untargetable until attacking; +6 damage on next strike.',
    combatEventSync: 'Dissolves into foliage: Untargetable and +6 damage on next strike.',
    samplePose: (p, ph) => {
      if (ph === 'anticipation') {
        const t = easeOutQuad(p);
        return { bodyPos: [0, -0.15 * t, 0], bodyRot: [0.25 * t, -0.2 * t, 0], bodyScale: [1, 1, 1], weaponPos: [-0.1 * t, -0.15 * t, 0.1 * t], weaponRot: [0.4 * t, 0, 0] };
      }
      if (ph === 'execution') {
        const t = easeInOutQuad(p);
        return { bodyPos: [0, lerp(-0.15, -0.35, t), 0], bodyRot: [lerp(0.25, 0.45, t), lerp(-0.2, -0.35, t), 0], bodyScale: [lerp(1, 0.85, t), lerp(1, 0.8, t), lerp(1, 0.85, t)], weaponPos: [-0.1, lerp(-0.15, -0.3, t), 0.15], weaponRot: [lerp(0.4, 0.65, t), 0, 0] };
      }
      if (ph === 'impact') {
        return { bodyPos: [0, -0.38, 0], bodyRot: [0.48, -0.38, 0], bodyScale: [0.85, 0.8, 0.85], weaponPos: [-0.12, -0.32, 0.18], weaponRot: [0.7, 0, 0] };
      }
      const t = easeOutQuad(p);
      return { bodyPos: [0, lerp(-0.38, 0, t), 0], bodyRot: [lerp(0.48, 0, t), lerp(-0.38, 0, t), 0], bodyScale: [lerp(0.85, 1, t), lerp(0.8, 1, t), lerp(0.85, 1, t)], weaponPos: [lerp(-0.12, 0, t), lerp(-0.32, 0, t), lerp(0.18, 0, t)], weaponRot: [lerp(0.7, 0, t), 0, 0] };
    }
  },

  wrath_of_the_primordial_grove: {
    skillId: 'wrath_of_the_primordial_grove',
    name: 'Wrath of the Primordial Grove',
    animationId: 'anim_briar_wrath_of_the_primordial_grove',
    anticipationDuration: 0.28,
    executionDuration: 0.4,
    impactTiming: 0.56,
    recoveryDuration: 0.42,
    totalDuration: 1.1,
    weaponTrail: { enabled: true, colorHex: 0x15803d, trailType: 'grove_wrath', intensity: 1.0 },
    vfx: { particleCount: 48, particleColorHex: 0x15803d, dustBurst: true, sparkBurst: true, shockwaveRadius: 3.5 },
    soundMethod: 'playWrathOfThePrimordialGrove',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Colossal subterranean roots crush all trapped foes.',
    combatEventSync: 'Crushes trapped foes for 24-36 Nature DMG, knocks prone & roots.',
    samplePose: (p, ph) => {
      if (ph === 'anticipation') {
        const t = easeOutQuad(p);
        return { bodyPos: [0, 0.15 * t, -0.15 * t], bodyRot: [-0.35 * t, 0, 0], bodyScale: [1, 1, 1], weaponPos: [0, 0.7 * t, -0.2 * t], weaponRot: [-0.8 * t, 0, 0] };
      }
      if (ph === 'execution') {
        const t = easeInQuad(p);
        return { bodyPos: [0, lerp(0.15, -0.25, t), 0.25 * t], bodyRot: [lerp(-0.35, 0.55, t), 0, 0], bodyScale: [1, 1, 1], weaponPos: [0, lerp(0.7, -0.45, t), lerp(-0.2, 0.75, t)], weaponRot: [lerp(-0.8, 1.2, t), 0, 0] };
      }
      if (ph === 'impact') {
        return { bodyPos: [0, -0.28, 0.3], bodyRot: [0.6, 0, 0], bodyScale: [1.12, 0.88, 1.12], weaponPos: [0, -0.5, 0.82], weaponRot: [1.25, 0, 0] };
      }
      const t = easeOutQuad(p);
      return { bodyPos: [0, lerp(-0.28, 0, t), lerp(0.3, 0, t)], bodyRot: [lerp(0.6, 0, t), 0, 0], bodyScale: [1, 1, 1], weaponPos: [0, lerp(-0.5, 0, t), lerp(0.82, 0, t)], weaponRot: [lerp(1.25, 0, t), 0, 0] };
    }
  },

  // ================= IRONBOUGH SENTINEL (6) =================
  ironwood_brace: {
    skillId: 'ironwood_brace',
    name: 'Ironwood Brace',
    animationId: 'anim_sentinel_ironwood_brace',
    anticipationDuration: 0.18,
    executionDuration: 0.26,
    impactTiming: 0.34,
    recoveryDuration: 0.28,
    totalDuration: 0.72,
    weaponTrail: { enabled: false, colorHex: 0x78716c, trailType: 'iron_brace', intensity: 0.7 },
    vfx: { particleCount: 22, particleColorHex: 0x78716c, dustBurst: true, sparkBurst: false },
    soundMethod: 'playIronwoodBrace',
    targetFacingBehavior: 'maintain_facing',
    movementBehavior: 'in_place',
    cancellationRules: 'Gains immunity to displacement, +3 AC, absorbs 12 damage.',
    combatEventSync: 'Roots feet into bedrock: Displacement immunity, +3 AC, absorbs 12 DMG.',
    samplePose: (p, ph) => {
      if (ph === 'anticipation') {
        const t = easeOutQuad(p);
        return { bodyPos: [0, -0.1 * t, 0], bodyRot: [0.15 * t, 0, 0], bodyScale: [1, 1, 1], weaponPos: [0.1 * t, 0, -0.1 * t], weaponRot: [0.3 * t, 0, 0] };
      }
      if (ph === 'execution') {
        const t = easeInOutQuad(p);
        return { bodyPos: [0, lerp(-0.1, -0.22, t), 0], bodyRot: [lerp(0.15, 0.3, t), 0, 0], bodyScale: [1.06, 0.94, 1.06], weaponPos: [0.1, lerp(0, -0.2, t), 0.1 * t], weaponRot: [lerp(0.3, 0.5, t), 0, 0] };
      }
      if (ph === 'impact') {
        return { bodyPos: [0, -0.24, 0], bodyRot: [0.32, 0, 0], bodyScale: [1.08, 0.92, 1.08], weaponPos: [0.1, -0.22, 0.12], weaponRot: [0.55, 0, 0] };
      }
      const t = easeOutQuad(p);
      return { bodyPos: [0, lerp(-0.24, 0, t), 0], bodyRot: [lerp(0.32, 0, t), 0, 0], bodyScale: [1, 1, 1], weaponPos: [lerp(0.1, 0, t), lerp(-0.22, 0, t), lerp(0.12, 0, t)], weaponRot: [lerp(0.55, 0, t), 0, 0] };
    }
  },

  rooting_cleave: {
    skillId: 'rooting_cleave',
    name: 'Rooting Cleave',
    animationId: 'anim_sentinel_rooting_cleave',
    anticipationDuration: 0.22,
    executionDuration: 0.3,
    impactTiming: 0.4,
    recoveryDuration: 0.3,
    totalDuration: 0.82,
    weaponTrail: { enabled: true, colorHex: 0x15803d, trailType: 'rooting_arc', intensity: 0.9 },
    vfx: { particleCount: 26, particleColorHex: 0x15803d, dustBurst: true, sparkBurst: true, shockwaveRadius: 1.8 },
    soundMethod: 'playRootingCleave',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'forward_step',
    cancellationRules: 'Cleave binds adjacent foes with roots.',
    combatEventSync: 'Sweeping cleave hits adjacent foes and roots them for 2 turns.',
    samplePose: (p, ph, isMiss) => {
      if (ph === 'anticipation') {
        const t = easeOutQuad(p);
        return { bodyPos: [0, -0.05 * t, -0.1 * t], bodyRot: [0.15 * t, -0.5 * t, 0], bodyScale: [1, 1, 1], weaponPos: [-0.2 * t, 0.2 * t, -0.2 * t], weaponRot: [-0.3 * t, -0.8 * t, 0.3 * t] };
      }
      if (ph === 'execution') {
        const t = easeOutQuad(p);
        const missOffset = isMiss ? 0.3 : 0;
        return { bodyPos: [0, 0, lerp(-0.1, 0.35, t)], bodyRot: [0.15, lerp(-0.5, 0.65 + missOffset, t), 0], bodyScale: [1, 1, 1], weaponPos: [lerp(-0.2, 0.45, t), lerp(0.2, 0.15, t), lerp(-0.2, 0.9, t)], weaponRot: [lerp(-0.3, 0.2, t), lerp(-0.8, 1.3, t), lerp(0.3, -0.4, t)] };
      }
      if (ph === 'impact') {
        return { bodyPos: [0, 0, 0.38], bodyRot: [0.18, 0.7, 0], bodyScale: [1.05, 1.05, 1.05], weaponPos: [0.48, 0.18, 0.95], weaponRot: [0.22, 1.35, -0.45] };
      }
      const t = easeOutQuad(p);
      return { bodyPos: [0, 0, lerp(0.38, 0, t)], bodyRot: [lerp(0.18, 0, t), lerp(0.7, 0, t), 0], bodyScale: [1, 1, 1], weaponPos: [lerp(0.48, 0, t), lerp(0.18, 0, t), lerp(0.95, 0, t)], weaponRot: [lerp(0.22, 0, t), lerp(1.35, 0, t), lerp(-0.45, 0, t)] };
    }
  },

  grounded_bastion: {
    skillId: 'grounded_bastion',
    name: 'Grounded Bastion',
    animationId: 'anim_sentinel_grounded_bastion',
    anticipationDuration: 0.18,
    executionDuration: 0.26,
    impactTiming: 0.36,
    recoveryDuration: 0.28,
    totalDuration: 0.72,
    weaponTrail: { enabled: false, colorHex: 0xa8a29e, trailType: 'ground_aura', intensity: 0.7 },
    vfx: { particleCount: 22, particleColorHex: 0xa8a29e, dustBurst: true, sparkBurst: false, shockwaveRadius: 2.0, allyPulse: true },
    soundMethod: 'playGroundedBastion',
    targetFacingBehavior: 'maintain_facing',
    movementBehavior: 'in_place',
    cancellationRules: 'Cannot be forcibly displaced; grants +2 AC to adjacent companions.',
    combatEventSync: 'Sentinel immune to pull/push; grants +2 AC to adjacent companions.',
    samplePose: (p, ph) => {
      if (ph === 'anticipation') {
        const t = easeOutQuad(p);
        return { bodyPos: [0, -0.06 * t, 0], bodyRot: [0.12 * t, 0, 0], bodyScale: [1, 1, 1], weaponPos: [0, -0.15 * t, 0.1 * t], weaponRot: [0.3 * t, 0, 0] };
      }
      if (ph === 'execution') {
        const t = easeInOutQuad(p);
        return { bodyPos: [0, lerp(-0.06, -0.18, t), 0], bodyRot: [lerp(0.12, 0.25, t), 0, 0], bodyScale: [1.05, 0.95, 1.05], weaponPos: [0, lerp(-0.15, -0.32, t), 0.2 * t], weaponRot: [lerp(0.3, 0.6, t), 0, 0] };
      }
      if (ph === 'impact') {
        return { bodyPos: [0, -0.2, 0], bodyRot: [0.28, 0, 0], bodyScale: [1.06, 0.94, 1.06], weaponPos: [0, -0.35, 0.22], weaponRot: [0.65, 0, 0] };
      }
      const t = easeOutQuad(p);
      return { bodyPos: [0, lerp(-0.2, 0, t), 0], bodyRot: [lerp(0.28, 0, t), 0, 0], bodyScale: [1, 1, 1], weaponPos: [0, lerp(-0.35, 0, t), lerp(0.22, 0, t)], weaponRot: [lerp(0.65, 0, t), 0, 0] };
    }
  },

  timberfall_slam: {
    skillId: 'timberfall_slam',
    name: 'Timberfall Slam',
    animationId: 'anim_sentinel_timberfall_slam',
    anticipationDuration: 0.24,
    executionDuration: 0.32,
    impactTiming: 0.44,
    recoveryDuration: 0.34,
    totalDuration: 0.9,
    weaponTrail: { enabled: true, colorHex: 0x78716c, trailType: 'timber_slam', intensity: 0.95 },
    vfx: { particleCount: 34, particleColorHex: 0x78716c, dustBurst: true, sparkBurst: true, shockwaveRadius: 2.4 },
    soundMethod: 'playTimberfallSlam',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'leaping_stride',
    cancellationRules: 'Slams petrified trunk into enemy; creates obstacle cover.',
    combatEventSync: 'Deals 15-23 damage, shoves foe 2 tiles back, leaves obstacle cover.',
    samplePose: (p, ph, isMiss) => {
      if (ph === 'anticipation') {
        const t = easeOutQuad(p);
        return { bodyPos: [0, 0.15 * t, -0.15 * t], bodyRot: [-0.35 * t, 0, 0], bodyScale: [1, 1, 1], weaponPos: [0, 0.75 * t, -0.25 * t], weaponRot: [-0.85 * t, 0, 0] };
      }
      if (ph === 'execution') {
        const t = easeInQuad(p);
        const missOffset = isMiss ? 0.3 : 0;
        return { bodyPos: [0, lerp(0.15, -0.22, t), lerp(-0.15, 0.45, t)], bodyRot: [lerp(-0.35, 0.52, t), missOffset, 0], bodyScale: [1, 1, 1], weaponPos: [0, lerp(0.75, -0.4, t), lerp(-0.25, 0.85, t)], weaponRot: [lerp(-0.85, 1.2, t), 0, 0] };
      }
      if (ph === 'impact') {
        return { bodyPos: [0, -0.25, 0.5], bodyRot: [0.58, 0, 0], bodyScale: [1.1, 0.9, 1.1], weaponPos: [0, -0.45, 0.9], weaponRot: [1.25, 0, 0] };
      }
      const t = easeOutQuad(p);
      return { bodyPos: [0, lerp(-0.25, 0, t), lerp(0.5, 0, t)], bodyRot: [lerp(0.58, 0, t), 0, 0], bodyScale: [1, 1, 1], weaponPos: [0, lerp(-0.45, 0, t), lerp(0.9, 0, t)], weaponRot: [lerp(1.25, 0, t), 0, 0] };
    }
  },

  heart_of_the_ancient_bough: {
    skillId: 'heart_of_the_ancient_bough',
    name: 'Heart of the Ancient Bough',
    animationId: 'anim_sentinel_heart_of_the_ancient_bough',
    anticipationDuration: 0.22,
    executionDuration: 0.3,
    impactTiming: 0.42,
    recoveryDuration: 0.32,
    totalDuration: 0.84,
    weaponTrail: { enabled: false, colorHex: 0x22c55e, trailType: 'bough_heart', intensity: 0.8 },
    vfx: { particleCount: 28, particleColorHex: 0x22c55e, dustBurst: false, sparkBurst: true, allyPulse: true },
    soundMethod: 'playHeartOfTheAncientBough',
    targetFacingBehavior: 'maintain_facing',
    movementBehavior: 'in_place',
    cancellationRules: 'Cleanses all debuffs, grants 20 Temp HP, +1 Max AP for 3 turns.',
    combatEventSync: 'Cleanses all debuffs, grants 20 Temp HP & +1 Max AP for 3 turns.',
    samplePose: (p, ph) => {
      if (ph === 'anticipation') {
        const t = easeOutQuad(p);
        return { bodyPos: [0, 0.08 * t, 0], bodyRot: [-0.15 * t, 0, 0], bodyScale: [1, 1, 1], weaponPos: [0.1 * t, 0.35 * t, 0], weaponRot: [0.2 * t, 0, 0.3 * t] };
      }
      if (ph === 'execution') {
        const t = easeInOutQuad(p);
        return { bodyPos: [0, lerp(0.08, 0.2, t), 0], bodyRot: [lerp(-0.15, -0.28, t), 0, 0], bodyScale: [1, 1.05, 1], weaponPos: [0.1, lerp(0.35, 0.7, t), 0.1 * t], weaponRot: [lerp(0.2, 0.3, t), 0, lerp(0.3, 0.5, t)] };
      }
      if (ph === 'impact') {
        return { bodyPos: [0, 0.22, 0], bodyRot: [-0.3, 0, 0], bodyScale: [1.08, 1.08, 1.08], weaponPos: [0.12, 0.75, 0.12], weaponRot: [0.35, 0, 0.55] };
      }
      const t = easeOutQuad(p);
      return { bodyPos: [0, lerp(0.22, 0, t), 0], bodyRot: [lerp(-0.3, 0, t), 0, 0], bodyScale: [1, 1, 1], weaponPos: [lerp(0.12, 0, t), lerp(0.75, 0, t), lerp(0.12, 0, t)], weaponRot: [lerp(0.35, 0, t), 0, lerp(0.55, 0, t)] };
    }
  },

  colossus_of_the_vale: {
    skillId: 'colossus_of_the_vale',
    name: 'Colossus of the Vale',
    animationId: 'anim_sentinel_colossus_of_the_vale',
    anticipationDuration: 0.28,
    executionDuration: 0.4,
    impactTiming: 0.54,
    recoveryDuration: 0.44,
    totalDuration: 1.12,
    weaponTrail: { enabled: true, colorHex: 0x15803d, trailType: 'colossus_wrath', intensity: 1.0 },
    vfx: { particleCount: 50, particleColorHex: 0x15803d, dustBurst: true, sparkBurst: true, shockwaveRadius: 3.6 },
    soundMethod: 'playColossusOfTheVale',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Colossus transformation increases reach to 2, reduces DMG taken by 40%.',
    combatEventSync: 'Transforms into ironwood colossus: Reach 2, 40% DMG reduction, cleaves foes.',
    samplePose: (p, ph) => {
      if (ph === 'anticipation') {
        const t = easeOutQuad(p);
        return { bodyPos: [0, 0.15 * t, -0.15 * t], bodyRot: [-0.3 * t, 0, 0], bodyScale: [1, 1, 1], weaponPos: [0, 0.7 * t, -0.2 * t], weaponRot: [-0.8 * t, 0, 0] };
      }
      if (ph === 'execution') {
        const t = easeInQuad(p);
        return { bodyPos: [0, lerp(0.15, -0.25, t), 0.25 * t], bodyRot: [lerp(-0.3, 0.55, t), 0, 0], bodyScale: [lerp(1, 1.2, t), lerp(1, 1.2, t), lerp(1, 1.2, t)], weaponPos: [0, lerp(0.7, -0.45, t), lerp(-0.2, 0.85, t)], weaponRot: [lerp(-0.8, 1.25, t), 0, 0] };
      }
      if (ph === 'impact') {
        return { bodyPos: [0, -0.28, 0.3], bodyRot: [0.6, 0, 0], bodyScale: [1.25, 1.15, 1.25], weaponPos: [0, -0.5, 0.95], weaponRot: [1.3, 0, 0] };
      }
      const t = easeOutQuad(p);
      return { bodyPos: [0, lerp(-0.28, 0, t), lerp(0.3, 0, t)], bodyRot: [lerp(0.6, 0, t), 0, 0], bodyScale: [lerp(1.25, 1, t), lerp(1.15, 1, t), lerp(1.25, 1, t)], weaponPos: [0, lerp(-0.5, 0, t), lerp(0.95, 0, t)], weaponRot: [lerp(1.3, 0, t), 0, 0] };
    }
  },
};
