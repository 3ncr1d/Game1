import { ItemId } from './gloamrestEngineTypes';

export const TOWN_GRID_SIZE = 50; // 50x50 tiles * 2.0 world units = 100x100 world units
export const TOWN_TILE_WORLD_SIZE = 2.0;

export type DistrictId =
  | 'hearth_square'
  | 'wandering_stag_tavern'
  | 'ironroot_forge'
  | 'green_vessel'
  | 'chapel_last_light'
  | 'watch_barracks'
  | 'timber_yard'
  | 'abandoned_manor'
  | 'whispering_gate';

export type InteriorId =
  | 'tavern'
  | 'forge'
  | 'herbalist'
  | 'chapel'
  | 'barracks'
  | 'carpenter'
  | 'manor'
  | 'manor_basement';

export type TownSceneId = 'exterior' | InteriorId;

export type TownTerrainKind =
  | 'cobble_plaza'
  | 'main_road'
  | 'dirt_path'
  | 'alley'
  | 'grass'
  | 'garden_soil'
  | 'forest_floor'
  | 'rocky_hill'
  | 'river_water'
  | 'stone_bridge'
  | 'wooden_bridge'
  | 'wall_stone'
  | 'building_footprint'
  | 'cemetery_ground'
  | 'training_sand';

export interface TownTile {
  x: number;
  z: number;
  terrain: TownTerrainKind;
  elevation: number;
  walkable: boolean;
  districtId?: DistrictId;
}

export interface DistrictDefinition {
  id: DistrictId;
  name: string;
  shortLabel: string;
  subtitle: string;
  description: string;
  landmarkName: string;
  bounds: { minX: number; maxX: number; minZ: number; maxZ: number };
  center: { x: number; z: number };
  interiorId?: InteriorId;
}

export interface BuildingExteriorSpec {
  id: string;
  name: string;
  districtId: DistrictId;
  style:
    | 'tavern_stag'
    | 'tavern_stable'
    | 'forge_workshop'
    | 'herbalist_cottage'
    | 'chapel_stone'
    | 'barracks_watchtower'
    | 'carpenter_shed'
    | 'abandoned_manor'
    | 'gatehouse'
    | 'village_house_a'
    | 'village_house_b';
  footprint: { minX: number; maxX: number; minZ: number; maxZ: number };
  doorTile?: { x: number; z: number }; // Walkable doorstep just outside building
  doorFacing?: 'north' | 'south' | 'east' | 'west';
  linkedInteriorId?: InteriorId;
}

export type InteractiveObjectKind =
  | 'door_enter'
  | 'door_exit'
  | 'secret_stairs'
  | 'ancient_well'
  | 'notice_board'
  | 'herb_patch'
  | 'blight_herb_patch'
  | 'chest'
  | 'damaged_cart'
  | 'roadside_cache'
  | 'training_dummy'
  | 'lore_bookshelf'
  | 'covenant_inscription'
  | 'movable_barrel'
  | 'rest_bed'
  | 'sanctuary_altar'
  | 'secret_latch'
  | 'wilderness_gate'
  | 'forest_clues'
  | 'town_bell'
  | 'garden_crypt';

export interface TownInteractiveObject {
  id: string;
  sceneId: TownSceneId;
  x: number;
  z: number;
  kind: InteractiveObjectKind;
  name: string;
  promptLabel: string;
  districtId?: DistrictId;
  targetSceneId?: TownSceneId;
  targetSpawn?: { x: number; z: number };
  lockedByDefault?: boolean;
  requiredKeyItemId?: string;
  lockpickDc?: number;
  lootItems?: { itemId: ItemId | string; quantity: number }[];
  lootGold?: number;
  gatherItemId?: string;
  loreTitle?: string;
  loreText?: string;
  hiddenUntilFlag?: string;
  blocksMovement?: boolean;
}

export interface InteriorFurnitureProp {
  id: string;
  kind:
    | 'hearth_fire'
    | 'bar_counter'
    | 'dining_table'
    | 'kitchen_cauldron'
    | 'bed'
    | 'forge_furnace'
    | 'anvil'
    | 'weapon_rack'
    | 'workbench'
    | 'potion_shelf'
    | 'alchemy_table'
    | 'greenhouse_planter'
    | 'chapel_altar'
    | 'chapel_pew'
    | 'confessional'
    | 'archive_shelf'
    | 'bunk_bed'
    | 'war_table'
    | 'sawhorse'
    | 'lumber_stack'
    | 'broken_table'
    | 'dusty_bookshelf'
    | 'family_crest_hearth'
    | 'astral_crystal'
    | 'crate_cluster';
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
  blocksMovement: boolean;
  label?: string;
}

export interface InteriorLayoutDefinition {
  id: InteriorId;
  name: string;
  subtitle: string;
  districtId: DistrictId;
  width: number;
  depth: number;
  floorTheme: 'timber_warm' | 'stone_forge' | 'botanical_wood' | 'sanctuary_flagstone' | 'dusty_ruin' | 'astral_vault';
  ambientPreset: 'tavern' | 'forge' | 'herbalist' | 'chapel' | 'barracks' | 'carpenter' | 'manor' | 'basement';
  entrySpawn: { x: number; z: number };
  exitDoorPos: { x: number; z: number };
  returnSceneId: TownSceneId;
  returnSpawn: { x: number; z: number };
  isSecretRoom?: boolean;
  props: InteriorFurnitureProp[];
}

export const GLOAMREST_DISTRICTS: Record<DistrictId, DistrictDefinition> = {
  hearth_square: {
    id: 'hearth_square',
    name: 'Hearth Square',
    shortLabel: 'District A',
    subtitle: 'Central Cobblestone Plaza & Ancient Well',
    description:
      'The social heart of Gloamrest, built around an ancient circular stone well fed by a sacred subterranean spring. Market canopies, benches, lantern posts, and the town notice board ring the flagstones.',
    landmarkName: 'Ancient Stone Well & Town Bell',
    bounds: { minX: 19, maxX: 29, minZ: 20, maxZ: 30 },
    center: { x: 24, z: 25 },
  },
  wandering_stag_tavern: {
    id: 'wandering_stag_tavern',
    name: 'Wandering Stag Tavern',
    shortLabel: 'District B',
    subtitle: 'Two-Story Timber Inn, Taproom & Stables',
    description:
      'A warm timber-framed coaching inn crowned with a carved wooden stag signboard. Travelers, guards, and storytellers gather around Mara Fenwick’s hearth while horses shelter in the rear stable.',
    landmarkName: 'Carved Stag Signboard & Hearth Chimney',
    bounds: { minX: 8, maxX: 18, minZ: 19, maxZ: 28 },
    center: { x: 14, z: 24 },
    interiorId: 'tavern',
  },
  ironroot_forge: {
    id: 'ironroot_forge',
    name: 'Ironroot Forge',
    shortLabel: 'District C',
    subtitle: 'Blacksmith Workshop, Furnace & Armory',
    description:
      'Heavy stone-and-timber smithy where Garron Holt works the outdoor anvil beneath a tall smoking brick furnace chimney, surrounded by weapon racks, split firewood, and iron ingot pallets.',
    landmarkName: 'Smoking Brick Furnace Chimney & Anvil',
    bounds: { minX: 9, maxX: 18, minZ: 9, maxZ: 17 },
    center: { x: 14, z: 14 },
    interiorId: 'forge',
  },
  green_vessel: {
    id: 'green_vessel',
    name: 'The Green Vessel',
    shortLabel: 'District D',
    subtitle: 'Herbalist Cottage, Apothecary & Herb Garden',
    description:
      'Across the Market Stone Bridge stands Elowen Mire’s ivy-draped timber cottage, fragrant with drying bundles of silverleaf, glass apothecary phials, and fenced medicinal garden beds.',
    landmarkName: 'Ivy-Clad Apothecary & Herb Beds',
    bounds: { minX: 33, maxX: 42, minZ: 25, maxZ: 33 },
    center: { x: 36, z: 29 },
    interiorId: 'herbalist',
  },
  chapel_last_light: {
    id: 'chapel_last_light',
    name: 'Chapel of the Last Light',
    shortLabel: 'District E',
    subtitle: 'Old Covenant Sanctuary, Bell Tower & Cemetery',
    description:
      'A weathered grey stone chapel overlooking Silverbrook River. Its narrow bell tower rises beside eroded statues, flickering votive candles, ancient oath inscriptions, and a quiet hedged cemetery.',
    landmarkName: 'Narrow Stone Bell Tower & Oath Stele',
    bounds: { minX: 34, maxX: 45, minZ: 13, maxZ: 23 },
    center: { x: 39, z: 19 },
    interiorId: 'chapel',
  },
  watch_barracks: {
    id: 'watch_barracks',
    name: 'Watch Barracks',
    shortLabel: 'District F',
    subtitle: 'Stone Watchtower, Garrison & Training Yard',
    description:
      'Gloamrest’s northern defensive bastion commanded by Captain Roderic. Features a crenelated watchtower, sparring sand-yard with wooden practice targets, weapon racks, and bounty notices.',
    landmarkName: 'Northern Stone Watchtower & Training Yard',
    bounds: { minX: 20, maxX: 30, minZ: 7, maxZ: 16 },
    center: { x: 25, z: 13 },
    interiorId: 'barracks',
  },
  timber_yard: {
    id: 'timber_yard',
    name: 'Timber Yard',
    shortLabel: 'District G',
    subtitle: 'Lumber Mill, Carpentry Shed & Wagon Works',
    description:
      'Working carpentry quarter managed by Bram Alder. Stacked ironpine timber, chopping blocks, wooden carts, and joinery workbenches supply Gloamrest’s bridges, roofs, and gate barricades.',
    landmarkName: 'Stacked Ironpine Timber & Saw-Shed',
    bounds: { minX: 8, maxX: 18, minZ: 32, maxZ: 42 },
    center: { x: 14, z: 36 },
    interiorId: 'carpenter',
  },
  abandoned_manor: {
    id: 'abandoned_manor',
    name: 'Abandoned Manor',
    shortLabel: 'District H',
    subtitle: 'Shuttered Noble Estate & Overgrown Briar Grounds',
    description:
      'An old noble residence behind a broken stone-and-iron fence in the southeastern bluff. Beneath its collapsed balcony and overgrown garden lies a locked hall connected to the realm’s forgotten oath.',
    landmarkName: 'Collapsed Manor Balcony & Broken Fence',
    bounds: { minX: 35, maxX: 45, minZ: 35, maxZ: 44 },
    center: { x: 39, z: 38 },
    interiorId: 'manor',
  },
  whispering_gate: {
    id: 'whispering_gate',
    name: 'Whispering Gate',
    shortLabel: 'District I',
    subtitle: 'Fortified Gatehouse, Wagon Staging & Vale Road',
    description:
      'Reinforced stone gatehouse and heavy timber gates guarding the stone bridge into Whispering Vale. Scout Sera Wren monitors forest tracks from the staging yard.',
    landmarkName: 'Fortified Gatehouse & Forest Stone Bridge',
    bounds: { minX: 33, maxX: 45, minZ: 2, maxZ: 11 },
    center: { x: 37, z: 8 },
  },
};

export const BUILDING_EXTERIORS: BuildingExteriorSpec[] = [
  {
    id: 'bldg_tavern',
    name: 'The Wandering Stag Tavern',
    districtId: 'wandering_stag_tavern',
    style: 'tavern_stag',
    footprint: { minX: 11, maxX: 16, minZ: 20, maxZ: 23 },
    doorTile: { x: 14, z: 24 },
    doorFacing: 'south',
    linkedInteriorId: 'tavern',
  },
  {
    id: 'bldg_tavern_stable',
    name: 'Tavern Timber Stables',
    districtId: 'wandering_stag_tavern',
    style: 'tavern_stable',
    footprint: { minX: 8, maxX: 10, minZ: 20, maxZ: 23 },
  },
  {
    id: 'bldg_forge',
    name: 'Ironroot Forge',
    districtId: 'ironroot_forge',
    style: 'forge_workshop',
    footprint: { minX: 10, maxX: 15, minZ: 10, maxZ: 13 },
    doorTile: { x: 13, z: 14 },
    doorFacing: 'south',
    linkedInteriorId: 'forge',
  },
  {
    id: 'bldg_herbalist',
    name: 'The Green Vessel',
    districtId: 'green_vessel',
    style: 'herbalist_cottage',
    footprint: { minX: 36, maxX: 40, minZ: 26, maxZ: 29 },
    doorTile: { x: 35, z: 28 },
    doorFacing: 'west',
    linkedInteriorId: 'herbalist',
  },
  {
    id: 'bldg_chapel',
    name: 'Chapel of the Last Light',
    districtId: 'chapel_last_light',
    style: 'chapel_stone',
    footprint: { minX: 38, maxX: 43, minZ: 14, maxZ: 18 },
    doorTile: { x: 40, z: 19 },
    doorFacing: 'south',
    linkedInteriorId: 'chapel',
  },
  {
    id: 'bldg_barracks',
    name: 'Watch Barracks & Watchtower',
    districtId: 'watch_barracks',
    style: 'barracks_watchtower',
    footprint: { minX: 21, maxX: 26, minZ: 8, maxZ: 11 },
    doorTile: { x: 24, z: 12 },
    doorFacing: 'south',
    linkedInteriorId: 'barracks',
  },
  {
    id: 'bldg_carpenter',
    name: 'Alder’s Carpentry Workshop',
    districtId: 'timber_yard',
    style: 'carpenter_shed',
    footprint: { minX: 9, maxX: 13, minZ: 34, maxZ: 37 },
    doorTile: { x: 14, z: 36 },
    doorFacing: 'east',
    linkedInteriorId: 'carpenter',
  },
  {
    id: 'bldg_manor',
    name: 'Abandoned Veyne Manor',
    districtId: 'abandoned_manor',
    style: 'abandoned_manor',
    footprint: { minX: 39, maxX: 44, minZ: 39, maxZ: 43 },
    doorTile: { x: 41, z: 38 },
    doorFacing: 'north',
    linkedInteriorId: 'manor',
  },
  {
    id: 'bldg_gatehouse_west',
    name: 'Whispering Gate Bastion',
    districtId: 'whispering_gate',
    style: 'gatehouse',
    footprint: { minX: 35, maxX: 36, minZ: 5, maxZ: 6 },
  },
  {
    id: 'bldg_gatehouse_east',
    name: 'Whispering Gate Bastion East',
    districtId: 'whispering_gate',
    style: 'gatehouse',
    footprint: { minX: 40, maxX: 41, minZ: 5, maxZ: 6 },
  },
  // Distinct non-identical residential cottages along secondary lanes & alleys
  {
    id: 'bldg_cottage_north_alley',
    name: 'Weaver’s Stone Cottage',
    districtId: 'hearth_square',
    style: 'village_house_a',
    footprint: { minX: 17, maxX: 19, minZ: 15, maxZ: 17 },
  },
  {
    id: 'bldg_cottage_south_lane',
    name: 'Cooper’s Gabled Homestead',
    districtId: 'hearth_square',
    style: 'village_house_b',
    footprint: { minX: 27, maxX: 29, minZ: 33, maxZ: 35 },
  },
];

/**
 * Generates the complete 50x50 (100x100 world unit) interconnected settlement grid.
 */
export function generateGloamrestExteriorGrid(): TownTile[][] {
  const grid: TownTile[][] = [];

  for (let x = 0; x < TOWN_GRID_SIZE; x++) {
    const col: TownTile[] = [];
    for (let z = 0; z < TOWN_GRID_SIZE; z++) {
      // Default outer wilderness woodland & hills outside town walls
      const outsideWalls = x < 5 || x > 46 || z < 5 || z > 46;
      let terrain: TownTerrainKind = outsideWalls ? 'forest_floor' : 'grass';
      let elevation = 0;
      let walkable = !outsideWalls;

      // Rocky hills on far perimeter
      if (x <= 2 || x >= 48 || z <= 1 || z >= 48) {
        terrain = 'rocky_hill';
        elevation = 1;
        walkable = false;
      }

      // Town defensive stone walls at x=5, x=46, z=5, z=46
      const isPerimeterWall =
        ((x === 5 || x === 46) && z >= 5 && z <= 46) ||
        ((z === 5 || z === 46) && x >= 5 && x <= 46);
      if (isPerimeterWall) {
        terrain = 'wall_stone';
        elevation = 1;
        walkable = false;
      }

      // Main South Pilgrim Entrance opening (x = 23..26, z = 44..47)
      if (x >= 23 && x <= 26 && z >= 44 && z <= 47) {
        terrain = 'main_road';
        elevation = 0;
        walkable = true;
      }

      // North-East Whispering Gate & Wilderness Forest Road exit (x = 37..39, z = 2..6)
      if (x >= 37 && x <= 39 && z >= 2 && z <= 7) {
        terrain = 'main_road';
        elevation = 0;
        walkable = true;
      }
      if (x >= 36 && x <= 43 && z >= 2 && z <= 4) {
        terrain = x >= 37 && x <= 41 ? 'dirt_path' : 'forest_floor';
        elevation = 0;
        walkable = true;
      }

      // Silverbrook River flowing North-to-South through x = 31..32
      if (x >= 31 && x <= 32 && z >= 2 && z <= 47) {
        terrain = 'river_water';
        elevation = -0.25;
        walkable = false;
      }

      // Three Bridges crossing Silverbrook River:
      // 1) Northern Gatehouse Stone Bridge (z = 7..8, x = 30..33)
      if (x >= 30 && x <= 33 && (z === 7 || z === 8)) {
        terrain = 'stone_bridge';
        elevation = 0.08;
        walkable = true;
      }
      // 2) Central Market Stone Bridge (z = 24..25, x = 30..33)
      if (x >= 30 && x <= 33 && (z === 24 || z === 25)) {
        terrain = 'stone_bridge';
        elevation = 0.08;
        walkable = true;
      }
      // 3) Southern Mill Wooden Footbridge (z = 36, x = 30..33)
      if (x >= 30 && x <= 33 && z === 36) {
        terrain = 'wooden_bridge';
        elevation = 0.06;
        walkable = true;
      }

      // Hearth Square Irregular Cobblestone Plaza (center (24,25))
      const dxSq = x - 24;
      const dzSq = z - 25;
      if (dxSq * dxSq + dzSq * dzSq <= 30 && x <= 29) {
        terrain = 'cobble_plaza';
        walkable = true;
      }

      // Interconnected Main Streets & Secondary Paths:
      // - South Pilgrim Road (x = 24..25, z = 29..46)
      if ((x === 24 || x === 25) && z >= 29 && z <= 46) {
        terrain = 'main_road';
        walkable = true;
      }
      // - North Watch Road (x = 24..25, z = 12..21)
      if ((x === 24 || x === 25) && z >= 12 && z <= 21) {
        terrain = 'main_road';
        walkable = true;
      }
      // - West Tavern & Forge High Street (z = 24..25, x = 12..20)
      if ((z === 24 || z === 25) && x >= 11 && x <= 20) {
        terrain = 'main_road';
        walkable = true;
      }
      // - Craft Lane up to Ironroot Forge (x = 13..14, z = 14..24)
      if ((x === 13 || x === 14) && z >= 14 && z <= 24) {
        terrain = 'dirt_path';
        walkable = true;
      }
      // - Back Alley linking Ironroot Forge to Watch Barracks (z = 14, x = 14..24)
      if (z === 14 && x >= 14 && x <= 24) {
        terrain = 'alley';
        walkable = true;
      }
      // - Timber Yard Lane going South-West (x = 14..15, z = 25..39 and z = 36, x = 14..30)
      if ((x === 14 || x === 15) && z >= 25 && z <= 39) {
        terrain = 'dirt_path';
        walkable = true;
      }
      if (z === 36 && x >= 14 && x <= 30) {
        terrain = 'dirt_path';
        walkable = true;
      }
      // - Northern Garrison Road to Gate Bridge & Whispering Gate (z = 8, x = 25..38)
      if ((z === 7 || z === 8) && x >= 25 && x <= 39) {
        terrain = x >= 30 && x <= 33 ? 'stone_bridge' : 'main_road';
        walkable = true;
      }
      if ((x === 25 || x === 26) && z >= 8 && z <= 13) {
        terrain = 'dirt_path';
        walkable = true;
      }
      // - East Bank Road connecting Gatehouse -> Chapel -> Market Bridge -> Green Vessel -> Abandoned Manor
      if ((x === 34 || x === 35) && z >= 8 && z <= 37) {
        terrain = 'main_road';
        walkable = true;
      }
      // - Chapel Walk (z = 19..20, x = 35..42)
      if ((z === 19 || z === 20) && x >= 35 && x <= 42) {
        terrain = 'cobble_plaza';
        walkable = true;
      }
      // - Chapel Cemetery Ground (x = 42..44, z = 20..22)
      if (x >= 42 && x <= 44 && z >= 20 && z <= 22) {
        terrain = 'cemetery_ground';
        walkable = true;
      }
      // - Green Vessel Herb Garden Soil (x = 33..35, z = 30..32)
      if (x >= 33 && x <= 35 && z >= 30 && z <= 32) {
        terrain = 'garden_soil';
        walkable = true;
      }
      // - Watch Barracks Training Sand Yard (x = 27..29, z = 10..13)
      if (x >= 27 && x <= 29 && z >= 10 && z <= 13) {
        terrain = 'training_sand';
        walkable = true;
      }
      // - Abandoned Manor Broken Stone Fence (x=36..44, z=35 with open breach at x=38..39)
      if (z === 35 && x >= 36 && x <= 44 && x !== 38 && x !== 39) {
        terrain = 'wall_stone';
        walkable = false;
      }
      if (x === 36 && z >= 35 && z <= 44 && z !== 36) {
        terrain = 'wall_stone';
        walkable = false;
      }
      if ((x === 38 || x === 39 || x === 40 || x === 41) && z >= 35 && z <= 38) {
        terrain = 'dirt_path';
        walkable = true;
      }

      // Assign District ID if inside a district's bounding box
      let districtId: DistrictId | undefined;
      for (const dist of Object.values(GLOAMREST_DISTRICTS)) {
        if (
          x >= dist.bounds.minX &&
          x <= dist.bounds.maxX &&
          z >= dist.bounds.minZ &&
          z <= dist.bounds.maxZ
        ) {
          districtId = dist.id;
          break;
        }
      }

      col.push({ x, z, terrain, elevation, walkable, districtId });
    }
    grid.push(col);
  }

  // Stamp building footprints as non-walkable while guaranteeing doorTiles are walkable
  for (const bldg of BUILDING_EXTERIORS) {
    for (let x = bldg.footprint.minX; x <= bldg.footprint.maxX; x++) {
      for (let z = bldg.footprint.minZ; z <= bldg.footprint.maxZ; z++) {
        if (grid[x]?.[z]) {
          grid[x][z].terrain = 'building_footprint';
          grid[x][z].walkable = false;
          grid[x][z].districtId = bldg.districtId;
        }
      }
    }
    if (bldg.doorTile && grid[bldg.doorTile.x]?.[bldg.doorTile.z]) {
      grid[bldg.doorTile.x][bldg.doorTile.z].walkable = true;
    }
  }

  // Ancient circular stone well center tile (24,25) is solid stone rim, surrounded by walkable plaza
  if (grid[24]?.[25]) {
    grid[24][25].walkable = false;
  }

  return grid;
}

/**
 * Distinct interior architectural layouts for all 7 accessible buildings + 1 secret basement vault.
 */
export const GLOAMREST_INTERIORS: Record<InteriorId, InteriorLayoutDefinition> = {
  tavern: {
    id: 'tavern',
    name: 'Wandering Stag Tavern — Taproom & Hearth',
    subtitle: 'Common Dining Hall, Oak Bar, Kitchen & Guest Stairs',
    districtId: 'wandering_stag_tavern',
    width: 14,
    depth: 12,
    floorTheme: 'timber_warm',
    ambientPreset: 'tavern',
    entrySpawn: { x: 7, z: 9 },
    exitDoorPos: { x: 7, z: 10 },
    returnSceneId: 'exterior',
    returnSpawn: { x: 14, z: 24 },
    props: [
      { id: 'tav_hearth', kind: 'hearth_fire', minX: 5, maxX: 7, minZ: 1, maxZ: 1, blocksMovement: true, label: 'Roaring Hearth Fireplace' },
      { id: 'tav_bar', kind: 'bar_counter', minX: 9, maxX: 12, minZ: 3, maxZ: 4, blocksMovement: true, label: 'Oak Taproom Counter' },
      { id: 'tav_kitchen', kind: 'kitchen_cauldron', minX: 11, maxX: 12, minZ: 1, maxZ: 2, blocksMovement: true, label: 'Kitchen Stew Cauldron' },
      { id: 'tav_table_1', kind: 'dining_table', minX: 3, maxX: 4, minZ: 4, maxZ: 5, blocksMovement: true, label: 'Travelers’ Dining Table' },
      { id: 'tav_table_2', kind: 'dining_table', minX: 3, maxX: 4, minZ: 7, maxZ: 8, blocksMovement: true, label: 'Corner Booth Table' },
      { id: 'tav_storage', kind: 'crate_cluster', minX: 1, maxX: 2, minZ: 1, maxZ: 2, blocksMovement: true, label: 'Cellar Cask Storage' },
      { id: 'tav_guest_bed', kind: 'bed', minX: 11, maxX: 12, minZ: 8, maxZ: 9, blocksMovement: true, label: 'Upstairs Guest Room Berth' },
    ],
  },

  forge: {
    id: 'forge',
    name: 'Ironroot Forge — Smithy & Armory',
    subtitle: 'Main Smelting Furnace, Anvil, Quench Trough & Racks',
    districtId: 'ironroot_forge',
    width: 12,
    depth: 10,
    floorTheme: 'stone_forge',
    ambientPreset: 'forge',
    entrySpawn: { x: 6, z: 7 },
    exitDoorPos: { x: 6, z: 8 },
    returnSceneId: 'exterior',
    returnSpawn: { x: 13, z: 14 },
    props: [
      { id: 'frg_furnace', kind: 'forge_furnace', minX: 5, maxX: 7, minZ: 1, maxZ: 2, blocksMovement: true, label: 'Blazing Smelting Furnace' },
      { id: 'frg_anvil', kind: 'anvil', minX: 6, maxX: 6, minZ: 4, maxZ: 4, blocksMovement: true, label: 'Master Ironroot Anvil' },
      { id: 'frg_racks', kind: 'weapon_rack', minX: 9, maxX: 10, minZ: 2, maxZ: 5, blocksMovement: true, label: 'Tempered Weapon Display' },
      { id: 'frg_bench', kind: 'workbench', minX: 1, maxX: 3, minZ: 2, maxZ: 3, blocksMovement: true, label: 'Armorer’s Grindstone Bench' },
      { id: 'frg_ingots', kind: 'crate_cluster', minX: 1, maxX: 2, minZ: 6, maxZ: 7, blocksMovement: true, label: 'Coal & Ore Bins' },
    ],
  },

  herbalist: {
    id: 'herbalist',
    name: 'The Green Vessel — Apothecary & Glasshouse',
    subtitle: 'Botanical Shelves, Mortar Workstation & Conservatory',
    districtId: 'green_vessel',
    width: 11,
    depth: 10,
    floorTheme: 'botanical_wood',
    ambientPreset: 'herbalist',
    entrySpawn: { x: 2, z: 5 },
    exitDoorPos: { x: 1, z: 5 },
    returnSceneId: 'exterior',
    returnSpawn: { x: 35, z: 28 },
    props: [
      { id: 'hrb_shelves', kind: 'potion_shelf', minX: 3, maxX: 7, minZ: 1, maxZ: 1, blocksMovement: true, label: 'Tincture & Phial Shelves' },
      { id: 'hrb_table', kind: 'alchemy_table', minX: 5, maxX: 6, minZ: 4, maxZ: 5, blocksMovement: true, label: 'Mortar & Alembic Table' },
      { id: 'hrb_greenhouse', kind: 'greenhouse_planter', minX: 8, maxX: 9, minZ: 2, maxZ: 7, blocksMovement: true, label: 'Glasshouse Seedling Beds' },
      { id: 'hrb_books', kind: 'archive_shelf', minX: 2, maxX: 3, minZ: 8, maxZ: 8, blocksMovement: true, label: 'Botanical Codices' },
    ],
  },

  chapel: {
    id: 'chapel',
    name: 'Chapel of the Last Light — Nave & Archive',
    subtitle: 'Sanctuary Altar, Confessional & Pre-Schism Archive',
    districtId: 'chapel_last_light',
    width: 12,
    depth: 14,
    floorTheme: 'sanctuary_flagstone',
    ambientPreset: 'chapel',
    entrySpawn: { x: 6, z: 11 },
    exitDoorPos: { x: 6, z: 12 },
    returnSceneId: 'exterior',
    returnSpawn: { x: 40, z: 19 },
    props: [
      { id: 'chp_altar', kind: 'chapel_altar', minX: 5, maxX: 7, minZ: 2, maxZ: 3, blocksMovement: true, label: 'Altar of the Last Light' },
      { id: 'chp_pew_l1', kind: 'chapel_pew', minX: 2, maxX: 4, minZ: 6, maxZ: 6, blocksMovement: true },
      { id: 'chp_pew_l2', kind: 'chapel_pew', minX: 2, maxX: 4, minZ: 9, maxZ: 9, blocksMovement: true },
      { id: 'chp_pew_r1', kind: 'chapel_pew', minX: 8, maxX: 9, minZ: 6, maxZ: 6, blocksMovement: true },
      { id: 'chp_confess', kind: 'confessional', minX: 1, maxX: 2, minZ: 2, maxZ: 3, blocksMovement: true, label: 'Carved Confessional Screen' },
      { id: 'chp_archive', kind: 'archive_shelf', minX: 9, maxX: 10, minZ: 2, maxZ: 4, blocksMovement: true, label: 'Covenant Historical Archive' },
    ],
  },

  barracks: {
    id: 'barracks',
    name: 'Watch Barracks — Garrison Hall & Armory',
    subtitle: 'Guard Quarters, Tactical Map Table & Locked Armory',
    districtId: 'watch_barracks',
    width: 13,
    depth: 10,
    floorTheme: 'stone_forge',
    ambientPreset: 'barracks',
    entrySpawn: { x: 6, z: 7 },
    exitDoorPos: { x: 6, z: 8 },
    returnSceneId: 'exterior',
    returnSpawn: { x: 24, z: 12 },
    props: [
      { id: 'brk_wartable', kind: 'war_table', minX: 5, maxX: 7, minZ: 4, maxZ: 5, blocksMovement: true, label: 'Whispering Vale Defense Map' },
      { id: 'brk_bunk_1', kind: 'bunk_bed', minX: 1, maxX: 2, minZ: 2, maxZ: 3, blocksMovement: true, label: 'Watchman Bunks' },
      { id: 'brk_bunk_2', kind: 'bunk_bed', minX: 1, maxX: 2, minZ: 5, maxZ: 6, blocksMovement: true },
      { id: 'brk_armory', kind: 'weapon_rack', minX: 10, maxX: 11, minZ: 2, maxZ: 6, blocksMovement: true, label: 'Garrison Halberd & Shield Racks' },
    ],
  },

  carpenter: {
    id: 'carpenter',
    name: 'Alder’s Joinery & Timber Shed',
    subtitle: 'Sawhorses, Planing Workbench & Seasoned Stock',
    districtId: 'timber_yard',
    width: 11,
    depth: 9,
    floorTheme: 'timber_warm',
    ambientPreset: 'carpenter',
    entrySpawn: { x: 8, z: 4 },
    exitDoorPos: { x: 9, z: 4 },
    returnSceneId: 'exterior',
    returnSpawn: { x: 14, z: 36 },
    props: [
      { id: 'crp_bench', kind: 'workbench', minX: 4, maxX: 6, minZ: 2, maxZ: 2, blocksMovement: true, label: 'Master Joinery Workbench' },
      { id: 'crp_saw', kind: 'sawhorse', minX: 4, maxX: 5, minZ: 5, maxZ: 5, blocksMovement: true, label: 'Oak Sawhorse' },
      { id: 'crp_lumber', kind: 'lumber_stack', minX: 1, maxX: 2, minZ: 2, maxZ: 6, blocksMovement: true, label: 'Seasoned Ironpine Beams' },
    ],
  },

  manor: {
    id: 'manor',
    name: 'Abandoned Veyne Manor — Ruined Hall & Library',
    subtitle: 'Dust-Choked Parlor, Damaged Library & Forgotten Crest',
    districtId: 'abandoned_manor',
    width: 14,
    depth: 12,
    floorTheme: 'dusty_ruin',
    ambientPreset: 'manor',
    entrySpawn: { x: 7, z: 2 },
    exitDoorPos: { x: 7, z: 1 },
    returnSceneId: 'exterior',
    returnSpawn: { x: 41, z: 38 },
    props: [
      { id: 'mnr_crest', kind: 'family_crest_hearth', minX: 6, maxX: 8, minZ: 9, maxZ: 10, blocksMovement: true, label: 'Forgotten Veyne Crest Hearth' },
      { id: 'mnr_lib_1', kind: 'dusty_bookshelf', minX: 1, maxX: 2, minZ: 3, maxZ: 8, blocksMovement: true, label: 'Damaged Noble Library' },
      { id: 'mnr_table', kind: 'broken_table', minX: 5, maxX: 6, minZ: 5, maxZ: 6, blocksMovement: true, label: 'Shattered Banquet Table' },
      { id: 'mnr_crates', kind: 'crate_cluster', minX: 11, maxX: 12, minZ: 8, maxZ: 9, blocksMovement: true },
    ],
  },

  manor_basement: {
    id: 'manor_basement',
    name: 'Hidden Manor Basement — Vault of the First Vigil',
    subtitle: 'Secret Subterranean Spring Conduit & Covenant Reliquary',
    districtId: 'abandoned_manor',
    width: 10,
    depth: 10,
    floorTheme: 'astral_vault',
    ambientPreset: 'basement',
    isSecretRoom: true,
    entrySpawn: { x: 5, z: 7 },
    exitDoorPos: { x: 5, z: 8 },
    returnSceneId: 'manor',
    returnSpawn: { x: 11, z: 4 },
    props: [
      { id: 'bsm_crystal_l', kind: 'astral_crystal', minX: 2, maxX: 2, minZ: 3, maxZ: 3, blocksMovement: true, label: 'Spring Conduit Shard' },
      { id: 'bsm_crystal_r', kind: 'astral_crystal', minX: 7, maxX: 7, minZ: 3, maxZ: 3, blocksMovement: true, label: 'Spring Conduit Shard' },
      { id: 'bsm_altar', kind: 'chapel_altar', minX: 4, maxX: 5, minZ: 2, maxZ: 2, blocksMovement: true, label: 'Dais of the First Vigil' },
    ],
  },
};

/**
 * Generates a walkable tile grid for any building interior, stamping perimeter walls and furniture collisions.
 */
export function generateInteriorGrid(interiorId: InteriorId): TownTile[][] {
  const def = GLOAMREST_INTERIORS[interiorId];
  const grid: TownTile[][] = [];
  for (let x = 0; x < def.width; x++) {
    const col: TownTile[] = [];
    for (let z = 0; z < def.depth; z++) {
      const isWall = x === 0 || x === def.width - 1 || z === 0 || z === def.depth - 1;
      col.push({
        x,
        z,
        terrain: isWall ? 'wall_stone' : 'cobble_plaza',
        elevation: 0,
        walkable: !isWall,
        districtId: def.districtId,
      });
    }
    grid.push(col);
  }

  for (const prop of def.props) {
    if (!prop.blocksMovement) continue;
    for (let x = prop.minX; x <= prop.maxX; x++) {
      for (let z = prop.minZ; z <= prop.maxZ; z++) {
        if (grid[x]?.[z]) {
          grid[x][z].walkable = false;
        }
      }
    }
  }

  // Ensure entry spawn & exit door tiles are always walkable
  if (grid[def.entrySpawn.x]?.[def.entrySpawn.z]) {
    grid[def.entrySpawn.x][def.entrySpawn.z].walkable = true;
  }
  if (grid[def.exitDoorPos.x]?.[def.exitDoorPos.z]) {
    grid[def.exitDoorPos.x][def.exitDoorPos.z].walkable = true;
  }

  return grid;
}

/**
 * Canonical interactive objects across Gloamrest's exterior districts and building interiors.
 */
export function createInitialGloamrestObjects(): TownInteractiveObject[] {
  return [
    // ==================== BUILDING ENTRANCE DOORS (EXTERIOR) ====================
    {
      id: 'door_tavern_enter',
      sceneId: 'exterior',
      x: 14,
      z: 23,
      kind: 'door_enter',
      name: 'Wandering Stag Tavern Door',
      promptLabel: 'Enter Wandering Stag Tavern [E]',
      districtId: 'wandering_stag_tavern',
      targetSceneId: 'tavern',
      targetSpawn: { x: 7, z: 9 },
    },
    {
      id: 'door_forge_enter',
      sceneId: 'exterior',
      x: 13,
      z: 13,
      kind: 'door_enter',
      name: 'Ironroot Forge Entrance',
      promptLabel: 'Enter Ironroot Forge [E]',
      districtId: 'ironroot_forge',
      targetSceneId: 'forge',
      targetSpawn: { x: 6, z: 7 },
    },
    {
      id: 'door_herbalist_enter',
      sceneId: 'exterior',
      x: 36,
      z: 28,
      kind: 'door_enter',
      name: 'The Green Vessel Door',
      promptLabel: 'Enter The Green Vessel [E]',
      districtId: 'green_vessel',
      targetSceneId: 'herbalist',
      targetSpawn: { x: 2, z: 5 },
    },
    {
      id: 'door_chapel_enter',
      sceneId: 'exterior',
      x: 40,
      z: 18,
      kind: 'door_enter',
      name: 'Chapel of the Last Light Portal',
      promptLabel: 'Enter Chapel of the Last Light [E]',
      districtId: 'chapel_last_light',
      targetSceneId: 'chapel',
      targetSpawn: { x: 6, z: 11 },
    },
    {
      id: 'door_barracks_enter',
      sceneId: 'exterior',
      x: 24,
      z: 11,
      kind: 'door_enter',
      name: 'Watch Barracks Gate',
      promptLabel: 'Enter Watch Barracks [E]',
      districtId: 'watch_barracks',
      targetSceneId: 'barracks',
      targetSpawn: { x: 6, z: 7 },
    },
    {
      id: 'door_carpenter_enter',
      sceneId: 'exterior',
      x: 13,
      z: 36,
      kind: 'door_enter',
      name: 'Carpentry Workshop Door',
      promptLabel: 'Enter Carpentry Workshop [E]',
      districtId: 'timber_yard',
      targetSceneId: 'carpenter',
      targetSpawn: { x: 8, z: 4 },
    },
    {
      id: 'door_manor_enter',
      sceneId: 'exterior',
      x: 41,
      z: 39,
      kind: 'door_enter',
      name: 'Locked Manor Oak Doors',
      promptLabel: 'Inspect / Unlock Abandoned Manor [E]',
      districtId: 'abandoned_manor',
      targetSceneId: 'manor',
      targetSpawn: { x: 7, z: 2 },
      lockedByDefault: true,
      requiredKeyItemId: 'manor_rusted_key',
      lockpickDc: 13,
    },

    // ==================== INTERIOR EXIT DOORS & SECRET STAIRS ====================
    {
      id: 'door_tavern_exit',
      sceneId: 'tavern',
      x: 7,
      z: 10,
      kind: 'door_exit',
      name: 'Exit to Hearth Square West',
      promptLabel: 'Leave Wandering Stag Tavern [E]',
      targetSceneId: 'exterior',
      targetSpawn: { x: 14, z: 24 },
    },
    {
      id: 'door_forge_exit',
      sceneId: 'forge',
      x: 6,
      z: 8,
      kind: 'door_exit',
      name: 'Exit to Ironroot Yard',
      promptLabel: 'Leave Ironroot Forge [E]',
      targetSceneId: 'exterior',
      targetSpawn: { x: 13, z: 14 },
    },
    {
      id: 'door_herbalist_exit',
      sceneId: 'herbalist',
      x: 1,
      z: 5,
      kind: 'door_exit',
      name: 'Exit to Herb Garden',
      promptLabel: 'Leave The Green Vessel [E]',
      targetSceneId: 'exterior',
      targetSpawn: { x: 35, z: 28 },
    },
    {
      id: 'door_chapel_exit',
      sceneId: 'chapel',
      x: 6,
      z: 12,
      kind: 'door_exit',
      name: 'Exit to Chapel Courtyard',
      promptLabel: 'Leave Chapel of the Last Light [E]',
      targetSceneId: 'exterior',
      targetSpawn: { x: 40, z: 19 },
    },
    {
      id: 'door_barracks_exit',
      sceneId: 'barracks',
      x: 6,
      z: 8,
      kind: 'door_exit',
      name: 'Exit to Training Yard',
      promptLabel: 'Leave Watch Barracks [E]',
      targetSceneId: 'exterior',
      targetSpawn: { x: 24, z: 12 },
    },
    {
      id: 'door_carpenter_exit',
      sceneId: 'carpenter',
      x: 9,
      z: 4,
      kind: 'door_exit',
      name: 'Exit to Timber Yard',
      promptLabel: 'Leave Carpentry Workshop [E]',
      targetSceneId: 'exterior',
      targetSpawn: { x: 14, z: 36 },
    },
    {
      id: 'door_manor_exit',
      sceneId: 'manor',
      x: 7,
      z: 1,
      kind: 'door_exit',
      name: 'Exit to Manor Grounds',
      promptLabel: 'Leave Abandoned Manor [E]',
      targetSceneId: 'exterior',
      targetSpawn: { x: 41, z: 38 },
    },
    {
      id: 'door_manor_basement_enter',
      sceneId: 'manor',
      x: 11,
      z: 3,
      kind: 'secret_stairs',
      name: 'Hidden Vault Stairwell',
      promptLabel: 'Descend into Hidden Manor Basement [E]',
      targetSceneId: 'manor_basement',
      targetSpawn: { x: 5, z: 7 },
      hiddenUntilFlag: 'manor_basement_revealed',
    },
    {
      id: 'door_manor_basement_exit',
      sceneId: 'manor_basement',
      x: 5,
      z: 8,
      kind: 'door_exit',
      name: 'Stairs to Manor Library',
      promptLabel: 'Ascend to Manor Hall [E]',
      targetSceneId: 'manor',
      targetSpawn: { x: 11, z: 4 },
    },

    // ==================== DISTRICT A: HEARTH SQUARE LANDMARKS ====================
    {
      id: 'obj_ancient_well',
      sceneId: 'exterior',
      x: 24,
      z: 25,
      kind: 'ancient_well',
      name: 'Ancient Sacred Stone Well',
      promptLabel: 'Inspect Ancient Well [E]',
      districtId: 'hearth_square',
    },
    {
      id: 'obj_square_notice_board',
      sceneId: 'exterior',
      x: 22,
      z: 23,
      kind: 'notice_board',
      name: 'Hearth Square Notice Board',
      promptLabel: 'Read Public Notices & Bounties [E]',
      districtId: 'hearth_square',
    },
    {
      id: 'obj_town_bell',
      sceneId: 'exterior',
      x: 26,
      z: 23,
      kind: 'town_bell',
      name: 'Gloamrest Bronze Watch-Bell',
      promptLabel: 'Examine Town Bell [E]',
      districtId: 'hearth_square',
    },

    // ==================== HERB GATHERING NODES (SIDE QUEST 01) ====================
    {
      id: 'herb_garden_silverleaf',
      sceneId: 'exterior',
      x: 34,
      z: 31,
      kind: 'herb_patch',
      name: 'Silverleaf Garden Bed',
      promptLabel: 'Harvest Fresh Silverleaf [E]',
      districtId: 'green_vessel',
      gatherItemId: 'silverleaf_herb',
    },
    {
      id: 'herb_riverbank_bitterroot',
      sceneId: 'exterior',
      x: 30,
      z: 28,
      kind: 'herb_patch',
      name: 'Riverbank Bitterroot Clump',
      promptLabel: 'Harvest Vale Bitterroot [E]',
      districtId: 'hearth_square',
      gatherItemId: 'bitterroot_stalk',
    },
    {
      id: 'herb_timber_silverleaf',
      sceneId: 'exterior',
      x: 17,
      z: 38,
      kind: 'herb_patch',
      name: 'Millstream Silverleaf Patch',
      promptLabel: 'Harvest Fresh Silverleaf [E]',
      districtId: 'timber_yard',
      gatherItemId: 'silverleaf_herb',
    },
    {
      id: 'herb_chapel_bitterroot',
      sceneId: 'exterior',
      x: 36,
      z: 21,
      kind: 'herb_patch',
      name: 'Chapel Slope Bitterroot',
      promptLabel: 'Harvest Vale Bitterroot [E]',
      districtId: 'chapel_last_light',
      gatherItemId: 'bitterroot_stalk',
    },
    {
      id: 'herb_manor_blight',
      sceneId: 'exterior',
      x: 37,
      z: 40,
      kind: 'blight_herb_patch',
      name: 'Rift-Touched Nightshade',
      promptLabel: 'Examine Strange Glowing Plant [E]',
      districtId: 'abandoned_manor',
      gatherItemId: 'blight_nightshade',
    },

    // ==================== QUEST & EXPLORATION OBJECTS ====================
    {
      id: 'obj_damaged_supply_cart',
      sceneId: 'exterior',
      x: 34,
      z: 9,
      kind: 'damaged_cart',
      name: 'Splintered Ironroot Supply Cart',
      promptLabel: 'Inspect Damaged Supply Cart [E]',
      districtId: 'whispering_gate',
      blocksMovement: true,
    },
    {
      id: 'obj_roadside_ravine_cache',
      sceneId: 'exterior',
      x: 42,
      z: 3,
      kind: 'roadside_cache',
      name: 'Overturned Ravine Ore Crate',
      promptLabel: 'Search Roadside Ore Cache [E]',
      districtId: 'whispering_gate',
      lootItems: [{ itemId: 'meteoric_ironroot_ingots', quantity: 1 }],
      lootGold: 12,
    },
    {
      id: 'obj_gate_forest_clues',
      sceneId: 'exterior',
      x: 39,
      z: 4,
      kind: 'forest_clues',
      name: 'Scorched Waystone & Clawed Tracks',
      promptLabel: 'Examine Wilderness Clues [E]',
      districtId: 'whispering_gate',
    },
    {
      id: 'obj_whispering_gate_exit',
      sceneId: 'exterior',
      x: 40,
      z: 2,
      kind: 'wilderness_gate',
      name: 'Whispering Vale Road',
      promptLabel: 'Travel into Whispering Vale [E]',
      districtId: 'whispering_gate',
    },
    {
      id: 'obj_training_dummy',
      sceneId: 'exterior',
      x: 28,
      z: 11,
      kind: 'training_dummy',
      name: 'Armored Combat Practice Target',
      promptLabel: 'Practice Tactical Strikes [E]',
      districtId: 'watch_barracks',
      blocksMovement: true,
    },
    {
      id: 'obj_timber_movable_barrel',
      sceneId: 'exterior',
      x: 16,
      z: 35,
      kind: 'movable_barrel',
      name: 'Pitch-Oil Timber Barrel',
      promptLabel: 'Inspect / Shove Heavy Barrel [E]',
      districtId: 'timber_yard',
      blocksMovement: true,
    },
    {
      id: 'obj_chapel_oath_stele',
      sceneId: 'exterior',
      x: 37,
      z: 17,
      kind: 'covenant_inscription',
      name: 'Weathered Covenant Oath Stele',
      promptLabel: 'Read Ancient Stone Inscription [E]',
      districtId: 'chapel_last_light',
      loreTitle: 'Stele of the Subterranean Vigil',
      loreText:
        '“Three springs feed the Vale: the High Reliquary, the Briar Root, and Gloamrest’s Deep Well. Should the Crown of Echoes fracture, the waters below shall shine with star-fire to warn the keepers.”',
    },
    {
      id: 'obj_manor_garden_crypt',
      sceneId: 'exterior',
      x: 44,
      z: 37,
      kind: 'garden_crypt',
      name: 'Overgrown Sundial Urn',
      promptLabel: 'Search Overgrown Sundial [E]',
      districtId: 'abandoned_manor',
      lootItems: [{ itemId: 'manor_rusted_key', quantity: 1 }],
      lootGold: 15,
    },

    // ==================== INTERIOR INTERACTABLES ====================
    {
      id: 'int_tavern_rest_bed',
      sceneId: 'tavern',
      x: 10,
      z: 8,
      kind: 'rest_bed',
      name: 'Guest Room Feather Bed',
      promptLabel: 'Rent Room & Rest (10g · Restore Full HP) [E]',
      districtId: 'wandering_stag_tavern',
    },
    {
      id: 'int_tavern_lore_ledger',
      sceneId: 'tavern',
      x: 2,
      z: 3,
      kind: 'lore_bookshelf',
      name: 'Wayfarers’ Road Register',
      promptLabel: 'Read Wayfarers’ Register [E]',
      loreTitle: 'Wandering Stag Guest Ledger',
      loreText:
        'Three merchant caravans signed in last fortnight bound for the Sanctum ridge. None signed out—yet their horses wandered back to Whispering Gate riderless at dawn, manes singed with blue frost.',
    },
    {
      id: 'int_chapel_altar_font',
      sceneId: 'chapel',
      x: 6,
      z: 4,
      kind: 'sanctuary_altar',
      name: 'Consecrated Font of the Last Light',
      promptLabel: 'Pray & Tend Wounds at Sanctuary Font [E]',
      districtId: 'chapel_last_light',
    },
    {
      id: 'int_chapel_archive_codex',
      sceneId: 'chapel',
      x: 8,
      z: 3,
      kind: 'lore_bookshelf',
      name: 'Annals of the First Vigil',
      promptLabel: 'Study Sanctuary Archive Scrolls [E]',
      loreTitle: 'Annals of the Silver Covenant, Vol. IV',
      loreText:
        '“Gloamrest was founded not by farmers, but by the Seventh Watch of the Silver Covenant—sworn to guard the stone aqueduct linking our village well to the Sanctum of the Shattered Oath.”',
    },
    {
      id: 'int_barracks_chest',
      sceneId: 'barracks',
      x: 9,
      z: 3,
      kind: 'chest',
      name: 'Quartermaster’s Field Chest',
      promptLabel: 'Open Garrison Supply Chest [E]',
      lootItems: [{ itemId: 'lamp_oil_flask', quantity: 1 }],
      lootGold: 18,
    },
    {
      id: 'int_carpenter_chest',
      sceneId: 'carpenter',
      x: 3,
      z: 7,
      kind: 'chest',
      name: 'Joiner’s Salvage Coffer',
      promptLabel: 'Open Joiner’s Coffer [E]',
      lootItems: [{ itemId: 'seasoned_ironpine_plank', quantity: 2 }],
      lootGold: 10,
    },
    {
      id: 'int_manor_library_books',
      sceneId: 'manor',
      x: 3,
      z: 6,
      kind: 'lore_bookshelf',
      name: 'Lord Veyne’s Sealed Chronicle',
      promptLabel: 'Examine Ruined Library Tome [E]',
      loreTitle: 'Confession of Lord Halcyon Veyne',
      loreText:
        '“When the Prelates shattered the Oath at the Sanctum, I sealed our First Vigil blade beneath the library floor. Turn the iron stag sconce beside the family crest hearth to unbar the vault stairs.”',
    },
    {
      id: 'int_manor_secret_latch',
      sceneId: 'manor',
      x: 9,
      z: 9,
      kind: 'secret_latch',
      name: 'Tarnished Crest Sconce',
      promptLabel: 'Examine Family Crest Hearth Mechanism [E]',
      districtId: 'abandoned_manor',
    },
    {
      id: 'int_basement_reliquary_chest',
      sceneId: 'manor_basement',
      x: 5,
      z: 3,
      kind: 'chest',
      name: 'First Vigil Reliquary Chest',
      promptLabel: 'Open First Vigil Reliquary [E]',
      lootItems: [
        { itemId: 'manor_first_vigil_blade', quantity: 1 },
        { itemId: 'veyne_family_signet', quantity: 1 },
      ],
      lootGold: 45,
    },
  ];
}

/**
 * Lightweight A* pathfinder for both the 50x50 Exterior Town Grid and any Building Interior Grid.
 */
export function findTownPath(
  grid: TownTile[][],
  startX: number,
  startZ: number,
  goalX: number,
  goalZ: number,
  blockedDynamicCoords: Set<string> = new Set()
): { x: number; z: number }[] {
  const width = grid.length;
  const depth = grid[0]?.length ?? 0;
  if (width === 0 || depth === 0) return [];

  const inBounds = (x: number, z: number) => x >= 0 && x < width && z >= 0 && z < depth;
  const isPassable = (x: number, z: number) =>
    inBounds(x, z) && Boolean(grid[x]?.[z]?.walkable) && !blockedDynamicCoords.has(`${x},${z}`);

  // If the clicked target tile itself is an unwalkable object/NPC/door, route to its nearest walkable neighbor!
  let targetX = goalX;
  let targetZ = goalZ;
  if (!isPassable(targetX, targetZ)) {
    const neighbors = [
      { x: goalX, z: goalZ + 1 },
      { x: goalX, z: goalZ - 1 },
      { x: goalX + 1, z: goalZ },
      { x: goalX - 1, z: goalZ },
      { x: goalX + 1, z: goalZ + 1 },
      { x: goalX - 1, z: goalZ + 1 },
      { x: goalX + 1, z: goalZ - 1 },
      { x: goalX - 1, z: goalZ - 1 },
    ].filter((pt) => isPassable(pt.x, pt.z));
    if (neighbors.length === 0) return [];
    neighbors.sort(
      (a, b) =>
        Math.abs(a.x - startX) +
        Math.abs(a.z - startZ) -
        (Math.abs(b.x - startX) + Math.abs(b.z - startZ))
    );
    targetX = neighbors[0].x;
    targetZ = neighbors[0].z;
  }

  if (startX === targetX && startZ === targetZ) return [];

  const key = (x: number, z: number) => `${x},${z}`;
  const open: { x: number; z: number; g: number; f: number }[] = [
    {
      x: startX,
      z: startZ,
      g: 0,
      f: Math.abs(targetX - startX) + Math.abs(targetZ - startZ),
    },
  ];
  const cameFrom = new Map<string, { x: number; z: number }>();
  const gScore = new Map<string, number>([[key(startX, startZ), 0]]);
  const closed = new Set<string>();

  const dirs = [
    { dx: 1, dz: 0, cost: 1 },
    { dx: -1, dz: 0, cost: 1 },
    { dx: 0, dz: 1, cost: 1 },
    { dx: 0, dz: -1, cost: 1 },
    // 8-directional diagonal exploration
    { dx: 1, dz: 1, cost: 1.414 },
    { dx: 1, dz: -1, cost: 1.414 },
    { dx: -1, dz: 1, cost: 1.414 },
    { dx: -1, dz: -1, cost: 1.414 },
  ];

  while (open.length > 0) {
    open.sort((a, b) => a.f - b.f);
    const current = open.shift()!;
    const cKey = key(current.x, current.z);
    if (closed.has(cKey)) continue;
    if (current.x === targetX && current.z === targetZ) {
      const path: { x: number; z: number }[] = [];
      let cur: { x: number; z: number } | undefined = { x: current.x, z: current.z };
      while (cur && !(cur.x === startX && cur.z === startZ)) {
        path.unshift(cur);
        cur = cameFrom.get(key(cur.x, cur.z));
      }
      return path;
    }
    closed.add(cKey);

    for (const d of dirs) {
      const nx = current.x + d.dx;
      const nz = current.z + d.dz;
      const nKey = key(nx, nz);
      if (closed.has(nKey) || !isPassable(nx, nz)) continue;
      // Prohibit diagonal movement through blocked corners
      if (d.dx !== 0 && d.dz !== 0) {
        if (!isPassable(current.x + d.dx, current.z) || !isPassable(current.x, current.z + d.dz)) {
          continue;
        }
      }
      const tentativeG = current.g + d.cost;
      if (tentativeG < (gScore.get(nKey) ?? Infinity)) {
        cameFrom.set(nKey, { x: current.x, z: current.z });
        gScore.set(nKey, tentativeG);
        open.push({
          x: nx,
          z: nz,
          g: tentativeG,
          f: tentativeG + Math.hypot(targetX - nx, targetZ - nz),
        });
      }
    }
  }

  return [];
}
