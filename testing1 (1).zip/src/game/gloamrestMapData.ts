import {
  DistrictId,
  InteriorId,
  TownSceneId,
  TOWN_GRID_SIZE,
  GLOAMREST_DISTRICTS,
  GLOAMREST_INTERIORS,
  BUILDING_EXTERIORS,
} from './gloamrestMapAndInteriors';
import { GloamrestSaveState } from './gloamrestEngineTypes';
import { GLOAMREST_QUESTS, QuestId } from './gloamrestItemsAndQuests';
import { GLOAMREST_NPCS } from './gloamrestNpcsAndDialogue';

/**
 * DIMRAETH: THE SHATTERED OATH
 * Cartographer's Survey & Settlement Map Data System
 * Connects the 50x50 playable Gloamrest world to the interactive map.
 */

export type MapDiscoveryState = 'unknown' | 'discovered' | 'fully_explored';

export type MapFilterCategory = 'all' | 'services' | 'quests' | 'npcs' | 'exits' | 'discovered';

export interface MapDistrictMetadata {
  id: DistrictId;
  districtNumber: string; // '01' .. '09'
  name: string;
  category: string;
  subtitle: string;
  description: string;
  landmarkName: string;
  landmarks: string[];
  bounds: { minX: number; maxX: number; minZ: number; maxZ: number };
  center: { x: number; z: number };
  interiorId?: InteriorId;
  services: string[];
  primaryNpcNames: string[];
  relatedQuestCodes: string[];
  entryRoads: string[];
}

export interface MapBuildingMetadata {
  id: string;
  name: string;
  districtId: DistrictId;
  category:
    | 'Commercial'
    | 'Hospitality'
    | 'Crafting'
    | 'Religious'
    | 'Military'
    | 'Production'
    | 'Ruined Estate'
    | 'Residential'
    | 'Fortification'
    | 'Landmark';
  footprint: { minX: number; maxX: number; minZ: number; maxZ: number };
  doorTile?: { x: number; z: number };
  linkedInteriorId?: InteriorId;
  services: string[];
  description: string;
}

export interface MapInteractiveMarker {
  id: string;
  type: 'player' | 'quest' | 'npc' | 'service' | 'exit' | 'landmark';
  title: string;
  subtitle?: string;
  districtId: DistrictId;
  gridX: number;
  gridZ: number;
  icon: string;
  color: string;
  serviceTag?: string;
  questCode?: string;
  questStepLabel?: string;
  isLocked?: boolean;
}

export const MAP_DISTRICT_METADATA: Record<DistrictId, MapDistrictMetadata> = {
  hearth_square: {
    id: 'hearth_square',
    districtNumber: '01',
    name: 'Hearth Square',
    category: 'Central Settlement',
    subtitle: 'Central Cobblestone Plaza & Ancient Well',
    description:
      'The social and commercial nexus of Gloamrest, paved in weathered granite flagstones surrounding an ancient stone well believed to tap sacred subterranean water from the Whispering Vale spring.',
    landmarkName: 'Ancient Stone Well & Bell Post',
    landmarks: [
      'Ancient Stone Well with Carved Covenant Crest',
      'Town Notice Board & Regional Decrees',
      'Cobblestone Market Canopies & Produce Stalls',
      'Granite Sitting Benches & Street Lanterns',
      'Weaver’s Stone Cottage & Cooper’s Gabled House',
    ],
    bounds: { minX: 19, maxX: 29, minZ: 20, maxZ: 30 },
    center: { x: 24, z: 25 },
    services: [
      'General Trading',
      'Town Decrees & Bounty Notices',
      'Elder Aldric Veyne Audiences',
      'Marketplace Commerce',
    ],
    primaryNpcNames: ['Aldric Veyne (Town Elder)', 'Bran Miller', 'Nesta Cooper'],
    relatedQuestCodes: ['MAIN QUEST 01', 'SIDE QUEST 02', 'MAIN QUEST 04'],
    entryRoads: [
      'South Pilgrim Road',
      'North Watch Road',
      'West High Street',
      'Market Stone Bridge',
    ],
  },
  wandering_stag_tavern: {
    id: 'wandering_stag_tavern',
    districtNumber: '02',
    name: 'Wandering Stag Tavern',
    category: 'Hospitality',
    subtitle: 'Two-Story Timber Inn, Taproom & Stables',
    description:
      'A warm two-story timber coaching inn crowned by a carved wooden stag signboard. Wayfarers, town guards, and merchants gather around Mara Fenwick’s roaring stone hearth for spiced ale and rumors.',
    landmarkName: 'Carved Wooden Stag & Hearth Chimney',
    landmarks: [
      'Carved Stag Inn Signboard Over Main Portal',
      'Broad River-Stone Chimney with Roaring Hearth',
      'Rear Stables & Covered Straw Hayloft',
      'Outdoor Cobblestone Dining Terrace',
    ],
    bounds: { minX: 8, maxX: 18, minZ: 19, maxZ: 28 },
    center: { x: 14, z: 24 },
    interiorId: 'tavern',
    services: [
      'Tavern Rest & Vitality Recovery (-10g)',
      'Warm Food & Spiced Ale Provisioning',
      'Whispering Vale Rumors & Lore',
      'Companion Interaction & Board',
    ],
    primaryNpcNames: ['Mara Fenwick (Innkeeper)', 'Kerrig Drifter'],
    relatedQuestCodes: ['MAIN QUEST 01'],
    entryRoads: ['West High Street', 'Tavern Stables Lane'],
  },
  ironroot_forge: {
    id: 'ironroot_forge',
    districtNumber: '03',
    name: 'Ironroot Forge',
    category: 'Crafting and Blacksmithing',
    subtitle: 'Blacksmith Workshop, Furnace & Armory',
    description:
      'Heavy timber-and-granite workshop where Master Smith Garron Holt hammers Astrarium iron over a massive anvil beneath a smoking brick chimney, surrounded by weapon racks and raw ore pallets.',
    landmarkName: 'Smoking Brick Chimney & Master Anvil',
    landmarks: [
      'Tall Smoking Brick Smelting Furnace',
      'Master Iron Anvil & Quenching Trough',
      'Iron Ore Pallets & Coal Bins',
      'Wagon-Axle Repair Stocks & Tool Racks',
    ],
    bounds: { minX: 9, maxX: 18, minZ: 9, maxZ: 17 },
    center: { x: 14, z: 14 },
    interiorId: 'forge',
    services: [
      'Weapon & Armor Purchases',
      'Equipment Durability Repair',
      'Raw Iron & Steel Trading',
      'Blacksmithing Consultations',
    ],
    primaryNpcNames: ['Garron Holt (Blacksmith)'],
    relatedQuestCodes: ['MAIN QUEST 02'],
    entryRoads: ['Craft Lane', 'Watch Barracks Back-Alley'],
  },
  green_vessel: {
    id: 'green_vessel',
    districtNumber: '04',
    name: 'The Green Vessel',
    category: 'Alchemy and Herbalism',
    subtitle: 'Herbalist Cottage, Apothecary & Herb Garden',
    description:
      'Cross the central stone bridge to find Elowen Mire’s ivy-covered botanical cottage, filled with drying bundles of Silverleaf, glass alembics, and fenced garden beds rich with medicinal flora.',
    landmarkName: 'Ivy-Clad Apothecary & Herb Garden',
    landmarks: [
      'Ivy-Clad Timber Apothecary Cottage',
      'Fenced Medicinal Silverleaf & Briar Beds',
      'External Wooden Drying Racks for Herbs',
      'Glass Phials & Boiling Alembics Window Display',
    ],
    bounds: { minX: 33, maxX: 42, minZ: 25, maxZ: 33 },
    center: { x: 36, z: 29 },
    interiorId: 'herbalist',
    services: [
      'Healing Draughts & Restoration Elixirs',
      'Botanical & Alchemical Reagents',
      'Herbal Gathering Quests',
      'Antidotes & Poison Cleansers',
    ],
    primaryNpcNames: ['Elowen Mire (Herbalist)'],
    relatedQuestCodes: ['MAIN QUEST 02', 'SIDE QUEST 01'],
    entryRoads: ['Market Stone Bridge', 'Riverbank Willow Path'],
  },
  chapel_last_light: {
    id: 'chapel_last_light',
    districtNumber: '05',
    name: 'Chapel of the Last Light',
    category: 'Religious Landmark',
    subtitle: 'Old Covenant Sanctuary, Bell Tower & Cemetery',
    description:
      'Weathered stone sanctuary erected by the ancient Silver Covenant overlooking Silverbrook River. A tall bell tower stands beside weathered knight statues, candle shrines, and a quiet walled graveyard.',
    landmarkName: 'Narrow Stone Bell Tower & Covenant Stele',
    landmarks: [
      'Narrow Bell Tower Rising Above Slate Roof',
      'Weathered Granite Knight Statues',
      'Ancient Oath Stele Inscribed with Runes',
      'Iron-Gated Hedged Cemetery with Mossy Headstones',
    ],
    bounds: { minX: 34, maxX: 45, minZ: 13, maxZ: 23 },
    center: { x: 39, z: 19 },
    interiorId: 'chapel',
    services: [
      'Spiritual Blessings & Wound Purification',
      'Covenant Historical Lore & Archive',
      'Oath Guidance & Moral Absolution',
      'Cemetery Crypt Inscriptions',
    ],
    primaryNpcNames: ['Father Lucian (Chapel Priest)'],
    relatedQuestCodes: ['MAIN QUEST 02'],
    entryRoads: ['Chapel Stone Way', 'Gatehouse Bridge Path'],
  },
  watch_barracks: {
    id: 'watch_barracks',
    districtNumber: '06',
    name: 'Watch Barracks',
    category: 'Military',
    subtitle: 'Stone Watchtower, Garrison & Training Yard',
    description:
      'Gloamrest’s northern bastion commanded by Captain Roderic. Encompasses a reinforced square watchtower, training sand yard with straw targets, armory racks, and tactical war dispatches.',
    landmarkName: 'Northern Stone Watchtower & Sparring Yard',
    landmarks: [
      'Square Crenelated Stone Watchtower',
      'Sparring Sand Yard & Straw Practice Targets',
      'Shield & Halberd Racks along Outer Wall',
      'Bounty Ledger & Threat Roster',
    ],
    bounds: { minX: 20, maxX: 30, minZ: 7, maxZ: 16 },
    center: { x: 25, z: 13 },
    interiorId: 'barracks',
    services: [
      'Tactical Sparring Drills (Non-Lethal Practice)',
      'Town Guard Bounty Contracts',
      'Settlement Defense Intel',
      'Security Patrol Briefings',
    ],
    primaryNpcNames: ['Captain Roderic (Town Guard)', 'Sergeant Halvar'],
    relatedQuestCodes: ['MAIN QUEST 03', 'MAIN QUEST 04'],
    entryRoads: ['North Watch Road', 'Barracks Back-Alley'],
  },
  timber_yard: {
    id: 'timber_yard',
    districtNumber: '07',
    name: 'Timber Yard',
    category: 'Production',
    subtitle: 'Lumber Mill, Carpentry Shed & Wagon Works',
    description:
      'Working carpentry yard managed by Master Bram Alder. Heavy ironpine logs, sawing trestles, split cedar shingles, and joinery benches provide materials for Gloamrest’s walls and bridges.',
    landmarkName: 'Stacked Ironpine Lumber & Carpentry Shed',
    landmarks: [
      'Pyramids of Stacked Ironpine Logs',
      'Open-Sided Sawing Shed with Two-Man Saws',
      'Wagon Repair Works & Spare Spoke Racks',
      'Carpentry Workshop with Plane Benches',
    ],
    bounds: { minX: 8, maxX: 18, minZ: 32, maxZ: 42 },
    center: { x: 14, z: 36 },
    interiorId: 'carpenter',
    services: [
      'Timber & Wood Supplies Trading',
      'Barricade Reinforcement Crafting',
      'Carpentry Repair Consultations',
      'Wagon Transport Inquiries',
    ],
    primaryNpcNames: ['Bram Alder (Master Carpenter)'],
    relatedQuestCodes: ['MAIN QUEST 02'],
    entryRoads: ['Timber Yard Lane', 'Mill Wooden Footbridge Path'],
  },
  abandoned_manor: {
    id: 'abandoned_manor',
    districtNumber: '08',
    name: 'Abandoned Manor',
    category: 'Ruined Estate',
    subtitle: 'Shuttered Noble Estate & Overgrown Briar Grounds',
    description:
      'The silent ancestral estate of the Veyne bloodline on the southeastern bluff. Behind a rusted iron fence lies an overgrown briar rose garden, broken stone portico, and heavy barred double doors.',
    landmarkName: 'Collapsed Manor Balcony & Overgrown Fence',
    landmarks: [
      'Barred Iron-Bound Oak Manor Double Doors',
      'Broken Cast-Iron Fence Overgrown with Briars',
      'Collapsed West Balcony & Sunder Masonry',
      'Hidden Subterranean Secret Vault Hatch',
    ],
    bounds: { minX: 35, maxX: 45, minZ: 35, maxZ: 44 },
    center: { x: 39, z: 38 },
    interiorId: 'manor',
    services: [
      'Ancestral Mystery & Secret Exploration',
      'Lockpick Practice (Door Lock DC 14)',
      'Subterranean Vault Discovery',
      'Hidden Ancient Relic Stashes',
    ],
    primaryNpcNames: ['Ancestral Shadows', 'Whispering Remnants'],
    relatedQuestCodes: ['OPTIONAL QUEST 01'],
    entryRoads: ['South-East Bluff Lane', 'Mill Footbridge East Path'],
  },
  whispering_gate: {
    id: 'whispering_gate',
    districtNumber: '09',
    name: 'Whispering Gate',
    category: 'Settlement Entrance',
    subtitle: 'Fortified Gatehouse, Wagon Staging & Vale Road',
    description:
      'The fortified threshold connecting Gloamrest to the dense wilderness of Whispering Vale. Dual stone bastions and heavy iron portcullises overlook the northern forest stone bridge.',
    landmarkName: 'Fortified Gate Bastions & Vale Bridge',
    landmarks: [
      'Twin Crenelated Stone Gatehouse Bastions',
      'Heavy Timber Portcullis & Iron Reinforcements',
      'Northern Forest Stone Bridge Crossing Silverbrook',
      'Scout Outpost Staging Yard & Torch Standards',
    ],
    bounds: { minX: 33, maxX: 45, minZ: 2, maxZ: 11 },
    center: { x: 37, z: 8 },
    services: [
      'Wilderness Gate to Whispering Outskirts',
      'Regional Sanctum Road Departure (MQ04)',
      'Forest Scouting Reports & Ranger Intel',
      'The Ascendant Tower Spire Entrance',
    ],
    primaryNpcNames: ['Scout Sera Wren', 'Gate Watch Kallum'],
    relatedQuestCodes: ['MAIN QUEST 03', 'MAIN QUEST 04'],
    entryRoads: ['North Watch Road', 'Forest Road to Whispering Vale'],
  },
};

export const MAP_BUILDINGS: MapBuildingMetadata[] = [
  {
    id: 'bldg_tavern',
    name: 'The Wandering Stag Tavern',
    districtId: 'wandering_stag_tavern',
    category: 'Hospitality',
    footprint: { minX: 11, maxX: 16, minZ: 20, maxZ: 23 },
    doorTile: { x: 14, z: 24 },
    linkedInteriorId: 'tavern',
    services: ['Tavern Room Rest', 'Spiced Ale & Provisions', 'Local Rumors'],
    description: 'Two-story oak-framed inn offering sanctuary to wanderers and weary guards.',
  },
  {
    id: 'bldg_tavern_stable',
    name: 'Tavern Timber Stables',
    districtId: 'wandering_stag_tavern',
    category: 'Hospitality',
    footprint: { minX: 8, maxX: 10, minZ: 20, maxZ: 23 },
    services: ['Horse Boarding', 'Feed Stacks'],
    description: 'Open-bay timber shed with straw beds where pack animals rest safely.',
  },
  {
    id: 'bldg_forge',
    name: 'Ironroot Forge Workshop',
    districtId: 'ironroot_forge',
    category: 'Crafting',
    footprint: { minX: 10, maxX: 15, minZ: 10, maxZ: 13 },
    doorTile: { x: 13, z: 14 },
    linkedInteriorId: 'forge',
    services: ['Weapon Smithing', 'Armor Repair', 'Ore Smelting'],
    description: 'Heavy granite workshop echoing with hammer strikes and the roar of coal bellows.',
  },
  {
    id: 'bldg_herbalist',
    name: 'The Green Vessel Apothecary',
    districtId: 'green_vessel',
    category: 'Commercial',
    footprint: { minX: 36, maxX: 40, minZ: 26, maxZ: 29 },
    doorTile: { x: 35, z: 28 },
    linkedInteriorId: 'herbalist',
    services: ['Healing Draughts', 'Alchemical Ingredients', 'Antidotes'],
    description: 'Ivy-draped cottage where dried silverleaf hangs alongside amber tonic phials.',
  },
  {
    id: 'bldg_chapel',
    name: 'Chapel of the Last Light',
    districtId: 'chapel_last_light',
    category: 'Religious',
    footprint: { minX: 38, maxX: 43, minZ: 14, maxZ: 18 },
    doorTile: { x: 40, z: 19 },
    linkedInteriorId: 'chapel',
    services: ['Spiritual Blessings', 'Covenant Inscriptions', 'Sanctuary'],
    description: 'Ancient stone chapel adorned with eroded covenant statues and solemn bells.',
  },
  {
    id: 'bldg_barracks',
    name: 'Watch Barracks & Watchtower',
    districtId: 'watch_barracks',
    category: 'Military',
    footprint: { minX: 21, maxX: 26, minZ: 8, maxZ: 11 },
    doorTile: { x: 24, z: 12 },
    linkedInteriorId: 'barracks',
    services: ['Tactical Sparring', 'Bounty Contracts', 'Security Briefings'],
    description: 'Reinforced military headquarters garrisoned by Captain Roderic’s guards.',
  },
  {
    id: 'bldg_carpenter',
    name: 'Alder’s Carpentry Shed',
    districtId: 'timber_yard',
    category: 'Production',
    footprint: { minX: 9, maxX: 13, minZ: 34, maxZ: 37 },
    doorTile: { x: 14, z: 36 },
    linkedInteriorId: 'carpenter',
    services: ['Timber Supplies', 'Tool Joinery', 'Barricade Works'],
    description: 'Sawdust-scented workshop where Bram Alder crafts beams, wheels, and palisades.',
  },
  {
    id: 'bldg_manor',
    name: 'Abandoned Veyne Manor',
    districtId: 'abandoned_manor',
    category: 'Ruined Estate',
    footprint: { minX: 39, maxX: 44, minZ: 39, maxZ: 43 },
    doorTile: { x: 41, z: 38 },
    linkedInteriorId: 'manor',
    services: ['Secret Exploration', 'Ancient Artifacts', 'Subterranean Vault (Lockpick DC 14)'],
    description: 'Barred noble mansion shrouded in mystery and overgrown with thorny briars.',
  },
  {
    id: 'bldg_gatehouse_west',
    name: 'Whispering Gate Western Bastion',
    districtId: 'whispering_gate',
    category: 'Fortification',
    footprint: { minX: 35, maxX: 36, minZ: 5, maxZ: 6 },
    services: ['Wall Watch', 'Arrow Slits'],
    description: 'Heavy stone bastion guarding the northern road exit.',
  },
  {
    id: 'bldg_gatehouse_east',
    name: 'Whispering Gate Eastern Bastion',
    districtId: 'whispering_gate',
    category: 'Fortification',
    footprint: { minX: 40, maxX: 41, minZ: 5, maxZ: 6 },
    services: ['Wall Watch', 'Wilderness Gate Portcullis'],
    description: 'Stone watch post overseeing the forest bridge.',
  },
  {
    id: 'bldg_cottage_weaver',
    name: 'Weaver’s Stone Cottage',
    districtId: 'hearth_square',
    category: 'Residential',
    footprint: { minX: 17, maxX: 19, minZ: 15, maxZ: 17 },
    services: ['Loom Works', 'Local Wool Goods'],
    description: 'Modest granite home beside the North Watch alley with flower boxes.',
  },
  {
    id: 'bldg_cottage_cooper',
    name: 'Cooper’s Gabled Homestead',
    districtId: 'hearth_square',
    category: 'Residential',
    footprint: { minX: 27, maxX: 29, minZ: 33, maxZ: 35 },
    services: ['Cask Making', 'Storage Barrels'],
    description: 'Cozy gabled dwelling along the South Pilgrim lane.',
  },
];

/**
 * Calculates whether a district is discovered in the player's saved state
 */
export function isDistrictDiscovered(
  state: GloamrestSaveState,
  districtId: DistrictId
): boolean {
  return state.discoveredDistricts.includes(districtId);
}

/**
 * Evaluates whether a district is fully explored (all key locations/interiors visited)
 */
export function isDistrictFullyExplored(
  state: GloamrestSaveState,
  districtId: DistrictId
): boolean {
  if (!state.discoveredDistricts.includes(districtId)) return false;

  const meta = MAP_DISTRICT_METADATA[districtId];
  if (meta.interiorId) {
    if (!state.discoveredInteriors.includes(meta.interiorId)) return false;
    // For Abandoned Manor, both the manor interior and basement must be discovered
    if (districtId === 'abandoned_manor') {
      return state.discoveredInteriors.includes('manor_basement');
    }
  }

  // Check landmark interactions for districts without exclusive interiors
  if (districtId === 'hearth_square') {
    return state.lootedOrHarvestedIds.includes('hearth_well_purified') ||
      state.talkedNpcIds.includes('aldric_veyne');
  }

  if (districtId === 'whispering_gate') {
    return state.talkedNpcIds.includes('scout_sera_wren') ||
      state.unlockedObjectIds.includes('gate_portcullis');
  }

  return true;
}

/**
 * Returns the exact discovery state for UI badges
 */
export function getDistrictDiscoveryState(
  state: GloamrestSaveState,
  districtId: DistrictId
): MapDiscoveryState {
  if (isDistrictFullyExplored(state, districtId)) return 'fully_explored';
  if (isDistrictDiscovered(state, districtId)) return 'discovered';
  return 'unknown';
}

/**
 * Counts total discovered districts (out of 9)
 */
export function getDiscoveredDistrictsCount(state: GloamrestSaveState): number {
  return state.discoveredDistricts.length;
}

/**
 * Counts total discovered interiors (out of 8)
 */
export function getExploredInteriorsCount(state: GloamrestSaveState): number {
  return state.discoveredInteriors.length;
}

/**
 * Retrieves the current active quest objectives on the map
 */
export function getActiveQuestMapMarkers(
  state: GloamrestSaveState
): MapInteractiveMarker[] {
  const markers: MapInteractiveMarker[] = [];
  const trackedQuest = GLOAMREST_QUESTS[state.activeTrackedQuestId];
  const trackedState = state.quests[state.activeTrackedQuestId];

  if (trackedQuest && trackedState && trackedState.status === 'active') {
    const nextIncomplete = trackedQuest.steps.find(
      (s) => !s.optional && !trackedState.completedStepIds.includes(s.id)
    );

    if (nextIncomplete?.targetDistrictId) {
      const distMeta =
        MAP_DISTRICT_METADATA[nextIncomplete.targetDistrictId as DistrictId];
      if (distMeta) {
        markers.push({
          id: `quest_${trackedQuest.id}`,
          type: 'quest',
          title: trackedQuest.title,
          subtitle: nextIncomplete.label,
          districtId: distMeta.id,
          gridX: distMeta.center.x,
          gridZ: distMeta.center.z,
          icon: '◆',
          color: '#E2B05A',
          questCode: trackedQuest.code,
          questStepLabel: nextIncomplete.label,
        });
      }
    }
  }

  return markers;
}

/**
 * Retrieves all relevant NPC locations based on the current time of day
 */
export function getNpcMapMarkers(state: GloamrestSaveState): MapInteractiveMarker[] {
  const markers: MapInteractiveMarker[] = [];

  for (const npc of GLOAMREST_NPCS) {
    // Only map named primary characters
    if (npc.isAmbientGuard) continue;

    const sched = npc.schedule[state.timeOfDay];
    if (sched && sched.sceneId === 'exterior' && sched.waypoints[0]) {
      const pos = sched.waypoints[0];
      // Determine district
      let distId: DistrictId = 'hearth_square';
      for (const [dKey, meta] of Object.entries(MAP_DISTRICT_METADATA) as [DistrictId, MapDistrictMetadata][]) {
        if (
          pos.x >= meta.bounds.minX &&
          pos.x <= meta.bounds.maxX &&
          pos.z >= meta.bounds.minZ &&
          pos.z <= meta.bounds.maxZ
        ) {
          distId = dKey;
          break;
        }
      }

      markers.push({
        id: `npc_${npc.id}`,
        type: 'npc',
        title: npc.name,
        subtitle: `${npc.role} — ${sched.activityLabel}`,
        districtId: distId,
        gridX: pos.x,
        gridZ: pos.z,
        icon: '👤',
        color: '#D1C7B7',
      });
    }
  }

  return markers;
}

/**
 * Generates all service icons on the map
 */
export function getServiceMapMarkers(): MapInteractiveMarker[] {
  return [
    {
      id: 'srv_well',
      type: 'service',
      title: 'Ancient Stone Well',
      subtitle: 'Town Center & Sacred Water Source',
      districtId: 'hearth_square',
      gridX: 24,
      gridZ: 25,
      icon: '⛲',
      color: '#38BDF8',
      serviceTag: 'water',
    },
    {
      id: 'srv_tavern',
      type: 'service',
      title: 'Wandering Stag Taproom',
      subtitle: 'Rest, Ale & Rumors',
      districtId: 'wandering_stag_tavern',
      gridX: 14,
      gridZ: 24,
      icon: '🍺',
      color: '#E2B05A',
      serviceTag: 'tavern',
    },
    {
      id: 'srv_forge',
      type: 'service',
      title: 'Garron Holt’s Ironroot Forge',
      subtitle: 'Weapon Smithing & Repairs',
      districtId: 'ironroot_forge',
      gridX: 13,
      gridZ: 14,
      icon: '⚒️',
      color: '#F97316',
      serviceTag: 'blacksmith',
    },
    {
      id: 'srv_alchemy',
      type: 'service',
      title: 'The Green Vessel Apothecary',
      subtitle: 'Healing Draughts & Herbs',
      districtId: 'green_vessel',
      gridX: 35,
      gridZ: 28,
      icon: '🧪',
      color: '#22C55E',
      serviceTag: 'alchemy',
    },
    {
      id: 'srv_chapel',
      type: 'service',
      title: 'Chapel of the Last Light',
      subtitle: 'Prayer, Lore & Sanctuary',
      districtId: 'chapel_last_light',
      gridX: 40,
      gridZ: 19,
      icon: '⛪',
      color: '#A855F7',
      serviceTag: 'healer',
    },
    {
      id: 'srv_barracks',
      type: 'service',
      title: 'Watch Barracks Training Yard',
      subtitle: 'Sparring Drills & Bounties',
      districtId: 'watch_barracks',
      gridX: 24,
      gridZ: 12,
      icon: '🛡️',
      color: '#EF4444',
      serviceTag: 'military',
    },
    {
      id: 'srv_timber',
      type: 'service',
      title: 'Alder’s Carpentry Mill',
      subtitle: 'Timber & Barricade Lumber',
      districtId: 'timber_yard',
      gridX: 14,
      gridZ: 36,
      icon: '🪓',
      color: '#B45309',
      serviceTag: 'carpentry',
    },
    {
      id: 'srv_exit_north',
      type: 'exit',
      title: 'Whispering Gate Passage',
      subtitle: 'Gateway to Whispering Vale & Ascendant Tower',
      districtId: 'whispering_gate',
      gridX: 37,
      gridZ: 6,
      icon: '🚪',
      color: '#E2B05A',
      serviceTag: 'travel',
    },
    {
      id: 'srv_exit_south',
      type: 'exit',
      title: 'South Pilgrim Entrance',
      subtitle: 'Road to Whispering Vale Frontier',
      districtId: 'hearth_square',
      gridX: 24,
      gridZ: 46,
      icon: '🚪',
      color: '#7E9C82',
      serviceTag: 'travel',
    },
  ];
}
