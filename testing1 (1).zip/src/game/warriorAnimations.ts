import * as THREE from 'three';

/**
 * DIMRAETH: THE SHATTERED OATH
 * Warrior Core Skill Master Animation System
 *
 * Provides distinct, grounded dark-fantasy animation definitions and procedural
 * rig transforms for all 12 Warrior core skills:
 * 1. Sundering Strike (`sundering_strike`)
 * 2. Guarded Stance (`guarded_stance`)
 * 3. Whirlwind Assault (`whirlwind_assault`)
 * 4. Driving Assault (`driving_assault`)
 * 5. Weapon Parry (`weapon_parry`)
 * 6. Crippling Blow (`crippling_blow`)
 * 7. Unbreakable Resolve (`unbreakable_resolve`)
 * 8. Earthsplitter (`earthsplitter`)
 * 9. Relentless Pursuit (`relentless_pursuit`)
 * 10. Iron Reprisal (`iron_reprisal`)
 * 11. Battlefield Commander (`battlefield_commander`)
 * 12. Last Stand (`last_stand`)
 */

export type WarriorSkillId =
  | 'sundering_strike'
  | 'guarded_stance'
  | 'whirlwind_assault'
  | 'driving_assault'
  | 'weapon_parry'
  | 'crippling_blow'
  | 'unbreakable_resolve'
  | 'earthsplitter'
  | 'relentless_pursuit'
  | 'iron_reprisal'
  | 'battlefield_commander'
  | 'last_stand';

export type AnimationPhase = 'anticipation' | 'execution' | 'impact' | 'recovery';

export type WeaponTrailType =
  | 'overhead_cleave'
  | 'horizontal_sweep'
  | 'forward_thrust'
  | 'deflection_arc'
  | 'low_hook'
  | 'ground_burst'
  | 'sprint_slipstream'
  | 'counter_snap'
  | 'rally_pulse'
  | 'unyielding_aura'
  | 'shield_glint';

export interface RigTransform {
  bodyPos: [number, number, number];
  bodyRot: [number, number, number];
  bodyScale: [number, number, number];
  weaponPos: [number, number, number];
  weaponRot: [number, number, number];
  shieldPos?: [number, number, number];
  shieldRot?: [number, number, number];
  leftLegRot?: [number, number, number];
  rightLegRot?: [number, number, number];
}

export interface WarriorAnimationConfig {
  skillId: WarriorSkillId;
  name: string;
  animationId: string;
  anticipationDuration: number;
  executionDuration: number;
  impactTiming: number; // Exact elapsed seconds from animation start when impact occurs
  recoveryDuration: number;
  sustainDuration?: number;
  totalDuration: number;
  weaponTrail: {
    enabled: boolean;
    colorHex: number;
    trailType: WeaponTrailType;
    intensity: number;
  };
  vfx: {
    particleCount: number;
    particleColorHex: number;
    dustBurst: boolean;
    sparkBurst: boolean;
    shockwaveRadius?: number;
    allyPulse?: boolean;
  };
  soundMethod: string;
  targetFacingBehavior: 'face_target' | 'maintain_facing' | 'rotate_360';
  movementBehavior: 'in_place' | 'forward_step' | 'rush_forward' | 'leaping_stride';
  cancellationRules: string;
  combatEventSync: string;
  samplePose: (progress: number, phase: AnimationPhase, isMiss?: boolean) => RigTransform;
}

// Ease helper functions (zero-allocation)
function easeOutQuad(t: number): number {
  return 1 - (1 - t) * (1 - t);
}

function easeInQuad(t: number): number {
  return t * t;
}

function easeInOutQuad(t: number): number {
  return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
}

function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

function lerpVec3(
  a: [number, number, number],
  b: [number, number, number],
  t: number
): [number, number, number] {
  return [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];
}

/* ========================================================================= */
/* 12 UNIQUE WARRIOR ANIMATION CONFIGURATIONS                                */
/* ========================================================================= */

export const WARRIOR_ANIMATION_REGISTRY: Record<WarriorSkillId, WarriorAnimationConfig> = {
  /* ----------------------------------------------------------------------- */
  /* 1. SUNDERING STRIKE                                                     */
  /* ----------------------------------------------------------------------- */
  sundering_strike: {
    skillId: 'sundering_strike',
    name: 'Sundering Strike',
    animationId: 'warrior_sundering_strike',
    anticipationDuration: 0.16,
    executionDuration: 0.22,
    impactTiming: 0.38, // At the end of execution / start of impact
    recoveryDuration: 0.22,
    totalDuration: 0.60,
    weaponTrail: {
      enabled: true,
      colorHex: 0xd6d3d1, // Cold steel
      trailType: 'overhead_cleave',
      intensity: 0.85,
    },
    vfx: {
      particleCount: 16,
      particleColorHex: 0xe2e8f0,
      dustBurst: true,
      sparkBurst: true,
      shockwaveRadius: 0.6,
    },
    soundMethod: 'playSunderingStrike',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'forward_step',
    cancellationRules: 'Uncancellable once execution begins; resolves cleanly on completion.',
    combatEventSync: 'Impact damage and armor sunder confirmed at 0.38s mark.',
    samplePose: (progress, phase, isMiss) => {
      if (phase === 'anticipation') {
        const t = easeInOutQuad(progress);
        return {
          bodyPos: [0, -0.06 * t, -0.06 * t],
          bodyRot: [0.08 * t, -0.42 * t, -0.05 * t],
          bodyScale: [1, 1, 1],
          weaponPos: [0.08 * t, 0.22 * t, -0.15 * t],
          weaponRot: [-0.95 * t, 0.35 * t, 0.45 * t],
          shieldPos: [-0.08 * t, -0.05 * t, 0.12 * t],
          shieldRot: [0.15 * t, 0.35 * t, 0],
          leftLegRot: [0.25 * t, 0, 0],
          rightLegRot: [-0.2 * t, 0, 0],
        };
      }
      if (phase === 'execution') {
        const t = easeInQuad(progress);
        const missOffset = isMiss ? 0.35 : 0;
        return {
          bodyPos: [0, -0.06 + 0.04 * t, -0.06 + 0.28 * t],
          bodyRot: [0.08 - 0.22 * t, -0.42 + 0.88 * t + missOffset, -0.05 + 0.12 * t],
          bodyScale: [1, 1, 1],
          weaponPos: [0.08 - 0.12 * t, 0.22 - 0.48 * t, -0.15 + 0.42 * t],
          weaponRot: [-0.95 + 2.35 * t, 0.35 - 0.65 * t, 0.45 - 1.1 * t],
          shieldPos: [-0.08 - 0.04 * t, -0.05 + 0.02 * t, 0.12 - 0.08 * t],
          shieldRot: [0.15 - 0.1 * t, 0.35 - 0.45 * t, 0],
          leftLegRot: [0.25 - 0.45 * t, 0, 0],
          rightLegRot: [-0.2 + 0.4 * t, 0, 0],
        };
      }
      // Recovery phase
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(-0.02, 0, t), lerp(0.22, 0, t)],
        bodyRot: [lerp(-0.14, 0, t), lerp(0.46, 0, t), lerp(0.07, 0, t)],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(-0.04, 0, t), lerp(-0.26, 0, t), lerp(0.27, 0, t)],
        weaponRot: [lerp(1.4, 0, t), lerp(-0.3, 0, t), lerp(-0.65, 0, t)],
        shieldPos: [lerp(-0.12, 0, t), lerp(-0.03, 0, t), lerp(0.04, 0, t)],
        shieldRot: [lerp(0.05, 0, t), lerp(-0.1, 0, t), 0],
        leftLegRot: [lerp(-0.2, 0, t), 0, 0],
        rightLegRot: [lerp(0.2, 0, t), 0, 0],
      };
    },
  },

  /* ----------------------------------------------------------------------- */
  /* 2. GUARDED STANCE                                                       */
  /* ----------------------------------------------------------------------- */
  guarded_stance: {
    skillId: 'guarded_stance',
    name: 'Guarded Stance',
    animationId: 'warrior_guarded_stance',
    anticipationDuration: 0.14,
    executionDuration: 0.22,
    impactTiming: 0.36,
    sustainDuration: 0.20,
    recoveryDuration: 0.18,
    totalDuration: 0.74,
    weaponTrail: {
      enabled: false,
      colorHex: 0x94a3b8,
      trailType: 'shield_glint',
      intensity: 0.3,
    },
    vfx: {
      particleCount: 8,
      particleColorHex: 0x38bdf8, // Defensive ward cyan
      dustBurst: true,
      sparkBurst: false,
    },
    soundMethod: 'playShieldBrace',
    targetFacingBehavior: 'maintain_facing',
    movementBehavior: 'in_place',
    cancellationRules: 'Self-buff; completes gracefully into defensive idle.',
    combatEventSync: 'Warded status and 6 Temp HP apply at 0.36s.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        const t = easeInOutQuad(progress);
        return {
          bodyPos: [0, -0.08 * t, 0],
          bodyRot: [0.05 * t, 0.15 * t, 0],
          bodyScale: [1, 1 - 0.04 * t, 1],
          weaponPos: [-0.08 * t, 0, 0],
          weaponRot: [0.25 * t, -0.2 * t, 0],
          shieldPos: [0.14 * t, 0.05 * t, 0.18 * t],
          shieldRot: [0.25 * t, 0.55 * t, 0],
          leftLegRot: [0.1 * t, 0, 0],
          rightLegRot: [-0.1 * t, 0, 0],
        };
      }
      if (phase === 'execution' || phase === 'impact') {
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, -0.14 * t, 0],
          bodyRot: [0.08 * t, 0.28 * t, 0],
          bodyScale: [1.02, 0.94, 1.02],
          weaponPos: [-0.14 * t, 0.04 * t, -0.08 * t],
          weaponRot: [0.42 * t, -0.32 * t, 0.12 * t],
          shieldPos: [0.26 * t, 0.12 * t, 0.32 * t],
          shieldRot: [0.42 * t, 0.92 * t, 0.05 * t],
          leftLegRot: [0.22 * t, 0, 0],
          rightLegRot: [-0.18 * t, 0, 0],
        };
      }
      // Recovery
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(-0.14, 0, t), 0],
        bodyRot: [lerp(0.08, 0, t), lerp(0.28, 0, t), 0],
        bodyScale: [lerp(1.02, 1, t), lerp(0.94, 1, t), lerp(1.02, 1, t)],
        weaponPos: [lerp(-0.14, 0, t), lerp(0.04, 0, t), lerp(-0.08, 0, t)],
        weaponRot: [lerp(0.42, 0, t), lerp(-0.32, 0, t), lerp(0.12, 0, t)],
        shieldPos: [lerp(0.26, 0, t), lerp(0.12, 0, t), lerp(0.32, 0, t)],
        shieldRot: [lerp(0.42, 0, t), lerp(0.92, 0, t), 0],
        leftLegRot: [lerp(0.22, 0, t), 0, 0],
        rightLegRot: [lerp(-0.18, 0, t), 0, 0],
      };
    },
  },

  /* ----------------------------------------------------------------------- */
  /* 3. WHIRLWIND ASSAULT                                                    */
  /* ----------------------------------------------------------------------- */
  whirlwind_assault: {
    skillId: 'whirlwind_assault',
    name: 'Whirlwind Assault',
    animationId: 'warrior_whirlwind_assault',
    anticipationDuration: 0.14,
    executionDuration: 0.30,
    impactTiming: 0.32,
    recoveryDuration: 0.20,
    totalDuration: 0.64,
    weaponTrail: {
      enabled: true,
      colorHex: 0xf1f5f9,
      trailType: 'horizontal_sweep',
      intensity: 1.0,
    },
    vfx: {
      particleCount: 24,
      particleColorHex: 0xe2e8f0,
      dustBurst: true,
      sparkBurst: true,
      shockwaveRadius: 1.25,
    },
    soundMethod: 'playWhirlwindSlash',
    targetFacingBehavior: 'rotate_360',
    movementBehavior: 'in_place',
    cancellationRules: 'Spins around the character tile; uncancellable once started.',
    combatEventSync: 'Strikes all adjacent foes and knocks them back 1 tile at 0.32s.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        const t = easeInOutQuad(progress);
        return {
          bodyPos: [0, -0.09 * t, 0],
          bodyRot: [0, -0.95 * t, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [-0.15 * t, 0.08 * t, 0.12 * t],
          weaponRot: [0.25 * t, -0.65 * t, 0.9 * t],
          shieldPos: [-0.05 * t, 0, -0.1 * t],
          shieldRot: [0, -0.4 * t, 0],
          leftLegRot: [-0.25 * t, 0, 0],
          rightLegRot: [0.25 * t, 0, 0],
        };
      }
      if (phase === 'execution') {
        const t = progress; // Linear full 360 spin
        const spinAngle = -0.95 + t * (Math.PI * 2 + 0.95);
        return {
          bodyPos: [0, -0.06 + Math.sin(t * Math.PI) * 0.08, 0],
          bodyRot: [0, spinAngle, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [0.15, 0.12, 0.25],
          weaponRot: [1.57, 0, -0.2], // Sword extended horizontally
          shieldPos: [-0.1, 0, 0.1],
          shieldRot: [0, 0.3, 0],
          leftLegRot: [Math.sin(t * Math.PI * 4) * 0.35, 0, 0],
          rightLegRot: [-Math.sin(t * Math.PI * 4) * 0.35, 0, 0],
        };
      }
      // Recovery
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(-0.06, 0, t), 0],
        bodyRot: [0, lerp(Math.PI * 2, 0, t), 0],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(0.15, 0, t), lerp(0.12, 0, t), lerp(0.25, 0, t)],
        weaponRot: [lerp(1.57, 0, t), 0, lerp(-0.2, 0, t)],
        shieldPos: [lerp(-0.1, 0, t), 0, lerp(0.1, 0, t)],
        shieldRot: [0, lerp(0.3, 0, t), 0],
        leftLegRot: [lerp(0.15, 0, t), 0, 0],
        rightLegRot: [lerp(-0.15, 0, t), 0, 0],
      };
    },
  },

  /* ----------------------------------------------------------------------- */
  /* 4. DRIVING ASSAULT                                                      */
  /* ----------------------------------------------------------------------- */
  driving_assault: {
    skillId: 'driving_assault',
    name: 'Driving Assault',
    animationId: 'warrior_driving_assault',
    anticipationDuration: 0.15,
    executionDuration: 0.25,
    impactTiming: 0.40,
    recoveryDuration: 0.20,
    totalDuration: 0.60,
    weaponTrail: {
      enabled: true,
      colorHex: 0xfbbf24,
      trailType: 'forward_thrust',
      intensity: 0.9,
    },
    vfx: {
      particleCount: 18,
      particleColorHex: 0xd97706,
      dustBurst: true,
      sparkBurst: true,
      shockwaveRadius: 0.8,
    },
    soundMethod: 'playShoulderCharge',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'rush_forward',
    cancellationRules: 'Bull-rush across up to 3 tiles; stops at obstacle/valid tile.',
    combatEventSync: 'Impact damage and 2-tile shove resolve at 0.40s.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        const t = easeInOutQuad(progress);
        return {
          bodyPos: [0, -0.1 * t, -0.18 * t],
          bodyRot: [0.42 * t, 0.22 * t, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [0, -0.12 * t, -0.2 * t],
          weaponRot: [0.65 * t, 0, 0],
          shieldPos: [0.22 * t, 0.15 * t, 0.35 * t],
          shieldRot: [0.45 * t, 0.85 * t, 0],
          leftLegRot: [0.35 * t, 0, 0],
          rightLegRot: [-0.4 * t, 0, 0],
        };
      }
      if (phase === 'execution') {
        const t = easeInQuad(progress);
        return {
          bodyPos: [0, -0.1 + 0.05 * t, -0.18 + 0.75 * t],
          bodyRot: [0.42 - 0.15 * t, 0.22 - 0.12 * t, 0],
          bodyScale: [1.05, 0.96, 1.05],
          weaponPos: [0, -0.12 + 0.25 * t, -0.2 + 0.6 * t],
          weaponRot: [0.65 + 0.6 * t, 0, 0],
          shieldPos: [0.22, 0.15, 0.35 + 0.25 * t],
          shieldRot: [0.45, 0.85, 0],
          leftLegRot: [0.35 - 0.7 * t, 0, 0],
          rightLegRot: [-0.4 + 0.7 * t, 0, 0],
        };
      }
      // Recovery
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(-0.05, 0, t), lerp(0.57, 0, t)],
        bodyRot: [lerp(0.27, 0, t), lerp(0.1, 0, t), 0],
        bodyScale: [lerp(1.05, 1, t), lerp(0.96, 1, t), lerp(1.05, 1, t)],
        weaponPos: [0, lerp(0.13, 0, t), lerp(0.4, 0, t)],
        weaponRot: [lerp(1.25, 0, t), 0, 0],
        shieldPos: [lerp(0.22, 0, t), lerp(0.15, 0, t), lerp(0.6, 0, t)],
        shieldRot: [lerp(0.45, 0, t), lerp(0.85, 0, t), 0],
        leftLegRot: [lerp(-0.35, 0, t), 0, 0],
        rightLegRot: [lerp(0.3, 0, t), 0, 0],
      };
    },
  },

  /* ----------------------------------------------------------------------- */
  /* 5. WEAPON PARRY                                                         */
  /* ----------------------------------------------------------------------- */
  weapon_parry: {
    skillId: 'weapon_parry',
    name: 'Weapon Parry',
    animationId: 'warrior_weapon_parry',
    anticipationDuration: 0.12,
    executionDuration: 0.18,
    impactTiming: 0.30,
    recoveryDuration: 0.18,
    totalDuration: 0.48,
    weaponTrail: {
      enabled: true,
      colorHex: 0x38bdf8,
      trailType: 'deflection_arc',
      intensity: 0.8,
    },
    vfx: {
      particleCount: 12,
      particleColorHex: 0xf8fafc,
      dustBurst: false,
      sparkBurst: true,
    },
    soundMethod: 'playBladeParry',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Quick defensive deflection; completes cleanly into counter guard.',
    combatEventSync: 'Warded status and deflection guard register at 0.30s.',
    samplePose: (progress, phase, isMiss) => {
      if (phase === 'anticipation') {
        const t = easeInOutQuad(progress);
        return {
          bodyPos: [0, -0.04 * t, 0],
          bodyRot: [0.05 * t, 0.25 * t, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [-0.18 * t, 0.14 * t, 0.1 * t],
          weaponRot: [0.85 * t, 0.55 * t, 1.15 * t],
          shieldPos: [-0.08 * t, 0, -0.1 * t],
          shieldRot: [0, -0.35 * t, 0],
          leftLegRot: [0.15 * t, 0, 0],
          rightLegRot: [-0.15 * t, 0, 0],
        };
      }
      if (phase === 'execution') {
        const t = easeOutQuad(progress);
        const missDeflect = isMiss ? 0.3 : 0;
        return {
          bodyPos: [0, -0.04 + 0.02 * t, 0],
          bodyRot: [0.05 - 0.08 * t, 0.25 - 0.55 * t + missDeflect, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [-0.18 + 0.32 * t, 0.14 + 0.1 * t, 0.1 + 0.12 * t],
          weaponRot: [0.85 + 0.35 * t, 0.55 - 1.25 * t, 1.15 - 1.55 * t],
          shieldPos: [-0.08, 0, -0.1],
          shieldRot: [0, -0.35, 0],
          leftLegRot: [0.15 - 0.25 * t, 0, 0],
          rightLegRot: [-0.15 + 0.25 * t, 0, 0],
        };
      }
      // Recovery
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(-0.02, 0, t), 0],
        bodyRot: [lerp(-0.03, 0, t), lerp(-0.3, 0, t), 0],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(0.14, 0, t), lerp(0.24, 0, t), lerp(0.22, 0, t)],
        weaponRot: [lerp(1.2, 0, t), lerp(-0.7, 0, t), lerp(-0.4, 0, t)],
        shieldPos: [lerp(-0.08, 0, t), 0, lerp(-0.1, 0, t)],
        shieldRot: [0, lerp(-0.35, 0, t), 0],
        leftLegRot: [lerp(-0.1, 0, t), 0, 0],
        rightLegRot: [lerp(0.1, 0, t), 0, 0],
      };
    },
  },

  /* ----------------------------------------------------------------------- */
  /* 6. CRIPPLING BLOW                                                       */
  /* ----------------------------------------------------------------------- */
  crippling_blow: {
    skillId: 'crippling_blow',
    name: 'Crippling Blow',
    animationId: 'warrior_crippling_blow',
    anticipationDuration: 0.15,
    executionDuration: 0.20,
    impactTiming: 0.35,
    recoveryDuration: 0.20,
    totalDuration: 0.55,
    weaponTrail: {
      enabled: true,
      colorHex: 0x84cc16, // Tendon-green / lime
      trailType: 'low_hook',
      intensity: 0.8,
    },
    vfx: {
      particleCount: 14,
      particleColorHex: 0x84cc16,
      dustBurst: true,
      sparkBurst: true,
    },
    soundMethod: 'playCripplingStrike',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'forward_step',
    cancellationRules: 'Controlled low-angle attack; uncancellable during execution.',
    combatEventSync: 'Damage and Rooted status confirm at 0.35s.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        const t = easeInOutQuad(progress);
        return {
          bodyPos: [0, -0.14 * t, 0.12 * t],
          bodyRot: [0.18 * t, -0.28 * t, 0.06 * t],
          bodyScale: [1, 1, 1],
          weaponPos: [0.05 * t, -0.18 * t, -0.12 * t],
          weaponRot: [0.15 * t, 0.32 * t, -0.42 * t],
          shieldPos: [-0.06 * t, 0.08 * t, 0.15 * t],
          shieldRot: [0.22 * t, 0.45 * t, 0],
          leftLegRot: [0.3 * t, 0, 0],
          rightLegRot: [-0.35 * t, 0, 0],
        };
      }
      if (phase === 'execution') {
        const t = easeInQuad(progress);
        return {
          bodyPos: [0, -0.14 - 0.04 * t, 0.12 + 0.22 * t],
          bodyRot: [0.18 + 0.12 * t, -0.28 + 0.65 * t, 0.06 - 0.14 * t],
          bodyScale: [1, 1, 1],
          weaponPos: [0.05 - 0.16 * t, -0.18 - 0.22 * t, -0.12 + 0.45 * t],
          weaponRot: [0.15 + 1.62 * t, 0.32 - 1.15 * t, -0.42 + 0.85 * t],
          shieldPos: [-0.06, 0.08, 0.15],
          shieldRot: [0.22, 0.45, 0],
          leftLegRot: [0.3 - 0.45 * t, 0, 0],
          rightLegRot: [-0.35 + 0.45 * t, 0, 0],
        };
      }
      // Recovery
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(-0.18, 0, t), lerp(0.34, 0, t)],
        bodyRot: [lerp(0.3, 0, t), lerp(0.37, 0, t), lerp(-0.08, 0, t)],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(-0.11, 0, t), lerp(-0.4, 0, t), lerp(0.33, 0, t)],
        weaponRot: [lerp(1.77, 0, t), lerp(-0.83, 0, t), lerp(0.43, 0, t)],
        shieldPos: [lerp(-0.06, 0, t), lerp(0.08, 0, t), lerp(0.15, 0, t)],
        shieldRot: [lerp(0.22, 0, t), lerp(0.45, 0, t), 0],
        leftLegRot: [lerp(-0.15, 0, t), 0, 0],
        rightLegRot: [lerp(0.1, 0, t), 0, 0],
      };
    },
  },

  /* ----------------------------------------------------------------------- */
  /* 7. UNBREAKABLE RESOLVE                                                  */
  /* ----------------------------------------------------------------------- */
  unbreakable_resolve: {
    skillId: 'unbreakable_resolve',
    name: 'Unbreakable Resolve',
    animationId: 'warrior_unbreakable_resolve',
    anticipationDuration: 0.16,
    executionDuration: 0.26,
    impactTiming: 0.42,
    sustainDuration: 0.22,
    recoveryDuration: 0.20,
    totalDuration: 0.84,
    weaponTrail: {
      enabled: false,
      colorHex: 0xf59e0b,
      trailType: 'unyielding_aura',
      intensity: 0.5,
    },
    vfx: {
      particleCount: 16,
      particleColorHex: 0xf59e0b, // Warm gold resolve
      dustBurst: true,
      sparkBurst: false,
      shockwaveRadius: 0.75,
    },
    soundMethod: 'playUnbreakableResolve',
    targetFacingBehavior: 'maintain_facing',
    movementBehavior: 'in_place',
    cancellationRules: 'Self-recovery skill; purges crowd control debuffs.',
    combatEventSync: 'Crowd-control cleanse and 12 Temp HP resolve at 0.42s.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        // Lowers head briefly, weapon drawn close
        const t = easeInOutQuad(progress);
        return {
          bodyPos: [0, -0.08 * t, 0],
          bodyRot: [0.32 * t, 0, 0],
          bodyScale: [1, 1 - 0.05 * t, 1],
          weaponPos: [-0.08 * t, -0.06 * t, 0],
          weaponRot: [0.2 * t, 0, 0],
          shieldPos: [0.1 * t, 0.04 * t, 0.1 * t],
          shieldRot: [0.2 * t, 0.3 * t, 0],
          leftLegRot: [0.15 * t, 0, 0],
          rightLegRot: [-0.15 * t, 0, 0],
        };
      }
      if (phase === 'execution' || phase === 'impact') {
        // Straightens forcefully into strong stance, chest rises, weapon raised
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, lerp(-0.08, 0.08, t), 0],
          bodyRot: [lerp(0.32, -0.22, t), 0, 0],
          bodyScale: [1.04, 1.05, 1.04],
          weaponPos: [lerp(-0.08, 0.06, t), lerp(-0.06, 0.32, t), 0.1],
          weaponRot: [lerp(0.2, -0.65, t), 0, 0],
          shieldPos: [0.18, 0.15, 0.22],
          shieldRot: [0.35, 0.5, 0],
          leftLegRot: [-0.1, 0, 0],
          rightLegRot: [0.1, 0, 0],
        };
      }
      // Recovery
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(0.08, 0, t), 0],
        bodyRot: [lerp(-0.22, 0, t), 0, 0],
        bodyScale: [lerp(1.04, 1, t), lerp(1.05, 1, t), lerp(1.04, 1, t)],
        weaponPos: [lerp(0.06, 0, t), lerp(0.32, 0, t), lerp(0.1, 0, t)],
        weaponRot: [lerp(-0.65, 0, t), 0, 0],
        shieldPos: [lerp(0.18, 0, t), lerp(0.15, 0, t), lerp(0.22, 0, t)],
        shieldRot: [lerp(0.35, 0, t), lerp(0.5, 0, t), 0],
        leftLegRot: [lerp(-0.1, 0, t), 0, 0],
        rightLegRot: [lerp(0.1, 0, t), 0, 0],
      };
    },
  },

  /* ----------------------------------------------------------------------- */
  /* 8. EARTHSPLITTER                                                        */
  /* ----------------------------------------------------------------------- */
  earthsplitter: {
    skillId: 'earthsplitter',
    name: 'Earthsplitter',
    animationId: 'warrior_earthsplitter',
    anticipationDuration: 0.22,
    executionDuration: 0.26,
    impactTiming: 0.48,
    recoveryDuration: 0.26,
    totalDuration: 0.74,
    weaponTrail: {
      enabled: true,
      colorHex: 0xfbbf24,
      trailType: 'ground_burst',
      intensity: 1.0,
    },
    vfx: {
      particleCount: 28,
      particleColorHex: 0xb45309, // Stone fragments & amber shockwave
      dustBurst: true,
      sparkBurst: true,
      shockwaveRadius: 1.8,
    },
    soundMethod: 'playEarthsplitterSlam',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'in_place',
    cancellationRules: 'Heavy two-handed ground slam; uncancellable once raised.',
    combatEventSync: '3-tile linear shockwave damage and sundering confirm at 0.48s.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        // Deep crouch and overhead 2-handed raise
        const t = easeInOutQuad(progress);
        return {
          bodyPos: [0, -0.18 * t, -0.1 * t],
          bodyRot: [-0.15 * t, 0, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [-0.18 * t, 0.62 * t, -0.18 * t],
          weaponRot: [-1.48 * t, 0, 0],
          shieldPos: [-0.12 * t, 0.25 * t, 0],
          shieldRot: [-0.5 * t, 0, 0],
          leftLegRot: [0.35 * t, 0, 0],
          rightLegRot: [-0.35 * t, 0, 0],
        };
      }
      if (phase === 'execution') {
        // Violent downward strike impacting the stone
        const t = easeInQuad(progress);
        return {
          bodyPos: [0, -0.18 + 0.08 * t, -0.1 + 0.3 * t],
          bodyRot: [-0.15 + 0.62 * t, 0, 0],
          bodyScale: [1.06, 0.92, 1.06],
          weaponPos: [-0.18 + 0.18 * t, 0.62 - 1.1 * t, -0.18 + 0.65 * t],
          weaponRot: [-1.48 + 3.05 * t, 0, 0],
          shieldPos: [-0.12 + 0.06 * t, 0.25 - 0.2 * t, 0.15 * t],
          shieldRot: [-0.5 + 0.7 * t, 0, 0],
          leftLegRot: [0.35 - 0.65 * t, 0, 0],
          rightLegRot: [-0.35 + 0.65 * t, 0, 0],
        };
      }
      // Recovery: Heaves weapon out of the ground
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(-0.1, 0, t), lerp(0.2, 0, t)],
        bodyRot: [lerp(0.47, 0, t), 0, 0],
        bodyScale: [lerp(1.06, 1, t), lerp(0.92, 1, t), lerp(1.06, 1, t)],
        weaponPos: [0, lerp(-0.48, 0, t), lerp(0.47, 0, t)],
        weaponRot: [lerp(1.57, 0, t), 0, 0],
        shieldPos: [lerp(-0.06, 0, t), lerp(0.05, 0, t), lerp(0.15, 0, t)],
        shieldRot: [lerp(0.2, 0, t), 0, 0],
        leftLegRot: [lerp(-0.3, 0, t), 0, 0],
        rightLegRot: [lerp(0.3, 0, t), 0, 0],
      };
    },
  },

  /* ----------------------------------------------------------------------- */
  /* 9. RELENTLESS PURSUIT                                                   */
  /* ----------------------------------------------------------------------- */
  relentless_pursuit: {
    skillId: 'relentless_pursuit',
    name: 'Relentless Pursuit',
    animationId: 'warrior_relentless_pursuit',
    anticipationDuration: 0.14,
    executionDuration: 0.28,
    impactTiming: 0.42,
    recoveryDuration: 0.18,
    totalDuration: 0.60,
    weaponTrail: {
      enabled: true,
      colorHex: 0x94a3b8,
      trailType: 'sprint_slipstream',
      intensity: 0.75,
    },
    vfx: {
      particleCount: 16,
      particleColorHex: 0x94a3b8,
      dustBurst: true,
      sparkBurst: false,
    },
    soundMethod: 'playTacticalSprint',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'leaping_stride',
    cancellationRules: 'Leaps directly adjacent to target; validates tile rules.',
    combatEventSync: 'Impact damage and adjacent positioning confirm at 0.42s.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        // Torso leans forward, rear foot prepares to push off
        const t = easeInOutQuad(progress);
        return {
          bodyPos: [0, -0.08 * t, -0.12 * t],
          bodyRot: [0.38 * t, 0, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [0.06 * t, -0.1 * t, -0.22 * t],
          weaponRot: [0.55 * t, 0.2 * t, -0.45 * t],
          shieldPos: [-0.05 * t, 0.08 * t, 0.15 * t],
          shieldRot: [0.35 * t, 0, 0],
          leftLegRot: [0.4 * t, 0, 0],
          rightLegRot: [-0.45 * t, 0, 0],
        };
      }
      if (phase === 'execution') {
        // Dynamic combat sprint stride
        const t = progress;
        const strideY = Math.sin(t * Math.PI) * 0.18;
        return {
          bodyPos: [0, -0.08 + strideY, -0.12 + 0.85 * t],
          bodyRot: [0.38 - 0.1 * t, 0, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [0.06, -0.1 + 0.25 * t, -0.22 + 0.5 * t],
          weaponRot: [0.55 + 0.4 * t, 0.2, -0.45],
          shieldPos: [-0.05, 0.08, 0.15],
          shieldRot: [0.35, 0, 0],
          leftLegRot: [Math.sin(t * Math.PI * 3) * 0.5, 0, 0],
          rightLegRot: [-Math.sin(t * Math.PI * 3) * 0.5, 0, 0],
        };
      }
      // Arrival plant & recovery
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(0.04, 0, t), lerp(0.73, 0, t)],
        bodyRot: [lerp(0.28, 0, t), 0, 0],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(0.06, 0, t), lerp(0.15, 0, t), lerp(0.28, 0, t)],
        weaponRot: [lerp(0.95, 0, t), lerp(0.2, 0, t), lerp(-0.45, 0, t)],
        shieldPos: [lerp(-0.05, 0, t), lerp(0.08, 0, t), lerp(0.15, 0, t)],
        shieldRot: [lerp(0.35, 0, t), 0, 0],
        leftLegRot: [lerp(0.3, 0, t), 0, 0],
        rightLegRot: [lerp(-0.3, 0, t), 0, 0],
      };
    },
  },

  /* ----------------------------------------------------------------------- */
  /* 10. IRON REPRISAL                                                       */
  /* ----------------------------------------------------------------------- */
  iron_reprisal: {
    skillId: 'iron_reprisal',
    name: 'Iron Reprisal',
    animationId: 'warrior_iron_reprisal',
    anticipationDuration: 0.10,
    executionDuration: 0.18,
    impactTiming: 0.28,
    recoveryDuration: 0.18,
    totalDuration: 0.46,
    weaponTrail: {
      enabled: true,
      colorHex: 0xe2e8f0,
      trailType: 'counter_snap',
      intensity: 0.95,
    },
    vfx: {
      particleCount: 16,
      particleColorHex: 0xfca5a5, // Retaliation crimson tint
      dustBurst: true,
      sparkBurst: true,
      shockwaveRadius: 0.6,
    },
    soundMethod: 'playIronReprisal',
    targetFacingBehavior: 'face_target',
    movementBehavior: 'forward_step',
    cancellationRules: 'Triggered counter-slash; faster than Sundering Strike.',
    combatEventSync: 'Kinetic vengeance damage resolves at 0.28s.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        // Defensive recoil brace
        const t = easeInOutQuad(progress);
        return {
          bodyPos: [0, -0.05 * t, -0.14 * t],
          bodyRot: [-0.12 * t, -0.32 * t, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [0.08 * t, 0.12 * t, -0.15 * t],
          weaponRot: [-0.6 * t, 0.4 * t, 0.3 * t],
          shieldPos: [0.15 * t, 0.05 * t, 0.2 * t],
          shieldRot: [0.25 * t, 0.5 * t, 0],
          leftLegRot: [-0.2 * t, 0, 0],
          rightLegRot: [0.2 * t, 0, 0],
        };
      }
      if (phase === 'execution') {
        // Sharp, immediate counterstrike arc
        const t = easeInQuad(progress);
        return {
          bodyPos: [0, -0.05 + 0.03 * t, -0.14 + 0.32 * t],
          bodyRot: [-0.12 + 0.24 * t, -0.32 + 0.72 * t, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [0.08 - 0.16 * t, 0.12 - 0.35 * t, -0.15 + 0.45 * t],
          weaponRot: [-0.6 + 1.85 * t, 0.4 - 0.95 * t, 0.3 - 0.95 * t],
          shieldPos: [0.15 - 0.1 * t, 0.05, 0.2 - 0.1 * t],
          shieldRot: [0.25 - 0.15 * t, 0.5 - 0.3 * t, 0],
          leftLegRot: [-0.2 + 0.45 * t, 0, 0],
          rightLegRot: [0.2 - 0.45 * t, 0, 0],
        };
      }
      // Recovery
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(-0.02, 0, t), lerp(0.18, 0, t)],
        bodyRot: [lerp(0.12, 0, t), lerp(0.4, 0, t), 0],
        bodyScale: [1, 1, 1],
        weaponPos: [lerp(-0.08, 0, t), lerp(-0.23, 0, t), lerp(0.3, 0, t)],
        weaponRot: [lerp(1.25, 0, t), lerp(-0.55, 0, t), lerp(-0.65, 0, t)],
        shieldPos: [lerp(0.05, 0, t), 0.05, lerp(0.1, 0, t)],
        shieldRot: [lerp(0.1, 0, t), lerp(0.2, 0, t), 0],
        leftLegRot: [lerp(0.25, 0, t), 0, 0],
        rightLegRot: [lerp(-0.25, 0, t), 0, 0],
      };
    },
  },

  /* ----------------------------------------------------------------------- */
  /* 11. BATTLEFIELD COMMANDER                                               */
  /* ----------------------------------------------------------------------- */
  battlefield_commander: {
    skillId: 'battlefield_commander',
    name: 'Battlefield Commander',
    animationId: 'warrior_battlefield_commander',
    anticipationDuration: 0.16,
    executionDuration: 0.26,
    impactTiming: 0.42,
    sustainDuration: 0.20,
    recoveryDuration: 0.20,
    totalDuration: 0.82,
    weaponTrail: {
      enabled: false,
      colorHex: 0xf59e0b,
      trailType: 'rally_pulse',
      intensity: 0.8,
    },
    vfx: {
      particleCount: 20,
      particleColorHex: 0xf59e0b, // Golden command aura
      dustBurst: true,
      sparkBurst: false,
      shockwaveRadius: 2.5,
      allyPulse: true,
    },
    soundMethod: 'playBattlefieldCommander',
    targetFacingBehavior: 'maintain_facing',
    movementBehavior: 'in_place',
    cancellationRules: 'Tactical rallying gesture; synchronizes pulse to party.',
    combatEventSync: 'Blessed (+2 Hit) and 10 Temp HP apply to allies at 0.42s.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        // Upright posture, weapon drawn close
        const t = easeInOutQuad(progress);
        return {
          bodyPos: [0, -0.04 * t, 0],
          bodyRot: [-0.08 * t, 0, 0],
          bodyScale: [1, 1, 1],
          weaponPos: [0, 0.15 * t, 0],
          weaponRot: [-0.4 * t, 0, 0],
          shieldPos: [0.12 * t, 0.05 * t, 0.15 * t],
          shieldRot: [0.2 * t, 0.35 * t, 0],
          leftLegRot: [0.1 * t, 0, 0],
          rightLegRot: [-0.1 * t, 0, 0],
        };
      }
      if (phase === 'execution' || phase === 'impact') {
        // Raises weapon straight skyward in commanding rallying salute
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, lerp(-0.04, 0.06, t), 0],
          bodyRot: [lerp(-0.08, -0.15, t), 0, 0],
          bodyScale: [1.02, 1.04, 1.02],
          weaponPos: [0, lerp(0.15, 0.68, t), 0],
          weaponRot: [lerp(-0.4, -1.57, t), 0, 0],
          shieldPos: [0.18, 0.1, 0.25],
          shieldRot: [0.3, 0.5, 0],
          leftLegRot: [-0.1, 0, 0],
          rightLegRot: [0.1, 0, 0],
        };
      }
      // Recovery
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(0.06, 0, t), 0],
        bodyRot: [lerp(-0.15, 0, t), 0, 0],
        bodyScale: [lerp(1.02, 1, t), lerp(1.04, 1, t), lerp(1.02, 1, t)],
        weaponPos: [0, lerp(0.68, 0, t), 0],
        weaponRot: [lerp(-1.57, 0, t), 0, 0],
        shieldPos: [lerp(0.18, 0, t), lerp(0.1, 0, t), lerp(0.25, 0, t)],
        shieldRot: [lerp(0.3, 0, t), lerp(0.5, 0, t), 0],
        leftLegRot: [lerp(-0.1, 0, t), 0, 0],
        rightLegRot: [lerp(0.1, 0, t), 0, 0],
      };
    },
  },

  /* ----------------------------------------------------------------------- */
  /* 12. LAST STAND                                                          */
  /* ----------------------------------------------------------------------- */
  last_stand: {
    skillId: 'last_stand',
    name: 'Last Stand',
    animationId: 'warrior_last_stand',
    anticipationDuration: 0.18,
    executionDuration: 0.30,
    impactTiming: 0.48,
    sustainDuration: 0.24,
    recoveryDuration: 0.22,
    totalDuration: 0.94,
    weaponTrail: {
      enabled: false,
      colorHex: 0xf59e0b,
      trailType: 'unyielding_aura',
      intensity: 1.0,
    },
    vfx: {
      particleCount: 24,
      particleColorHex: 0xf59e0b,
      dustBurst: true,
      sparkBurst: true,
      shockwaveRadius: 1.5,
    },
    soundMethod: 'playLastStandDefiance',
    targetFacingBehavior: 'maintain_facing',
    movementBehavior: 'in_place',
    cancellationRules: 'Defiant ultimate stance; unlocks immortality threshold for 2 turns.',
    combatEventSync: 'Immortal threshold, +4 STR, and 20 Temp HP confirm at 0.48s.',
    samplePose: (progress, phase) => {
      if (phase === 'anticipation') {
        // Staggered low, weapon planted/held close, physically strained
        const t = easeInOutQuad(progress);
        return {
          bodyPos: [0, -0.2 * t, 0],
          bodyRot: [0.42 * t, 0.25 * t, -0.12 * t],
          bodyScale: [1, 1 - 0.08 * t, 1],
          weaponPos: [-0.12 * t, -0.15 * t, 0.1 * t],
          weaponRot: [0.35 * t, -0.3 * t, 0],
          shieldPos: [0.1 * t, -0.05 * t, 0.15 * t],
          shieldRot: [0.4 * t, 0.3 * t, 0],
          leftLegRot: [0.3 * t, 0, 0],
          rightLegRot: [-0.35 * t, 0, 0],
        };
      }
      if (phase === 'execution' || phase === 'impact') {
        // Forces upright in supreme defiance, feet plant firmly, shield locked
        const t = easeOutQuad(progress);
        return {
          bodyPos: [0, lerp(-0.2, 0.06, t), 0],
          bodyRot: [lerp(0.42, -0.24, t), 0, 0],
          bodyScale: [1.06, 1.06, 1.06],
          weaponPos: [0, lerp(-0.15, 0.28, t), 0.15],
          weaponRot: [lerp(0.35, -0.5, t), 0, 0],
          shieldPos: [0.22, 0.12, 0.3],
          shieldRot: [0.35, 0.65, 0],
          leftLegRot: [-0.15, 0, 0],
          rightLegRot: [0.15, 0, 0],
        };
      }
      // Recovery
      const t = easeOutQuad(progress);
      return {
        bodyPos: [0, lerp(0.06, 0, t), 0],
        bodyRot: [lerp(-0.24, 0, t), 0, 0],
        bodyScale: [lerp(1.06, 1, t), lerp(1.06, 1, t), lerp(1.06, 1, t)],
        weaponPos: [0, lerp(0.28, 0, t), lerp(0.15, 0, t)],
        weaponRot: [lerp(-0.5, 0, t), 0, 0],
        shieldPos: [lerp(0.22, 0, t), lerp(0.12, 0, t), lerp(0.3, 0, t)],
        shieldRot: [lerp(0.35, 0, t), lerp(0.65, 0, t), 0],
        leftLegRot: [lerp(-0.15, 0, t), 0, 0],
        rightLegRot: [lerp(0.15, 0, t), 0, 0],
      };
    },
  },
};

/**
 * Evaluates current animation phase and progress [0..1] within that phase.
 */
export function getAnimationPhaseAndProgress(
  config: WarriorAnimationConfig,
  elapsed: number
): { phase: AnimationPhase; progress: number; isImpactInstant: boolean } {
  const { anticipationDuration, executionDuration, recoveryDuration, totalDuration } = config;
  const sustain = config.sustainDuration ?? 0;

  if (elapsed < anticipationDuration) {
    return {
      phase: 'anticipation',
      progress: Math.min(1, Math.max(0, elapsed / anticipationDuration)),
      isImpactInstant: false,
    };
  }

  const executionEnd = anticipationDuration + executionDuration;
  if (elapsed <= executionEnd) {
    const execProgress = Math.min(1, Math.max(0, (elapsed - anticipationDuration) / executionDuration));
    return {
      phase: 'execution',
      progress: execProgress,
      isImpactInstant: Math.abs(elapsed - config.impactTiming) < 0.03,
    };
  }

  const sustainEnd = executionEnd + sustain;
  if (sustain > 0 && elapsed <= sustainEnd) {
    return {
      phase: 'impact',
      progress: Math.min(1, Math.max(0, (elapsed - executionEnd) / sustain)),
      isImpactInstant: false,
    };
  }

  const recoveryProgress = Math.min(
    1,
    Math.max(0, (elapsed - sustainEnd) / recoveryDuration)
  );

  return {
    phase: 'recovery',
    progress: recoveryProgress,
    isImpactInstant: false,
  };
}

/**
 * Evaluates rig transforms for a given warrior skill animation at current elapsed time.
 */
export function sampleWarriorRigTransform(
  skillId: WarriorSkillId,
  elapsed: number,
  isMiss?: boolean
): { transform: RigTransform; phase: AnimationPhase; isImpactInstant: boolean; isFinished: boolean } {
  const config = WARRIOR_ANIMATION_REGISTRY[skillId];
  if (!config) {
    return {
      transform: {
        bodyPos: [0, 0, 0],
        bodyRot: [0, 0, 0],
        bodyScale: [1, 1, 1],
        weaponPos: [0, 0, 0],
        weaponRot: [0, 0, 0],
      },
      phase: 'recovery',
      isImpactInstant: false,
      isFinished: true,
    };
  }

  const { phase, progress, isImpactInstant } = getAnimationPhaseAndProgress(config, elapsed);
  const transform = config.samplePose(progress, phase, isMiss);
  const isFinished = elapsed >= config.totalDuration;

  return { transform, phase, isImpactInstant, isFinished };
}
