import { ALL_SKILLS_DATABASE } from './progressionData';

export const BASE_SKILL_ICONS = new Set([
  'sunblade_cleave',
  'dawnbreaker_judgment',
  'searing_smite',
  'lay_on_hands',
  'aegis_bulwark',
  'astral_bolt',
  'astral_soul_blade',
  'crimson_tempest',
  'searing_blood_nova',
  'chrono_rift_collapse',
  'gravity_shackle',
  'arcane_conduit',
  'heartseeker_shot',
  'briarfang_strike',
  'heart_briar_volley',
  'ironwood_tempest',
  'bramble_snare',
  'viper_twinshot',
  'warden_salve',
  'inquisitor_mace',
  'void_barrage',
  'shadow_lunge',
]);

export function resolveSkillIconAssetPath(skillId: string, skillName?: string): string {
  if (BASE_SKILL_ICONS.has(skillId)) {
    return `/assets/icons/skills/${skillId}.svg`;
  }
  if (ALL_SKILLS_DATABASE[skillId]) {
    return `/assets/icons/progression-skills/${skillId}.svg`;
  }
  const lower = (skillName ?? '').toLowerCase();
  if (lower.includes('dawnbreaker')) return '/assets/icons/skills/dawnbreaker_judgment.svg';
  if (lower.includes('soul-blade')) return '/assets/icons/skills/astral_soul_blade.svg';
  if (lower.includes('blood-nova')) return '/assets/icons/skills/searing_blood_nova.svg';
  if (lower.includes('chrono-rift')) return '/assets/icons/skills/chrono_rift_collapse.svg';
  if (lower.includes('briarfang')) return '/assets/icons/skills/briarfang_strike.svg';
  if (lower.includes('heart-briar')) return '/assets/icons/skills/heart_briar_volley.svg';
  if (lower.includes('ironwood')) return '/assets/icons/skills/ironwood_tempest.svg';
  return '/assets/icons/skills/sunblade_cleave.svg';
}
