import test from 'node:test';
import assert from 'node:assert/strict';
import {
  ALL_8_DIRECTIONS,
  DIRECTION_8_SPECS,
  Direction8,
  canMove8Directional,
  computeWarrior8DirStance,
  getAngleForDirection8,
  getDirection8FromAngle,
  getDirection8FromVector,
  get8DirectionalValidMoves,
  resolve8DirectionalInput,
  shortestAngleDiff,
  smoothRotateAngle,
} from './eightDirectionalMovement';
import { findTownPath } from './gloamrestMapAndInteriors';

test('1. 8-Directional Vector and Angle Mapping: All 8 compass points', () => {
  // Test discrete vectors for all 8 directions
  assert.equal(getDirection8FromVector(0, -1), 'N');
  assert.equal(getDirection8FromVector(1, -1), 'NE');
  assert.equal(getDirection8FromVector(1, 0), 'E');
  assert.equal(getDirection8FromVector(1, 1), 'SE');
  assert.equal(getDirection8FromVector(0, 1), 'S');
  assert.equal(getDirection8FromVector(-1, 1), 'SW');
  assert.equal(getDirection8FromVector(-1, 0), 'W');
  assert.equal(getDirection8FromVector(-1, -1), 'NW');

  // Verify angle mappings round-trip to the correct sector
  for (const dir of ALL_8_DIRECTIONS) {
    const angle = getAngleForDirection8(dir);
    const resolved = getDirection8FromAngle(angle);
    assert.equal(resolved, dir, `Expected angle ${angle} rad for ${dir} to resolve to ${dir}`);
  }
});

test('2. Keyboard Input Resolution: Normalization & Simultaneous Diagonal Inputs', () => {
  // Pure Cardinals
  const northKeys = new Set(['KeyW']);
  const resN = resolve8DirectionalInput(northKeys);
  assert.equal(resN.dir8, 'N');
  assert.equal(resN.isMoving, true);
  assert.equal(resN.isRunning, false);
  assert.ok(Math.abs(resN.moveX - 0) < 1e-6);
  assert.ok(Math.abs(resN.moveZ - -1) < 1e-6);
  assert.ok(Math.abs(Math.hypot(resN.moveX, resN.moveZ) - 1.0) < 1e-6);

  // Simultaneous Diagonals: W + D (Northeast)
  const neKeys = new Set(['KeyW', 'KeyD']);
  const resNE = resolve8DirectionalInput(neKeys);
  assert.equal(resNE.dir8, 'NE');
  assert.equal(resNE.isMoving, true);
  // Normalization check: Math.hypot(moveX, moveZ) must equal exactly 1.0, NOT sqrt(2) ~ 1.414
  const neMagnitude = Math.hypot(resNE.moveX, resNE.moveZ);
  assert.ok(
    Math.abs(neMagnitude - 1.0) < 1e-6,
    `Diagonal vector must be normalized to 1.0, got ${neMagnitude}`
  );
  assert.ok(Math.abs(resNE.moveX - Math.SQRT1_2) < 1e-6);
  assert.ok(Math.abs(resNE.moveZ - -Math.SQRT1_2) < 1e-6);

  // Simultaneous Diagonals: S + A + Shift (Southwest Run)
  const swRunKeys = new Set(['KeyS', 'KeyA', 'ShiftLeft']);
  const resSW = resolve8DirectionalInput(swRunKeys);
  assert.equal(resSW.dir8, 'SW');
  assert.equal(resSW.isMoving, true);
  assert.equal(resSW.isRunning, true);
  const swMagnitude = Math.hypot(resSW.moveX, resSW.moveZ);
  assert.ok(Math.abs(swMagnitude - 1.0) < 1e-6);

  // Arrow keys support: ArrowDown + ArrowRight (Southeast)
  const seArrowKeys = new Set(['ArrowDown', 'ArrowRight']);
  const resSE = resolve8DirectionalInput(seArrowKeys);
  assert.equal(resSE.dir8, 'SE');
  assert.equal(resSE.isMoving, true);

  // Idle (no keys held)
  const idleKeys = new Set<string>();
  const resIdle = resolve8DirectionalInput(idleKeys);
  assert.equal(resIdle.isMoving, false);
  assert.equal(resIdle.dir8, null);
  assert.equal(resIdle.moveX, 0);
  assert.equal(resIdle.moveZ, 0);
});

test('3. Corner-Cutting Collision Prevention: Diagonal moves cannot bypass walls', () => {
  // Setup a 3x3 test space
  // Open tiles: '.' Blocked: '#'
  // Scenario A: Free space
  // . . .
  // . P . (P at 1,1 moves to 2,2)
  // . . .
  const freeMap = () => true;
  assert.equal(canMove8Directional(1, 1, 2, 2, freeMap), true);

  // Scenario B: Destination is blocked
  const blockedDest = (x: number, z: number) => !(x === 2 && z === 2);
  assert.equal(canMove8Directional(1, 1, 2, 2, blockedDest), false);

  // Scenario C: Blocked corner cutting
  // Moving from (1, 1) to (2, 2), but (2, 1) is a stone wall '#'
  // . . .
  // . P #
  // . . .
  const blockedCornerA = (x: number, z: number) => !(x === 2 && z === 1);
  assert.equal(
    canMove8Directional(1, 1, 2, 2, blockedCornerA),
    false,
    'Cannot cut through corner when adjacent orthogonal tile (2,1) is blocked'
  );

  // Scenario D: Other corner is blocked
  // Moving from (1, 1) to (2, 2), but (1, 2) is a stone wall '#'
  // . . .
  // . P .
  // . # .
  const blockedCornerB = (x: number, z: number) => !(x === 1 && z === 2);
  assert.equal(
    canMove8Directional(1, 1, 2, 2, blockedCornerB),
    false,
    'Cannot cut through corner when adjacent orthogonal tile (1,2) is blocked'
  );

  // Scenario E: Cardinal moves do not trigger corner check
  // Moving from (1,1) to (2,1) is orthogonal
  assert.equal(canMove8Directional(1, 1, 2, 1, freeMap), true);
});

test('4. Smooth Shortest-Arc Rotation: Exponential damping and wrap-around', () => {
  // Turning from North (PI) to Northwest (-3PI/4)
  const target = (-3 * Math.PI) / 4;
  const current = Math.PI;
  const diff = shortestAngleDiff(target, current);
  // Shortest turn from PI to -3PI/4 is +PI/4 (45 degrees counterclockwise)
  assert.ok(Math.abs(diff - Math.PI / 4) < 1e-6);

  // Damping step brings current closer to target
  const nextAngle = smoothRotateAngle(current, target, 10.0, 0.016);
  assert.ok(nextAngle > current || Math.abs(nextAngle - target) < Math.abs(current - target));
});

test('5. Tactical Grid 8-Directional BFS Reachability: Accurate tiles & corner rule', () => {
  // 5x5 grid with a pillar at (1, 0)
  // S at (0, 0) with moveRange = 1
  const mapWithPillar = (x: number, z: number) => !(x === 1 && z === 0);

  const moves = get8DirectionalValidMoves(0, 0, 1, 5, 5, mapWithPillar);

  // With pillar at (1, 0):
  // Orthogonal (0, 1) -> Valid
  // Orthogonal (1, 0) -> Blocked
  // Diagonal (1, 1) -> Invalid because (1, 0) corner is blocked!
  const hasDiagonal1_1 = moves.some((m) => m.x === 1 && m.z === 1);
  assert.equal(
    hasDiagonal1_1,
    false,
    'Tile (1,1) must be unreachable with moveRange 1 because adjacent corner (1,0) is a pillar'
  );

  // In open 5x5 grid from (2, 2) with moveRange 1:
  // All 8 adjacent neighbors should be reachable!
  const openGrid = () => true;
  const openMoves = get8DirectionalValidMoves(2, 2, 1, 5, 5, openGrid);
  assert.equal(openMoves.length, 8, 'Move range 1 in open field must reach exactly 8 tiles');
  const foundDirs = new Set(openMoves.map((m) => m.dir8));
  for (const d of ALL_8_DIRECTIONS) {
    assert.ok(foundDirs.has(d), `Expected 8-directional BFS to reach direction ${d}`);
  }
});

test('6. Warrior 8-Directional Stance: Weapon & Shield attachments for Idle, Walk, Run', () => {
  // Test all 8 directions in Idle
  for (const dir of ALL_8_DIRECTIONS) {
    const angle = getAngleForDirection8(dir);
    const idleStance = computeWarrior8DirStance(angle, false, false, 0.5);

    assert.equal(idleStance.direction8, dir);
    assert.equal(idleStance.isMoving, false);
    assert.equal(idleStance.isRunning, false);
    // Orthodox stance: left leg slightly forward
    assert.ok(idleStance.legLeftRotX > 0);
    assert.ok(idleStance.legRightRotX < 0);
    // Longsword and shield are poised in guard positions
    assert.ok(idleStance.swordPos[0] > 0, 'Longsword in right hand (positive X)');
    assert.ok(idleStance.shieldPos[0] < 0, 'Shield on left arm (negative X)');
  }

  // Test Walking Locomotion
  const walkStance = computeWarrior8DirStance(0, true, false, 0.25);
  assert.equal(walkStance.isMoving, true);
  assert.equal(walkStance.isRunning, false);
  assert.ok(walkStance.torsoPitch > 0, 'Forward torso lean while walking');

  // Test Running Locomotion
  const runStance = computeWarrior8DirStance(0, true, true, 0.25);
  assert.equal(runStance.isMoving, true);
  assert.equal(runStance.isRunning, true);
  assert.ok(runStance.torsoPitch > walkStance.torsoPitch, 'Running lean must be greater than walk');
  assert.ok(runStance.bodyBobY >= 0, 'Dynamic stride bob active');
});

test('7. Gloamrest Click-to-Move Pathfinding: 8 directions with corner prevention', () => {
  // Construct a 20x20 test grid of walkable TownTiles
  const testGrid: any[][] = Array.from({ length: 20 }, (_, x) =>
    Array.from({ length: 20 }, (_, z) => ({
      x,
      z,
      walkable: true,
      elevation: 0,
      terrain: 'cobblestone',
    }))
  );

  // Diagonal pathfinding across open space: from (10,10) to (13,13)
  const path = findTownPath(testGrid, 10, 10, 13, 13);
  assert.ok(path.length > 0);
  // In 8-directional movement, the first step is diagonal (11, 11)
  assert.deepEqual(path[0], { x: 11, z: 11 });

  // Now make (11, 10) non-walkable
  testGrid[11][10].walkable = false;
  // Route from (10, 10) to (11, 11)
  // Because (11, 10) is blocked, diagonal corner-cutting is forbidden!
  // It must step orthogonally to (10, 11) before reaching (11, 11)
  const pathAroundPillar = findTownPath(testGrid, 10, 10, 11, 11);
  assert.ok(pathAroundPillar.length > 0);
  assert.deepEqual(pathAroundPillar[0], { x: 10, z: 11 });
  assert.deepEqual(pathAroundPillar[1], { x: 11, z: 11 });
});
