import {
  TowerBossDefinition,
  TowerEncounterType,
  TowerEnemySlotConfig,
  TowerFloorDefinition,
  TowerFloorRewardConfig,
  TowerGridPreset,
  TowerObjectiveConfig,
  TowerProgressionState,
  TowerRegionId,
  TowerRegionMetadata,
  TowerShopItem,
  TOWER_CHECKPOINT_FLOORS,
} from './towerTypes';
import { ALL_100_TOWER_FLOORS, TOWER_REGIONS } from './towerFloorsData';
import { TOWER_MAJOR_BOSSES, TOWER_MINI_BOSSES } from './towerBossesData';
import {
  Ability,
  AbilityElement,
  CombatUnit,
  EnemyArchetype,
  EnvironmentalSurface,
  GridTile,
  GRID_SIZE,
  TacticalEnvObject,
  UnitId,
  WorldReactivityState,
} from './rules';


/**
 * DIMRAETH: THE ASCENDANT TOWER ENGINE
 * Core gameplay logic, floor initialization, objective evaluation, and shop management
 */

export const TOWER_SHOP_CATALOG: TowerShopItem[] = [
  {
    id: 'tower_item_consumable_draught',
    name: 'Tower Draught of Vitality',
    category: 'consumable',
    oathShardCost: 12,
    requiredFloorCleared: 1,
    rarity: 'Uncommon',
    description: 'A concentrated healing draught brewed from twilight lichen in the lower halls.',
    statsSummary: 'Restores 24 HP to any ally during or between battles.',
  },
  {
    id: 'tower_item_consumable_elixir',
    name: 'Astral Elixir of Focus',
    category: 'consumable',
    oathShardCost: 20,
    requiredFloorCleared: 10,
    rarity: 'Rare',
    description: 'Distilled starlight that clears negative afflictions and stimulates battle adrenaline.',
    statsSummary: 'Cleanses all debuffs and grants +2 Action Points immediately.',
  },
  {
    id: 'tower_item_shield_valerius',
    name: 'Warden’s Granite Bulwark',
    category: 'armor',
    oathShardCost: 45,
    requiredFloorCleared: 10,
    rarity: 'Epic',
    description: 'The ancient stone-reinforced shield of Valerius the Unbroken.',
    statsSummary: '+3 Armor Class, +15 Max HP, unlocks Vanguard Bulwark passive.',
  },
  {
    id: 'tower_item_relic_withered',
    name: 'Heart of the Briar Matron',
    category: 'relic',
    oathShardCost: 65,
    requiredFloorCleared: 20,
    rarity: 'Epic',
    description: 'A pulsating amber seed plucked from the deep ironwood roots of Sylvaeth.',
    statsSummary: 'Regenerates 4 HP each turn; enemies that hit you suffer 4 Nature recoil damage.',
  },
  {
    id: 'tower_item_weapon_crucible',
    name: 'Crucible Slag Blade',
    category: 'weapon',
    oathShardCost: 85,
    requiredFloorCleared: 30,
    rarity: 'Epic',
    description: 'Forged within the roaring magma vents of the Ember Foundry.',
    statsSummary: '1d10+4 Fire damage, 25% chance on hit to ignite target for 2 turns.',
  },
  {
    id: 'tower_item_armor_frost',
    name: 'Glacial Sovereign Mantle',
    category: 'armor',
    oathShardCost: 110,
    requiredFloorCleared: 40,
    rarity: 'Epic',
    description: 'A crystallized mantle woven from the permafrost of Illyria’s throne.',
    statsSummary: '+4 Armor Class, immunity to Chill/Freeze, creates Ice floor on dodge.',
  },
  {
    id: 'tower_item_relic_astral_rift',
    name: 'Xal’Kareth’s Rift Chronometer',
    category: 'relic',
    oathShardCost: 140,
    requiredFloorCleared: 50,
    rarity: 'Epic',
    description: 'An oscillating spatial compass that bends the distance between coordinates.',
    statsSummary: '+2 Move Range, can blink up to 3 tiles once per combat round for 1 AP.',
  },
  {
    id: 'tower_item_weapon_leviathan',
    name: 'Tide-Reaver Great Trident',
    category: 'weapon',
    oathShardCost: 175,
    requiredFloorCleared: 60,
    rarity: 'Legendary',
    description: 'A coral-encrusted polearm wielded by the abyssal lords of the Sunken Spires.',
    statsSummary: '2d8+5 Cold/Physical damage, pulls target 2 tiles toward attacker on hit.',
  },
  {
    id: 'tower_item_armor_archon',
    name: 'Sanguine Archon Vestments',
    category: 'armor',
    oathShardCost: 210,
    requiredFloorCleared: 70,
    rarity: 'Legendary',
    description: 'Robes dyed in ancient sacrificial blood that siphon the lifeforce of surrounding foes.',
    statsSummary: '18% Lifesteal on all physical and spell attacks; +20 Max HP.',
  },
  {
    id: 'tower_item_relic_ashen_sigil',
    name: 'General Malakor’s Ashen Sigil',
    category: 'relic',
    oathShardCost: 250,
    requiredFloorCleared: 80,
    rarity: 'Legendary',
    description: 'The military medal of the Ashen Legion, radiating aura of relentless conquest.',
    statsSummary: 'All party members gain +2 to hit rolls and start combat with +1 extra AP.',
  },
  {
    id: 'tower_item_relic_chronosphere',
    name: 'Fractured Hourglass of Aeons',
    category: 'relic',
    oathShardCost: 300,
    requiredFloorCleared: 90,
    rarity: 'Legendary',
    description: 'A swirling vortex of crystallized moments held within an astrarium sphere.',
    statsSummary: 'Active: Once per combat encounter, reset all ability cooldowns for the active party member.',
  },
  {
    id: 'tower_item_crown_architect',
    name: 'Crown of the Oath Architect',
    category: 'armor',
    oathShardCost: 400,
    requiredFloorCleared: 100,
    rarity: 'Legendary',
    description: 'The primordial coronet worn by the Architect of the Ascendant Tower.',
    statsSummary: '+6 Armor Class, +35 Max HP, +1 Permanent Max AP, immune to critical hits.',
  },
  {
    id: 'tower_perk_vitality',
    name: 'Ascendant Vitality Blessing',
    category: 'oath_perk',
    oathShardCost: 50,
    requiredFloorCleared: 15,
    rarity: 'Rare',
    description: 'An oath-attuned ritual that fortifies the lifeforce of all who ascend the spire.',
    statsSummary: 'Permanent +6 Max HP to Commander and all companions in the tower.',
  },
  {
    id: 'tower_perk_alacrity',
    name: 'Astral Alacrity Attunement',
    category: 'oath_perk',
    oathShardCost: 100,
    requiredFloorCleared: 45,
    rarity: 'Epic',
    description: 'Aligns the party’s nervous system with the tower’s celestial frequencies.',
    statsSummary: 'Permanent +2 Initiative to all party members in the tower.',
  },
  {
    id: 'tower_perk_defiance',
    name: 'Warden’s Undying Defiance',
    category: 'oath_perk',
    oathShardCost: 180,
    requiredFloorCleared: 75,
    rarity: 'Legendary',
    description: 'An unbroken promise that refuses defeat when the descent threatens all.',
    statsSummary: 'Once per battle, a party member who would be KO’d survives with 12 HP instead.',
  },
];

/**
 * Creates a brand new TowerProgressionState
 */
export function createInitialTowerState(): TowerProgressionState {
  return {
    highestFloorCleared: 0,
    currentUnlockedFloor: 1,
    completedFloorNumbers: [],
    unlockedCheckpoints: [],
    oathShards: 0,
    firstClearClaimedFloorNumbers: [],
    bossClearRecords: {},
    purchasedShopItemIds: [],
  };
}

/**
 * Generates the 10x10 tactical grid for a specific tower floor based on its preset
 */
export function generateTowerGrid(floorDef: TowerFloorDefinition): GridTile[][] {
  const grid: GridTile[][] = [];
  const preset = floorDef.gridPreset;

  const elevations = preset.elevations || {};
  const customTerrains = preset.customTerrains || {};
  const surfaces = preset.surfaces || {};
  const unwalkableSet = new Set(
    (preset.unwalkableTiles || []).map((t) => `${t.x},${t.z}`)
  );

  for (let x = 0; x < GRID_SIZE; x++) {
    const row: GridTile[] = [];
    for (let z = 0; z < GRID_SIZE; z++) {
      const key = `${x},${z}`;
      const elevation = elevations[key] ?? 0;
      const terrain = customTerrains[key] ?? (elevation > 0 ? 'bastion' : 'stone');
      const surface = surfaces[key] ?? 'none';
      const walkable = !unwalkableSet.has(key);

      row.push({
        x,
        z,
        elevation,
        terrain,
        surface,
        walkable,
      });
    }
    grid.push(row);
  }

  return grid;
}

/**
 * Builds the tactical environmental objects for a specific tower floor
 */
export function buildTowerEnvObjects(floorDef: TowerFloorDefinition): TacticalEnvObject[] {
  const preset = floorDef.gridPreset;
  if (!preset.objects) return [];

  return preset.objects.map((obj) => ({
    id: obj.id,
    name: obj.name,
    kind: obj.kind,
    gridX: obj.x,
    gridZ: obj.z,
    elevation: (preset.elevations && preset.elevations[`${obj.x},${obj.z}`]) || 0,
    hp: obj.hp ?? (obj.kind === 'oil_barrel' ? 12 : 24),
    maxHp: obj.hp ?? (obj.kind === 'oil_barrel' ? 12 : 24),
    pushable: obj.pushable ?? (obj.kind === 'runestone_block'),
    destroyed: false,
  }));
}

/**
 * Converts a TowerEnemySlotConfig to a live CombatUnit
 */
export function convertEnemySlotToCombatUnit(
  slot: TowerEnemySlotConfig,
  index: number
): CombatUnit {
  const unitId = `enemy_${slot.id}_${index}` as UnitId;
  const isBoss = !!slot.isBoss;
  const isMini = !!slot.isMiniBoss;

  return {
    id: unitId,
    name: slot.name,
    title: slot.title,
    faction: 'enemy',
    archetype: slot.archetype as EnemyArchetype,
    gridX: slot.gridX,
    gridZ: slot.gridZ,
    elevation: slot.elevation ?? 0,
    hp: slot.hp,
    maxHp: slot.maxHp,
    tempHp: 0,
    ap: slot.ap,
    maxAp: slot.ap,
    moveRange: slot.moveRange,
    movedThisTurn: false,
    armorClass: slot.armorClass,
    initiative: slot.initiative,
    stats: { ...slot.stats },
    abilities: [...slot.abilities],
    cooldowns: {},
    statuses: [],
    isKO: false,
    koTimer: 0,
    telegraph: isBoss
      ? {
          abilityName: slot.abilities[0]?.name ?? 'Cataclysmic Smash',
          targetUnitId: '',
          targetX: Math.max(0, slot.gridX - 1),
          targetZ: slot.gridZ,
          damagePreview: Math.round(slot.hp * 0.15),
        }
      : undefined,
  };
}

/**
 * Builds the complete tactical encounter for a tower floor
 */
export function buildTowerFloorEncounter(
  floorNumber: number,
  partyUnits: CombatUnit[],
  towerState?: TowerProgressionState
): {
  floorDef: TowerFloorDefinition;
  grid: GridTile[][];
  envObjects: TacticalEnvObject[];
  units: CombatUnit[];
} {
  const floorDef = ALL_100_TOWER_FLOORS[floorNumber] ?? ALL_100_TOWER_FLOORS[1];
  const grid = generateTowerGrid(floorDef);
  const envObjects = buildTowerEnvObjects(floorDef);

  // Position party units in starting spawn zone (x: 1..3, z: 7..9)
  const defaultPartySpawns = [
    { x: 1, z: 8 },
    { x: 2, z: 8 },
    { x: 3, z: 8 },
    { x: 2, z: 9 },
  ];

  const gearedParty: CombatUnit[] = partyUnits.map((u, idx) => {
    const spawn = defaultPartySpawns[idx % defaultPartySpawns.length];
    // Check if we have party HP snapshot from active run
    let preservedHp = u.maxHp;
    if (towerState?.activeRun?.partyHpSnapshot && towerState.activeRun.partyHpSnapshot[u.id] !== undefined) {
      preservedHp = Math.max(1, towerState.activeRun.partyHpSnapshot[u.id]);
    }

    return {
      ...u,
      gridX: spawn.x,
      gridZ: spawn.z,
      elevation: grid[spawn.x]?.[spawn.z]?.elevation ?? 0,
      hp: floorDef.isSanctuary ? u.maxHp : preservedHp,
      ap: u.maxAp,
      isKO: false,
      koTimer: 0,
      cooldowns: {},
      statuses: [],
      movedThisTurn: false,
    };
  });

  // Convert enemy formation
  const enemies: CombatUnit[] = floorDef.enemyFormation.map((slot, idx) =>
    convertEnemySlotToCombatUnit(slot, idx)
  );

  return {
    floorDef,
    grid,
    envObjects,
    units: [...gearedParty, ...enemies],
  };
}

/**
 * Objective evaluation outcome
 */
export type TowerObjectiveOutcome = 'in_progress' | 'victory' | 'defeat';

/**
 * Evaluates whether the tower floor objective has been achieved or failed
 */
export function evaluateTowerFloorObjective(
  floorDef: TowerFloorDefinition,
  units: CombatUnit[],
  roundNumber: number,
  envObjects: TacticalEnvObject[]
): {
  outcome: TowerObjectiveOutcome;
  statusMessage: string;
} {
  const partyLiving = units.filter((u) => u.faction === 'party' && !u.isKO);
  const enemiesLiving = units.filter((u) => u.faction === 'enemy' && !u.isKO);

  // Total party wipe is immediate defeat
  if (partyLiving.length === 0 && units.some((u) => u.faction === 'party')) {
    return { outcome: 'defeat', statusMessage: 'All party members have fallen in battle.' };
  }

  const obj = floorDef.objective;

  switch (obj.type) {
    case 'survival': {
      const requiredRounds = obj.surviveRounds ?? 5;
      if (roundNumber > requiredRounds) {
        return {
          outcome: 'victory',
          statusMessage: `Survived the assault for ${requiredRounds} rounds! Floor cleared!`,
        };
      }
      return {
        outcome: 'in_progress',
        statusMessage: `Survival in progress: Round ${roundNumber} / ${requiredRounds}.`,
      };
    }

    case 'boss': {
      // Find boss unit
      const bossAlive = enemiesLiving.some(
        (u) =>
          u.archetype === 'champion' ||
          (obj.targetUnitIds && obj.targetUnitIds.some((id) => u.id.includes(id)))
      );
      if (!bossAlive && enemiesLiving.length === 0) {
        return { outcome: 'victory', statusMessage: `Major Boss vanquished! The way forward opens.` };
      }
      return { outcome: 'in_progress', statusMessage: `Boss battle ongoing: Slay the floor guardian!` };
    }

    case 'mini_boss': {
      const miniBossAlive = enemiesLiving.some((u) => u.archetype === 'bruiser' || u.archetype === 'champion');
      if (enemiesLiving.length === 0) {
        return { outcome: 'victory', statusMessage: `Elite mini-boss and guard routed! Floor cleared.` };
      }
      return { outcome: 'in_progress', statusMessage: `Engage and defeat the elite guardian.` };
    }

    case 'destruction': {
      if (obj.targetEnvObjectIds && obj.targetEnvObjectIds.length > 0) {
        const remainingTargets = envObjects.filter(
          (o) => obj.targetEnvObjectIds!.includes(o.id) && !o.destroyed
        );
        if (remainingTargets.length === 0) {
          return {
            outcome: 'victory',
            statusMessage: 'All corruption conduits destroyed! Floor purged.',
          };
        }
        return {
          outcome: 'in_progress',
          statusMessage: `Destroy conduits: ${remainingTargets.length} target(s) remaining.`,
        };
      }
      // Fallback to defeating all enemies
      if (enemiesLiving.length === 0) {
        return { outcome: 'victory', statusMessage: 'All threats eliminated.' };
      }
      return { outcome: 'in_progress', statusMessage: 'Sunder the designated structures.' };
    }

    case 'defense': {
      if (obj.defendTargetId) {
        const targetObj = envObjects.find((o) => o.id === obj.defendTargetId);
        if (targetObj && targetObj.destroyed) {
          return {
            outcome: 'defeat',
            statusMessage: `The sacred relic [${targetObj.name}] has been shattered! Objective failed.`,
          };
        }
      }
      if (enemiesLiving.length === 0) {
        return { outcome: 'victory', statusMessage: 'Sacred relic preserved! Attackers routed.' };
      }
      return { outcome: 'in_progress', statusMessage: 'Defend the sacred relic from enemy strikes!' };
    }

    case 'escort': {
      if (obj.escapeTile) {
        const reached = partyLiving.some(
          (u) => u.gridX === obj.escapeTile!.x && u.gridZ === obj.escapeTile!.z
        );
        if (reached) {
          return { outcome: 'victory', statusMessage: 'Target successfully escorted to extraction rift!' };
        }
      }
      return { outcome: 'in_progress', statusMessage: 'Escort ally to the extraction coordinate.' };
    }

    case 'puzzle': {
      if (obj.puzzleSockets && obj.puzzleSockets.length > 0) {
        const allSocketsFilled = obj.puzzleSockets.every((s) => {
          const matchingObj = envObjects.find(
            (o) => o.id === s.objId && !o.destroyed && o.gridX === s.targetX && o.gridZ === s.targetZ
          );
          return !!matchingObj;
        });
        if (allSocketsFilled) {
          return { outcome: 'victory', statusMessage: 'Runestones properly seated in ancient sockets!' };
        }
      }
      if (enemiesLiving.length === 0) {
        return { outcome: 'victory', statusMessage: 'Enemies repelled. Way opens.' };
      }
      return { outcome: 'in_progress', statusMessage: 'Align the puzzle stones while fending off enemies.' };
    }

    case 'multi_wave':
    case 'trial':
    case 'standard':
    default: {
      if (enemiesLiving.length === 0) {
        return { outcome: 'victory', statusMessage: 'All enemies defeated! Floor cleared.' };
      }
      return { outcome: 'in_progress', statusMessage: `Combat in progress: ${enemiesLiving.length} enemy forces remain.` };
    }
  }
}

/**
 * Handles floor completion:
 * Updates cleared floors, unlocks next floor, unlocks checkpoints, awards first-clear Oath Shards
 */
export function completeTowerFloor(
  state: TowerProgressionState,
  floorNumber: number,
  roundsTaken: number,
  partyUnits: CombatUnit[]
): {
  nextState: TowerProgressionState;
  firstClearEarned: boolean;
  shardsEarned: number;
  xpEarned: number;
  unlockedCheckpoint?: number;
  bossDefeated?: TowerBossDefinition;
} {
  const floorDef = ALL_100_TOWER_FLOORS[floorNumber] ?? ALL_100_TOWER_FLOORS[1];
  const isFirstClear = !state.completedFloorNumbers.includes(floorNumber);

  const newCompleted = Array.from(new Set([...state.completedFloorNumbers, floorNumber])).sort(
    (a, b) => a - b
  );
  const nextUnlocked = Math.max(state.currentUnlockedFloor, Math.min(100, floorNumber + 1));
  const newHighest = Math.max(state.highestFloorCleared, floorNumber);

  let shardsEarned = 0;
  let xpEarned = 0;
  const newFirstClaims = [...state.firstClearClaimedFloorNumbers];

  if (isFirstClear) {
    shardsEarned = floorDef.rewards.firstClearOathShards;
    xpEarned = floorDef.rewards.firstClearXp;
    newFirstClaims.push(floorNumber);
  } else {
    // Repeat clear gives small shard bonus
    shardsEarned = Math.max(1, Math.round(floorDef.rewards.firstClearOathShards * 0.2));
    xpEarned = Math.round(floorDef.rewards.firstClearXp * 0.1);
  }

  // Checkpoint unlocking
  const newCheckpoints = [...state.unlockedCheckpoints];
  let newlyUnlockedCheckpoint: number | undefined;
  if (floorDef.isCheckpoint && !newCheckpoints.includes(floorNumber)) {
    newCheckpoints.push(floorNumber);
    newCheckpoints.sort((a, b) => a - b);
    newlyUnlockedCheckpoint = floorNumber;
  }

  // Boss record
  const newBossRecords = { ...state.bossClearRecords };
  let defeatedBoss: TowerBossDefinition | undefined;
  if (floorDef.isBossFloor) {
    newBossRecords[floorNumber] = {
      clearedAt: Date.now(),
      roundsTaken,
    };
    defeatedBoss = TOWER_MAJOR_BOSSES[floorNumber];
  }

  // Snapshot party HP for active run (unless sanctuary floor)
  const hpSnapshot: Record<string, number> = {};
  for (const u of partyUnits.filter((p) => p.faction === 'party')) {
    hpSnapshot[u.id] = floorDef.isSanctuary ? u.maxHp : Math.max(1, u.hp);
  }

  const nextState: TowerProgressionState = {
    ...state,
    highestFloorCleared: newHighest,
    currentUnlockedFloor: nextUnlocked,
    completedFloorNumbers: newCompleted,
    unlockedCheckpoints: newCheckpoints,
    oathShards: state.oathShards + shardsEarned,
    firstClearClaimedFloorNumbers: newFirstClaims,
    bossClearRecords: newBossRecords,
    activeRun: {
      currentFloor: nextUnlocked,
      partyHpSnapshot: hpSnapshot,
    },
  };

  return {
    nextState,
    firstClearEarned: isFirstClear,
    shardsEarned,
    xpEarned,
    unlockedCheckpoint: newlyUnlockedCheckpoint,
    bossDefeated: defeatedBoss,
  };
}

/**
 * Purchases an item from the Tower Shop
 */
export function purchaseTowerShopItem(
  state: TowerProgressionState,
  itemId: string
): {
  success: boolean;
  nextState: TowerProgressionState;
  item?: TowerShopItem;
  reason?: string;
} {
  const item = TOWER_SHOP_CATALOG.find((i) => i.id === itemId);
  if (!item) {
    return { success: false, nextState: state, reason: 'Item not found in catalog.' };
  }

  if (state.oathShards < item.oathShardCost) {
    return {
      success: false,
      nextState: state,
      reason: `Insufficient Oath Shards! Need ${item.oathShardCost}, but only possess ${state.oathShards}.`,
    };
  }

  if (state.highestFloorCleared < item.requiredFloorCleared) {
    return {
      success: false,
      nextState: state,
      reason: `Locked! Requires reaching and clearing Floor ${item.requiredFloorCleared}.`,
    };
  }

  if (state.purchasedShopItemIds.includes(itemId) && item.category !== 'consumable') {
    return {
      success: false,
      nextState: state,
      reason: 'This unique relic or armory upgrade has already been purchased.',
    };
  }

  const nextPurchased =
    item.category === 'consumable'
      ? state.purchasedShopItemIds
      : [...state.purchasedShopItemIds, itemId];

  const nextState: TowerProgressionState = {
    ...state,
    oathShards: state.oathShards - item.oathShardCost,
    purchasedShopItemIds: nextPurchased,
  };

  return {
    success: true,
    nextState,
    item,
  };
}

/**
 * Heals active run party HP to maximum when resting at a sanctuary floor
 */
export function restAtTowerSanctuary(state: TowerProgressionState): TowerProgressionState {
  if (!state.activeRun) return state;
  return {
    ...state,
    activeRun: {
      ...state.activeRun,
      partyHpSnapshot: {}, // cleared snapshot restores full HP
    },
  };
}
