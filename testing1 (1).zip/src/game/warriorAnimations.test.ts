import test from 'node:test';
import assert from 'node:assert/strict';
import {
  WARRIOR_ANIMATION_REGISTRY,
  WarriorSkillId,
  sampleWarriorRigTransform,
  getAnimationPhaseAndProgress,
} from './warriorAnimations';
import { ALL_SKILLS_DATABASE } from './progressionData';
import { soundEngine } from './audio';

const ALL_12_WARRIOR_SKILL_IDS: WarriorSkillId[] = [
  'sundering_strike',
  'guarded_stance',
  'whirlwind_assault',
  'driving_assault',
  'weapon_parry',
  'crippling_blow',
  'unbreakable_resolve',
  'earthsplitter',
  'relentless_pursuit',
  'iron_reprisal',
  'battlefield_commander',
  'last_stand',
];

test('1. Warrior Animation Registry Completeness: all 12 core skills exist and correspond to progressionData', () => {
  assert.equal(ALL_12_WARRIOR_SKILL_IDS.length, 12);

  ALL_12_WARRIOR_SKILL_IDS.forEach((id) => {
    const config = WARRIOR_ANIMATION_REGISTRY[id];
    assert.ok(config, `Animation config for ${id} must exist in registry.`);
    assert.equal(config.skillId, id);

    // Corresponds to authoritative skill in ALL_SKILLS_DATABASE
    const dbSkill = ALL_SKILLS_DATABASE[id];
    assert.ok(dbSkill, `Skill ${id} must exist in ALL_SKILLS_DATABASE.`);
    assert.equal(dbSkill.classKey, 'warrior');
    assert.equal(dbSkill.name, config.name);
  });
});

test('2. Unique Animation Identity: all 12 skills have strictly distinct animation IDs, poses, and sound cues', () => {
  const seenAnimationIds = new Set<string>();
  const seenSoundMethods = new Set<string>();
  const sampledPoses = new Map<WarriorSkillId, string>();

  ALL_12_WARRIOR_SKILL_IDS.forEach((id) => {
    const config = WARRIOR_ANIMATION_REGISTRY[id];

    // Unique animation ID
    assert.ok(
      !seenAnimationIds.has(config.animationId),
      `Duplicate animationId detected: ${config.animationId}`
    );
    seenAnimationIds.add(config.animationId);

    // Unique sound cue method
    assert.ok(
      !seenSoundMethods.has(config.soundMethod),
      `Duplicate soundMethod detected: ${config.soundMethod}`
    );
    seenSoundMethods.add(config.soundMethod);

    // Verify sound method exists on soundEngine
    const soundFn = (soundEngine as any)[config.soundMethod];
    assert.equal(
      typeof soundFn,
      'function',
      `soundEngine must have method ${config.soundMethod}`
    );

    // Sample execution pose at impactTiming
    const sample = sampleWarriorRigTransform(id, config.impactTiming);
    const poseKey = `${sample.transform.weaponRot.map((v) => v.toFixed(2)).join(',')}|${sample.transform.weaponPos.map((v) => v.toFixed(2)).join(',')}`;

    for (const [otherId, otherKey] of sampledPoses.entries()) {
      assert.notEqual(
        poseKey,
        otherKey,
        `Skills ${id} and ${otherId} must have visually distinct weapon impact poses.`
      );
    }
    sampledPoses.set(id, poseKey);
  });

  assert.equal(seenAnimationIds.size, 12);
  assert.equal(seenSoundMethods.size, 12);
});

test('3. Animation Lifecycle Timing & Phase Progression: anticipation, execution, impact, and recovery', () => {
  ALL_12_WARRIOR_SKILL_IDS.forEach((id) => {
    const config = WARRIOR_ANIMATION_REGISTRY[id];

    assert.ok(config.anticipationDuration > 0.05, `${id} anticipationDuration must be > 0.05s`);
    assert.ok(config.executionDuration > 0.1, `${id} executionDuration must be > 0.1s`);
    assert.ok(config.recoveryDuration > 0.1, `${id} recoveryDuration must be > 0.1s`);
    assert.ok(config.totalDuration <= 1.0, `${id} totalDuration must remain <= 1.0s to avoid slowing combat`);

    const expectedTotal =
      config.anticipationDuration +
      config.executionDuration +
      (config.sustainDuration ?? 0) +
      config.recoveryDuration;
    assert.ok(
      Math.abs(config.totalDuration - expectedTotal) < 0.01,
      `${id} totalDuration (${config.totalDuration}) must equal sum of lifecycle phases (${expectedTotal})`
    );

    // Impact timing must fall inside execution phase
    assert.ok(
      config.impactTiming >= config.anticipationDuration,
      `${id} impactTiming (${config.impactTiming}) must be after anticipation (${config.anticipationDuration})`
    );
    assert.ok(
      config.impactTiming <= config.anticipationDuration + config.executionDuration + 0.05,
      `${id} impactTiming (${config.impactTiming}) must occur by end of execution`
    );

    // Test phase evaluation at 0, middle, impact, and end
    const atStart = getAnimationPhaseAndProgress(config, 0.01);
    assert.equal(atStart.phase, 'anticipation');

    const atImpact = getAnimationPhaseAndProgress(config, config.impactTiming);
    assert.ok(atImpact.phase === 'execution' || atImpact.phase === 'impact');

    const atRecovery = getAnimationPhaseAndProgress(config, config.totalDuration - 0.05);
    assert.equal(atRecovery.phase, 'recovery');

    const atDone = sampleWarriorRigTransform(id, config.totalDuration + 0.01);
    assert.equal(atDone.isFinished, true);
  });
});

test('4. Weapon Trail & VFX Specifications: correct types, restrained particles, and color palettes', () => {
  ALL_12_WARRIOR_SKILL_IDS.forEach((id) => {
    const config = WARRIOR_ANIMATION_REGISTRY[id];

    assert.ok(config.vfx.particleCount >= 8 && config.vfx.particleCount <= 32, `${id} particleCount must be restrained (8-32)`);
    assert.ok(typeof config.vfx.particleColorHex === 'number', `${id} particleColorHex must be valid hex`);
    assert.ok(typeof config.vfx.dustBurst === 'boolean', `${id} dustBurst flag must be boolean`);
    assert.ok(typeof config.vfx.sparkBurst === 'boolean', `${id} sparkBurst flag must be boolean`);

    // Weapon trails validation
    assert.ok(typeof config.weaponTrail.enabled === 'boolean');
    assert.ok(config.weaponTrail.intensity > 0 && config.weaponTrail.intensity <= 1.0);
    assert.ok(typeof config.weaponTrail.trailType === 'string');

    // Specific skill trail checks
    if (id === 'sundering_strike') {
      assert.equal(config.weaponTrail.trailType, 'overhead_cleave');
      assert.equal(config.weaponTrail.enabled, true);
    } else if (id === 'whirlwind_assault') {
      assert.equal(config.weaponTrail.trailType, 'horizontal_sweep');
      assert.equal(config.weaponTrail.enabled, true);
      assert.equal(config.targetFacingBehavior, 'rotate_360');
    } else if (id === 'driving_assault') {
      assert.equal(config.weaponTrail.trailType, 'forward_thrust');
      assert.equal(config.movementBehavior, 'rush_forward');
    } else if (id === 'earthsplitter') {
      assert.equal(config.weaponTrail.trailType, 'ground_burst');
      assert.ok((config.vfx.shockwaveRadius ?? 0) >= 1.5, 'Earthsplitter must produce substantial linear ground shockwave');
    } else if (id === 'battlefield_commander') {
      assert.equal(config.vfx.allyPulse, true, 'Battlefield Commander must pulse rally highlight to allies');
    }
  });
});

test('5. Equipment Attachment & Rigging Integrity: Longsword and Shield remain oriented throughout animations', () => {
  ALL_12_WARRIOR_SKILL_IDS.forEach((id) => {
    // Sample 5 keyframes across duration
    const steps = [0.1, 0.25, 0.5, 0.75, 1.0];
    steps.forEach((stepFrac) => {
      const config = WARRIOR_ANIMATION_REGISTRY[id];
      const elapsed = config.totalDuration * stepFrac;
      const { transform } = sampleWarriorRigTransform(id, elapsed);

      // Weapon position offset must be within arm reach (< 1.5 units)
      const weaponDist = Math.hypot(...transform.weaponPos);
      assert.ok(
        weaponDist < 1.5,
        `${id} weapon offset at ${elapsed.toFixed(2)}s (${weaponDist.toFixed(2)}) must not detach from arm`
      );

      // Shield offset must be within arm reach (< 1.2 units)
      if (transform.shieldPos) {
        const shieldDist = Math.hypot(...transform.shieldPos);
        assert.ok(
          shieldDist < 1.2,
          `${id} shield offset at ${elapsed.toFixed(2)}s (${shieldDist.toFixed(2)}) must not detach from left arm`
        );
      }

      // Body scale must remain near 1.0 (no extreme grotesque distortion)
      transform.bodyScale.forEach((s) => {
        assert.ok(s >= 0.85 && s <= 1.25, `${id} body scale ${s} must remain within physical bounds`);
      });
    });
  });
});

test('6. Combat Synchronization Separation: animations are strictly visual presentations and respect miss state', () => {
  ALL_12_WARRIOR_SKILL_IDS.forEach((id) => {
    const config = WARRIOR_ANIMATION_REGISTRY[id];

    // Sample hit vs miss
    const hitPose = sampleWarriorRigTransform(id, config.impactTiming, false);
    const missPose = sampleWarriorRigTransform(id, config.impactTiming, true);

    assert.ok(hitPose.transform, 'Hit pose must compute cleanly');
    assert.ok(missPose.transform, 'Miss pose must compute cleanly');

    // Miss state does not break finishing or recovery
    const endMiss = sampleWarriorRigTransform(id, config.totalDuration, true);
    assert.equal(endMiss.isFinished, true);

    // End of recovery returns smoothly near zero offsets
    const endHit = sampleWarriorRigTransform(id, config.totalDuration, false);
    assert.ok(Math.abs(endHit.transform.bodyPos[0]) < 0.05);
  });
});
