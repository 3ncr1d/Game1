import { get8DirectionalValidMoves } from './eightDirectionalMovement';

export type CompanionId = 'seraphina' | 'kaelen' | 'thorne';
export type EnemyArchetype = 'stalker' | 'weaver' | 'inquisitor' | 'bruiser' | 'champion';
export type UnitId = CompanionId | string;

export type RelationshipTier = 'Hostile' | 'Guarded' | 'Comrade' | 'Trusted' | 'Sworn Bond';

export type WorldFlag =
  | 'sanctum_purified'
  | 'blood_weave_unleashed'
  | 'inquisitor_spared'
  | 'briar_ward_awakened'
  | 'astral_crown_claimed'
  | 'astral_crown_shattered';

export interface WorldReactivityState {
  flags: WorldFlag[];
  corruptionLevel: number; // 0 to 100 (lower = purified emerald/gold, higher = crimson/void)
  oathAlignment: 'Mercy' | 'Dominion' | 'Balance';
  factions: {
    silverCovenant: number; // -50 to +50
    bloodScholars: number;
    sylvanCircle: number;
  };
  chronicleLog: string[];
}

export type AbilityElement = 'physical' | 'fire' | 'radiant' | 'nature' | 'arcane';

export type EnvironmentalSurface =
  | 'none'
  | 'oil_pool'
  | 'fire_pool'
  | 'sanctified_pool'
  | 'bramble_snare'
  | 'runic_mine'
  | 'astral_rift'
  | 'prismatic_field';

export interface TacticalEnvObject {
  id: string;
  name: string;
  kind: 'oil_barrel' | 'runic_brazier' | 'runestone_block';
  gridX: number;
  gridZ: number;
  elevation: number;
  hp: number;
  maxHp: number;
  pushable: boolean;
  destroyed: boolean;
}

export function gridToWorld(gx: number, gz: number, elevation = 0): [number, number, number] {
  const wx = (gx - (GRID_SIZE - 1) / 2) * 2.0;
  const wz = (gz - (GRID_SIZE - 1) / 2) * 2.0;
  const wy = elevation * 0.65;
  return [wx, wy, wz];
}

export type AbilityCategory =
  | 'martial_cleave'
  | 'consecration_judgment'
  | 'execution_gapcloser'
  | 'cleansing_mend'
  | 'bastion_aura'
  | 'piercing_ray'
  | 'pyromantic_detonation'
  | 'spacetime_implosion'
  | 'telekinetic_tether'
  | 'phase_transfusion'
  | 'deadeye_snipe'
  | 'predator_strike'
  | 'briar_barricade'
  | 'seismic_glaive'
  | 'trap_snare'
  | 'evasive_barrage'
  | 'barkskin_poultice'
  | 'enemy_maneuver'
  | 'support'
  | 'control';

export type AbilityAoeShape =
  | 'single'
  | 'sweeping_arc'
  | 'solar_cross'
  | 'bastion_aura'
  | 'piercing_ray'
  | 'chebyshev_3x3'
  | 'vacuum_implosion'
  | 'tether_pull'
  | 'briar_wall_3'
  | 'shockwave_ring'
  | 'trap_tile';

export interface Ability {
  id: string;
  name: string;
  key: '1' | '2' | '3' | '4';
  apCost: number;
  cooldown: number;
  range: number; // in grid tiles (1 = melee adjacent, 4-5 = ranged)
  aoeRadius?: number;
  aoeShape?: AbilityAoeShape;
  category?: AbilityCategory;
  damageRange: [number, number];
  healAmount?: number;
  statusEffect?: 'blessed' | 'burning' | 'rooted' | 'sundered' | 'warded' | 'chilled';
  element?: AbilityElement;
  pushDistance?: number;
  pullDistance?: number;
  selfReposition?: 'leap_adjacent' | 'backstep_1';
  cleanseStatuses?: ('burning' | 'rooted' | 'sundered' | 'chilled')[];
  grantTempHp?: number;
  allyAuraTempHp?: number;
  resetTargetMove?: boolean;
  refundApOnKO?: number;
  uniqueMechanicLabel?: string;
  targetType: 'enemy' | 'ally' | 'self' | 'ground';
  roleClue: string;
  description: string;
}

export interface CombatUnit {
  id: UnitId;
  name: string;
  title: string;
  faction: 'party' | 'enemy';
  characterClass?: 'warrior' | 'mage' | 'rogue' | 'paladin' | 'ranger';
  companionId?: CompanionId;
  archetype?: EnemyArchetype;
  gridX: number;
  gridZ: number;
  elevation: number; // 0 = ground, 1 = high ground bastion
  hp: number;
  maxHp: number;
  tempHp: number;
  ap: number;
  maxAp: number;
  moveRange: number;
  movedThisTurn: boolean;
  armorClass: number;
  initiative: number;
  stats: {
    str: number;
    dex: number;
    int: number;
    cha: number;
  };
  abilities: Ability[];
  cooldowns: Record<string, number>;
  statuses: {
    type: 'blessed' | 'burning' | 'rooted' | 'sundered' | 'warded' | 'chilled';
    turnsLeft: number;
  }[];
  isKO: boolean;
  koTimer: number;
  telegraph?: {
    abilityName: string;
    targetUnitId: string;
    targetX: number;
    targetZ: number;
    damagePreview: number;
  };
  immunities?: ('sundered' | 'rooted' | 'burning' | 'displacement' | 'chilled')[];
  guardedStanceTurns?: number;
  weaponParryActive?: boolean;
  ironReprisalActive?: boolean;
  lastStandTurns?: number;
  usedLastStand?: boolean;
  damageTakenSinceLastTurn?: number;
  // Mage defensive reactions & combat fields
  counterspellActive?: boolean;
  counterspellTurns?: number;
  aegisWardActive?: boolean;
  aegisWardTurns?: number;
  phaseVeilTurns?: number;
  activeRunicMineCoords?: { x: number; z: number };
  activePrismaticFieldCoords?: { x: number; z: number };
}

export interface CompanionRelationship {
  id: CompanionId;
  name: string;
  title: string;
  raceClass: string;
  approval: number; // 0 to 100
  personalQuestStage: string;
  synergyName: string;
  synergyDescription: string;
  campConversationsCompleted: string[];
}

export interface DialogueChoice {
  id: string;
  text: string;
  skillCheck?: {
    stat: 'str' | 'dex' | 'int' | 'cha';
    skillName: 'Persuasion' | 'Arcana' | 'Intimidation' | 'Insight' | 'Nature';
    dc: number;
    speakerId: CompanionId;
  };
  approvalDeltas: Partial<Record<CompanionId, number>>;
  setWorldFlags?: WorldFlag[];
  corruptionDelta?: number;
  alignmentShift?: 'Mercy' | 'Dominion' | 'Balance';
  combatEffect?: 'bless_party' | 'weaken_enemies' | 'empower_kaelen' | 'heal_party';
  nextNodeId: string | 'END_COMBAT' | 'END_PEACEFUL_BUFF';
  outcomeSummary: string;
}

export interface DialogueNode {
  id: string;
  speakerName: string;
  speakerTitle: string;
  speakerPortrait: CompanionId | 'inquisitor' | 'oracle' | 'archon';
  locationTitle: string;
  text: string;
  companionInterjections: {
    companionId: CompanionId;
    quote: string;
  }[];
  choices: DialogueChoice[];
}

export interface GridTile {
  x: number;
  z: number;
  elevation: number; // 0 = normal, 1 = high bastion
  terrain: 'stone' | 'moss' | 'hazard_rift' | 'pillar' | 'bastion';
  surface?: EnvironmentalSurface;
  walkable: boolean;
}

export interface StageConfig {
  id: number;
  name: string;
  subtitle: string;
  chapterLabel: string;
  introNodeId: string;
  ambientPreset: 'twilight_sanctum' | 'crimson_rift' | 'emerald_grove';
}

export const GRID_SIZE = 10; // 10x10 tactical grid (0..9)

export const STAGES: StageConfig[] = [
  {
    id: 0,
    name: 'Sanctum of the Shattered Oath',
    subtitle: 'Where the Silver Covenant fractured beneath the Astral Spire',
    chapterLabel: 'Act I · Whispering Vale',
    introNodeId: 'act1_sanctum_parley',
    ambientPreset: 'twilight_sanctum',
  },
  {
    id: 1,
    name: 'The Blighted Briar Crossing',
    subtitle: 'Ancient sylvan root-bridges choked by Void-Weave crystals',
    chapterLabel: 'Act II · Thornwood Reach',
    introNodeId: 'act2_briar_parley',
    ambientPreset: 'emerald_grove',
  },
  {
    id: 2,
    name: 'The Sunken Astral Reliquary',
    subtitle: 'Heart of the Dimraeth Rift and the Crown of Echoes',
    chapterLabel: 'Act III · Inner Sanctum',
    introNodeId: 'act3_reliquary_parley',
    ambientPreset: 'crimson_rift',
  },
];

export function getRelationshipTier(approval: number): RelationshipTier {
  if (approval < 20) return 'Hostile';
  if (approval < 45) return 'Guarded';
  if (approval < 70) return 'Comrade';
  if (approval < 88) return 'Trusted';
  return 'Sworn Bond';
}

export function getCompanionSynergyBonus(approval: number): {
  attackBonus: number;
  damageBonus: number;
  critThreshold: number;
} {
  const tier = getRelationshipTier(approval);
  switch (tier) {
    case 'Sworn Bond':
      return { attackBonus: 3, damageBonus: 4, critThreshold: 18 };
    case 'Trusted':
      return { attackBonus: 2, damageBonus: 2, critThreshold: 19 };
    case 'Comrade':
      return { attackBonus: 1, damageBonus: 1, critThreshold: 20 };
    case 'Guarded':
      return { attackBonus: 0, damageBonus: 0, critThreshold: 20 };
    case 'Hostile':
      return { attackBonus: -1, damageBonus: 0, critThreshold: 20 };
  }
}

export function getStatModifier(statValue: number): number {
  return Math.floor((statValue - 10) / 2);
}

export function manhattanDistance(x1: number, z1: number, x2: number, z2: number): number {
  return Math.abs(x1 - x2) + Math.abs(z1 - z2);
}

export function chebyshevDistance(x1: number, z1: number, x2: number, z2: number): number {
  return Math.max(Math.abs(x1 - x2), Math.abs(z1 - z2));
}

export function generateTacticalGrid(stageId: number, worldState: WorldReactivityState): GridTile[][] {
  const grid: GridTile[][] = [];
  const isPurified = worldState.flags.includes('sanctum_purified');
  const isBloodUnleashed = worldState.flags.includes('blood_weave_unleashed');
  const isBriarAwakened = worldState.flags.includes('briar_ward_awakened');

  for (let x = 0; x < GRID_SIZE; x++) {
    const row: GridTile[] = [];
    for (let z = 0; z < GRID_SIZE; z++) {
      let terrain: GridTile['terrain'] = 'stone';
      let surface: EnvironmentalSurface = 'none';
      let elevation = 0;
      let walkable = true;

      // Ruined pillars (unwalkable cover)
      if ((x === 2 && z === 4) || (x === 7 && z === 4) || (x === 4 && z === 2 && stageId === 2)) {
        terrain = 'pillar';
        walkable = false;
      }
      // High ground tactical bastions (+1 elevation, +2 attack bonus)
      else if (
        (x >= 1 && x <= 2 && z >= 6 && z <= 7) ||
        (x >= 7 && x <= 8 && z >= 2 && z <= 3) ||
        (stageId >= 1 && x >= 4 && x <= 5 && z === 5)
      ) {
        terrain = 'bastion';
        elevation = 1;
      }
      // Astral / Blood rift hazards in center unless purified
      else if (!isPurified && ((x === 4 && z === 4) || (x === 5 && z === 4) || (isBloodUnleashed && x === 5 && z === 5))) {
        terrain = 'hazard_rift';
      } else if ((x + z) % 3 === 0) {
        terrain = 'moss';
      }

      // Alchemical Oil Pools that ignite when struck by fire abilities
      if (walkable && ((x === 3 && (z === 2 || z === 3)) || (x === 6 && (z === 2 || z === 3)))) {
        surface = isPurified ? 'sanctified_pool' : 'oil_pool';
      } else if (walkable && isBriarAwakened && (x === 4 || x === 5) && z === 3) {
        surface = 'bramble_snare';
      }

      row.push({ x, z, elevation, terrain, surface, walkable });
    }
    grid.push(row);
  }
  return grid;
}

export function createEncounterObjects(stageId: number): TacticalEnvObject[] {
  return [
    {
      id: `obj_brazier_${stageId}`,
      name: 'Volatile Runic Brazier',
      kind: 'runic_brazier',
      gridX: 2,
      gridZ: 3,
      elevation: 0,
      hp: 12,
      maxHp: 12,
      pushable: true,
      destroyed: false,
    },
    {
      id: `obj_barrel_${stageId}`,
      name: 'Alchemical Oil Cask',
      kind: 'oil_barrel',
      gridX: 6,
      gridZ: 3,
      elevation: 0,
      hp: 10,
      maxHp: 10,
      pushable: true,
      destroyed: false,
    },
    {
      id: `obj_monolith_${stageId}`,
      name: 'Runestone Push-Block',
      kind: 'runestone_block',
      gridX: 4,
      gridZ: 5,
      elevation: 0,
      hp: 30,
      maxHp: 30,
      pushable: true,
      destroyed: false,
    },
  ];
}

export function getValidMoveTiles(
  unit: CombatUnit,
  grid: GridTile[][],
  allUnits: CombatUnit[],
  envObjects: TacticalEnvObject[] = []
): { x: number; z: number }[] {
  if (unit.movedThisTurn || unit.ap < 1 || unit.statuses.some((s) => s.type === 'rooted')) {
    return [];
  }
  const occupied = new Set(
    allUnits.filter((u) => !u.isKO && u.id !== unit.id).map((u) => `${u.gridX},${u.gridZ}`)
  );
  for (const obj of envObjects) {
    if (!obj.destroyed) {
      occupied.add(`${obj.gridX},${obj.gridZ}`);
    }
  }

  const isWalkable = (x: number, z: number) => {
    if (x < 0 || x >= GRID_SIZE || z < 0 || z >= GRID_SIZE) return false;
    const tile = grid[x]?.[z];
    if (!tile || !tile.walkable) return false;
    if (occupied.has(`${x},${z}`)) return false;
    return true;
  };

  const effectiveMoveRange =
    (unit.guardedStanceTurns ?? 0) > 0
      ? Math.max(1, unit.moveRange - 1)
      : unit.moveRange;

  const moves = get8DirectionalValidMoves(
    unit.gridX,
    unit.gridZ,
    effectiveMoveRange,
    GRID_SIZE,
    GRID_SIZE,
    isWalkable
  );

  return moves.map((m) => ({ x: m.x, z: m.z }));
}

export function isLastStandConditionMet(
  unit: CombatUnit,
  allUnits: CombatUnit[]
): { allowed: boolean; reason: string } {
  if (unit.usedLastStand) {
    return {
      allowed: false,
      reason: 'Last Stand can only be used once per combat encounter.',
    };
  }
  const hpRatio = unit.hp / Math.max(1, unit.maxHp);
  if (hpRatio <= 0.45) {
    return {
      allowed: true,
      reason: 'Critical Vitality (<=45% HP)',
    };
  }
  const adjacentEnemies = allUnits.filter(
    (u) =>
      !u.isKO &&
      u.faction !== unit.faction &&
      chebyshevDistance(u.gridX, u.gridZ, unit.gridX, unit.gridZ) <= 1
  ).length;
  if (adjacentEnemies >= 2) {
    return {
      allowed: true,
      reason: `Surrounded (${adjacentEnemies} Adjacent Enemies)`,
    };
  }
  const livingAllies = allUnits.filter(
    (u) => !u.isKO && u.faction === unit.faction
  ).length;
  if (livingAllies <= 1) {
    return {
      allowed: true,
      reason: 'Last Conscious Party Member',
    };
  }
  return {
    allowed: false,
    reason:
      'Requires critical condition: <=45% HP, surrounded by 2+ adjacent enemies, or last conscious ally.',
  };
}

export function resolveWarriorDefensiveReactions(
  attacker: CombatUnit,
  defender: CombatUnit,
  ability: Ability,
  rawDamage: number
): {
  finalDamage: number;
  parryTriggered: boolean;
  reprisalTriggered: boolean;
  lastStandClamped: boolean;
  counterDamageToAttacker: number;
  reactionLog: string[];
} {
  const reactionLog: string[] = [];
  let finalDamage = Math.max(0, rawDamage);
  let parryTriggered = false;
  let reprisalTriggered = false;
  let lastStandClamped = false;
  let counterDamageToAttacker = 0;

  const dist = manhattanDistance(
    attacker.gridX,
    attacker.gridZ,
    defender.gridX,
    defender.gridZ
  );
  const isQualifyingMelee =
    dist <= 2 &&
    ability.range <= 2 &&
    (ability.aoeRadius ?? 0) === 0 &&
    ability.aoeShape !== 'chebyshev_3x3' &&
    ability.aoeShape !== 'shockwave_ring';

  if (defender.weaponParryActive) {
    if (isQualifyingMelee) {
      parryTriggered = true;
      finalDamage = 0;
      counterDamageToAttacker += 8;
      reactionLog.push(
        `Weapon Parry deflects ${attacker.name}'s melee strike and counters for 8 DMG!`
      );
    } else {
      reactionLog.push(
        `Weapon Parry cannot deflect ${attacker.name}'s ranged or area attack.`
      );
    }
  }

  if (
    !parryTriggered &&
    finalDamage > 0 &&
    (defender.guardedStanceTurns ?? 0) > 0 &&
    (ability.element === 'physical' || !ability.element)
  ) {
    const reduced = Math.max(1, Math.floor(finalDamage * 0.75));
    if (reduced < finalDamage) {
      finalDamage = reduced;
      reactionLog.push(
        `Guarded Stance mitigates incoming physical damage to ${finalDamage}.`
      );
    }
  }

  if (!parryTriggered && finalDamage > 0 && (defender.lastStandTurns ?? 0) > 0) {
    const maxBeforeFloor = defender.tempHp + Math.max(0, defender.hp - 1);
    if (finalDamage > maxBeforeFloor) {
      finalDamage = maxBeforeFloor;
      lastStandClamped = true;
      reactionLog.push(
        `Warrior refuses to fall! Last Stand holds ${defender.name} at 1 HP!`
      );
    }
  }

  if (defender.ironReprisalActive && isQualifyingMelee && !parryTriggered) {
    const remainingHpAfterHit = defender.hp + defender.tempHp - finalDamage;
    if (remainingHpAfterHit >= 1 || (defender.lastStandTurns ?? 0) > 0) {
      reprisalTriggered = true;
      counterDamageToAttacker += 9;
      reactionLog.push(
        `Iron Reprisal retaliates against ${attacker.name} for 9 physical DMG!`
      );
    }
  }

  return {
    finalDamage,
    parryTriggered,
    reprisalTriggered,
    lastStandClamped,
    counterDamageToAttacker,
    reactionLog,
  };
}

export function resolveMageDefensiveReactions(
  attacker: CombatUnit,
  defender: CombatUnit,
  ability: Ability,
  rawDamage: number,
  allUnits: CombatUnit[] = []
): {
  finalDamage: number;
  counterspellTriggered: boolean;
  phaseVeilMitigated: boolean;
  aegisWardShockwave: boolean;
  counterDamageToAttacker: number;
  shockwaveTargets: { unit: CombatUnit; damage: number }[];
  reactionLog: string[];
} {
  const reactionLog: string[] = [];
  let finalDamage = Math.max(0, rawDamage);
  let counterspellTriggered = false;
  let phaseVeilMitigated = false;
  let aegisWardShockwave = false;
  let counterDamageToAttacker = 0;
  const shockwaveTargets: { unit: CombatUnit; damage: number }[] = [];

  const dist = manhattanDistance(
    attacker.gridX,
    attacker.gridZ,
    defender.gridX,
    defender.gridZ
  );

  const isQualifyingSpellOrRanged =
    dist >= 2 ||
    ability.element === 'arcane' ||
    ability.element === 'fire' ||
    ability.element === 'radiant' ||
    ability.range >= 3;

  if (defender.counterspellActive) {
    if (isQualifyingSpellOrRanged) {
      counterspellTriggered = true;
      finalDamage = 0;
      counterDamageToAttacker += 8;
      reactionLog.push(
        `Counterspell unravels ${attacker.name}'s attack, nullifying damage and reflecting 8 Arcane DMG!`
      );
    } else {
      reactionLog.push(
        `Counterspell cannot deflect direct melee strike from ${attacker.name}.`
      );
    }
  }

  if (
    !counterspellTriggered &&
    finalDamage > 0 &&
    (defender.phaseVeilTurns ?? 0) > 0 &&
    (ability.element === 'physical' || !ability.element)
  ) {
    const reduced = Math.max(1, Math.floor(finalDamage * 0.5));
    if (reduced < finalDamage) {
      finalDamage = reduced;
      phaseVeilMitigated = true;
      reactionLog.push(
        `Phase Veil phases through the strike, mitigating 50% physical damage to ${finalDamage}!`
      );
    }
  }

  if (
    !counterspellTriggered &&
    defender.aegisWardActive &&
    defender.tempHp > 0 &&
    finalDamage >= defender.tempHp
  ) {
    aegisWardShockwave = true;
    reactionLog.push(
      `Aegis Ward shatters! Arcane shockwave releases 6 Arcane DMG to adjacent foes!`
    );
    for (const u of allUnits) {
      if (
        !u.isKO &&
        u.faction !== defender.faction &&
        chebyshevDistance(u.gridX, u.gridZ, defender.gridX, defender.gridZ) <= 1
      ) {
        shockwaveTargets.push({ unit: u, damage: 6 });
      }
    }
  }

  return {
    finalDamage,
    counterspellTriggered,
    phaseVeilMitigated,
    aegisWardShockwave,
    counterDamageToAttacker,
    shockwaveTargets,
    reactionLog,
  };
}

export interface CombatResolution {
  hit: boolean;
  critical: boolean;
  d20Roll: number;
  attackModifier: number;
  highGroundBonus: number;
  flankingBonus: number;
  synergyBonus: number;
  blessedBonus?: number;
  totalAttackRoll: number;
  targetAC: number;
  damage: number;
  heal: number;
  statusApplied?: string;
  targetKO: boolean;
  bonusConditionalDamage?: number;
  conditionalMechanicNote?: string;
  apRefunded?: number;
  tempHpGranted?: number;
  cleansedStatuses?: ('burning' | 'rooted' | 'sundered')[];
  resetTargetMove?: boolean;
  summaryText: string;
}

export interface DiceModifierTerm {
  label: string;
  value: number;
}

export interface DiceRollToastEntry {
  id: number;
  kind: 'attack' | 'skill' | 'support';
  actorName: string;
  actorPortrait: string;
  actionLabel: string;
  d20Roll: number;
  modifiers: DiceModifierTerm[];
  totalRoll: number;
  thresholdLabel: string;
  thresholdValue: number;
  success: boolean;
  critical: boolean;
  fumble: boolean;
  outcomeBadge: string;
  impactSummary: string;
  equationText: string;
}

export function resolveAbilityUse(
  attacker: CombatUnit,
  target: CombatUnit,
  ability: Ability,
  allUnits: CombatUnit[],
  relationships: Record<CompanionId, CompanionRelationship>,
  worldState: WorldReactivityState,
  deterministicRoll?: number
): CombatResolution {
  const d20Roll = deterministicRoll ?? Math.floor(Math.random() * 20) + 1;

  // Healing or buff ability on ally/self
  if (ability.targetType === 'ally' || ability.targetType === 'self') {
    if (ability.id === 'last_stand') {
      const cond = isLastStandConditionMet(attacker, allUnits);
      if (!cond.allowed) {
        return {
          hit: false,
          critical: false,
          d20Roll,
          attackModifier: 0,
          highGroundBonus: 0,
          flankingBonus: 0,
          synergyBonus: 0,
          blessedBonus: 0,
          totalAttackRoll: d20Roll,
          targetAC: 0,
          damage: 0,
          heal: 0,
          targetKO: false,
          summaryText: `Last Stand cannot be used: ${cond.reason}`,
        };
      }
    }

    const baseHeal = ability.healAmount ?? 0;
    const mercyBonus = worldState.oathAlignment === 'Mercy' ? 3 : 0;
    const totalHeal = baseHeal > 0 ? baseHeal + mercyBonus : 0;
    const tempHpGranted = ability.grantTempHp ?? 0;
    const cleansedStatuses = (ability.cleanseStatuses ?? []).filter((st) =>
      target.statuses.some((active) => active.type === st)
    );
    const resetTargetMove = Boolean(ability.resetTargetMove);

    const extraSupportTags: string[] = [];
    if (tempHpGranted > 0) extraSupportTags.push(`+${tempHpGranted} Temp HP`);
    if (cleansedStatuses.length > 0) {
      extraSupportTags.push(`purged ${cleansedStatuses.map((s) => s.toUpperCase()).join('/')}`);
    }
    if (resetTargetMove) extraSupportTags.push('Move Phase Reset');
    const extraSuffix = extraSupportTags.length > 0 ? ` [${extraSupportTags.join(' · ')}]` : '';

    let customSummary =
      totalHeal > 0
        ? `${attacker.name} casts ${ability.name} on ${target.name}, restoring ${totalHeal} HP${
            ability.statusEffect ? ` and granting ${ability.statusEffect.toUpperCase()}` : ''
          }${extraSuffix}!`
        : `${attacker.name} invokes ${ability.name} on ${target.name} (${ability.statusEffect?.toUpperCase() ?? 'BUFF'})${extraSuffix}!`;

    if (ability.id === 'guarded_stance') {
      customSummary = `Warrior adopts a guarded stance. ${attacker.name} gains Warded (+2 AC), 25% Physical Reduction, Displacement Immunity, and +6 Temp HP (-1 Move Range trade-off)!`;
    } else if (ability.id === 'weapon_parry') {
      customSummary = `${attacker.name} prepares Weapon Parry (+8 Temp HP, Warded +2 AC) to deflect and counter the next incoming melee strike!`;
    } else if (ability.id === 'unbreakable_resolve') {
      customSummary = `Warrior steels their resolve. ${attacker.name} purges crowd-control afflictions and fortifies with +12 Temp HP!`;
    } else if (ability.id === 'battlefield_commander') {
      customSummary = `Battlefield Commander rallies nearby allies. ${attacker.name} grants +10 Temp HP and Blessed (+2 Hit) within 4 tiles!`;
    } else if (ability.id === 'last_stand') {
      customSummary = `Warrior refuses to fall. ${attacker.name} activates Last Stand (+20 Temp HP, Warded +2 AC, and 1 HP survival floor for 2 turns)!`;
    } else if (ability.id === 'aegis_ward') {
      customSummary = `Mage invokes Aegis Ward. ${attacker.name} gains +10 Temp HP and Warded (+2 AC) for 2 turns; shield break releases a 6 Arcane DMG shockwave!`;
    } else if (ability.id === 'counterspell') {
      customSummary = `Mage arms Counterspell. ${attacker.name} enters a 2-turn reactive stance to negate incoming ranged/spell attacks and reflect 8 Arcane DMG!`;
    } else if (ability.id === 'phase_veil') {
      customSummary = `Mage shifts into Phase Veil. ${attacker.name} cleanses debuffs, gains +1 Move Range, and gains 50% physical damage mitigation for 2 turns!`;
    }

    return {
      hit: true,
      critical: d20Roll === 20,
      d20Roll,
      attackModifier: 0,
      highGroundBonus: 0,
      flankingBonus: 0,
      synergyBonus: mercyBonus,
      blessedBonus: 0,
      totalAttackRoll: d20Roll + mercyBonus,
      targetAC: 0,
      damage: 0,
      heal: totalHeal,
      statusApplied: ability.statusEffect,
      targetKO: false,
      tempHpGranted,
      cleansedStatuses,
      resetTargetMove,
      summaryText: customSummary,
    };
  }

  // Offensive attack / spell
  const primaryKey =
    attacker.companionId === 'kaelen' ||
    attacker.archetype === 'weaver' ||
    (attacker.stats.int > attacker.stats.str && attacker.stats.int >= attacker.stats.dex)
      ? 'int'
      : attacker.companionId === 'thorne' ||
        attacker.archetype === 'stalker' ||
        (attacker.stats.dex > attacker.stats.str && attacker.stats.dex > attacker.stats.int)
      ? 'dex'
      : 'str';
  const primaryStat = attacker.stats[primaryKey];

  const attackModifier = getStatModifier(primaryStat) + 2; // +2 proficiency
  const highGroundBonus =
    attacker.elevation > target.elevation ? 2 : attacker.elevation < target.elevation ? -1 : 0;

  // Check flanking: another conscious ally is adjacent to target
  const hasFlankingAlly = allUnits.some(
    (u) =>
      !u.isKO &&
      u.faction === attacker.faction &&
      u.id !== attacker.id &&
      chebyshevDistance(u.gridX, u.gridZ, target.gridX, target.gridZ) <= 1
  );
  const flankingBonus = hasFlankingAlly ? 2 : 0;

  // Companion relationship synergy
  const rel = attacker.companionId ? relationships[attacker.companionId] : undefined;
  const synergy = rel ? getCompanionSynergyBonus(rel.approval) : { attackBonus: 0, damageBonus: 0, critThreshold: 20 };

  const blessedBonus = attacker.statuses.some((s) => s.type === 'blessed') ? 2 : 0;
  const sunderedPenalty = target.statuses.some((s) => s.type === 'sundered') ? -2 : 0;
  const wardedBonus = target.statuses.some((s) => s.type === 'warded') ? 2 : 0;

  const effectiveAC = target.armorClass + sunderedPenalty + wardedBonus;
  const totalAttackRoll =
    d20Roll + attackModifier + highGroundBonus + flankingBonus + synergy.attackBonus + blessedBonus;

  const critical = d20Roll >= synergy.critThreshold;
  const hit = critical || (d20Roll !== 1 && totalAttackRoll >= effectiveAC);

  if (!hit) {
    return {
      hit: false,
      critical: false,
      d20Roll,
      attackModifier,
      highGroundBonus,
      flankingBonus,
      synergyBonus: synergy.attackBonus,
      blessedBonus,
      totalAttackRoll,
      targetAC: effectiveAC,
      damage: 0,
      heal: 0,
      targetKO: false,
      summaryText: `${attacker.name}'s ${ability.name} missed ${target.name} (Rolled ${totalAttackRoll} vs AC ${effectiveAC}).`,
    };
  }

  const [minDmg, maxDmg] = ability.damageRange;
  const rawRoll =
    deterministicRoll !== undefined
      ? Math.round((minDmg + maxDmg) / 2)
      : Math.floor(Math.random() * (maxDmg - minDmg + 1)) + minDmg;

  const bloodWeaveBonus =
    attacker.faction === 'party' && worldState?.flags?.includes('blood_weave_unleashed') ? 3 : 0;
  const highGroundDmg = attacker.elevation > target.elevation ? 2 : 0;

  // Skill-specific unique conditional mechanics (zero duplicate triggers)
  let bonusConditionalDamage = 0;
  let conditionalMechanicNote: string | undefined;
  const distToTarget = manhattanDistance(attacker.gridX, attacker.gridZ, target.gridX, target.gridZ);

  if (ability.id === 'searing_smite' && target.hp <= target.maxHp * 0.5) {
    bonusConditionalDamage += 6;
    conditionalMechanicNote = 'Bloodied Execution +6 DMG';
  } else if (
    ability.id === 'sundering_strike' &&
    target.statuses.some((s) => s.type === 'sundered')
  ) {
    bonusConditionalDamage += 3;
    conditionalMechanicNote = 'Sundered Exploit +3 DMG';
  } else if (
    ability.id === 'iron_reprisal' &&
    ((attacker.damageTakenSinceLastTurn ?? 0) > 0 || attacker.hp < attacker.maxHp)
  ) {
    bonusConditionalDamage += 6;
    conditionalMechanicNote = 'Absorbed Hit Reprisal +6 DMG';
  } else if (
    (ability.id === 'crimson_tempest' || ability.id === 'searing_blood_nova') &&
    target.statuses.some((s) => s.type === 'burning')
  ) {
    bonusConditionalDamage += 5;
    conditionalMechanicNote = 'Thermal Resonance +5 DMG';
  } else if (ability.id === 'heartseeker_shot' && distToTarget >= 4) {
    bonusConditionalDamage += 3;
    conditionalMechanicNote = 'Deadeye Distance +3 DMG';
  } else if (
    ability.id === 'briarfang_strike' &&
    target.statuses.some((s) => s.type === 'rooted' || s.type === 'sundered')
  ) {
    bonusConditionalDamage += 4;
    conditionalMechanicNote = 'Predator Exploit +4 DMG';
  } else if (ability.id === 'heart_briar_volley') {
    const hasAdjacentAlly = allUnits.some(
      (u) =>
        !u.isKO &&
        u.faction === target.faction &&
        u.id !== target.id &&
        chebyshevDistance(u.gridX, u.gridZ, target.gridX, target.gridZ) <= 1
    );
    if (!hasAdjacentAlly) {
      bonusConditionalDamage += 5;
      conditionalMechanicNote = 'Isolated Ambush +5 DMG';
    }
  } else if (
    ability.id === 'shadow_lunge' &&
    (target.hp <= target.maxHp * 0.6 ||
      target.statuses.some((s) => s.type === 'sundered' || s.type === 'burning'))
  ) {
    bonusConditionalDamage += 3;
    conditionalMechanicNote = 'Opportunist Backstab +3 DMG';
  } else if (ability.id === 'glacial_lance') {
    if (target.statuses.some((s) => s.type === 'chilled')) {
      bonusConditionalDamage += 4;
      conditionalMechanicNote = 'Chilled Shatter +4 DMG';
    }
  } else if (ability.id === 'arcane_disjunction') {
    const hadMagicalBuff =
      target.statuses.some((s) => s.type === 'warded' || s.type === 'blessed') ||
      target.tempHp > 0;
    if (hadMagicalBuff) {
      bonusConditionalDamage += 6;
      conditionalMechanicNote = 'Disjunction Purge +6 DMG';
    }
  }

  const totalDamage = Math.max(
    1,
    (critical ? rawRoll * 2 : rawRoll) +
      synergy.damageBonus +
      bloodWeaveBonus +
      highGroundDmg +
      bonusConditionalDamage
  );

  const willKO = target.hp + target.tempHp - totalDamage <= 0;
  const isBloodiedPursuit =
    ability.id === 'relentless_pursuit' && target.hp <= target.maxHp * 0.4;
  const apRefunded =
    (willKO || isBloodiedPursuit) && (ability.refundApOnKO ?? 0) > 0
      ? ability.refundApOnKO
      : 0;
  const tempHpGranted = ability.id === 'ironwood_tempest' ? ability.grantTempHp ?? 5 : 0;

  let appliedStatus = ability.statusEffect;
  let immunityNote = '';
  if (appliedStatus && target.immunities?.includes(appliedStatus as any)) {
    immunityNote = ` [${target.name} resisted ${appliedStatus.toUpperCase()}!]`;
    appliedStatus = undefined;
  }

  let flavorPrefix = '';
  if (ability.id === 'sundering_strike') {
    flavorPrefix = appliedStatus === 'sundered'
      ? `Sundering Strike breaks ${target.name}'s defense. `
      : `Sundering Strike hits ${target.name} (armor break resisted). `;
  } else if (ability.id === 'crippling_blow') {
    flavorPrefix = appliedStatus === 'rooted'
      ? `Crippling Blow impairs ${target.name}'s movement. `
      : `Crippling Blow strikes ${target.name} (movement impairment resisted). `;
  } else if (ability.id === 'relentless_pursuit') {
    flavorPrefix = `Relentless Pursuit closes the gap on ${target.name}. `;
  } else if (ability.id === 'iron_reprisal') {
    flavorPrefix = `Iron Reprisal unleashes stored vengeance on ${target.name}. `;
  } else if (ability.id === 'infernal_orb') {
    flavorPrefix = `Infernal Orb detonates across ${target.name}'s position! `;
  } else if (ability.id === 'glacial_lance') {
    flavorPrefix = appliedStatus === 'chilled'
      ? `Glacial Lance impales ${target.name} with piercing frost (Chilled)! `
      : `Glacial Lance pierces ${target.name} with freezing shards! `;
  } else if (ability.id === 'chain_lightning') {
    flavorPrefix = `Chain Lightning strikes ${target.name} and arcs across nearby foes! `;
  } else if (ability.id === 'arcane_disjunction') {
    flavorPrefix = `Arcane Disjunction unmakes ${target.name}'s magical wards! `;
  } else if (ability.id === 'gravitational_collapse') {
    flavorPrefix = `Gravitational Collapse drags ${target.name} into the singularity! `;
  }

  return {
    hit: true,
    critical,
    d20Roll,
    attackModifier,
    highGroundBonus,
    flankingBonus,
    synergyBonus: synergy.attackBonus,
    blessedBonus,
    totalAttackRoll,
    targetAC: effectiveAC,
    damage: totalDamage,
    heal: 0,
    statusApplied: appliedStatus,
    targetKO: willKO,
    bonusConditionalDamage,
    conditionalMechanicNote,
    apRefunded,
    tempHpGranted,
    summaryText: `${flavorPrefix}${attacker.name} hits ${target.name} with ${ability.name}${
      critical ? ' [CRITICAL!]' : ''
    } for ${totalDamage} DMG (Roll ${d20Roll}+${totalAttackRoll - d20Roll}=${totalAttackRoll} vs AC ${effectiveAC})${
      highGroundBonus > 0 ? ' [High Ground]' : ''
    }${flankingBonus > 0 ? ' [Flanking]' : ''}${
      conditionalMechanicNote ? ` [${conditionalMechanicNote}]` : ''
    }${immunityNote}${apRefunded && apRefunded > 0 ? ` [+${apRefunded} AP Refund!]` : ''}!`,
  };
}

export interface SkillCheckResult {
  success: boolean;
  critical: boolean;
  d20Roll: number;
  statMod: number;
  synergyMod: number;
  total: number;
  dc: number;
}

export function resolveSkillCheck(
  choice: DialogueChoice,
  units: CombatUnit[],
  relationships: Record<CompanionId, CompanionRelationship>,
  deterministicRoll?: number
): SkillCheckResult {
  if (!choice.skillCheck) {
    return {
      success: true,
      critical: false,
      d20Roll: 20,
      statMod: 0,
      synergyMod: 0,
      total: 20,
      dc: 0,
    };
  }

  const { stat, dc, speakerId } = choice.skillCheck;
  const speaker = units.find((u) => u.companionId === speakerId) ?? units[0];
  const statVal = speaker ? speaker.stats[stat] : 14;
  const statMod = getStatModifier(statVal);
  const rel = relationships[speakerId];
  const synergyMod = rel ? getCompanionSynergyBonus(rel.approval).attackBonus : 0;
  const d20Roll = deterministicRoll ?? Math.floor(Math.random() * 20) + 1;
  const total = d20Roll + statMod + synergyMod;
  const critical = d20Roll === 20;
  const success = critical || (d20Roll !== 1 && total >= dc);

  return {
    success,
    critical,
    d20Roll,
    statMod,
    synergyMod,
    total,
    dc,
  };
}

function formatSigned(val: number): string {
  return val >= 0 ? `+${val}` : `${val}`;
}

export function buildCombatRollToast(
  attacker: CombatUnit,
  target: CombatUnit,
  ability: Ability,
  res: CombatResolution,
  id: number = Date.now()
): DiceRollToastEntry {
  const actorPortrait = attacker.companionId ?? attacker.archetype ?? 'inquisitor';

  if (ability.targetType === 'ally' || ability.targetType === 'self') {
    const modifiers: DiceModifierTerm[] = [];
    if (res.synergyBonus !== 0) {
      modifiers.push({ label: 'Mercy Oath', value: res.synergyBonus });
    }
    const equationParts = [`1d20 (${res.d20Roll})`];
    for (const m of modifiers) {
      equationParts.push(`${m.label} (${formatSigned(m.value)})`);
    }
    const statusLabel = res.statusApplied ? ` · +${res.statusApplied.toUpperCase()}` : '';
    return {
      id,
      kind: 'support',
      actorName: attacker.name,
      actorPortrait,
      actionLabel: `${ability.name} → ${target.name}`,
      d20Roll: res.d20Roll,
      modifiers,
      totalRoll: res.totalAttackRoll,
      thresholdLabel: 'ALLY WARD',
      thresholdValue: 0,
      success: true,
      critical: res.critical,
      fumble: false,
      outcomeBadge: res.heal > 0 ? 'VITALITY MENDED' : 'WARD INVOKED',
      impactSummary: res.heal > 0 ? `+${res.heal} HP${statusLabel}` : `${res.statusApplied?.toUpperCase() ?? 'BUFF'}`,
      equationText: `${equationParts.join(' + ')} = ${res.totalAttackRoll}`,
    };
  }

  const statName =
    attacker.companionId === 'kaelen' || attacker.archetype === 'weaver'
      ? 'INT/Prof'
      : attacker.companionId === 'thorne' || attacker.archetype === 'stalker'
      ? 'DEX/Prof'
      : 'STR/Prof';

  const modifiers: DiceModifierTerm[] = [{ label: statName, value: res.attackModifier }];
  if (res.highGroundBonus !== 0) {
    modifiers.push({
      label: res.highGroundBonus > 0 ? 'High Ground' : 'Low Ground',
      value: res.highGroundBonus,
    });
  }
  if (res.flankingBonus !== 0) {
    modifiers.push({ label: 'Flanking', value: res.flankingBonus });
  }
  if (res.synergyBonus !== 0) {
    modifiers.push({ label: 'Sworn Bond', value: res.synergyBonus });
  }
  if (res.blessedBonus && res.blessedBonus !== 0) {
    modifiers.push({ label: 'Blessed', value: res.blessedBonus });
  }

  const equationParts = [`1d20 (${res.d20Roll})`];
  for (const m of modifiers) {
    equationParts.push(`${m.label} (${formatSigned(m.value)})`);
  }
  const equationText = `${equationParts.join(' + ')} = ${res.totalAttackRoll} vs AC ${res.targetAC}`;
  const fumble = res.d20Roll === 1;
  const statusSuffix = res.statusApplied && res.hit ? ` · ${res.statusApplied.toUpperCase()}` : '';

  return {
    id,
    kind: 'attack',
    actorName: attacker.name,
    actorPortrait,
    actionLabel: `${ability.name} → ${target.name}`,
    d20Roll: res.d20Roll,
    modifiers,
    totalRoll: res.totalAttackRoll,
    thresholdLabel: `AC ${res.targetAC}`,
    thresholdValue: res.targetAC,
    success: res.hit,
    critical: res.critical,
    fumble,
    outcomeBadge: res.critical
      ? 'CRITICAL HIT!'
      : fumble
      ? 'CRITICAL MISS (NAT 1)'
      : res.hit
      ? 'ATTACK HIT'
      : 'DEFLECTED / MISS',
    impactSummary: res.hit ? `${res.damage} DMG${statusSuffix}` : `0 DMG (Missed AC ${res.targetAC})`,
    equationText,
  };
}

export function buildSkillCheckRollToast(
  choice: DialogueChoice,
  result: SkillCheckResult,
  relationships: Record<CompanionId, CompanionRelationship>,
  id: number = Date.now()
): DiceRollToastEntry {
  const sc = choice.skillCheck;
  const speakerId = sc?.speakerId ?? 'seraphina';
  const speakerRel = relationships[speakerId];
  const actorName = speakerRel?.name ?? 'Party Envoy';
  const statLabel = sc ? sc.stat.toUpperCase() : 'CHA';
  const skillLabel = sc ? `${sc.skillName} Check` : 'Decisive Action';

  const modifiers: DiceModifierTerm[] = [];
  if (sc) {
    modifiers.push({ label: statLabel, value: result.statMod });
    if (result.synergyMod !== 0) {
      modifiers.push({ label: 'Bond Synergy', value: result.synergyMod });
    }
  }

  const equationParts = [`1d20 (${result.d20Roll})`];
  for (const m of modifiers) {
    equationParts.push(`${m.label} (${formatSigned(m.value)})`);
  }
  const equationText = sc
    ? `${equationParts.join(' + ')} = ${result.total} vs DC ${result.dc}`
    : `Automatic Resolution (${choice.alignmentShift ?? 'Balance'})`;
  const fumble = result.d20Roll === 1 && !!sc;

  return {
    id,
    kind: 'skill',
    actorName,
    actorPortrait: speakerId,
    actionLabel: sc ? `${skillLabel} (DC ${result.dc})` : 'Sanctum Parley Decree',
    d20Roll: result.d20Roll,
    modifiers,
    totalRoll: result.total,
    thresholdLabel: sc ? `DC ${result.dc}` : 'AUTO',
    thresholdValue: result.dc,
    success: result.success,
    critical: result.critical,
    fumble,
    outcomeBadge: result.critical
      ? 'CRITICAL SUCCESS (NAT 20)'
      : fumble
      ? 'CRITICAL FAILURE (NAT 1)'
      : result.success
      ? 'SKILL CHECK PASSED'
      : 'CHECK RESISTED',
    impactSummary: result.success
      ? choice.combatEffect
        ? `Effect: ${choice.combatEffect.replace('_', ' ').toUpperCase()}`
        : 'Parley Sworn'
      : 'Adversary Resisted',
    equationText,
  };
}

export type TacticalAdvantageState = 'party_ascendant' | 'evenly_matched' | 'enemy_dominance';

export interface TacticalAdvantageReport {
  state: TacticalAdvantageState;
  themeTitle: string;
  shortLabel: string;
  partyScore: number;
  enemyScore: number;
  delta: number;
}

export function evaluateTacticalAdvantage(
  units: CombatUnit[],
  worldState?: WorldReactivityState
): TacticalAdvantageReport {
  const partyUnits = units.filter((u) => u.faction === 'party');
  const enemyUnits = units.filter((u) => u.faction === 'enemy');

  const computeFactionScore = (list: CombatUnit[]): number => {
    if (list.length === 0) return 0;
    const living = list.filter((u) => !u.isKO && u.hp > 0);
    if (living.length === 0) return 0;

    const totalHp = living.reduce((sum, u) => sum + Math.max(0, u.hp), 0);
    const totalMaxHp = list.reduce((sum, u) => sum + Math.max(1, u.maxHp), 0);
    const hpPct = (totalHp / totalMaxHp) * 100;
    const survivalScore = (living.length / list.length) * 60;

    let tacticalModifiers = 0;
    for (const u of living) {
      if (u.elevation > 0) tacticalModifiers += 5;
      for (const s of u.statuses) {
        if (s.type === 'blessed' || s.type === 'warded') {
          tacticalModifiers += 5;
        } else if (s.type === 'burning' || s.type === 'rooted' || s.type === 'sundered') {
          tacticalModifiers -= 5;
        }
      }
    }

    return Math.round(hpPct + survivalScore + tacticalModifiers);
  };

  let partyScore = computeFactionScore(partyUnits);
  const enemyScore = computeFactionScore(enemyUnits);

  if (worldState?.flags.includes('sanctum_purified')) {
    partyScore += 4;
  }

  const delta = partyScore - enemyScore;

  if (delta >= 12) {
    return {
      state: 'party_ascendant',
      themeTitle: 'Ascendant Dawn',
      shortLabel: 'Party Advantage',
      partyScore,
      enemyScore,
      delta,
    };
  }

  if (delta <= -12) {
    return {
      state: 'enemy_dominance',
      themeTitle: 'Ashen Eclipse',
      shortLabel: 'Enemy Threat',
      partyScore,
      enemyScore,
      delta,
    };
  }

  return {
    state: 'evenly_matched',
    themeTitle: 'Clash of Oaths',
    shortLabel: 'Balanced Clash',
    partyScore,
    enemyScore,
    delta,
  };
}

export interface UnitInspectStatItem {
  key: 'str' | 'dex' | 'int' | 'cha';
  label: string;
  fullName: string;
  score: number;
  modifier: number;
  formattedModifier: string;
  isPrimary: boolean;
}

export interface UnitInspectStatusDetail {
  type: 'blessed' | 'burning' | 'rooted' | 'sundered' | 'warded';
  label: string;
  turnsLeft: number;
  mechanicalEffect: string;
}

export interface UnitInspectAbilityDetail {
  id: string;
  key: '1' | '2' | '3' | '4';
  name: string;
  apCost: number;
  cooldown: number;
  cooldownRemaining: number;
  range: number;
  aoeRadius?: number;
  aoeShape?: AbilityAoeShape;
  targetType: 'enemy' | 'ally' | 'self' | 'ground';
  element: string;
  pushDistance: number;
  pullDistance?: number;
  uniqueMechanicLabel?: string;
  statusEffect?: 'blessed' | 'burning' | 'rooted' | 'sundered' | 'warded';
  roleClue: string;
  description: string;
  diceFormula: string;
  effectiveOutputLabel: string;
  attackRollFormula: string;
}

export interface UnitInspectProfile {
  unitId: string;
  name: string;
  title: string;
  faction: 'party' | 'enemy';
  roleSummary: string;
  positionLabel: string;
  elevationLabel: string;
  hp: number;
  maxHp: number;
  ap: number;
  maxAp: number;
  moveRange: number;
  initiative: number;
  baseAC: number;
  effectiveAC: number;
  acBreakdown: string;
  primaryStatLabel: string;
  attackRollFormula: string;
  critThreshold: number;
  critRangeLabel: string;
  companionBondLabel?: string;
  companionSynergySummary?: string;
  stats: UnitInspectStatItem[];
  statuses: UnitInspectStatusDetail[];
  abilities: UnitInspectAbilityDetail[];
}

export interface StatusEffectTooltipData {
  type: 'blessed' | 'burning' | 'rooted' | 'sundered' | 'warded';
  label: string;
  shortClue: string;
  categoryLabel: 'Beneficial Buff' | 'Affliction Debuff';
  isBuff: boolean;
  mechanicalEffect: string;
  turnsLeft: number | null;
  durationLabel: string;
}

const INSPECT_STATUS_DESCRIPTIONS: Record<
  'blessed' | 'burning' | 'rooted' | 'sundered' | 'warded',
  { label: string; shortClue: string; isBuff: boolean; effect: string }
> = {
  blessed: {
    label: 'Blessed',
    shortClue: '+2 Attack',
    isBuff: true,
    effect: '+2 to Attack Rolls & Skill Checks through radiant guidance.',
  },
  burning: {
    label: 'Burning',
    shortClue: '-3 HP/turn',
    isBuff: false,
    effect: 'Suffers 3 Fire DMG at the start of each turn from alchemical flames.',
  },
  rooted: {
    label: 'Rooted',
    shortClue: '0 Move',
    isBuff: false,
    effect: 'Movement range reduced to 0 tiles while entangled in place.',
  },
  sundered: {
    label: 'Sundered',
    shortClue: '-2 AC',
    isBuff: false,
    effect: '-2 Armor Class penalty from fractured armor plating.',
  },
  warded: {
    label: 'Warded',
    shortClue: '+2 AC',
    isBuff: true,
    effect: '+2 Armor Class bonus from a shimmering runic barrier.',
  },
};

export function getStatusEffectTooltipData(
  type: 'blessed' | 'burning' | 'rooted' | 'sundered' | 'warded',
  turnsLeft?: number
): StatusEffectTooltipData {
  const entry = INSPECT_STATUS_DESCRIPTIONS[type] ?? INSPECT_STATUS_DESCRIPTIONS.blessed;
  const normalizedTurns = typeof turnsLeft === 'number' ? Math.max(0, Math.round(turnsLeft)) : null;
  const durationLabel =
    normalizedTurns === null
      ? 'Active until dispelled'
      : normalizedTurns === 1
      ? '1 Turn Remaining'
      : `${normalizedTurns} Turns Remaining`;

  return {
    type,
    label: entry.label,
    shortClue: entry.shortClue,
    categoryLabel: entry.isBuff ? 'Beneficial Buff' : 'Affliction Debuff',
    isBuff: entry.isBuff,
    mechanicalEffect: entry.effect,
    turnsLeft: normalizedTurns,
    durationLabel,
  };
}

function formatDamageDiceNotation(minDmg: number, maxDmg: number): string {
  const spread = Math.max(0, maxDmg - minDmg);
  if (spread === 5) {
    const flat = minDmg - 1;
    return `1d6${flat >= 0 ? ` + ${flat}` : ` - ${Math.abs(flat)}`}`;
  }
  if (spread === 7) {
    const flat = minDmg - 1;
    return `1d8${flat >= 0 ? ` + ${flat}` : ` - ${Math.abs(flat)}`}`;
  }
  if (spread === 6) {
    const flat = minDmg - 2;
    return `2d4${flat >= 0 ? ` + ${flat}` : ` - ${Math.abs(flat)}`}`;
  }
  if (spread === 4) {
    const flat = minDmg - 1;
    return `1d4${flat >= 0 ? ` + ${flat}` : ` - ${Math.abs(flat)}`}`;
  }
  const dieFaces = Math.max(4, spread + 1);
  const flat = minDmg - 1;
  return `1d${dieFaces}${flat >= 0 ? ` + ${flat}` : ` - ${Math.abs(flat)}`}`;
}

export function buildUnitInspectProfile(
  unit: CombatUnit,
  relationships: Record<CompanionId, CompanionRelationship>,
  worldState: WorldReactivityState
): UnitInspectProfile {
  const isCaster =
    unit.companionId === 'kaelen' ||
    unit.archetype === 'weaver' ||
    (unit.stats.int > unit.stats.str && unit.stats.int >= unit.stats.dex);
  const isRanger =
    unit.companionId === 'thorne' ||
    unit.archetype === 'stalker' ||
    (!isCaster && unit.stats.dex > unit.stats.str && unit.stats.dex > unit.stats.int);
  const primaryKey: 'str' | 'dex' | 'int' | 'cha' = isCaster ? 'int' : isRanger ? 'dex' : 'str';

  const statDefinitions: { key: 'str' | 'dex' | 'int' | 'cha'; label: string; fullName: string }[] = [
    { key: 'str', label: 'STR', fullName: 'Strength' },
    { key: 'dex', label: 'DEX', fullName: 'Dexterity' },
    { key: 'int', label: 'INT', fullName: 'Intelligence' },
    { key: 'cha', label: 'CHA', fullName: 'Charisma' },
  ];

  const stats: UnitInspectStatItem[] = statDefinitions.map((def) => {
    const score = unit.stats[def.key];
    const mod = getStatModifier(score);
    return {
      key: def.key,
      label: def.label,
      fullName: def.fullName,
      score,
      modifier: mod,
      formattedModifier: mod >= 0 ? `+${mod}` : `${mod}`,
      isPrimary: def.key === primaryKey,
    };
  });

  const primaryStatItem = stats.find((s) => s.key === primaryKey)!;
  const baseAttackMod = primaryStatItem.modifier + 2; // +2 Proficiency bonus

  const companionRel = unit.companionId ? relationships[unit.companionId] : undefined;
  const synergy = companionRel
    ? getCompanionSynergyBonus(companionRel.approval)
    : { attackBonus: 0, damageBonus: 0, critThreshold: 20 };
  const bondTier = companionRel ? getRelationshipTier(companionRel.approval) : undefined;

  const blessedBonus = unit.statuses.some((s) => s.type === 'blessed') ? 2 : 0;
  const highGroundHit = unit.elevation > 0 ? 2 : 0;
  const totalHitBonus = baseAttackMod + synergy.attackBonus + blessedBonus + highGroundHit;

  const hitParts: string[] = [`+${baseAttackMod} ${primaryStatItem.label}/Prof`];
  if (synergy.attackBonus > 0 && bondTier) {
    hitParts.push(`+${synergy.attackBonus} ${bondTier}`);
  } else if (synergy.attackBonus < 0 && bondTier) {
    hitParts.push(`${synergy.attackBonus} ${bondTier}`);
  }
  if (blessedBonus > 0) hitParts.push('+2 Blessed');
  if (highGroundHit > 0) hitParts.push('+2 High Ground');

  const attackRollFormula = `1d20 ${totalHitBonus >= 0 ? `+ ${totalHitBonus}` : `- ${Math.abs(totalHitBonus)}`} (${hitParts.join(' · ')})`;

  const sunderedPenalty = unit.statuses.some((s) => s.type === 'sundered') ? -2 : 0;
  const wardedBonus = unit.statuses.some((s) => s.type === 'warded') ? 2 : 0;
  const effectiveAC = unit.armorClass + sunderedPenalty + wardedBonus;

  const acParts: string[] = [`Base ${unit.armorClass}`];
  if (wardedBonus > 0) acParts.push('+2 Warded');
  if (sunderedPenalty < 0) acParts.push('-2 Sundered');
  const acBreakdown =
    acParts.length > 1 ? `${acParts.join(' ')} = ${effectiveAC} AC` : `Base ${unit.armorClass} AC`;

  const bloodWeaveBonus =
    worldState.flags.includes('blood_weave_unleashed') && unit.faction === 'party' ? 3 : 0;
  const mercyHealBonus =
    worldState.oathAlignment === 'Mercy' && unit.faction === 'party' ? 3 : 0;
  const highGroundDmg = unit.elevation > 0 ? 2 : 0;

  const statuses: UnitInspectStatusDetail[] = unit.statuses.map((s) => ({
    type: s.type,
    label: INSPECT_STATUS_DESCRIPTIONS[s.type]?.label ?? s.type,
    turnsLeft: s.turnsLeft,
    mechanicalEffect: INSPECT_STATUS_DESCRIPTIONS[s.type]?.effect ?? '',
  }));

  const abilities: UnitInspectAbilityDetail[] = unit.abilities.map((ab) => {
    const cdRem = unit.cooldowns[ab.id] ?? 0;
    const elemLabel = ab.element
      ? ab.element.charAt(0).toUpperCase() + ab.element.slice(1)
      : 'Physical';

    if (ab.targetType === 'ally' || ab.targetType === 'self' || (ab.healAmount ?? 0) > 0) {
      const baseHeal = ab.healAmount ?? 8;
      const totalHeal = baseHeal + mercyHealBonus;
      const healMods: string[] = [`2d4 + ${Math.max(1, baseHeal - 5)} Base`];
      if (mercyHealBonus > 0) healMods.push(`+${mercyHealBonus} Mercy Oath`);
      return {
        id: ab.id,
        key: ab.key,
        name: ab.name,
        apCost: ab.apCost,
        cooldown: ab.cooldown,
        cooldownRemaining: cdRem,
        range: ab.range,
        aoeRadius: ab.aoeRadius,
        aoeShape: ab.aoeShape,
        targetType: ab.targetType,
        element: elemLabel,
        pushDistance: ab.pushDistance ?? 0,
        pullDistance: ab.pullDistance,
        uniqueMechanicLabel: ab.uniqueMechanicLabel,
        statusEffect: ab.statusEffect,
        roleClue: ab.roleClue,
        description: ab.description,
        diceFormula: healMods.join(' '),
        effectiveOutputLabel: `+${totalHeal} HP ${elemLabel} Heal`,
        attackRollFormula: 'Auto-Hit (Allied Conduit)',
      };
    }

    const [minDmg, maxDmg] = ab.damageRange;
    const baseDice = formatDamageDiceNotation(minDmg, maxDmg);
    const dmgModParts: string[] = [baseDice];
    if (synergy.damageBonus > 0 && bondTier) {
      dmgModParts.push(`+${synergy.damageBonus} ${bondTier}`);
    }
    if (bloodWeaveBonus > 0) {
      dmgModParts.push(`+${bloodWeaveBonus} Blood-Weave`);
    }
    if (highGroundDmg > 0) {
      dmgModParts.push(`+${highGroundDmg} High Ground`);
    }

    const totalExtraDmg = synergy.damageBonus + bloodWeaveBonus + highGroundDmg;
    const effMin = Math.max(1, minDmg + totalExtraDmg);
    const effMax = Math.max(effMin, maxDmg + totalExtraDmg);

    return {
      id: ab.id,
      key: ab.key,
      name: ab.name,
      apCost: ab.apCost,
      cooldown: ab.cooldown,
      cooldownRemaining: cdRem,
      range: ab.range,
      aoeRadius: ab.aoeRadius,
      aoeShape: ab.aoeShape,
      targetType: ab.targetType,
      element: elemLabel,
      pushDistance: ab.pushDistance ?? 0,
      pullDistance: ab.pullDistance,
      uniqueMechanicLabel: ab.uniqueMechanicLabel,
      statusEffect: ab.statusEffect,
      roleClue: ab.roleClue,
      description: ab.description,
      diceFormula: dmgModParts.join(' '),
      effectiveOutputLabel: `${effMin}–${effMax} ${elemLabel} DMG`,
      attackRollFormula,
    };
  });

  const roleSummary =
    unit.faction === 'party'
      ? companionRel?.raceClass ?? 'Expedition Vanguard'
      : unit.archetype === 'inquisitor'
      ? 'Enemy Frontline Juggernaut'
      : unit.archetype === 'weaver'
      ? 'Enemy High-Ground Caster'
      : 'Enemy Flanking Stalker';

  return {
    unitId: unit.id,
    name: unit.name,
    title: unit.title,
    faction: unit.faction,
    roleSummary,
    positionLabel: `Tile (${unit.gridX}, ${unit.gridZ})`,
    elevationLabel: unit.elevation > 0 ? 'High Ground (+2 Hit / +2 DMG)' : 'Standard Ground (Elev 0)',
    hp: Math.round(unit.hp),
    maxHp: unit.maxHp,
    ap: unit.ap,
    maxAp: unit.maxAp,
    moveRange: unit.statuses.some((s) => s.type === 'rooted') ? 0 : unit.moveRange,
    initiative: unit.initiative,
    baseAC: unit.armorClass,
    effectiveAC,
    acBreakdown,
    primaryStatLabel: `${primaryStatItem.label} (${primaryStatItem.score} / ${primaryStatItem.formattedModifier})`,
    attackRollFormula,
    critThreshold: synergy.critThreshold,
    critRangeLabel: synergy.critThreshold < 20 ? `${synergy.critThreshold}–20` : '20',
    companionBondLabel:
      companionRel && bondTier
        ? `${bondTier} (${companionRel.approval}/100)`
        : undefined,
    companionSynergySummary: companionRel
      ? `${companionRel.synergyName}: +${synergy.attackBonus} Hit · +${synergy.damageBonus} DMG · Crit ${
          synergy.critThreshold < 20 ? `${synergy.critThreshold}–20` : '20'
        }`
      : undefined,
    stats,
    statuses,
    abilities,
  };
}

export interface InitiativeRibbonEntry {
  unit: CombatUnit;
  collapseState: 'active' | 'collapsing';
}

export function computeInitiativeRibbonEntries(
  units: CombatUnit[],
  collapsingUnitIds: ReadonlySet<string>
): InitiativeRibbonEntry[] {
  const entries: InitiativeRibbonEntry[] = [];
  for (const unit of units) {
    if (collapsingUnitIds.has(unit.id)) {
      entries.push({ unit, collapseState: 'collapsing' });
    } else if (!unit.isKO && unit.hp > 0) {
      entries.push({ unit, collapseState: 'active' });
    }
  }
  return entries;
}

export interface EnvironmentalReactionResult {
  updatedGrid: GridTile[][];
  updatedObjects: TacticalEnvObject[];
  updatedUnits: CombatUnit[];
  triggeredEvents: string[];
  ignitedTiles: { x: number; z: number }[];
  bonusDamageDealt: number;
}

function computePushVector(fromX: number, fromZ: number, toX: number, toZ: number): [number, number] {
  const dx = toX - fromX;
  const dz = toZ - fromZ;
  if (dx === 0 && dz === 0) return [0, -1];
  if (Math.abs(dx) >= Math.abs(dz)) {
    return [Math.sign(dx), 0];
  }
  return [0, Math.sign(dz)];
}

export function resolveEnvironmentalInteraction(
  attacker: CombatUnit,
  ability: Ability,
  targetX: number,
  targetZ: number,
  grid: GridTile[][],
  envObjects: TacticalEnvObject[],
  units: CombatUnit[],
  hitTargetUnitId?: string
): EnvironmentalReactionResult {
  const updatedGrid: GridTile[][] = grid.map((row) => row.map((tile) => ({ ...tile })));
  const updatedObjects: TacticalEnvObject[] = envObjects.map((o) => ({ ...o }));
  const updatedUnits: CombatUnit[] = units.map((u) => ({
    ...u,
    statuses: u.statuses.map((s) => ({ ...s })),
  }));
  const triggeredEvents: string[] = [];
  const ignitedTiles: { x: number; z: number }[] = [];
  let bonusDamageDealt = 0;

  const isFire = ability.element === 'fire' || ability.statusEffect === 'burning';
  const isNature = ability.element === 'nature';
  const isRadiant = ability.element === 'radiant';

  const applyDamageAndStatus = (
    unit: CombatUnit,
    dmg: number,
    status?: 'blessed' | 'burning' | 'rooted' | 'sundered' | 'warded'
  ) => {
    if (unit.isKO) return;
    if (dmg > 0) {
      const absorbed = Math.min(unit.tempHp, dmg);
      const hpDmg = Math.max(0, dmg - absorbed);
      unit.tempHp = unit.tempHp - absorbed;
      const minHpFloor = (unit.lastStandTurns ?? 0) > 0 ? 1 : 0;
      unit.hp = Math.max(minHpFloor, unit.hp - hpDmg);
      unit.isKO = unit.hp <= 0;
      bonusDamageDealt += dmg;
    }
    if (status && !unit.isKO) {
      unit.statuses = [
        ...unit.statuses.filter((s) => s.type !== status),
        { type: status, turnsLeft: 2 },
      ];
    }
  };

  const isTileOpenForUnit = (tx: number, tz: number, ignoreUnitId?: string): boolean => {
    if (tx < 0 || tx >= GRID_SIZE || tz < 0 || tz >= GRID_SIZE) return false;
    const tile = updatedGrid[tx]?.[tz];
    if (!tile || !tile.walkable) return false;
    if (
      updatedUnits.some(
        (u) => !u.isKO && u.id !== ignoreUnitId && u.gridX === tx && u.gridZ === tz
      )
    ) {
      return false;
    }
    if (updatedObjects.some((o) => !o.destroyed && o.gridX === tx && o.gridZ === tz)) {
      return false;
    }
    return true;
  };

  // 0. Pre-Knockback Vector & AoE Geometry Mechanics (Piercing Rays, Sweeping Arcs, 3x3 Blasts, Shockwaves, Warrior Core Skills)
  if (ability.id === 'whirlwind_assault') {
    const cleavedNames: string[] = [];
    for (const u of updatedUnits) {
      if (
        !u.isKO &&
        u.faction !== attacker.faction &&
        u.id !== hitTargetUnitId &&
        chebyshevDistance(u.gridX, u.gridZ, attacker.gridX, attacker.gridZ) <= 1
      ) {
        applyDamageAndStatus(u, 10);
        cleavedNames.push(u.name);
      }
    }
    if (cleavedNames.length > 0) {
      triggeredEvents.push(
        `WHIRLWIND ASSAULT: 360-degree sweep cleaves ${cleavedNames.join(', ')} (10 Physical DMG)!`
      );
    } else if (hitTargetUnitId) {
      triggeredEvents.push(
        `WHIRLWIND ASSAULT: ${attacker.name} completes a full 360-degree blade sweep while holding (${attacker.gridX}, ${attacker.gridZ})!`
      );
    }
  }

  if (ability.id === 'earthsplitter') {
    const [rayX, rayZ] = computePushVector(attacker.gridX, attacker.gridZ, targetX, targetZ);
    const fracturedNames: string[] = [];
    let blockedByObstacle = false;
    for (let distStep = 1; distStep <= 3; distStep++) {
      const rx = attacker.gridX + rayX * distStep;
      const rz = attacker.gridZ + rayZ * distStep;
      if (rx < 0 || rx >= GRID_SIZE || rz < 0 || rz >= GRID_SIZE) break;
      const tileAtStep = updatedGrid[rx]?.[rz];
      if (!tileAtStep || !tileAtStep.walkable) {
        blockedByObstacle = true;
        break;
      }
      const foe = updatedUnits.find(
        (u) =>
          !u.isKO &&
          u.faction !== attacker.faction &&
          u.id !== hitTargetUnitId &&
          u.gridX === rx &&
          u.gridZ === rz
      );
      if (foe) {
        const canSunder = !foe.immunities?.includes('sundered');
        applyDamageAndStatus(foe, 14, canSunder ? 'sundered' : undefined);
        fracturedNames.push(foe.name);
      }
    }
    if (fracturedNames.length > 0) {
      triggeredEvents.push(
        `EARTHSPLITTER FRACTURE: Travelling ground fissure strikes ${fracturedNames.join(', ')} (14 DMG & Sundered)${
          blockedByObstacle ? ' before halting at an obstacle' : ''
        }!`
      );
    } else if (blockedByObstacle) {
      triggeredEvents.push(
        `EARTHSPLITTER: Ground fissure halts against impassable stone!`
      );
    }
  }

  if (
    (ability.id === 'astral_bolt' || ability.id === 'astral_soul_blade') &&
    hitTargetUnitId
  ) {
    const [rayX, rayZ] = computePushVector(attacker.gridX, attacker.gridZ, targetX, targetZ);
    const piercedNames: string[] = [];
    for (let distStep = 1; distStep <= 2; distStep++) {
      const rx = targetX + rayX * distStep;
      const rz = targetZ + rayZ * distStep;
      const pierced = updatedUnits.find(
        (u) =>
          !u.isKO &&
          u.faction !== attacker.faction &&
          u.id !== hitTargetUnitId &&
          u.gridX === rx &&
          u.gridZ === rz
      );
      if (pierced) {
        applyDamageAndStatus(
          pierced,
          5,
          ability.id === 'astral_soul_blade' ? 'burning' : undefined
        );
        piercedNames.push(pierced.name);
      }
    }
    if (piercedNames.length > 0) {
      triggeredEvents.push(
        `PIERCING RAY: ${ability.name} lances through to strike ${piercedNames.join(', ')} (5 DMG)!`
      );
    }
  }

  if (ability.id === 'sunblade_cleave' && hitTargetUnitId) {
    const cleavedNames: string[] = [];
    for (const u of updatedUnits) {
      if (
        !u.isKO &&
        u.faction !== attacker.faction &&
        u.id !== hitTargetUnitId &&
        chebyshevDistance(u.gridX, u.gridZ, attacker.gridX, attacker.gridZ) <= 1 &&
        chebyshevDistance(u.gridX, u.gridZ, targetX, targetZ) <= 1
      ) {
        applyDamageAndStatus(u, 5, 'burning');
        cleavedNames.push(u.name);
      }
    }
    if (cleavedNames.length > 0) {
      triggeredEvents.push(
        `SWEEPING ARC: Sunblade Cleave scorches ${cleavedNames.join(', ')} (5 Fire DMG & Burning)!`
      );
    }
  }

  if (ability.id === 'crimson_tempest' || ability.id === 'searing_blood_nova') {
    const blastNames: string[] = [];
    for (const u of updatedUnits) {
      if (
        !u.isKO &&
        u.faction !== attacker.faction &&
        u.id !== hitTargetUnitId &&
        chebyshevDistance(u.gridX, u.gridZ, targetX, targetZ) <= 1
      ) {
        applyDamageAndStatus(u, 6, 'burning');
        blastNames.push(u.name);
      }
    }
    if (blastNames.length > 0) {
      triggeredEvents.push(
        `CRIMSON 3×3 BLAST: ${blastNames.join(', ')} scorched for 6 Fire DMG & Burning!`
      );
    }
  }

  if (ability.id === 'ironwood_tempest') {
    const shockedNames: string[] = [];
    for (const u of updatedUnits) {
      if (
        !u.isKO &&
        u.faction !== attacker.faction &&
        u.id !== hitTargetUnitId &&
        manhattanDistance(u.gridX, u.gridZ, targetX, targetZ) === 1
      ) {
        applyDamageAndStatus(u, 5);
        shockedNames.push(u.name);
      }
    }
    const caster = updatedUnits.find((u) => u.id === attacker.id && !u.isKO);
    if (caster) {
      caster.tempHp = Math.max(caster.tempHp, ability.grantTempHp ?? 5);
      applyDamageAndStatus(caster, 0, 'warded');
    }
    triggeredEvents.push(
      `IRONBOUGH STANCE: ${attacker.name} gains Warded (+2 AC) & +5 Temp HP${
        shockedNames.length > 0
          ? ` as seismic shockwaves strike ${shockedNames.join(', ')} (5 DMG)`
          : ''
      }!`
    );
  }

  if (ability.id === 'infernal_orb') {
    const scorchedNames: string[] = [];
    for (const u of updatedUnits) {
      if (!u.isKO && u.faction !== attacker.faction) {
        if (chebyshevDistance(u.gridX, u.gridZ, targetX, targetZ) <= 1) {
          if (u.id !== hitTargetUnitId) {
            applyDamageAndStatus(u, 14, 'burning');
            scorchedNames.push(u.name);
          }
        }
      }
    }
    for (let ox = Math.max(0, targetX - 1); ox <= Math.min(GRID_SIZE - 1, targetX + 1); ox++) {
      for (let oz = Math.max(0, targetZ - 1); oz <= Math.min(GRID_SIZE - 1, targetZ + 1); oz++) {
        if (updatedGrid[ox]?.[oz]?.surface === 'oil_pool') {
          updatedGrid[ox][oz].surface = 'fire_pool';
          ignitedTiles.push({ x: ox, z: oz });
        }
      }
    }
    if (scorchedNames.length > 0) {
      triggeredEvents.push(
        `INFERNAL ORB AOE: Radius 1 firestorm engulfs ${scorchedNames.join(', ')} (14 Fire DMG & Burning)!`
      );
    }
  }

  if (ability.id === 'glacial_lance') {
    const [rayX, rayZ] = computePushVector(attacker.gridX, attacker.gridZ, targetX, targetZ);
    const chilledNames: string[] = [];
    let blockedByWall = false;
    for (let step = 1; step <= 3; step++) {
      const rx = attacker.gridX + rayX * step;
      const rz = attacker.gridZ + rayZ * step;
      if (rx < 0 || rx >= GRID_SIZE || rz < 0 || rz >= GRID_SIZE) break;
      const tile = updatedGrid[rx]?.[rz];
      if (!tile || !tile.walkable) {
        blockedByWall = true;
        break;
      }
      const foe = updatedUnits.find(
        (u) =>
          !u.isKO &&
          u.faction !== attacker.faction &&
          u.id !== hitTargetUnitId &&
          u.gridX === rx &&
          u.gridZ === rz
      );
      if (foe) {
        const isAlreadyChilled = foe.statuses.some((s) => s.type === 'chilled');
        const dmg = isAlreadyChilled ? 16 : 12;
        applyDamageAndStatus(foe, dmg, 'chilled');
        chilledNames.push(`${foe.name} (${dmg} Frost DMG${isAlreadyChilled ? ' + Shatter' : ''})`);
      }
    }
    if (chilledNames.length > 0) {
      triggeredEvents.push(
        `GLACIAL LANCE: Piercing frost ray strikes ${chilledNames.join(', ')}${
          blockedByWall ? ' before shattering against stone' : ''
        }!`
      );
    }
  }

  if (ability.id === 'chain_lightning' && hitTargetUnitId) {
    const primaryTarget = updatedUnits.find((u) => u.id === hitTargetUnitId && !u.isKO);
    if (primaryTarget) {
      const hitIds = new Set<string>([primaryTarget.id]);
      const chainEvents: string[] = [];
      let currentChainOrigin = primaryTarget;
      const jumpDamages = [8, 5];

      for (let jump = 0; jump < 2; jump++) {
        let nearestFoe: CombatUnit | null = null;
        let nearestDist = 999;
        for (const u of updatedUnits) {
          if (!u.isKO && u.faction !== attacker.faction && !hitIds.has(u.id)) {
            const d = chebyshevDistance(
              currentChainOrigin.gridX,
              currentChainOrigin.gridZ,
              u.gridX,
              u.gridZ
            );
            if (d <= 3 && d < nearestDist) {
              nearestDist = d;
              nearestFoe = u;
            }
          }
        }
        if (nearestFoe) {
          hitIds.add(nearestFoe.id);
          const dmg = jumpDamages[jump];
          applyDamageAndStatus(nearestFoe, dmg);
          chainEvents.push(`${nearestFoe.name} (${dmg} Lightning DMG)`);
          currentChainOrigin = nearestFoe;
        } else {
          break;
        }
      }
      if (chainEvents.length > 0) {
        triggeredEvents.push(
          `CHAIN LIGHTNING ARCS: Arcane lightning leaps to ${chainEvents.join(', ')}!`
        );
      }
    }
  }

  if (ability.id === 'blink_step') {
    const caster = updatedUnits.find((u) => u.id === attacker.id && !u.isKO);
    if (caster && isTileOpenForUnit(targetX, targetZ, caster.id)) {
      caster.gridX = targetX;
      caster.gridZ = targetZ;
      caster.elevation = updatedGrid[targetX][targetZ].elevation;
      caster.statuses = caster.statuses.filter((s) => s.type !== 'rooted');
      triggeredEvents.push(
        `BLINK STEP: ${caster.name} instantly folds space to teleport to (${targetX}, ${targetZ})!`
      );
    }
  }

  if (ability.id === 'gravitational_collapse') {
    const pulledNames: string[] = [];
    for (const u of updatedUnits) {
      if (!u.isKO && u.faction !== attacker.faction) {
        const distToCenter = chebyshevDistance(u.gridX, u.gridZ, targetX, targetZ);
        if (distToCenter >= 1 && distToCenter <= 2) {
          if (!u.immunities?.includes('displacement')) {
            const [pullX, pullZ] = computePushVector(u.gridX, u.gridZ, targetX, targetZ);
            const nx = u.gridX + pullX;
            const nz = u.gridZ + pullZ;
            if (isTileOpenForUnit(nx, nz, u.id)) {
              u.gridX = nx;
              u.gridZ = nz;
              u.elevation = updatedGrid[nx][nz].elevation;
            }
          }
          applyDamageAndStatus(u, 8);
          pulledNames.push(u.name);
        }
      }
    }
    if (pulledNames.length > 0) {
      triggeredEvents.push(
        `GRAVITATIONAL COLLAPSE: Singularity at (${targetX}, ${targetZ}) pulls ${pulledNames.join(', ')} and deals 8 Arcane DMG!`
      );
    }
  }

  if (ability.id === 'arcane_disjunction' && hitTargetUnitId) {
    const target = updatedUnits.find((u) => u.id === hitTargetUnitId && !u.isKO);
    if (target) {
      const hadWarded = target.statuses.some((s) => s.type === 'warded');
      const hadBlessed = target.statuses.some((s) => s.type === 'blessed');
      const hadTempHp = target.tempHp > 0;
      if (hadWarded || hadBlessed || hadTempHp) {
        target.statuses = target.statuses.filter(
          (s) => s.type !== 'warded' && s.type !== 'blessed'
        );
        target.tempHp = 0;
        applyDamageAndStatus(target, 6);
        triggeredEvents.push(
          `ARCANE DISJUNCTION: Purged magical wards from ${target.name} (+6 bonus Arcane DMG)!`
        );
      }
    }
  }

  // 1. Check Pushable / Destructible Object at (targetX, targetZ) or caught in AoE
  const hitObject = updatedObjects.find(
    (o) =>
      !o.destroyed &&
      ((o.gridX === targetX && o.gridZ === targetZ) ||
        (isFire && (ability.aoeRadius ?? 0) >= 1 && chebyshevDistance(o.gridX, o.gridZ, targetX, targetZ) <= 1))
  );

  if (hitObject) {
    if (isFire && (hitObject.kind === 'oil_barrel' || hitObject.kind === 'runic_brazier')) {
      // Explosive detonation!
      hitObject.destroyed = true;
      hitObject.hp = 0;
      const ox = hitObject.gridX;
      const oz = hitObject.gridZ;

      for (let nx = Math.max(0, ox - 1); nx <= Math.min(GRID_SIZE - 1, ox + 1); nx++) {
        for (let nz = Math.max(0, oz - 1); nz <= Math.min(GRID_SIZE - 1, oz + 1); nz++) {
          const t = updatedGrid[nx]?.[nz];
          if (t && t.walkable && manhattanDistance(ox, oz, nx, nz) <= 1) {
            t.surface = 'fire_pool';
            ignitedTiles.push({ x: nx, z: nz });
          }
        }
      }

      for (const u of updatedUnits) {
        if (!u.isKO && chebyshevDistance(u.gridX, u.gridZ, ox, oz) <= 1) {
          applyDamageAndStatus(u, 8, 'burning');
        }
      }
      triggeredEvents.push(
        `${hitObject.name} detonates in a fiery blast (8 Fire DMG & Burning)!`
      );
    } else if (hitObject.pushable) {
      // Kinetic Shove along attack vector
      const [stepX, stepZ] = computePushVector(
        attacker.gridX,
        attacker.gridZ,
        hitObject.gridX,
        hitObject.gridZ
      );
      const pushSteps = Math.max(1, ability.pushDistance ?? 1);
      let curX = hitObject.gridX;
      let curZ = hitObject.gridZ;
      let collidedUnit: CombatUnit | undefined;

      for (let s = 0; s < pushSteps; s++) {
        const nx = curX + stepX;
        const nz = curZ + stepZ;
        if (nx < 0 || nx >= GRID_SIZE || nz < 0 || nz >= GRID_SIZE) break;
        const nextTile = updatedGrid[nx]?.[nz];
        if (!nextTile || !nextTile.walkable) break;

        const unitInWay = updatedUnits.find((u) => !u.isKO && u.gridX === nx && u.gridZ === nz);
        if (unitInWay) {
          collidedUnit = unitInWay;
          break;
        }
        const objInWay = updatedObjects.find(
          (o) => !o.destroyed && o.id !== hitObject.id && o.gridX === nx && o.gridZ === nz
        );
        if (objInWay) break;

        curX = nx;
        curZ = nz;
      }

      hitObject.gridX = curX;
      hitObject.gridZ = curZ;
      hitObject.elevation = updatedGrid[curX]?.[curZ]?.elevation ?? 0;

      if (collidedUnit) {
        applyDamageAndStatus(collidedUnit, 8, 'sundered');
        if (hitObject.kind === 'runic_brazier') {
          hitObject.destroyed = true;
          const cTile = updatedGrid[collidedUnit.gridX]?.[collidedUnit.gridZ];
          if (cTile) {
            cTile.surface = 'fire_pool';
            ignitedTiles.push({ x: collidedUnit.gridX, z: collidedUnit.gridZ });
          }
          applyDamageAndStatus(collidedUnit, 0, 'burning');
          triggeredEvents.push(
            `${hitObject.name} smashes into ${collidedUnit.name} and erupts in flames (8 DMG & Sundered)!`
          );
        } else if (hitObject.kind === 'oil_barrel') {
          hitObject.destroyed = true;
          const cTile = updatedGrid[collidedUnit.gridX]?.[collidedUnit.gridZ];
          if (cTile) cTile.surface = 'oil_pool';
          triggeredEvents.push(
            `${hitObject.name} shatters against ${collidedUnit.name} (8 DMG & Oil Slick)!`
          );
        } else {
          triggeredEvents.push(
            `${hitObject.name} slams into ${collidedUnit.name} for 8 Crushing DMG!`
          );
        }
      } else {
        const destTile = updatedGrid[curX]?.[curZ];
        if (hitObject.kind === 'runestone_block' && destTile?.terrain === 'hazard_rift') {
          destTile.terrain = 'stone';
          destTile.surface = 'none';
          triggeredEvents.push(
            `${hitObject.name} slides onto (${curX}, ${curZ}) and seals the Astral Rift hazard!`
          );
        } else {
          triggeredEvents.push(
            `${attacker.name} shoves ${hitObject.name} to (${curX}, ${curZ})!`
          );
        }
      }
    }
  }

  // 2. Check Unit Knockback when hitTargetUnitId is provided and ability has pushDistance
  if (hitTargetUnitId && (ability.pushDistance ?? 0) > 0) {
    const pushedUnit = updatedUnits.find((u) => u.id === hitTargetUnitId && !u.isKO);
    // If Driving Assault, move caster adjacent to the target BEFORE pushing the target!
    if (ability.id === 'driving_assault') {
      const caster = updatedUnits.find((u) => u.id === attacker.id && !u.isKO);
      if (
        caster &&
        !caster.statuses.some((s) => s.type === 'rooted') &&
        manhattanDistance(caster.gridX, caster.gridZ, targetX, targetZ) >= 2
      ) {
        const adjOffsets = [
          { x: targetX - 1, z: targetZ },
          { x: targetX + 1, z: targetZ },
          { x: targetX, z: targetZ - 1 },
          { x: targetX, z: targetZ + 1 },
          { x: targetX - 1, z: targetZ - 1 },
          { x: targetX + 1, z: targetZ - 1 },
          { x: targetX - 1, z: targetZ + 1 },
          { x: targetX + 1, z: targetZ + 1 },
        ]
          .filter((pt) => isTileOpenForUnit(pt.x, pt.z, caster.id))
          .sort(
            (a, b) =>
              manhattanDistance(caster.gridX, caster.gridZ, a.x, a.z) -
              manhattanDistance(caster.gridX, caster.gridZ, b.x, b.z)
          );
        if (adjOffsets.length > 0) {
          const dest = adjOffsets[0];
          caster.gridX = dest.x;
          caster.gridZ = dest.z;
          caster.elevation = updatedGrid[dest.x][dest.z].elevation;
          triggeredEvents.push(
            `DRIVING ASSAULT: ${caster.name} charges forward to (${dest.x}, ${dest.z})!`
          );
        }
      }
    }

    if (pushedUnit && pushedUnit.id !== attacker.id) {
      if (
        pushedUnit.immunities?.includes('displacement') ||
        (pushedUnit.guardedStanceTurns ?? 0) > 0
      ) {
        triggeredEvents.push(
          `${pushedUnit.name} braces and resists forced displacement!`
        );
      } else {
        const [stepX, stepZ] = computePushVector(
          attacker.gridX,
          attacker.gridZ,
          pushedUnit.gridX,
          pushedUnit.gridZ
        );
        const pushSteps = Math.max(1, ability.pushDistance ?? 1);
        let curX = pushedUnit.gridX;
        let curZ = pushedUnit.gridZ;
        let hitObstacle = false;

        for (let step = 0; step < pushSteps; step++) {
          const nx = curX + stepX;
          const nz = curZ + stepZ;
          const nextTile = updatedGrid[nx]?.[nz];
          const blockedByUnit = updatedUnits.some(
            (u) => !u.isKO && u.id !== pushedUnit.id && u.gridX === nx && u.gridZ === nz
          );
          const blockedByObj = updatedObjects.some(
            (o) => !o.destroyed && o.gridX === nx && o.gridZ === nz
          );

          if (
            nx < 0 ||
            nx >= GRID_SIZE ||
            nz < 0 ||
            nz >= GRID_SIZE ||
            !nextTile ||
            !nextTile.walkable ||
            blockedByUnit ||
            blockedByObj
          ) {
            hitObstacle = true;
            break;
          }
          curX = nx;
          curZ = nz;
        }

        const movedTiles =
          curX !== pushedUnit.gridX || curZ !== pushedUnit.gridZ;
        if (movedTiles) {
          const destTile = updatedGrid[curX][curZ];
          pushedUnit.gridX = curX;
          pushedUnit.gridZ = curZ;
          pushedUnit.elevation = destTile.elevation;
          if (destTile.surface === 'fire_pool' || destTile.terrain === 'hazard_rift') {
            applyDamageAndStatus(pushedUnit, 4, 'burning');
            triggeredEvents.push(
              `${pushedUnit.name} is knocked into ${
                destTile.surface === 'fire_pool' ? 'roaring flames' : 'the Astral Rift'
              } (+4 Burn DMG)!`
            );
          } else if (destTile.surface === 'bramble_snare') {
            applyDamageAndStatus(pushedUnit, 0, 'rooted');
            triggeredEvents.push(`${pushedUnit.name} is knocked into Briar-Thorns (Rooted)!`);
          } else {
            triggeredEvents.push(`${pushedUnit.name} is knocked back to (${curX}, ${curZ})!`);
          }
        }
        if (hitObstacle) {
          applyDamageAndStatus(pushedUnit, 4, !pushedUnit.immunities?.includes('sundered') ? 'sundered' : undefined);
          triggeredEvents.push(`${pushedUnit.name} is slammed into an obstacle (+4 Impact DMG)!`);
        }
      }
    }
  }

  // 2B. Unique Displacement, Pull, Leap, Vacuum & Vault Mechanics
  if (hitTargetUnitId && (ability.pullDistance ?? 0) > 0) {
    const pulledUnit = updatedUnits.find((u) => u.id === hitTargetUnitId && !u.isKO);
    if (pulledUnit && pulledUnit.id !== attacker.id) {
      const [pullX, pullZ] = computePushVector(
        pulledUnit.gridX,
        pulledUnit.gridZ,
        attacker.gridX,
        attacker.gridZ
      );
      const nx = pulledUnit.gridX + pullX;
      const nz = pulledUnit.gridZ + pullZ;
      if (isTileOpenForUnit(nx, nz, pulledUnit.id)) {
        const prevElev = pulledUnit.elevation;
        const nextTile = updatedGrid[nx][nz];
        pulledUnit.gridX = nx;
        pulledUnit.gridZ = nz;
        pulledUnit.elevation = nextTile.elevation;
        applyDamageAndStatus(pulledUnit, 0, 'rooted');

        if (
          prevElev > nextTile.elevation ||
          nextTile.terrain === 'hazard_rift' ||
          nextTile.surface === 'fire_pool' ||
          nextTile.surface === 'bramble_snare'
        ) {
          applyDamageAndStatus(
            pulledUnit,
            4,
            nextTile.surface === 'fire_pool' ? 'burning' : 'rooted'
          );
          triggeredEvents.push(
            `TETHER PULL: ${pulledUnit.name} is yanked to (${nx}, ${nz}) (+4 Gravitational Shear DMG & Rooted)!`
          );
        } else {
          triggeredEvents.push(
            `TETHER PULL: ${pulledUnit.name} is pulled toward ${attacker.name} to (${nx}, ${nz}) and Rooted!`
          );
        }
      }
    }
  }

  if (ability.id === 'chrono_rift_collapse') {
    const candidates = updatedUnits
      .filter(
        (u) =>
          !u.isKO &&
          u.faction !== attacker.faction &&
          u.id !== hitTargetUnitId &&
          chebyshevDistance(u.gridX, u.gridZ, targetX, targetZ) > 0 &&
          chebyshevDistance(u.gridX, u.gridZ, targetX, targetZ) <= 2
      )
      .sort(
        (a, b) =>
          manhattanDistance(a.gridX, a.gridZ, targetX, targetZ) -
          manhattanDistance(b.gridX, b.gridZ, targetX, targetZ)
      );

    const pulledNames: string[] = [];
    for (const u of candidates) {
      const dx = Math.sign(targetX - u.gridX);
      const dz = Math.sign(targetZ - u.gridZ);
      const curDist = manhattanDistance(u.gridX, u.gridZ, targetX, targetZ);
      const stepOptions = [
        { x: u.gridX + dx, z: u.gridZ + dz },
        { x: u.gridX + dx, z: u.gridZ },
        { x: u.gridX, z: u.gridZ + dz },
      ];
      const chosenStep = stepOptions.find(
        (opt) =>
          (opt.x !== targetX || opt.z !== targetZ || !hitTargetUnitId) &&
          manhattanDistance(opt.x, opt.z, targetX, targetZ) < curDist &&
          isTileOpenForUnit(opt.x, opt.z, u.id)
      );
      if (chosenStep) {
        u.gridX = chosenStep.x;
        u.gridZ = chosenStep.z;
        u.elevation = updatedGrid[chosenStep.x][chosenStep.z].elevation;
        applyDamageAndStatus(u, 4);
        pulledNames.push(u.name);
      } else {
        applyDamageAndStatus(u, 4);
        pulledNames.push(u.name);
      }
    }
    if (pulledNames.length > 0) {
      triggeredEvents.push(
        `CHRONO VACUUM: Singularity collapses inward on ${pulledNames.join(', ')} (4 Arcane DMG)!`
      );
    }
  }

  if (ability.selfReposition === 'leap_adjacent') {
    const caster = updatedUnits.find((u) => u.id === attacker.id && !u.isKO);
    if (
      caster &&
      !caster.statuses.some((s) => s.type === 'rooted') &&
      manhattanDistance(caster.gridX, caster.gridZ, targetX, targetZ) >= 2
    ) {
      const adjOffsets = [
        { x: targetX - 1, z: targetZ },
        { x: targetX + 1, z: targetZ },
        { x: targetX, z: targetZ - 1 },
        { x: targetX, z: targetZ + 1 },
      ]
        .filter((pt) => isTileOpenForUnit(pt.x, pt.z, caster.id))
        .sort(
          (a, b) =>
            manhattanDistance(caster.gridX, caster.gridZ, a.x, a.z) -
            manhattanDistance(caster.gridX, caster.gridZ, b.x, b.z)
        );
      if (adjOffsets.length > 0) {
        const dest = adjOffsets[0];
        caster.gridX = dest.x;
        caster.gridZ = dest.z;
        caster.elevation = updatedGrid[dest.x][dest.z].elevation;
        triggeredEvents.push(
          `VENGEANCE LEAP: ${caster.name} surges into melee at (${dest.x}, ${dest.z})!`
        );
      }
    }
  }

  if (ability.selfReposition === 'backstep_1') {
    const caster = updatedUnits.find((u) => u.id === attacker.id && !u.isKO);
    if (caster && !caster.statuses.some((s) => s.type === 'rooted')) {
      const [retX, retZ] = computePushVector(targetX, targetZ, caster.gridX, caster.gridZ);
      const curDist = manhattanDistance(caster.gridX, caster.gridZ, targetX, targetZ);
      const retreatCandidates = [
        { x: caster.gridX + retX, z: caster.gridZ + retZ },
        { x: caster.gridX + 1, z: caster.gridZ },
        { x: caster.gridX - 1, z: caster.gridZ },
        { x: caster.gridX, z: caster.gridZ + 1 },
        { x: caster.gridX, z: caster.gridZ - 1 },
      ].filter(
        (pt) =>
          manhattanDistance(pt.x, pt.z, targetX, targetZ) > curDist &&
          isTileOpenForUnit(pt.x, pt.z, caster.id)
      );
      if (retreatCandidates.length > 0) {
        const dest = retreatCandidates[0];
        caster.gridX = dest.x;
        caster.gridZ = dest.z;
        caster.elevation = updatedGrid[dest.x][dest.z].elevation;
        triggeredEvents.push(
          `EVASIVE VAULT: ${caster.name} backsteps to (${dest.x}, ${dest.z})!`
        );
      }
    }
  }

  // 2C. Support & Formation Aura Mechanics (Squad Phalanx, Affliction Purge, Phase Reset, Barkskin Balm, Warrior Core Defenses)
  if (ability.id === 'guarded_stance') {
    const caster = updatedUnits.find((u) => u.id === attacker.id && !u.isKO);
    if (caster) {
      caster.tempHp = Math.max(caster.tempHp, ability.grantTempHp ?? 6);
      caster.guardedStanceTurns = 2;
      applyDamageAndStatus(caster, 0, 'warded');
      triggeredEvents.push(
        `GUARDED STANCE: Warrior adopts a guarded stance (+6 Temp HP, Warded +2 AC, 25% Physical Reduction, Displacement Immunity, -1 Move Range trade-off).`
      );
    }
  }

  if (ability.id === 'weapon_parry') {
    const caster = updatedUnits.find((u) => u.id === attacker.id && !u.isKO);
    if (caster) {
      caster.tempHp = Math.max(caster.tempHp, ability.grantTempHp ?? 8);
      caster.weaponParryActive = true;
      applyDamageAndStatus(caster, 0, 'warded');
      triggeredEvents.push(
        `WEAPON PARRY: ${caster.name} enters deflection stance (+8 Temp HP, Warded +2 AC, ready to parry & counter the next melee strike).`
      );
    }
  }

  if (ability.id === 'unbreakable_resolve') {
    const caster = updatedUnits.find((u) => u.id === attacker.id && !u.isKO);
    if (caster) {
      caster.tempHp = Math.max(caster.tempHp, ability.grantTempHp ?? 12);
      caster.statuses = caster.statuses.filter(
        (s) => s.type !== 'burning' && s.type !== 'rooted' && s.type !== 'sundered'
      );
      triggeredEvents.push(
        `UNBREAKABLE RESOLVE: Warrior steels their resolve (purged debuffs and refreshed +12 Temp HP buffer).`
      );
    }
  }

  if (ability.id === 'iron_reprisal') {
    const caster = updatedUnits.find((u) => u.id === attacker.id && !u.isKO);
    if (caster) {
      caster.ironReprisalActive = true;
      caster.damageTakenSinceLastTurn = 0;
      triggeredEvents.push(
        `IRON REPRISAL: ${caster.name} channels kinetic vengeance and arms a 1-round melee counter-retaliation!`
      );
    }
  }

  if (ability.id === 'battlefield_commander') {
    const ralliedNames: string[] = [];
    for (const u of updatedUnits) {
      if (
        !u.isKO &&
        u.faction === attacker.faction &&
        manhattanDistance(u.gridX, u.gridZ, attacker.gridX, attacker.gridZ) <= 4
      ) {
        u.tempHp = Math.max(u.tempHp, ability.grantTempHp ?? 10);
        applyDamageAndStatus(u, 0, 'blessed');
        ralliedNames.push(u.name);
      }
    }
    triggeredEvents.push(
      `BATTLEFIELD COMMANDER: Battlefield Commander rallies nearby allies (${ralliedNames.join(', ')}) with +10 Temp HP & Blessed (+2 Hit)!`
    );
  }

  if (ability.id === 'last_stand') {
    const caster = updatedUnits.find((u) => u.id === attacker.id && !u.isKO);
    if (caster && isLastStandConditionMet(attacker, updatedUnits).allowed) {
      caster.tempHp = Math.max(caster.tempHp, ability.grantTempHp ?? 20);
      caster.lastStandTurns = 2;
      caster.usedLastStand = true;
      applyDamageAndStatus(caster, 0, 'warded');
      triggeredEvents.push(
        `LAST STAND: Warrior refuses to fall! ${caster.name} gains +20 Temp HP, Warded (+2 AC), and a 1 HP survival floor for 2 turns!`
      );
    }
  }

  if (ability.id === 'aegis_ward') {
    const caster = updatedUnits.find((u) => u.id === attacker.id && !u.isKO);
    if (caster) {
      caster.tempHp = Math.max(caster.tempHp, ability.grantTempHp ?? 10);
      caster.aegisWardActive = true;
      caster.aegisWardTurns = 2;
      applyDamageAndStatus(caster, 0, 'warded');
      triggeredEvents.push(
        `AEGIS WARD: ${caster.name} manifests a crystalline barrier (+10 Temp HP, Warded +2 AC for 2 turns). Barrier collapse releases a 6 Arcane DMG shockwave!`
      );
    }
  }

  if (ability.id === 'counterspell') {
    const caster = updatedUnits.find((u) => u.id === attacker.id && !u.isKO);
    if (caster) {
      caster.counterspellActive = true;
      caster.counterspellTurns = 2;
      triggeredEvents.push(
        `COUNTERSPELL: ${caster.name} weaves an anti-arcane mantle, ready to negate the next incoming ranged/magical attack and reflect 8 Arcane DMG!`
      );
    }
  }

  if (ability.id === 'phase_veil') {
    const caster = updatedUnits.find((u) => u.id === attacker.id && !u.isKO);
    if (caster) {
      caster.statuses = caster.statuses.filter(
        (s) =>
          s.type !== 'burning' &&
          s.type !== 'rooted' &&
          s.type !== 'sundered' &&
          s.type !== 'chilled'
      );
      caster.phaseVeilTurns = 2;
      caster.moveRange = caster.moveRange + 1;
      triggeredEvents.push(
        `PHASE VEIL: ${caster.name} slips between dimensions! Purged debuffs, +1 Move Range, and 50% physical damage mitigation for 2 turns.`
      );
    }
  }

  if (ability.id === 'aegis_bulwark') {
    const caster = updatedUnits.find((u) => u.id === attacker.id && !u.isKO);
    if (caster) {
      caster.tempHp = Math.max(caster.tempHp, ability.grantTempHp ?? 8);
      applyDamageAndStatus(caster, 0, 'warded');
    }
    const shieldedAllies: string[] = [];
    for (const u of updatedUnits) {
      if (
        !u.isKO &&
        u.faction === attacker.faction &&
        u.id !== attacker.id &&
        manhattanDistance(u.gridX, u.gridZ, attacker.gridX, attacker.gridZ) <= 2
      ) {
        u.tempHp += ability.allyAuraTempHp ?? 4;
        u.statuses = u.statuses.filter((s) => s.type !== 'burning');
        shieldedAllies.push(u.name);
      }
    }
    triggeredEvents.push(
      shieldedAllies.length > 0
        ? `BASTION PHALANX: Sovereign Aegis shields ${attacker.name} (+8 Temp HP) and nearby allies ${shieldedAllies.join(', ')} (+4 Temp HP)!`
        : `BASTION AEGIS: ${attacker.name} fortifies with +8 Temp HP & Warded (+2 AC)!`
    );
  }

  if (ability.id === 'lay_on_hands') {
    const ally = updatedUnits.find(
      (u) => !u.isKO && (u.id === hitTargetUnitId || (u.gridX === targetX && u.gridZ === targetZ))
    );
    if (ally && ally.faction === attacker.faction) {
      ally.statuses = [
        ...ally.statuses.filter(
          (s) => s.type !== 'burning' && s.type !== 'rooted' && s.type !== 'sundered' && s.type !== 'blessed'
        ),
        { type: 'blessed', turnsLeft: 2 },
      ];
    }
    const t = updatedGrid[targetX]?.[targetZ];
    if (t && t.walkable) {
      t.surface = 'sanctified_pool';
      if (t.terrain === 'hazard_rift') t.terrain = 'stone';
      triggeredEvents.push(
        `DAWNLIGHT SANCTUARY: Afflictions purged and (${targetX}, ${targetZ}) consecrated into Sanctified Ground!`
      );
    }
  }

  if (ability.id === 'arcane_conduit') {
    const ally = updatedUnits.find(
      (u) => !u.isKO && (u.id === hitTargetUnitId || (u.gridX === targetX && u.gridZ === targetZ))
    );
    if (ally && ally.faction === attacker.faction) {
      ally.movedThisTurn = false;
      ally.tempHp = Math.max(ally.tempHp, ability.grantTempHp ?? 5);
      ally.statuses = [
        ...ally.statuses.filter((s) => s.type !== 'rooted' && s.type !== 'blessed'),
        { type: 'blessed', turnsLeft: 2 },
      ];
      const t = updatedGrid[ally.gridX]?.[ally.gridZ];
      if (t && (t.terrain === 'hazard_rift' || t.surface === 'bramble_snare')) {
        if (t.terrain === 'hazard_rift') t.terrain = 'stone';
        if (t.surface === 'bramble_snare') t.surface = 'none';
      }
      triggeredEvents.push(
        `LEY-LINE TRANSFUSION: ${ally.name} gains +5 Temp HP, Root cleanse, and a refreshed Movement Phase!`
      );
    }
  }

  if (ability.id === 'warden_salve') {
    const ally = updatedUnits.find(
      (u) => !u.isKO && (u.id === hitTargetUnitId || (u.gridX === targetX && u.gridZ === targetZ))
    );
    if (ally && ally.faction === attacker.faction) {
      ally.statuses = [
        ...ally.statuses.filter(
          (s) => s.type !== 'burning' && s.type !== 'sundered' && s.type !== 'warded'
        ),
        { type: 'warded', turnsLeft: 2 },
      ];
    }
    const t = updatedGrid[targetX]?.[targetZ];
    if (
      t &&
      t.walkable &&
      (t.surface === 'fire_pool' || t.surface === 'oil_pool' || t.terrain === 'hazard_rift')
    ) {
      t.terrain = 'moss';
      t.surface = 'none';
      triggeredEvents.push(
        `SYLVAN BALM: Herbal poultice mends armor, extinguishes flames, and restores verdant moss at (${targetX}, ${targetZ})!`
      );
    } else {
      triggeredEvents.push(
        `SYLVAN BALM: Herbal poultice cleanses Burn/Sunder and hardens Barkskin Ward (+2 AC)!`
      );
    }
  }

  // 3. Surface Elemental & Geometric Reactions (Solar Cross, 3-Tile Briar Wall, Chain Oil Ignition, Brambles, Purification, Mage Surfaces)
  if (ability.id === 'runic_mine') {
    const caster = updatedUnits.find((u) => u.id === attacker.id && !u.isKO);
    if (caster && caster.activeRunicMineCoords) {
      const oldX = caster.activeRunicMineCoords.x;
      const oldZ = caster.activeRunicMineCoords.z;
      if (updatedGrid[oldX]?.[oldZ]?.surface === 'runic_mine') {
        updatedGrid[oldX][oldZ].surface = 'none';
      }
    }
    const t = updatedGrid[targetX]?.[targetZ];
    if (t && t.walkable) {
      t.surface = 'runic_mine';
      if (caster) {
        caster.activeRunicMineCoords = { x: targetX, z: targetZ };
      }
      triggeredEvents.push(
        `RUNIC MINE: Inscribed an arcane detonation ward at (${targetX}, ${targetZ}). Detonates on enemy step (14 DMG & Root)!`
      );
    }
  } else if (ability.id === 'astral_rift') {
    let riftCount = 0;
    for (let rx = Math.max(0, targetX - 1); rx <= Math.min(GRID_SIZE - 1, targetX + 1); rx++) {
      for (let rz = Math.max(0, targetZ - 1); rz <= Math.min(GRID_SIZE - 1, targetZ + 1); rz++) {
        if (manhattanDistance(targetX, targetZ, rx, rz) <= 1) {
          const t = updatedGrid[rx]?.[rz];
          if (t && t.walkable) {
            t.surface = 'astral_rift';
            riftCount++;
          }
        }
      }
    }
    for (const u of updatedUnits) {
      if (
        !u.isKO &&
        u.faction !== attacker.faction &&
        manhattanDistance(u.gridX, u.gridZ, targetX, targetZ) <= 1
      ) {
        applyDamageAndStatus(u, 4, 'sundered');
      }
    }
    triggeredEvents.push(
      `ASTRAL RIFT: Tore a ${riftCount}-tile spatial rift across (${targetX}, ${targetZ}) (4 Arcane DMG & Sundered)!`
    );
  } else if (ability.id === 'prismatic_field') {
    let fieldCount = 0;
    for (let px = Math.max(0, targetX - 1); px <= Math.min(GRID_SIZE - 1, targetX + 1); px++) {
      for (let pz = Math.max(0, targetZ - 1); pz <= Math.min(GRID_SIZE - 1, targetZ + 1); pz++) {
        const t = updatedGrid[px]?.[pz];
        if (t && t.walkable) {
          t.surface = 'prismatic_field';
          fieldCount++;
        }
      }
    }
    const buffedAllies: string[] = [];
    const debuffedEnemies: string[] = [];
    for (const u of updatedUnits) {
      if (!u.isKO && chebyshevDistance(u.gridX, u.gridZ, targetX, targetZ) <= 1) {
        if (u.faction === attacker.faction) {
          u.tempHp = Math.max(u.tempHp, 8);
          applyDamageAndStatus(u, 0, 'warded');
          buffedAllies.push(u.name);
        } else {
          applyDamageAndStatus(u, 0, 'sundered');
          debuffedEnemies.push(u.name);
        }
      }
    }
    triggeredEvents.push(
      `PRISMATIC FIELD: Created a 3x3 harmonic matrix across (${targetX}, ${targetZ})!${
        buffedAllies.length > 0 ? ` Allies buffed: ${buffedAllies.join(', ')}.` : ''
      }${debuffedEnemies.length > 0 ? ` Foes sundered: ${debuffedEnemies.join(', ')}.` : ''}`
    );
  } else if (ability.id === 'dawnbreaker_judgment') {
    const crossHealed: string[] = [];
    for (let x = Math.max(0, targetX - 1); x <= Math.min(GRID_SIZE - 1, targetX + 1); x++) {
      for (let z = Math.max(0, targetZ - 1); z <= Math.min(GRID_SIZE - 1, targetZ + 1); z++) {
        if (manhattanDistance(targetX, targetZ, x, z) <= 1) {
          const t = updatedGrid[x]?.[z];
          if (t && t.walkable) {
            t.surface = 'sanctified_pool';
            if (t.terrain === 'hazard_rift') t.terrain = 'stone';
          }
        }
      }
    }
    for (const u of updatedUnits) {
      if (
        !u.isKO &&
        u.faction === attacker.faction &&
        manhattanDistance(u.gridX, u.gridZ, targetX, targetZ) <= 1
      ) {
        u.hp = Math.min(u.maxHp, u.hp + 6);
        u.statuses = u.statuses.filter((s) => s.type !== 'burning');
        applyDamageAndStatus(u, 0, 'blessed');
        crossHealed.push(u.name);
      }
    }
    triggeredEvents.push(
      `SOLAR CROSS: Dawnbreaker Judgment consecrates a 5-tile cross into Sanctified Ground${
        crossHealed.length > 0 ? ` and mends ${crossHealed.join(', ')} (+6 HP & Blessed)` : ''
      }!`
    );
  } else if (ability.id === 'heart_briar_volley') {
    const [vx, vz] = computePushVector(attacker.gridX, attacker.gridZ, targetX, targetZ);
    const perpCoords =
      Math.abs(vx) > 0
        ? [
            { x: targetX, z: targetZ - 1 },
            { x: targetX, z: targetZ },
            { x: targetX, z: targetZ + 1 },
          ]
        : [
            { x: targetX - 1, z: targetZ },
            { x: targetX, z: targetZ },
            { x: targetX + 1, z: targetZ },
          ];
    let plantedCount = 0;
    for (const pt of perpCoords) {
      const t = updatedGrid[pt.x]?.[pt.z];
      if (t && t.walkable) {
        t.surface = 'bramble_snare';
        if (t.terrain === 'hazard_rift') t.terrain = 'moss';
        plantedCount++;
        for (const u of updatedUnits) {
          if (
            !u.isKO &&
            u.faction !== attacker.faction &&
            u.gridX === pt.x &&
            u.gridZ === pt.z
          ) {
            applyDamageAndStatus(u, u.id === hitTargetUnitId ? 0 : 4, 'rooted');
          }
        }
      }
    }
    if (plantedCount > 0) {
      triggeredEvents.push(
        `BRIAR BARRICADE: A ${plantedCount}-tile living thorn wall erupts across (${targetX}, ${targetZ}), rooting foes!`
      );
    }
  } else if (isFire) {
    // Seed BFS with any oil_pool at (targetX, targetZ) or adjacent within AoE
    const queue: { x: number; z: number }[] = [];
    const visited = new Set<string>();
    const searchRadius = Math.max(1, ability.aoeRadius ?? 0);

    for (let x = Math.max(0, targetX - searchRadius); x <= Math.min(GRID_SIZE - 1, targetX + searchRadius); x++) {
      for (let z = Math.max(0, targetZ - searchRadius); z <= Math.min(GRID_SIZE - 1, targetZ + searchRadius); z++) {
        if (manhattanDistance(targetX, targetZ, x, z) <= searchRadius || (x === targetX && z === targetZ)) {
          if (updatedGrid[x]?.[z]?.surface === 'oil_pool') {
            queue.push({ x, z });
            visited.add(`${x},${z}`);
          }
        }
      }
    }

    while (queue.length > 0) {
      const cur = queue.shift()!;
      const tile = updatedGrid[cur.x]?.[cur.z];
      if (!tile) continue;
      tile.surface = 'fire_pool';
      ignitedTiles.push({ x: cur.x, z: cur.z });

      // Check 8-way connected oil_pool neighbors for chain reaction ignition
      for (let dx = -1; dx <= 1; dx++) {
        for (let dz = -1; dz <= 1; dz++) {
          if (dx === 0 && dz === 0) continue;
          const nx = cur.x + dx;
          const nz = cur.z + dz;
          const key = `${nx},${nz}`;
          if (
            nx >= 0 &&
            nx < GRID_SIZE &&
            nz >= 0 &&
            nz < GRID_SIZE &&
            !visited.has(key) &&
            updatedGrid[nx]?.[nz]?.surface === 'oil_pool'
          ) {
            visited.add(key);
            queue.push({ x: nx, z: nz });
          }
        }
      }
    }

    if (ignitedTiles.length > 0) {
      const ignitedSet = new Set(ignitedTiles.map((t) => `${t.x},${t.z}`));
      for (const u of updatedUnits) {
        if (!u.isKO && ignitedSet.has(`${u.gridX},${u.gridZ}`)) {
          applyDamageAndStatus(u, 6, 'burning');
        }
      }
      triggeredEvents.push(
        `SURFACE IGNITION: Oil Pool erupts into Alchemical Fire across ${ignitedTiles.length} tile${
          ignitedTiles.length > 1 ? 's' : ''
        } (+6 Fire DMG & Burning)!`
      );
    }
  } else if (isNature && ability.targetType !== 'ally' && ability.targetType !== 'self') {
    const t = updatedGrid[targetX]?.[targetZ];
    if (
      t &&
      t.walkable &&
      (t.surface === 'oil_pool' ||
        t.terrain === 'hazard_rift' ||
        t.surface === 'none' ||
        t.surface === 'sanctified_pool')
    ) {
      t.surface = 'bramble_snare';
      if (t.terrain === 'hazard_rift') t.terrain = 'moss';
      for (const u of updatedUnits) {
        if (!u.isKO && u.faction !== attacker.faction && u.gridX === targetX && u.gridZ === targetZ) {
          applyDamageAndStatus(u, 0, 'rooted');
        }
      }
      triggeredEvents.push(
        `SURFACE REACTION: Sylvan Briar-Thorns overgrow (${targetX}, ${targetZ}), creating an entangling snare!`
      );
    }
  } else if (isRadiant && ability.id !== 'lay_on_hands' && ability.id !== 'aegis_bulwark') {
    const t = updatedGrid[targetX]?.[targetZ];
    if (
      t &&
      t.walkable &&
      (t.surface === 'oil_pool' || t.surface === 'fire_pool' || t.terrain === 'hazard_rift')
    ) {
      t.surface = 'sanctified_pool';
      if (t.terrain === 'hazard_rift') t.terrain = 'stone';
      for (const u of updatedUnits) {
        if (!u.isKO && u.faction === 'party' && u.gridX === targetX && u.gridZ === targetZ) {
          u.hp = Math.min(u.maxHp, u.hp + 5);
          applyDamageAndStatus(u, 0, 'blessed');
        }
      }
      triggeredEvents.push(
        `SURFACE PURIFIED: Radiant light sanctifies (${targetX}, ${targetZ}) into a Blessed Dawn Pool!`
      );
    }
  }

  return {
    updatedGrid,
    updatedObjects,
    updatedUnits,
    triggeredEvents,
    ignitedTiles,
    bonusDamageDealt,
  };
}

/**
 * Distinct Enemy AI Decision Policies:
 * 1. 'stalker' (Flanker / Rushdown): Seeks low-HP or isolated backline targets (Kaelen/Thorne), closes in fast.
 * 2. 'weaver' (Ranged Kiter / High-Ground Seeker): Prefers elevated bastion tiles or stays at range 3-4 while casting AoE/Hex.
 * 3. 'inquisitor' (Shielded Frontline Juggernaut): Advances toward the highest-HP vanguard (Seraphina) and uses Sunder/Bulwark.
 */
export function computeEnemyTurnAction(
  enemy: CombatUnit,
  allUnits: CombatUnit[],
  grid: GridTile[][],
  envObjects: TacticalEnvObject[] = []
): {
  moveTo: { x: number; z: number };
  targetUnitId: string;
  ability: Ability;
} {
  const livingParty = allUnits.filter((u) => u.faction === 'party' && !u.isKO);
  if (livingParty.length === 0) {
    return {
      moveTo: { x: enemy.gridX, z: enemy.gridZ },
      targetUnitId: enemy.id,
      ability: enemy.abilities[0],
    };
  }

  const validMoves = getValidMoveTiles(enemy, grid, allUnits, envObjects);
  const candidatePositions = [{ x: enemy.gridX, z: enemy.gridZ }, ...validMoves];

  let chosenTarget = livingParty[0];
  let bestPos = { x: enemy.gridX, z: enemy.gridZ };

  if (enemy.archetype === 'stalker') {
    // Policy 1: Target lowest HP party member and get adjacent
    chosenTarget = [...livingParty].sort((a, b) => a.hp - b.hp)[0];
    bestPos = [...candidatePositions].sort((a, b) => {
      const distA = manhattanDistance(a.x, a.z, chosenTarget.gridX, chosenTarget.gridZ);
      const distB = manhattanDistance(b.x, b.z, chosenTarget.gridX, chosenTarget.gridZ);
      return distA - distB;
    })[0];
  } else if (enemy.archetype === 'weaver') {
    // Policy 2: Prefer High Ground (elevation 1) and maintain distance 3-4 from nearest enemy
    chosenTarget = [...livingParty].sort(
      (a, b) =>
        manhattanDistance(enemy.gridX, enemy.gridZ, a.gridX, a.gridZ) -
        manhattanDistance(enemy.gridX, enemy.gridZ, b.gridX, b.gridZ)
    )[0];

    bestPos = [...candidatePositions].sort((a, b) => {
      const tileA = grid[a.x]?.[a.z];
      const tileB = grid[b.x]?.[b.z];
      const elevScoreA = (tileA?.elevation ?? 0) * 4;
      const elevScoreB = (tileB?.elevation ?? 0) * 4;
      const distA = manhattanDistance(a.x, a.z, chosenTarget.gridX, chosenTarget.gridZ);
      const distB = manhattanDistance(b.x, b.z, chosenTarget.gridX, chosenTarget.gridZ);
      // Ideal distance is 3 or 4
      const rangeFitA = -Math.abs(distA - 3.5);
      const rangeFitB = -Math.abs(distB - 3.5);
      return elevScoreB + rangeFitB - (elevScoreA + rangeFitA);
    })[0];
  } else {
    // Policy 3 ('inquisitor'): Confront highest-HP frontline unit head-on
    chosenTarget = [...livingParty].sort((a, b) => b.hp - a.hp)[0];
    bestPos = [...candidatePositions].sort((a, b) => {
      const distA = manhattanDistance(a.x, a.z, chosenTarget.gridX, chosenTarget.gridZ);
      const distB = manhattanDistance(b.x, b.z, chosenTarget.gridX, chosenTarget.gridZ);
      return distA - distB;
    })[0];
  }

  const finalDist = manhattanDistance(bestPos.x, bestPos.z, chosenTarget.gridX, chosenTarget.gridZ);
  // Pick the strongest in-range ability
  const usableAbilities = enemy.abilities.filter(
    (ab) => ab.range >= finalDist && (enemy.cooldowns[ab.id] ?? 0) <= 0
  );
  const chosenAbility =
    usableAbilities.length > 0
      ? usableAbilities[usableAbilities.length - 1]
      : enemy.abilities[0];

  return {
    moveTo: bestPos,
    targetUnitId: chosenTarget.id,
    ability: chosenAbility,
  };
}

export function createInitialRelationships(): Record<CompanionId, CompanionRelationship> {
  return {
    seraphina: {
      id: 'seraphina',
      name: 'Seraphina Vane',
      title: 'Oathbreaker Paladin',
      raceClass: 'Half-Elf · Vengeance & Dawn',
      approval: 62,
      personalQuestStage: 'Seeking the truth of the Silver Covenant’s betrayal at Dimraeth.',
      synergyName: 'Aegis of the Unbroken',
      synergyDescription: 'High approval grants +2 Attack, +2 Radiant DMG, and expanded Crit range.',
      campConversationsCompleted: [],
    },
    kaelen: {
      id: 'kaelen',
      name: 'Kaelen Vos',
      title: 'Blood-Weave Arcanist',
      raceClass: 'Tiefling · Astral Scholar',
      approval: 58,
      personalQuestStage: 'Deciphering the forbidden Astral Spire sigils before the Rift collapses.',
      synergyName: 'Resonant Blood-Sigil',
      synergyDescription: 'High approval empowers arcane spells with +2 Spell Attack & +2 Force DMG.',
      campConversationsCompleted: [],
    },
    thorne: {
      id: 'thorne',
      name: 'Thorne Ironbough',
      title: 'Sylvan Warden',
      raceClass: 'Wood-Kin · Stalker of the Vale',
      approval: 65,
      personalQuestStage: 'Purging the Void-blight from the ancient Heart-Briar roots.',
      synergyName: 'Hawkeye of the Vale',
      synergyDescription: 'High approval grants +2 Ranged Accuracy and lethal critical precision.',
      campConversationsCompleted: [],
    },
  };
}

export function createInitialWorldState(): WorldReactivityState {
  return {
    flags: [],
    corruptionLevel: 45,
    oathAlignment: 'Balance',
    factions: {
      silverCovenant: 0,
      bloodScholars: 5,
      sylvanCircle: 10,
    },
    chronicleLog: [
      'The expedition entered the Whispering Vale of Dimraeth as the Astral Rift fractured the sky.',
    ],
  };
}

export function createEncounterUnits(
  stageId: number,
  worldState: WorldReactivityState
): CombatUnit[] {
  const isPurified = worldState.flags.includes('sanctum_purified');
  const isBloodUnleashed = worldState.flags.includes('blood_weave_unleashed');
  const inquisitorSpared = worldState.flags.includes('inquisitor_spared');

  const partyBonusHp = isPurified ? 6 : 0;
  const kaelenSpellBonus = isBloodUnleashed ? 3 : 0;

  const party: CombatUnit[] = [
    {
      id: 'seraphina',
      name: 'Seraphina Vane',
      title: 'Oathbreaker Paladin',
      faction: 'party',
      companionId: 'seraphina',
      gridX: 3,
      gridZ: 7,
      elevation: 0,
      hp: 44 + partyBonusHp,
      maxHp: 44 + partyBonusHp,
      tempHp: 0,
      ap: 2,
      maxAp: 2,
      moveRange: 4,
      movedThisTurn: false,
      armorClass: 15,
      initiative: 16,
      stats: { str: 18, dex: 12, int: 11, cha: 16 },
      cooldowns: {},
      statuses: [],
      isKO: false,
      koTimer: 0,
      abilities: [
        {
          id: 'sunblade_cleave',
          name: 'Sunblade Cleave',
          key: '1',
          apCost: 1,
          cooldown: 0,
          range: 2,
          aoeShape: 'sweeping_arc',
          category: 'martial_cleave',
          damageRange: [8, 13],
          element: 'fire',
          pushDistance: 1,
          uniqueMechanicLabel: 'Sweeping Vanguard Arc (5 Fire DMG + Burn to Mutual Adjacent Foe) & Push 1',
          targetType: 'enemy',
          roleClue: 'Sweeping Arc · Cleaves Adjacent & Push 1',
          description:
            'Deliver a sweeping dawnfire greatsword strike that shoves the primary foe 1 tile, ignites oil, and cleaves mutually adjacent enemies for 5 Fire DMG & Burning.',
        },
        {
          id: 'searing_smite',
          name: 'Oathbreaker Smite',
          key: '2',
          apCost: 2,
          cooldown: 2,
          range: 2,
          aoeShape: 'single',
          category: 'execution_gapcloser',
          damageRange: [14, 21],
          element: 'radiant',
          selfReposition: 'leap_adjacent',
          refundApOnKO: 1,
          statusEffect: 'sundered',
          uniqueMechanicLabel: 'Gap-Close Leap · +6 Execution DMG vs ≤50% HP · +1 AP on KO',
          targetType: 'enemy',
          roleClue: 'Execution Leap · +6 vs Bloodied & +1 AP KO',
          description:
            'Surge into melee with a pillar of fractured astral judgment that sunders armor (-2 AC), deals +6 Execution DMG to targets at ≤50% HP, and refunds +1 AP on a kill.',
        },
        {
          id: 'lay_on_hands',
          name: 'Dawnlight Mending',
          key: '3',
          apCost: 1,
          cooldown: 2,
          range: 4,
          aoeShape: 'single',
          category: 'cleansing_mend',
          damageRange: [0, 0],
          healAmount: 14,
          element: 'radiant',
          cleanseStatuses: ['burning', 'rooted', 'sundered'],
          statusEffect: 'blessed',
          uniqueMechanicLabel: 'Full Affliction Purge (Burn/Root/Sunder) & Consecrate Tile',
          targetType: 'ally',
          roleClue: 'Triage · Heal 14 + Purge Debuffs + Sanctify',
          description:
            'Restore 14 HP to an ally, purge all negative afflictions (Burning, Rooted, Sundered), grant Blessed (+2 Hit), and consecrate their tile into Sanctified Ground.',
        },
        {
          id: 'aegis_bulwark',
          name: 'Sovereign Aegis',
          key: '4',
          apCost: 1,
          cooldown: 2,
          range: 1,
          aoeRadius: 2,
          aoeShape: 'bastion_aura',
          category: 'bastion_aura',
          damageRange: [0, 0],
          healAmount: 6,
          grantTempHp: 8,
          allyAuraTempHp: 4,
          element: 'radiant',
          statusEffect: 'warded',
          uniqueMechanicLabel: '+8 Self Temp HP & +4 Squad Temp HP Aura (Radius 2)',
          targetType: 'self',
          roleClue: 'Phalanx · +8 Temp HP, +2 AC & Squad Shield',
          description:
            'Raise an unbroken covenant shield: recover 6 HP, gain +8 Temp HP & Warded (+2 AC), and grant +4 Temp HP (plus Burn extinguish) to allies within 2 tiles.',
        },
      ],
    },
    {
      id: 'kaelen',
      name: 'Kaelen Vos',
      title: 'Blood-Weave Arcanist',
      faction: 'party',
      companionId: 'kaelen',
      gridX: 5,
      gridZ: 7,
      elevation: 0,
      hp: 32 + partyBonusHp,
      maxHp: 32 + partyBonusHp,
      tempHp: 0,
      ap: 2,
      maxAp: 2,
      moveRange: 4,
      movedThisTurn: false,
      armorClass: 13,
      initiative: 18,
      stats: { str: 9, dex: 14, int: 19, cha: 15 },
      cooldowns: {},
      statuses: [],
      isKO: false,
      koTimer: 0,
      abilities: [
        {
          id: 'astral_bolt',
          name: 'Astral Lance',
          key: '1',
          apCost: 1,
          cooldown: 0,
          range: 6,
          aoeShape: 'piercing_ray',
          category: 'piercing_ray',
          damageRange: [7 + kaelenSpellBonus, 12 + kaelenSpellBonus],
          element: 'arcane',
          pushDistance: 1,
          uniqueMechanicLabel: 'Linear Piercing Ray (5 Arcane DMG Behind Target) & Push 1',
          targetType: 'enemy',
          roleClue: 'Piercing Ray 6 · Hits Line & Pushes 1',
          description:
            'Hurl a condensed starlight spear that shoves the primary target 1 tile and pierces enemies up to 2 tiles directly behind them for 5 Arcane DMG.',
        },
        {
          id: 'crimson_tempest',
          name: 'Crimson Singularity',
          key: '2',
          apCost: 2,
          cooldown: 2,
          range: 5,
          aoeRadius: 1,
          aoeShape: 'chebyshev_3x3',
          category: 'pyromantic_detonation',
          damageRange: [13 + kaelenSpellBonus, 19 + kaelenSpellBonus],
          element: 'fire',
          statusEffect: 'burning',
          uniqueMechanicLabel: '3×3 Blast (6 DMG Secondary) · +5 Thermal Resonance vs Burning',
          targetType: 'enemy',
          roleClue: '3×3 Firestorm · +5 vs Burning & Ignites Oil',
          description:
            'Detonate a 3×3 Blood-Weave firestorm (+5 Resonance DMG against Burning foes) that scorches nearby enemies for 6 Fire DMG and chain-ignites oil & volatile casks.',
        },
        {
          id: 'gravity_shackle',
          name: 'Rift Singularity Bind',
          key: '3',
          apCost: 1,
          cooldown: 2,
          range: 5,
          aoeShape: 'tether_pull',
          category: 'telekinetic_tether',
          damageRange: [6, 10],
          element: 'arcane',
          pullDistance: 1,
          statusEffect: 'rooted',
          uniqueMechanicLabel: 'Telekinetic Tether Pull 1 Tile Toward Caster & Root (+4 Hazard/Drop Shear)',
          targetType: 'enemy',
          roleClue: 'Tether Pull 1 · Yanks Foe Inward & Roots',
          description:
            'Hook an enemy in warped gravity, pulling them 1 tile toward the Arcanist (+4 Shear DMG if yanked off High Ground or onto a hazard) and locking them Rooted.',
        },
        {
          id: 'arcane_conduit',
          name: 'Weave Transfusion',
          key: '4',
          apCost: 1,
          cooldown: 2,
          range: 5,
          aoeShape: 'single',
          category: 'phase_transfusion',
          damageRange: [0, 0],
          healAmount: 11,
          grantTempHp: 5,
          cleanseStatuses: ['rooted'],
          resetTargetMove: true,
          element: 'arcane',
          statusEffect: 'blessed',
          uniqueMechanicLabel: 'Ley-Line Stride Reset (Ally Moves Again) + 5 Temp HP & Root Break',
          targetType: 'ally',
          roleClue: 'Phase Shift · Heal 11, +5 Temp HP & Reset Move',
          description:
            'Infuse an ally with ley-line momentum: restore 11 HP, weave +5 Temp HP, break Rooted, grant Blessed, and refresh their Movement Phase this round.',
        },
      ],
    },
    {
      id: 'thorne',
      name: 'Thorne Ironbough',
      title: 'Sylvan Warden',
      faction: 'party',
      companionId: 'thorne',
      gridX: 7,
      gridZ: 7,
      elevation: 0,
      hp: 36 + partyBonusHp,
      maxHp: 36 + partyBonusHp,
      tempHp: 0,
      ap: 2,
      maxAp: 2,
      moveRange: 5,
      movedThisTurn: false,
      armorClass: 14,
      initiative: 19,
      stats: { str: 13, dex: 19, int: 13, cha: 11 },
      cooldowns: {},
      statuses: [],
      isKO: false,
      koTimer: 0,
      abilities: [
        {
          id: 'heartseeker_shot',
          name: 'Heartseeker Arrow',
          key: '1',
          apCost: 1,
          cooldown: 0,
          range: 6,
          aoeShape: 'single',
          category: 'deadeye_snipe',
          damageRange: [8, 13],
          element: 'physical',
          pushDistance: 1,
          uniqueMechanicLabel: 'Deadeye Longshot (+3 Sniper DMG at Distance ≥4 Tiles) & Push 1',
          targetType: 'enemy',
          roleClue: 'Deadeye 6 · +3 DMG at 4+ Tiles & Push 1',
          description:
            'Loose a heavy ironwood shaft that shoves targets 1 tile and deals +3 Deadeye Sniper DMG when fired from 4 or more tiles away.',
        },
        {
          id: 'bramble_snare',
          name: 'Briar-Thorn Volley',
          key: '2',
          apCost: 1,
          cooldown: 2,
          range: 5,
          aoeShape: 'trap_tile',
          category: 'trap_snare',
          damageRange: [9, 14],
          element: 'nature',
          statusEffect: 'rooted',
          uniqueMechanicLabel: 'Unit-or-Ground Choke-Point Trap (Plants Persistent Bramble Snare)',
          targetType: 'enemy',
          roleClue: 'Trap / Root · Target Foe or Empty Tile',
          description:
            'Fire a living sylvan shaft at an enemy or empty walkable tile to entangle foes (Rooted) and plant a persistent Bramble Snare choke-point trap.',
        },
        {
          id: 'viper_twinshot',
          name: 'Tempest Twin-Barrage',
          key: '3',
          apCost: 2,
          cooldown: 2,
          range: 6,
          aoeShape: 'single',
          category: 'evasive_barrage',
          damageRange: [15, 22],
          element: 'fire',
          selfReposition: 'backstep_1',
          statusEffect: 'sundered',
          uniqueMechanicLabel: 'Twin Fire Armor-Shred + Automatic 1-Tile Evasive Backstep Vault',
          targetType: 'enemy',
          roleClue: 'Kite Finisher · Sunder, Ignite & Backstep 1',
          description:
            'Loose twin fire-tipped shafts that sunder armor (-2 AC) and ignite oil while the Warden automatically vaults 1 tile away from the target.',
        },
        {
          id: 'warden_salve',
          name: 'Sylvan Wild-Balm',
          key: '4',
          apCost: 1,
          cooldown: 2,
          range: 4,
          aoeShape: 'single',
          category: 'barkskin_poultice',
          damageRange: [0, 0],
          healAmount: 12,
          cleanseStatuses: ['burning', 'sundered'],
          element: 'nature',
          statusEffect: 'warded',
          uniqueMechanicLabel: 'Extinguish Burn + Repair Sundered AC + Barkskin Ward (+2 AC) & Moss Restore',
          targetType: 'ally',
          roleClue: 'Armor Balm · Heal 12, Cure Burn/Sunder & +2 AC',
          description:
            'Apply Vale poultices to restore 12 HP, extinguish Burning, repair Sundered armor, grant Barkskin Ward (+2 AC), and restore hazardous ground to moss.',
        },
      ],
    },
  ];

  // Stage-scaled enemies with 3 distinct archetypes
  const stageHpScale = stageId * 6;
  const weakenPenalty = inquisitorSpared ? -4 : 0;

  const enemies: CombatUnit[] = [
    {
      id: `enemy_inquisitor_${stageId}`,
      name:
        stageId === 0
          ? 'Inquisitor Malakor'
          : stageId === 1
          ? 'Blight-Warden Vael'
          : 'Archon Severin the Hollow',
      title:
        stageId === 0
          ? 'Herald of the Ashen Rite'
          : stageId === 1
          ? 'Corrupted Sylvan Knight'
          : 'Sovereign of the Rift',
      faction: 'enemy',
      archetype: 'inquisitor',
      gridX: 4,
      gridZ: 1,
      elevation: 0,
      hp: Math.max(20, 38 + stageHpScale + weakenPenalty),
      maxHp: Math.max(20, 38 + stageHpScale + weakenPenalty),
      tempHp: 0,
      ap: 2,
      maxAp: 2,
      moveRange: 3,
      movedThisTurn: false,
      armorClass: 14,
      initiative: 14,
      stats: { str: 17, dex: 11, int: 12, cha: 14 },
      cooldowns: {},
      statuses: [],
      isKO: false,
      koTimer: 0,
      abilities: [
        {
          id: 'inquisitor_mace',
          name: 'Obsidian Halberd Crush',
          key: '1',
          apCost: 1,
          cooldown: 0,
          range: 2,
          aoeShape: 'single',
          category: 'enemy_maneuver',
          damageRange: [7, 11],
          element: 'physical',
          pushDistance: 1,
          statusEffect: 'sundered',
          uniqueMechanicLabel: 'Vanguard Breaker · Sunders AC (-2) & Shoves 1 Tile',
          targetType: 'enemy',
          roleClue: 'Melee Juggernaut · Sunder & Shoves 1',
          description:
            'Crushing obsidian halberd blow that sunders frontline armor (-2 AC) and knocks targets backward 1 tile.',
        },
      ],
    },
    {
      id: `enemy_weaver_${stageId}`,
      name: stageId === 0 ? 'Rift-Weaver Lyra' : stageId === 1 ? 'Thorn-Hexer Sira' : 'Astral Cantor Nyx',
      title: 'Void-Touched Channeler',
      faction: 'enemy',
      archetype: 'weaver',
      gridX: 7,
      gridZ: 2,
      elevation: 1,
      hp: Math.max(16, 26 + stageHpScale + weakenPenalty),
      maxHp: Math.max(16, 26 + stageHpScale + weakenPenalty),
      tempHp: 0,
      ap: 2,
      maxAp: 2,
      moveRange: 3,
      movedThisTurn: false,
      armorClass: 12,
      initiative: 15,
      stats: { str: 9, dex: 14, int: 16, cha: 13 },
      cooldowns: {},
      statuses: [],
      isKO: false,
      koTimer: 0,
      abilities: [
        {
          id: 'void_barrage',
          name: 'Abyssal Rift Volley',
          key: '1',
          apCost: 1,
          cooldown: 0,
          range: 5,
          aoeShape: 'single',
          category: 'enemy_maneuver',
          damageRange: [6, 10],
          element: 'fire',
          statusEffect: 'burning',
          uniqueMechanicLabel: 'High-Ground Void Artillery · Inflicts Burning & Ignites Oil',
          targetType: 'enemy',
          roleClue: 'Ranged Caster · Ignites Oil & Burns',
          description:
            'Channel bolts of abyssal void-fire from elevated bastions that inflict Burning and ignite oil pools.',
        },
      ],
    },
    {
      id: `enemy_stalker_${stageId}`,
      name: stageId === 0 ? 'Ashen Hound-blade' : stageId === 1 ? 'Briar Shadow-Stalker' : 'Void-Reaver Kael',
      title: 'Silent Flanker',
      faction: 'enemy',
      archetype: 'stalker',
      gridX: 2,
      gridZ: 2,
      elevation: 0,
      hp: Math.max(16, 24 + stageHpScale + weakenPenalty),
      maxHp: Math.max(16, 24 + stageHpScale + weakenPenalty),
      tempHp: 0,
      ap: 2,
      maxAp: 2,
      moveRange: 4,
      movedThisTurn: false,
      armorClass: 13,
      initiative: 17,
      stats: { str: 13, dex: 17, int: 10, cha: 9 },
      cooldowns: {},
      statuses: [],
      isKO: false,
      koTimer: 0,
      abilities: [
        {
          id: 'shadow_lunge',
          name: 'Shadowstep Twin-Dagger',
          key: '1',
          apCost: 1,
          cooldown: 0,
          range: 2,
          aoeShape: 'single',
          category: 'enemy_maneuver',
          damageRange: [6, 10],
          element: 'physical',
          uniqueMechanicLabel: 'Opportunist Flanker · +3 Backstab DMG vs ≤60% HP or Afflicted Foes',
          targetType: 'enemy',
          roleClue: 'Opportunist Flanker · +3 vs Wounded',
          description:
            'Darts toward vulnerable targets, dealing +3 Opportunist Backstab DMG against foes at ≤60% HP or afflicted by Burning/Sundered.',
        },
      ],
    },
  ];

  return [...party, ...enemies].sort((a, b) => b.initiative - a.initiative);
}

export const DIALOGUE_NODES: Record<string, DialogueNode> = {
  act1_sanctum_parley: {
    id: 'act1_sanctum_parley',
    speakerName: 'Inquisitor Malakor',
    speakerTitle: 'Herald of the Ashen Rite · Sanctum Gate',
    speakerPortrait: 'inquisitor',
    locationTitle: 'Act I · Sanctum of the Shattered Oath',
    text: '“Halt, Oathbreaker! The Astral Spire bleeds into the Vale, and only by binding the sanctum’s souls into the Ashen Seal can we cage the Rift. Lay down your blades—or be consumed as fuel for the ward!”',
    companionInterjections: [
      {
        companionId: 'seraphina',
        quote: '“He wears the Silver Covenant’s crest, yet he sacrifices the innocent to mask their failure. Do not let his zealotry blind you.”',
      },
      {
        companionId: 'kaelen',
        quote: '“Look at the obelisk’s resonance! If we siphon that raw Blood-Weave instead of sealing it, our spells will hit like falling stars.”',
      },
      {
        companionId: 'thorne',
        quote: '“The very roots under this stone are suffocating. Purify the obelisk, and the land itself will shield us.”',
      },
    ],
    choices: [
      {
        id: 'persuade_purify',
        text: '[Persuasion · Seraphina] “Your Covenant swore to shield the realm, Malakor! Help us purify the Spire without spilling innocent blood.”',
        skillCheck: {
          stat: 'cha',
          skillName: 'Persuasion',
          dc: 12,
          speakerId: 'seraphina',
        },
        approvalDeltas: { seraphina: 15, thorne: 10, kaelen: -5 },
        setWorldFlags: ['sanctum_purified', 'inquisitor_spared'],
        corruptionDelta: -20,
        alignmentShift: 'Mercy',
        combatEffect: 'bless_party',
        nextNodeId: 'END_PEACEFUL_BUFF',
        outcomeSummary:
          'The Astral Obelisk blazes with purified gold! Malakor’s resolve wavers (-4 Enemy HP), Rift hazards clear, and the party gains +6 Max HP & Blessed.',
      },
      {
        id: 'arcana_siphon',
        text: '[Arcana · Kaelen] “Shatter his containment glyphs and drink the raw Blood-Weave from the Spire!”',
        skillCheck: {
          stat: 'int',
          skillName: 'Arcana',
          dc: 13,
          speakerId: 'kaelen',
        },
        approvalDeltas: { kaelen: 18, seraphina: -8, thorne: -6 },
        setWorldFlags: ['blood_weave_unleashed'],
        corruptionDelta: 25,
        alignmentShift: 'Dominion',
        combatEffect: 'empower_kaelen',
        nextNodeId: 'END_COMBAT',
        outcomeSummary:
          'Crimson lightning surges through your party! All party attacks gain +3 Bonus Damage as the Astral Rift turns blood-red.',
      },
      {
        id: 'nature_ward',
        text: '[Nature · Thorne] “Call upon the ancient Sylvan Briar beneath the flagstones to crack their formation.”',
        skillCheck: {
          stat: 'dex',
          skillName: 'Nature',
          dc: 12,
          speakerId: 'thorne',
        },
        approvalDeltas: { thorne: 16, seraphina: 8, kaelen: 4 },
        setWorldFlags: ['sanctum_purified', 'briar_ward_awakened'],
        corruptionDelta: -15,
        alignmentShift: 'Balance',
        combatEffect: 'weaken_enemies',
        nextNodeId: 'END_COMBAT',
        outcomeSummary:
          'Emerald roots erupt through the sanctum floor, purifying the Rift tiles and sundering enemy armor before battle begins!',
      },
      {
        id: 'direct_attack',
        text: '[Draw Weapons] “Enough words. We carve our own path through the Sanctum!”',
        approvalDeltas: { seraphina: 5, kaelen: 5, thorne: 5 },
        alignmentShift: 'Balance',
        nextNodeId: 'END_COMBAT',
        outcomeSummary: 'Blades ring out across the Sanctum as tactical combat begins immediately.',
      },
    ],
  },
  act2_briar_parley: {
    id: 'act2_briar_parley',
    speakerName: 'Blight-Warden Vael',
    speakerTitle: 'Corrupted Sylvan Knight · Thornwood Crossing',
    speakerPortrait: 'oracle',
    locationTitle: 'Act II · The Blighted Briar Crossing',
    text: '“The Heart-Briar drinks the Rift’s sorrow... Turn back, wanderers, or let the iron-thorns bind your bones to the eternal watch!”',
    companionInterjections: [
      {
        companionId: 'thorne',
        quote: '“Vael was my mentor in the Sylvan Circle! Reach the sliver of his spirit that still remembers the Green Oath!”',
      },
      {
        companionId: 'kaelen',
        quote: '“His armor is fused with Void-quartz. A precise arcane harmonic will destabilize his shield matrix.”',
      },
    ],
    choices: [
      {
        id: 'thorne_oath_recall',
        text: '[Insight · Thorne] “By the First Leaf and the Autumn Watch, Vael—remember who you swore to protect!”',
        skillCheck: {
          stat: 'dex',
          skillName: 'Insight',
          dc: 13,
          speakerId: 'thorne',
        },
        approvalDeltas: { thorne: 18, seraphina: 12, kaelen: 2 },
        setWorldFlags: ['sanctum_purified', 'briar_ward_awakened'],
        corruptionDelta: -20,
        alignmentShift: 'Mercy',
        combatEffect: 'heal_party',
        nextNodeId: 'END_PEACEFUL_BUFF',
        outcomeSummary:
          'Vael’s corrupted visor cracks with emerald tears! The Briar blesses your party with full vitality and Warded armor.',
      },
      {
        id: 'intimidate_vael',
        text: '[Intimidation · Seraphina] “Stand aside, revenant, orDawnfire will burn this crossing to ash!”',
        skillCheck: {
          stat: 'str',
          skillName: 'Intimidation',
          dc: 12,
          speakerId: 'seraphina',
        },
        approvalDeltas: { seraphina: 12, kaelen: 10, thorne: -5 },
        setWorldFlags: ['blood_weave_unleashed'],
        corruptionDelta: 15,
        alignmentShift: 'Dominion',
        combatEffect: 'weaken_enemies',
        nextNodeId: 'END_COMBAT',
        outcomeSummary:
          'Your thunderous vow shakes the Blight-host, sundering enemy defenses at the start of battle.',
      },
    ],
  },
  act3_reliquary_parley: {
    id: 'act3_reliquary_parley',
    speakerName: 'Archon Severin the Hollow',
    speakerTitle: 'Sovereign of the Rift · Sunken Reliquary',
    speakerPortrait: 'archon',
    locationTitle: 'Act III · The Sunken Astral Reliquary',
    text: '“You stand before the Crown of Echoes! Every oath you kept or broke in Dimraeth converges here. Will you shatter the Crown to free the Vale, or claim its dominion for yourselves?”',
    companionInterjections: [
      {
        companionId: 'seraphina',
        quote: '“Shatter the Crown! No mortal or god should cage the souls of Dimraeth again!”',
      },
      {
        companionId: 'kaelen',
        quote: '“Think of what we could rewrite with the Crown intact! The planes themselves would bow to our design.”',
      },
      {
        companionId: 'thorne',
        quote: '“Let the earth reclaim its quiet. End Severin’s vigil and heal the Rift!”',
      },
    ],
    choices: [
      {
        id: 'shatter_crown',
        text: '[Persuasion · Seraphina] “We shatter the Crown of Echoes and restore the Vale’s freedom!”',
        skillCheck: {
          stat: 'cha',
          skillName: 'Persuasion',
          dc: 14,
          speakerId: 'seraphina',
        },
        approvalDeltas: { seraphina: 20, thorne: 18, kaelen: -6 },
        setWorldFlags: ['astral_crown_shattered', 'sanctum_purified'],
        corruptionDelta: -30,
        alignmentShift: 'Mercy',
        combatEffect: 'bless_party',
        nextNodeId: 'END_PEACEFUL_BUFF',
        outcomeSummary:
          'Radiant dawnlight floods the Sunken Reliquary! Your companions stand united with maximum Blessing for the final clash.',
      },
      {
        id: 'claim_crown',
        text: '[Arcana · Kaelen] “Bind the Crown of Echoes to our Blood-Weave and seize sovereignty over the Rift!”',
        skillCheck: {
          stat: 'int',
          skillName: 'Arcana',
          dc: 14,
          speakerId: 'kaelen',
        },
        approvalDeltas: { kaelen: 22, seraphina: -12, thorne: -10 },
        setWorldFlags: ['astral_crown_claimed', 'blood_weave_unleashed'],
        corruptionDelta: 30,
        alignmentShift: 'Dominion',
        combatEffect: 'empower_kaelen',
        nextNodeId: 'END_COMBAT',
        outcomeSummary:
          'You claim the Astral Crown’s forbidden power! Arcane lightning surges through every strike.',
      },
    ],
  },
};

export type CharacterRaceId = 'half_elf' | 'tiefling' | 'wood_kin' | 'astral_human';
export type CharacterClassId = 'paladin' | 'arcanist' | 'warden';
export type CharacterSubclassId =
  | 'dawn_warden'
  | 'vengeance_knight'
  | 'crimson_savant'
  | 'rift_chronomancer'
  | 'briar_stalker'
  | 'ironbough_sentinel';

export interface CharacterRaceOption {
  id: CharacterRaceId;
  name: string;
  tagline: string;
  lore: string;
  statBonuses: { str: number; dex: number; int: number; cha: number };
  hpBonus: number;
  acBonus: number;
  moveBonus: number;
  initiativeBonus: number;
  approvalBonus: number;
  traitName: string;
  traitSummary: string;
}

export interface CharacterSubclassOption {
  id: CharacterSubclassId;
  classId: CharacterClassId;
  name: string;
  titleSuffix: string;
  specialty: string;
  description: string;
  statBonuses: { str: number; dex: number; int: number; cha: number };
  hpBonus: number;
  acBonus: number;
  moveBonus: number;
  initiativeBonus: number;
  startingStatus: 'blessed' | 'warded';
  signatureAbility: Ability;
}

export interface CharacterClassOption {
  id: CharacterClassId;
  name: string;
  roleLabel: string;
  description: string;
  baseStats: { str: number; dex: number; int: number; cha: number };
  baseHp: number;
  baseAc: number;
  baseMove: number;
  baseInitiative: number;
  subclasses: CharacterSubclassId[];
}

export interface CharacterCreationBuild {
  commanderName: string;
  raceId: CharacterRaceId;
  classId: CharacterClassId;
  subclassId: CharacterSubclassId;
  allocatedStats?: { str: number; dex: number; int: number; cha: number };
  backgroundId?: string;
  personalityId?: string;
  voiceId?: string;
  detailedAppearance?: any;
  appearance?: any;
}

export const CHARACTER_RACES: Record<CharacterRaceId, CharacterRaceOption> = {
  half_elf: {
    id: 'half_elf',
    name: 'Silverborn Half-Elf',
    tagline: '+2 CHA · +1 STR · Fey-Touched Poise',
    lore: 'Scions of the Silver Covenant spires who bridge mortal resolve with timeless astral grace.',
    statBonuses: { str: 1, dex: 0, int: 0, cha: 2 },
    hpBonus: 4,
    acBonus: 0,
    moveBonus: 0,
    initiativeBonus: 1,
    approvalBonus: 5,
    traitName: 'Fey-Touched Poise',
    traitSummary: '+4 Max HP, +1 Initiative, and +5 Starting Companion Approval',
  },
  tiefling: {
    id: 'tiefling',
    name: 'Ashen Tiefling',
    tagline: '+2 INT · +1 CHA · Hellfire Bloodline',
    lore: 'Heirs of the Crimson Eclipse whose veins burn with resonant planar embers.',
    statBonuses: { str: 0, dex: 0, int: 2, cha: 1 },
    hpBonus: 2,
    acBonus: 0,
    moveBonus: 1,
    initiativeBonus: 1,
    approvalBonus: 2,
    traitName: 'Hellfire Bloodline',
    traitSummary: '+1 Move Range, +1 Initiative, and +2 Max HP',
  },
  wood_kin: {
    id: 'wood_kin',
    name: 'Sylvan Wood-Kin',
    tagline: '+2 DEX · +1 STR · Fleetfoot Barkskin',
    lore: 'Ancient guardians of the Whispering Vale whose reflexes match the wind through ironwood boughs.',
    statBonuses: { str: 1, dex: 2, int: 0, cha: 0 },
    hpBonus: 2,
    acBonus: 1,
    moveBonus: 1,
    initiativeBonus: 2,
    approvalBonus: 3,
    traitName: 'Fleetfoot Barkskin',
    traitSummary: '+1 Armor Class, +1 Move Range, and +2 Initiative',
  },
  astral_human: {
    id: 'astral_human',
    name: 'Highborne Human',
    tagline: '+1 All Stats · +6 Max HP · Sovereign Adaptability',
    lore: 'Disciplined commanders of the fallen frontier bastions, forged in relentless tactical campaigns.',
    statBonuses: { str: 1, dex: 1, int: 1, cha: 1 },
    hpBonus: 6,
    acBonus: 0,
    moveBonus: 0,
    initiativeBonus: 2,
    approvalBonus: 4,
    traitName: 'Sovereign Adaptability',
    traitSummary: '+6 Max HP, +2 Initiative, and +4 Companion Approval',
  },
};

export const CHARACTER_SUBCLASSES: Record<CharacterSubclassId, CharacterSubclassOption> = {
  dawn_warden: {
    id: 'dawn_warden',
    classId: 'paladin',
    name: 'Oath of the Dawn Warden',
    titleSuffix: 'Dawn Warden Paladin',
    specialty: 'Sanctified Bulwark & Radiant Mending',
    description: 'Channels unbroken solar wards to shield the vanguard and purify corrupted ground.',
    statBonuses: { str: 1, dex: 0, int: 0, cha: 2 },
    hpBonus: 4,
    acBonus: 1,
    moveBonus: 0,
    initiativeBonus: 0,
    startingStatus: 'warded',
    signatureAbility: {
      id: 'dawnbreaker_judgment',
      name: 'Dawnbreaker Judgment',
      key: '2',
      apCost: 2,
      cooldown: 2,
      range: 3,
      aoeRadius: 1,
      aoeShape: 'solar_cross',
      category: 'consecration_judgment',
      damageRange: [15, 22],
      element: 'radiant',
      statusEffect: 'sundered',
      uniqueMechanicLabel: '5-Tile Solar Cross Consecration & +6 HP / Blessed Pulse to Allies in Cross',
      targetType: 'enemy',
      roleClue: '5-Tile Solar Cross · Sunder Foe & Heal Allies',
      description:
        'Call down a cruciform solar pillar (15–22 Radiant DMG + Sundered) that consecrates a 5-tile cross into Sanctified Ground and heals allies in the cross for +6 HP & Blessed.',
    },
  },
  vengeance_knight: {
    id: 'vengeance_knight',
    classId: 'paladin',
    name: 'Oath of Shattered Vengeance',
    titleSuffix: 'Vengeance Oathbreaker',
    specialty: 'Relentless Execution & Astral Smite',
    description: 'Forsakes defensive restraint to deliver devastating greatsword executions.',
    statBonuses: { str: 2, dex: 1, int: 0, cha: 0 },
    hpBonus: 2,
    acBonus: 0,
    moveBonus: 0,
    initiativeBonus: 1,
    startingStatus: 'blessed',
    signatureAbility: {
      id: 'searing_smite',
      name: 'Oathbreaker Smite',
      key: '2',
      apCost: 2,
      cooldown: 2,
      range: 2,
      aoeShape: 'single',
      category: 'execution_gapcloser',
      damageRange: [16, 24],
      element: 'radiant',
      selfReposition: 'leap_adjacent',
      refundApOnKO: 1,
      statusEffect: 'sundered',
      uniqueMechanicLabel: 'Gap-Close Leap · +6 Execution DMG vs ≤50% HP · +1 AP Refund on Kill',
      targetType: 'enemy',
      roleClue: 'Execution Leap · +6 vs Bloodied & +1 AP KO',
      description:
        'Leap into melee with fractured astral judgment (16–24 Radiant DMG + Sundered), dealing +6 Execution DMG against targets at ≤50% HP and refunding +1 AP on a kill.',
    },
  },
  crimson_savant: {
    id: 'crimson_savant',
    classId: 'arcanist',
    name: 'Crimson Savant',
    titleSuffix: 'Crimson Savant Arcanist',
    specialty: 'Pyromantic Detonation & Blood-Sigils',
    description: 'Ignites the battlefield with volatile Blood-Weave firestorms and searing lances.',
    statBonuses: { str: 0, dex: 0, int: 3, cha: 1 },
    hpBonus: 0,
    acBonus: 0,
    moveBonus: 0,
    initiativeBonus: 1,
    startingStatus: 'blessed',
    signatureAbility: {
      id: 'searing_blood_nova',
      name: 'Searing Blood-Nova',
      key: '2',
      apCost: 2,
      cooldown: 2,
      range: 5,
      aoeRadius: 1,
      aoeShape: 'chebyshev_3x3',
      category: 'pyromantic_detonation',
      damageRange: [16, 23],
      element: 'fire',
      statusEffect: 'burning',
      uniqueMechanicLabel: '3×3 Pyromantic Blast (6 DMG Secondary) · +5 Thermal Resonance vs Burning',
      targetType: 'enemy',
      roleClue: '3×3 Nova · +5 vs Burning & Chain Ignition',
      description:
        'Detonate a 3×3 crimson firestorm at range 5 (16–23 Fire DMG +5 Resonance vs Burning) that scorches surrounding foes for 6 Fire DMG and chain-ignites oil & barrels.',
    },
  },
  rift_chronomancer: {
    id: 'rift_chronomancer',
    classId: 'arcanist',
    name: 'Rift Chronomancer',
    titleSuffix: 'Rift Chronomancer',
    specialty: 'Spacetime Control & Astral Barriers',
    description: 'Warps temporal ley-lines to immobilize enemies and phase through danger.',
    statBonuses: { str: 0, dex: 1, int: 2, cha: 1 },
    hpBonus: 2,
    acBonus: 1,
    moveBonus: 1,
    initiativeBonus: 2,
    startingStatus: 'warded',
    signatureAbility: {
      id: 'chrono_rift_collapse',
      name: 'Chrono-Rift Collapse',
      key: '2',
      apCost: 2,
      cooldown: 2,
      range: 5,
      aoeRadius: 2,
      aoeShape: 'vacuum_implosion',
      category: 'spacetime_implosion',
      damageRange: [14, 21],
      element: 'arcane',
      statusEffect: 'rooted',
      uniqueMechanicLabel: 'Radius-2 Gravitational Singularity Vacuum Pull Inward (+4 Warp DMG) & Root',
      targetType: 'enemy',
      roleClue: 'Vacuum Implosion · Roots & Pulls Foes Inward',
      description:
        'Collapse a localized spacetime rift (14–21 Arcane DMG + Rooted) that vacuums all other enemies within 2 tiles inward toward the epicenter for 4 Arcane Warp DMG.',
    },
  },
  briar_stalker: {
    id: 'briar_stalker',
    classId: 'warden',
    name: 'Gloom-Briar Stalker',
    titleSuffix: 'Gloom-Briar Stalker',
    specialty: 'Lethal Ambush & Entangling Volleys',
    description: 'Strikes from the canopy shadows with thorn-laced shafts that pin foes in place.',
    statBonuses: { str: 1, dex: 3, int: 0, cha: 0 },
    hpBonus: 2,
    acBonus: 0,
    moveBonus: 1,
    initiativeBonus: 2,
    startingStatus: 'blessed',
    signatureAbility: {
      id: 'heart_briar_volley',
      name: 'Heart-Briar Volley',
      key: '2',
      apCost: 2,
      cooldown: 2,
      range: 5,
      aoeRadius: 1,
      aoeShape: 'briar_wall_3',
      category: 'briar_barricade',
      damageRange: [15, 22],
      element: 'nature',
      statusEffect: 'rooted',
      uniqueMechanicLabel: '+5 Isolated Ambush DMG & Raises 3-Tile Perpendicular Briar-Thorn Wall',
      targetType: 'enemy',
      roleClue: '3-Tile Briar Wall · +5 Isolated & Roots Line',
      description:
        'Loose living ironwood thorns (15–22 Nature DMG, +5 Ambush DMG against isolated foes) that raise a 3-tile perpendicular wall of Bramble Snares across the grid.',
    },
  },
  ironbough_sentinel: {
    id: 'ironbough_sentinel',
    classId: 'warden',
    name: 'Ironbough Sentinel',
    titleSuffix: 'Ironbough Sentinel',
    specialty: 'Living Bark Armor & Primal Counterstrike',
    description: 'Stands immovable as ancient oak, shattering enemy armor with heavy sylvan strikes.',
    statBonuses: { str: 2, dex: 1, int: 0, cha: 0 },
    hpBonus: 6,
    acBonus: 1,
    moveBonus: 0,
    initiativeBonus: 1,
    startingStatus: 'warded',
    signatureAbility: {
      id: 'ironwood_tempest',
      name: 'Ironwood Tempest',
      key: '2',
      apCost: 2,
      cooldown: 2,
      range: 3,
      aoeRadius: 1,
      aoeShape: 'shockwave_ring',
      category: 'seismic_glaive',
      damageRange: [15, 22],
      grantTempHp: 5,
      element: 'physical',
      pushDistance: 1,
      statusEffect: 'sundered',
      uniqueMechanicLabel: 'Adjacent Seismic Shockwave (5 DMG) + Self Warded (+2 AC) & +5 Temp HP',
      targetType: 'enemy',
      roleClue: 'Seismic Glaive · Sunder, Shockwave & Self +2 AC',
      description:
        'Unleash an ironwood glaive tempest (15–22 Physical DMG + Sundered + Push 1) that batters orthogonal foes for 5 DMG and grants you Warded (+2 AC) & +5 Temp HP.',
    },
  },
};

export const CHARACTER_CLASSES: Record<CharacterClassId, CharacterClassOption> = {
  paladin: {
    id: 'paladin',
    name: 'Oathbreaker Paladin',
    roleLabel: 'Frontline Martial & Radiant Conduit',
    description: 'Commands the vanguard in heavy plate, blending searing greatsword strikes with sanctifying wards.',
    baseStats: { str: 16, dex: 12, int: 11, cha: 14 },
    baseHp: 40,
    baseAc: 15,
    baseMove: 4,
    baseInitiative: 19,
    subclasses: ['dawn_warden', 'vengeance_knight'],
  },
  arcanist: {
    id: 'arcanist',
    name: 'Blood-Weave Arcanist',
    roleLabel: 'Ranged Spellblade & Ley-Line Scholar',
    description: 'Harnesses forbidden astral sigils and pyromantic singularities to reshape the tactical grid.',
    baseStats: { str: 10, dex: 14, int: 16, cha: 14 },
    baseHp: 34,
    baseAc: 14,
    baseMove: 4,
    baseInitiative: 20,
    subclasses: ['crimson_savant', 'rift_chronomancer'],
  },
  warden: {
    id: 'warden',
    name: 'Sylvan Warden',
    roleLabel: 'High-Mobility Skirmisher & Vale Guardian',
    description: 'Masters ranged precision, living bramble snares, and ironwood resilience across elevated terrain.',
    baseStats: { str: 13, dex: 16, int: 12, cha: 12 },
    baseHp: 38,
    baseAc: 14,
    baseMove: 5,
    baseInitiative: 21,
    subclasses: ['briar_stalker', 'ironbough_sentinel'],
  },
};

export interface ComputedCharacterBuildPreview {
  commanderName: string;
  race: CharacterRaceOption;
  classDef: CharacterClassOption;
  subclass: CharacterSubclassOption;
  stats: { str: number; dex: number; int: number; cha: number };
  maxHp: number;
  armorClass: number;
  moveRange: number;
  initiative: number;
  startingStatus: 'blessed' | 'warded';
  signatureAbility: Ability;
  fullLineageTitle: string;
}

export function createDefaultCharacterBuild(): CharacterCreationBuild {
  return {
    commanderName: 'Seraphina Vane',
    raceId: 'half_elf',
    classId: 'paladin',
    subclassId: 'vengeance_knight',
  };
}

export function computeCharacterBuildPreview(
  build: CharacterCreationBuild
): ComputedCharacterBuildPreview {
  const race = CHARACTER_RACES[build.raceId] ?? CHARACTER_RACES.half_elf;
  const classDef = CHARACTER_CLASSES[build.classId] ?? CHARACTER_CLASSES.paladin;
  const validSubclassId = classDef.subclasses.includes(build.subclassId)
    ? build.subclassId
    : classDef.subclasses[0];
  const subclass = CHARACTER_SUBCLASSES[validSubclassId];

  const alloc = build.allocatedStats ?? { str: 0, dex: 0, int: 0, cha: 0 };
  const stats = {
    str: classDef.baseStats.str + race.statBonuses.str + subclass.statBonuses.str + alloc.str,
    dex: classDef.baseStats.dex + race.statBonuses.dex + subclass.statBonuses.dex + alloc.dex,
    int: classDef.baseStats.int + race.statBonuses.int + subclass.statBonuses.int + alloc.int,
    cha: classDef.baseStats.cha + race.statBonuses.cha + subclass.statBonuses.cha + alloc.cha,
  };

  const maxHp = classDef.baseHp + race.hpBonus + subclass.hpBonus;
  const armorClass = classDef.baseAc + race.acBonus + subclass.acBonus;
  const moveRange = classDef.baseMove + race.moveBonus + subclass.moveBonus;
  const initiative = classDef.baseInitiative + race.initiativeBonus + subclass.initiativeBonus;
  const cleanName = build.commanderName.trim() || 'Seraphina Vane';

  return {
    commanderName: cleanName,
    race,
    classDef,
    subclass,
    stats,
    maxHp,
    armorClass,
    moveRange,
    initiative,
    startingStatus: subclass.startingStatus,
    signatureAbility: subclass.signatureAbility,
    fullLineageTitle: `${race.name} · ${classDef.name} (${subclass.name})`,
  };
}

export function applyCharacterBuildToParty(
  units: CombatUnit[],
  relationships: Record<CompanionId, CompanionRelationship>,
  build: CharacterCreationBuild
): {
  units: CombatUnit[];
  relationships: Record<CompanionId, CompanionRelationship>;
} {
  const preview = computeCharacterBuildPreview(build);

  const updatedUnits = units.map((unit) => {
    if (unit.id !== 'seraphina') return unit;

    const kaelenTemplate = units.find((u) => u.id === 'kaelen');
    const thorneTemplate = units.find((u) => u.id === 'thorne');

    const updatedAbilities = unit.abilities.map((ab) => {
      if (ab.key === '2') {
        return { ...preview.signatureAbility };
      }
      if (preview.classDef.id === 'arcanist') {
        if (ab.key === '1') {
          return {
            id: 'astral_soul_blade',
            name: 'Astral Soul-Blade',
            key: '1' as const,
            apCost: 1,
            cooldown: 0,
            range: 4,
            aoeShape: 'piercing_ray' as const,
            category: 'piercing_ray' as const,
            damageRange: [8, 13] as [number, number],
            element: 'fire' as const,
            pushDistance: 1,
            uniqueMechanicLabel: 'Linear Piercing Fire-Ray (5 Fire DMG + Burn Behind) & Push 1',
            targetType: 'enemy' as const,
            roleClue: 'Piercing Ray 4 · Scorches Line & Push 1',
            description:
              'Project a condensed astral-fire blade at range 4 that shoves the primary target 1 tile, ignites oil, and pierces foes behind them for 5 Fire DMG & Burning.',
          };
        }
        if (ab.key === '3') {
          const bind = kaelenTemplate?.abilities.find((a) => a.key === '3');
          if (bind) return { ...bind };
        }
        if (ab.key === '4') {
          const conduit = kaelenTemplate?.abilities.find((a) => a.key === '4');
          if (conduit) return { ...conduit };
        }
      }
      if (preview.classDef.id === 'warden') {
        if (ab.key === '1') {
          return {
            id: 'briarfang_strike',
            name: 'Briarfang Strike',
            key: '1' as const,
            apCost: 1,
            cooldown: 0,
            range: 3,
            aoeShape: 'single' as const,
            category: 'predator_strike' as const,
            damageRange: [9, 14] as [number, number],
            element: 'nature' as const,
            uniqueMechanicLabel: 'Predator Exploit (+4 DMG vs Rooted/Sundered) & Sprouts Briar Snare',
            targetType: 'enemy' as const,
            roleClue: 'Predator 3 · +4 vs Root/Sunder & Briars',
            description:
              'Lunge with an ironwood spear-fang at range 3, dealing +4 Predator DMG against Rooted or Sundered prey and sprouting entangling Briar-Thorns beneath them.',
          };
        }
        if (ab.key === '3') {
          const barrage = thorneTemplate?.abilities.find((a) => a.key === '3');
          if (barrage) return { ...barrage };
        }
        if (ab.key === '4') {
          const salve = thorneTemplate?.abilities.find((a) => a.key === '4');
          if (salve) return { ...salve };
        }
      }
      return ab;
    });

    const hasStartingStatus = unit.statuses.some((s) => s.type === preview.startingStatus);
    const nextStatuses = hasStartingStatus
      ? unit.statuses
      : [...unit.statuses, { type: preview.startingStatus, turnsLeft: 2 }];

    return {
      ...unit,
      name: preview.commanderName,
      title: preview.subclass.titleSuffix,
      hp: preview.maxHp,
      maxHp: preview.maxHp,
      armorClass: preview.armorClass,
      moveRange: preview.moveRange,
      initiative: preview.initiative,
      stats: { ...preview.stats },
      abilities: updatedAbilities,
      statuses: nextStatuses,
    };
  });

  const updatedRelationships: Record<CompanionId, CompanionRelationship> = {
    ...relationships,
    seraphina: {
      ...relationships.seraphina,
      name: preview.commanderName,
      title: preview.subclass.titleSuffix,
      raceClass: `${preview.race.name} · ${preview.subclass.name}`,
      approval: Math.min(100, relationships.seraphina.approval + preview.race.approvalBonus),
    },
    kaelen: {
      ...relationships.kaelen,
      approval: Math.min(100, relationships.kaelen.approval + preview.race.approvalBonus),
    },
    thorne: {
      ...relationships.thorne,
      approval: Math.min(100, relationships.thorne.approval + preview.race.approvalBonus),
    },
  };

  return {
    units: [...updatedUnits].sort((a, b) => b.initiative - a.initiative),
    relationships: updatedRelationships,
  };
}

/**
 * PART VIII — WARRIOR CORE SKILL FAMILY COMBAT TEST ENCOUNTER
 * Creates a dedicated 10x10 tactical proving ground with:
 * - Warrior Commander + 2 Party Allies (for Battlefield Commander & zero-friendly-fire validation)
 * - High-Defense Bastion Juggernaut (AC 18, adjacent to Warrior for Sundering Strike & Iron Reprisal)
 * - Low-Defense Ashen Cutthroat (AC 11, adjacent to Warrior for Whirlwind Assault & Relentless Pursuit)
 * - High-Mobility Wind-Runner (Move 6, adjacent to Warrior for Crippling Blow & 3-target Whirlwind)
 * - Unstoppable Anchor-Golem (Immune to Sundered, Rooted, and Forced Displacement)
 * - Aligned Line Targets (Shieldbearer + Ranged Weaver + Area Pyromancer) & Pillar Obstacles for Earthsplitter, Driving Assault, & Weapon Parry validation.
 */
export function createWarriorTrialGroundsEncounter(
  worldState: WorldReactivityState
): {
  grid: GridTile[][];
  envObjects: TacticalEnvObject[];
  units: CombatUnit[];
} {
  const grid = generateTacticalGrid(0, worldState);
  // Ensure clear pillar obstacles at (2,4) and (7,4) and a walkable line from (4,6) -> (5,6) -> (6,6)
  for (let x = 0; x < GRID_SIZE; x++) {
    for (let z = 0; z < GRID_SIZE; z++) {
      grid[x][z].surface = 'none';
      if ((x === 2 && z === 4) || (x === 7 && z === 4) || (x === 8 && z === 6)) {
        grid[x][z].terrain = 'pillar';
        grid[x][z].walkable = false;
      } else if ((x === 4 && z === 4) || (x === 5 && z === 4)) {
        grid[x][z].terrain = 'hazard_rift';
        grid[x][z].walkable = true;
      } else if (x === 6 && z === 4) {
        grid[x][z].terrain = 'stone';
        grid[x][z].surface = 'fire_pool';
        grid[x][z].walkable = true;
      } else {
        grid[x][z].terrain = 'stone';
        grid[x][z].walkable = true;
      }
    }
  }

  const baseUnits = createEncounterUnits(0, worldState);
  const seraphina = baseUnits.find((u) => u.id === 'seraphina')!;
  const kaelen = baseUnits.find((u) => u.id === 'kaelen')!;
  const thorne = baseUnits.find((u) => u.id === 'thorne')!;

  const warriorCommander: CombatUnit = {
    ...seraphina,
    name: 'Vanguard Commander',
    title: 'Warrior · Trial Proving Grounds',
    gridX: 3,
    gridZ: 7,
    elevation: 0,
    hp: 48,
    maxHp: 48,
    ap: 4,
    maxAp: 4,
    moveRange: 4,
    armorClass: 16,
    initiative: 25,
    damageTakenSinceLastTurn: 8,
    abilities: [
      {
        id: 'sundering_strike',
        name: 'Sundering Strike',
        key: '1',
        apCost: 1,
        cooldown: 0,
        range: 1,
        aoeShape: 'single',
        category: 'martial_cleave',
        damageRange: [9, 14],
        element: 'physical',
        statusEffect: 'sundered',
        uniqueMechanicLabel: 'Sunders target armor (-2 AC) and deals +3 bonus cleave if target was already sundered.',
        targetType: 'enemy',
        roleClue: '1d6 + STR + 3 · STR',
        description: 'Deliver a crushing overhead blow that shatters enemy plate, inflicting Sundered (-2 AC) for 2 turns.',
      },
      {
        id: 'whirlwind_assault',
        name: 'Whirlwind Assault',
        key: '2',
        apCost: 2,
        cooldown: 2,
        range: 1,
        aoeRadius: 1,
        aoeShape: 'shockwave_ring',
        category: 'martial_cleave',
        damageRange: [8, 13],
        element: 'physical',
        uniqueMechanicLabel: 'Spins greatsword in a 360-degree sweep around the Warrior, cleaving all adjacent enemies within 1 tile once.',
        targetType: 'enemy',
        roleClue: '1d8 + STR + 2 (All Adjacent Enemies) · STR',
        description: 'Perform a sweeping 360-degree blade rotation that strikes all adjacent foes once for 8-13 physical DMG.',
      },
      {
        id: 'driving_assault',
        name: 'Driving Assault',
        key: '3',
        apCost: 2,
        cooldown: 2,
        range: 3,
        aoeShape: 'single',
        category: 'execution_gapcloser',
        damageRange: [11, 16],
        pushDistance: 2,
        selfReposition: 'leap_adjacent',
        element: 'physical',
        statusEffect: 'sundered',
        uniqueMechanicLabel: 'Vanguard bull-rush across up to 3 tiles; stops at first enemy struck and shoves target 2 tiles back.',
        targetType: 'enemy',
        roleClue: '1d10 + STR + 4 + Push 2 · STR',
        description: 'Rush across up to 3 tiles to ram the target, dealing 11-16 DMG, pushing them 2 tiles back, and inflicting Sundered.',
      },
      {
        id: 'earthsplitter',
        name: 'Earthsplitter',
        key: '4',
        apCost: 2,
        cooldown: 3,
        range: 3,
        aoeShape: 'piercing_ray',
        category: 'seismic_glaive',
        damageRange: [14, 20],
        element: 'physical',
        statusEffect: 'sundered',
        uniqueMechanicLabel: 'Slams great weapon into stone, projecting a 3-tile directional ground fracture that damages and sunders each enemy on the line.',
        targetType: 'enemy',
        roleClue: '2d8 + STR (3-Tile Fracture) · STR',
        description: 'Drive your blade into the earth to project a 3-tile linear fracture, dealing 14-20 physical DMG and Sundering enemies along the line.',
      },
    ],
  };

  const trialAllies: CombatUnit[] = [
    warriorCommander,
    { ...kaelen, gridX: 1, gridZ: 8, initiative: 20 },
    { ...thorne, gridX: 5, gridZ: 8, initiative: 19 },
  ];

  const trialEnemies: CombatUnit[] = [
    {
      id: 'trial_high_defense',
      name: 'Bastion Plate-Juggernaut',
      title: 'High-Defense Test Target (AC 18)',
      faction: 'enemy',
      archetype: 'inquisitor',
      gridX: 3,
      gridZ: 6,
      elevation: 0,
      hp: 45,
      maxHp: 45,
      tempHp: 0,
      ap: 2,
      maxAp: 2,
      moveRange: 3,
      movedThisTurn: false,
      armorClass: 18,
      initiative: 14,
      stats: { str: 18, dex: 10, int: 10, cha: 12 },
      cooldowns: {},
      statuses: [],
      isKO: false,
      koTimer: 0,
      abilities: baseUnits.find((u) => u.faction === 'enemy')!.abilities,
    },
    {
      id: 'trial_low_defense',
      name: 'Ashen Cutthroat',
      title: 'Low-Defense Bloodied Target (AC 11 · <=40% HP)',
      faction: 'enemy',
      archetype: 'stalker',
      gridX: 4,
      gridZ: 7,
      elevation: 0,
      hp: 10,
      maxHp: 28,
      tempHp: 0,
      ap: 2,
      maxAp: 2,
      moveRange: 4,
      movedThisTurn: false,
      armorClass: 11,
      initiative: 13,
      stats: { str: 12, dex: 15, int: 10, cha: 10 },
      cooldowns: {},
      statuses: [],
      isKO: false,
      koTimer: 0,
      abilities: baseUnits.find((u) => u.archetype === 'stalker')!.abilities,
    },
    {
      id: 'trial_high_mobility',
      name: 'Wind-Runner Skirmisher',
      title: 'High-Mobility Test Target (Move 6)',
      faction: 'enemy',
      archetype: 'stalker',
      gridX: 2,
      gridZ: 7,
      elevation: 0,
      hp: 26,
      maxHp: 26,
      tempHp: 0,
      ap: 2,
      maxAp: 2,
      moveRange: 6,
      movedThisTurn: false,
      armorClass: 13,
      initiative: 12,
      stats: { str: 12, dex: 18, int: 10, cha: 10 },
      cooldowns: {},
      statuses: [],
      isKO: false,
      koTimer: 0,
      abilities: baseUnits.find((u) => u.archetype === 'stalker')!.abilities,
    },
    {
      id: 'trial_melee_boss',
      name: 'Executioner Vaelgor',
      title: 'Melee Boss (Heavy Melee Striker)',
      faction: 'enemy',
      archetype: 'inquisitor',
      gridX: 3,
      gridZ: 8,
      elevation: 0,
      hp: 65,
      maxHp: 65,
      tempHp: 0,
      ap: 2,
      maxAp: 2,
      moveRange: 3,
      movedThisTurn: false,
      armorClass: 16,
      initiative: 15,
      stats: { str: 20, dex: 12, int: 10, cha: 14 },
      cooldowns: {},
      statuses: [],
      isKO: false,
      koTimer: 0,
      abilities: baseUnits.find((u) => u.faction === 'enemy')!.abilities,
    },
    {
      id: 'trial_unstoppable',
      name: 'Colossus Anchor-Golem',
      title: 'Root & Sunder Immune Target',
      faction: 'enemy',
      archetype: 'bruiser',
      gridX: 1,
      gridZ: 5,
      elevation: 0,
      hp: 40,
      maxHp: 40,
      tempHp: 0,
      ap: 2,
      maxAp: 2,
      moveRange: 2,
      movedThisTurn: false,
      armorClass: 14,
      initiative: 11,
      stats: { str: 18, dex: 8, int: 8, cha: 8 },
      cooldowns: {},
      statuses: [],
      immunities: ['rooted', 'displacement', 'sundered'],
      isKO: false,
      koTimer: 0,
      abilities: baseUnits.find((u) => u.faction === 'enemy')!.abilities,
    },
    {
      id: 'trial_displacement_immune',
      name: 'Ironclad Siege-Warden',
      title: 'Displacement-Resistant Target (Near Hazard)',
      faction: 'enemy',
      archetype: 'inquisitor',
      gridX: 6,
      gridZ: 5,
      elevation: 0,
      hp: 38,
      maxHp: 38,
      tempHp: 0,
      ap: 2,
      maxAp: 2,
      moveRange: 2,
      movedThisTurn: false,
      armorClass: 15,
      initiative: 10,
      stats: { str: 17, dex: 10, int: 10, cha: 10 },
      cooldowns: {},
      statuses: [],
      immunities: ['displacement'],
      isKO: false,
      koTimer: 0,
      abilities: baseUnits.find((u) => u.faction === 'enemy')!.abilities,
    },
    {
      id: 'trial_line_front',
      name: 'Covenant Shieldbearer',
      title: 'Line & Hazard Push Target (Front)',
      faction: 'enemy',
      archetype: 'inquisitor',
      gridX: 5,
      gridZ: 6,
      elevation: 0,
      hp: 30,
      maxHp: 30,
      tempHp: 0,
      ap: 2,
      maxAp: 2,
      moveRange: 3,
      movedThisTurn: false,
      armorClass: 13,
      initiative: 10,
      stats: { str: 15, dex: 12, int: 10, cha: 10 },
      cooldowns: {},
      statuses: [],
      isKO: false,
      koTimer: 0,
      abilities: baseUnits.find((u) => u.faction === 'enemy')!.abilities,
    },
    {
      id: 'trial_pillar_behind',
      name: 'Sanctum Acolyte (Behind Pillar)',
      title: 'Pillar-Occluded Line Target (2,3 behind Pillar 2,4)',
      faction: 'enemy',
      archetype: 'weaver',
      gridX: 2,
      gridZ: 3,
      elevation: 0,
      hp: 24,
      maxHp: 24,
      tempHp: 0,
      ap: 2,
      maxAp: 2,
      moveRange: 3,
      movedThisTurn: false,
      armorClass: 12,
      initiative: 8,
      stats: { str: 10, dex: 14, int: 16, cha: 12 },
      cooldowns: {},
      statuses: [],
      isKO: false,
      koTimer: 0,
      abilities: baseUnits.find((u) => u.archetype === 'weaver')!.abilities,
    },
    {
      id: 'trial_ranged_weaver',
      name: 'Rift-Weaver Marksman',
      title: 'Ranged Caster (Range 5)',
      faction: 'enemy',
      archetype: 'weaver',
      gridX: 6,
      gridZ: 6,
      elevation: 0,
      hp: 24,
      maxHp: 24,
      tempHp: 0,
      ap: 2,
      maxAp: 2,
      moveRange: 3,
      movedThisTurn: false,
      armorClass: 12,
      initiative: 9,
      stats: { str: 10, dex: 14, int: 17, cha: 12 },
      cooldowns: {},
      statuses: [],
      isKO: false,
      koTimer: 0,
      abilities: baseUnits.find((u) => u.archetype === 'weaver')!.abilities,
    },
  ];

  return {
    grid,
    envObjects: createEncounterObjects(0),
    units: [...trialAllies, ...trialEnemies].sort((a, b) => b.initiative - a.initiative),
  };
}

/**
 * PART IX — MAGE CORE SKILL FAMILY COMBAT TEST ENCOUNTER
 * Creates a dedicated 10x10 tactical proving ground for Mage Core Skills:
 * - Mage Commander (equipped with all 12 Mage Core Skills) + Companion Kaelen Vos
 * - Inquisitor Vaelgor (Heavily buffed with Warded + Blessed + 15 Temp HP for Arcane Disjunction purge validation)
 * - Swift Stalker (for Glacial Lance Chilled status & +4 Frost bonus shatter testing)
 * - Ranged Rift-Weaver (Range 5 caster for Counterspell ranged/spell reflection validation)
 * - Oil Pool Grunts (standing on oil pools near explosive barrels for Infernal Orb AoE fire ignition testing)
 * - Anchored Golem & Clustered Foes (for Gravitational Collapse, Runic Mine, Astral Rift, and Prismatic Field validation)
 */
export function createMageTrialGroundsEncounter(
  worldState: WorldReactivityState
): {
  grid: GridTile[][];
  envObjects: TacticalEnvObject[];
  units: CombatUnit[];
} {
  const grid = generateTacticalGrid(0, worldState);
  for (let x = 0; x < GRID_SIZE; x++) {
    for (let z = 0; z < GRID_SIZE; z++) {
      grid[x][z].surface = 'none';
      if ((x === 2 && z === 4) || (x === 7 && z === 4)) {
        grid[x][z].terrain = 'pillar';
        grid[x][z].walkable = false;
      } else if (x === 4 && z === 5) {
        grid[x][z].terrain = 'stone';
        grid[x][z].surface = 'oil_pool';
        grid[x][z].walkable = true;
      } else if (x === 5 && z === 5) {
        grid[x][z].terrain = 'stone';
        grid[x][z].surface = 'oil_pool';
        grid[x][z].walkable = true;
      } else {
        grid[x][z].terrain = 'stone';
        grid[x][z].walkable = true;
      }
    }
  }

  const baseUnits = createEncounterUnits(0, worldState);
  const seraphina = baseUnits.find((u) => u.id === 'seraphina')!;
  const kaelen = baseUnits.find((u) => u.id === 'kaelen')!;

  const mageCommander: CombatUnit = {
    ...seraphina,
    id: 'seraphina',
    name: 'Arcane Savant',
    title: 'Mage · Trial Proving Grounds',
    characterClass: 'mage',
    gridX: 3,
    gridZ: 7,
    elevation: 0,
    hp: 40,
    maxHp: 40,
    ap: 4,
    maxAp: 4,
    moveRange: 4,
    armorClass: 14,
    initiative: 26,
    stats: { str: 10, dex: 14, int: 20, cha: 14 },
    abilities: [
      {
        id: 'infernal_orb',
        name: 'Infernal Orb',
        key: '1',
        apCost: 2,
        cooldown: 2,
        range: 4,
        aoeRadius: 1,
        aoeShape: 'chebyshev_3x3',
        category: 'pyromantic_detonation',
        damageRange: [12, 16],
        element: 'fire',
        statusEffect: 'burning',
        uniqueMechanicLabel: 'Radius 1 Fire AoE (12-16 DMG + Burning 2T) & ignites oil pools/barrels.',
        targetType: 'ground',
        roleClue: 'Fire AoE · Radius 1 · Burns 2T',
        description: 'Hurl a volatile sphere of elemental flame that explodes in a 1-tile radius, dealing 12-16 Fire damage, inflicting Burning, and igniting flammable terrain.',
      },
      {
        id: 'glacial_lance',
        name: 'Glacial Lance',
        key: '2',
        apCost: 2,
        cooldown: 2,
        range: 4,
        aoeShape: 'piercing_ray',
        category: 'piercing_ray',
        damageRange: [10, 14],
        element: 'arcane',
        statusEffect: 'chilled',
        uniqueMechanicLabel: 'Directional 3-tile frost ray. Inflicts Chilled; already-Chilled foes suffer +4 bonus DMG.',
        targetType: 'enemy',
        roleClue: '3-Tile Ray · Chilled 2T · +4 vs Chilled',
        description: 'Conjure a piercing spear of condensed frost that strikes through up to 3 tiles in a line. Deals 10-14 Frost damage, inflicts Chilled, and deals +4 bonus damage to already-Chilled targets.',
      },
      {
        id: 'chain_lightning',
        name: 'Chain Lightning',
        key: '3',
        apCost: 2,
        cooldown: 3,
        range: 4,
        aoeShape: 'single',
        category: 'piercing_ray',
        damageRange: [12, 12],
        element: 'arcane',
        uniqueMechanicLabel: 'Arcs across up to 3 foes (12 -> 8 -> 5 DMG). Deterministic nearest-neighbor.',
        targetType: 'enemy',
        roleClue: 'Arcs 3 Foes · 12/8/5 DMG',
        description: 'Discharge an electric arc that strikes the primary target for 12 damage, then leaps to up to 2 additional nearby enemies for 8 and 5 damage without damaging allies.',
      },
      {
        id: 'blink_step',
        name: 'Blink Step',
        key: '4',
        apCost: 1,
        cooldown: 2,
        range: 4,
        aoeShape: 'single',
        category: 'support',
        damageRange: [0, 0],
        element: 'arcane',
        uniqueMechanicLabel: 'Instant 4-tile teleport. Works while Rooted and avoids opportunity attacks.',
        targetType: 'ground',
        roleClue: 'Teleport 4 Tiles · Bypasses Root',
        description: 'Fold space to instantly teleport to an unoccupied target tile within 4 tiles, crossing obstacles and ignoring Rooted movement restrictions.',
      },
    ],
  };

  const trialAllies: CombatUnit[] = [
    mageCommander,
    { ...kaelen, gridX: 2, gridZ: 8, initiative: 20 },
  ];

  const trialEnemies: CombatUnit[] = [
    {
      id: 'trial_mage_inquisitor',
      name: 'Inquisitor Vaelgor',
      title: 'Buffed Target (Warded + Blessed + 15 Temp HP for Disjunction)',
      faction: 'enemy',
      archetype: 'inquisitor',
      gridX: 4,
      gridZ: 6,
      elevation: 0,
      hp: 35,
      maxHp: 35,
      tempHp: 15,
      ap: 2,
      maxAp: 2,
      moveRange: 3,
      movedThisTurn: false,
      armorClass: 16,
      initiative: 12,
      stats: { str: 18, dex: 10, int: 10, cha: 12 },
      cooldowns: {},
      statuses: [
        { type: 'warded', turnsLeft: 2 },
        { type: 'blessed', turnsLeft: 2 },
      ],
      isKO: false,
      koTimer: 0,
      abilities: baseUnits.find((u) => u.faction === 'enemy')!.abilities,
    },
    {
      id: 'trial_mage_stalker',
      name: 'Ashen Stalker Kith',
      title: 'Mobile Striker (Testing Glacial Lance & Chilled Shatter)',
      faction: 'enemy',
      archetype: 'stalker',
      gridX: 3,
      gridZ: 5,
      elevation: 0,
      hp: 28,
      maxHp: 28,
      tempHp: 0,
      ap: 2,
      maxAp: 2,
      moveRange: 4,
      movedThisTurn: false,
      armorClass: 12,
      initiative: 15,
      stats: { str: 12, dex: 16, int: 10, cha: 10 },
      cooldowns: {},
      statuses: [],
      isKO: false,
      koTimer: 0,
      abilities: baseUnits.find((u) => u.archetype === 'stalker')!.abilities,
    },
    {
      id: 'trial_mage_weaver',
      name: 'Rift-Weaver Marksman',
      title: 'Ranged Caster (Range 5 for Counterspell Reflection)',
      faction: 'enemy',
      archetype: 'weaver',
      gridX: 7,
      gridZ: 5,
      elevation: 0,
      hp: 24,
      maxHp: 24,
      tempHp: 0,
      ap: 2,
      maxAp: 2,
      moveRange: 3,
      movedThisTurn: false,
      armorClass: 12,
      initiative: 10,
      stats: { str: 10, dex: 14, int: 17, cha: 12 },
      cooldowns: {},
      statuses: [],
      isKO: false,
      koTimer: 0,
      abilities: baseUnits.find((u) => u.archetype === 'weaver')!.abilities,
    },
    {
      id: 'trial_mage_oil_grunt1',
      name: 'Covenant Outrider (On Oil Pool)',
      title: 'Oil-Standing Target (4,5 for Infernal Orb AoE)',
      faction: 'enemy',
      archetype: 'stalker',
      gridX: 4,
      gridZ: 5,
      elevation: 0,
      hp: 22,
      maxHp: 22,
      tempHp: 0,
      ap: 2,
      maxAp: 2,
      moveRange: 3,
      movedThisTurn: false,
      armorClass: 12,
      initiative: 8,
      stats: { str: 12, dex: 12, int: 10, cha: 10 },
      cooldowns: {},
      statuses: [],
      isKO: false,
      koTimer: 0,
      abilities: baseUnits.find((u) => u.archetype === 'stalker')!.abilities,
    },
    {
      id: 'trial_mage_oil_grunt2',
      name: 'Covenant Shieldbearer (Near Barrel)',
      title: 'Adjacent Oil Target (5,5 for Chain Reaction)',
      faction: 'enemy',
      archetype: 'inquisitor',
      gridX: 5,
      gridZ: 5,
      elevation: 0,
      hp: 26,
      maxHp: 26,
      tempHp: 0,
      ap: 2,
      maxAp: 2,
      moveRange: 3,
      movedThisTurn: false,
      armorClass: 13,
      initiative: 7,
      stats: { str: 14, dex: 10, int: 10, cha: 10 },
      cooldowns: {},
      statuses: [],
      isKO: false,
      koTimer: 0,
      abilities: baseUnits.find((u) => u.faction === 'enemy')!.abilities,
    },
    {
      id: 'trial_mage_displacement_immune',
      name: 'Colossus Ward-Golem',
      title: 'Displacement-Immune Target (Testing Pull Resistance)',
      faction: 'enemy',
      archetype: 'bruiser',
      gridX: 5,
      gridZ: 6,
      elevation: 0,
      hp: 36,
      maxHp: 36,
      tempHp: 0,
      ap: 2,
      maxAp: 2,
      moveRange: 2,
      movedThisTurn: false,
      armorClass: 14,
      initiative: 6,
      stats: { str: 18, dex: 8, int: 8, cha: 8 },
      cooldowns: {},
      statuses: [],
      immunities: ['displacement'],
      isKO: false,
      koTimer: 0,
      abilities: baseUnits.find((u) => u.faction === 'enemy')!.abilities,
    },
  ];

  return {
    grid,
    envObjects: createEncounterObjects(0),
    units: [...trialAllies, ...trialEnemies].sort((a, b) => b.initiative - a.initiative),
  };
}


