import test from 'node:test';
import assert from 'node:assert/strict';
import {
  performanceManager,
  exponentialDamp,
  clampDeltaTime,
  TARGET_FPS_OPTIONS,
  TargetFpsMode,
} from './performanceManager';

test('1. Target FPS Options: Supports Native VRR, 60, 120, 144, 240, 360, and Uncapped', () => {
  assert.equal(TARGET_FPS_OPTIONS.length, 7);

  const expectedModes: TargetFpsMode[] = ['native', '60', '120', '144', '240', '360', 'uncapped'];
  for (const mode of expectedModes) {
    assert.ok(
      TARGET_FPS_OPTIONS.some((o) => o.id === mode),
      `Must support target mode ${mode}`
    );
  }

  // Set and test each target
  performanceManager.setTargetMode('360');
  assert.equal(performanceManager.getTargetMode(), '360');
  assert.equal(performanceManager.getTargetFpsNumber(), 360);

  performanceManager.setTargetMode('240');
  assert.equal(performanceManager.getTargetFpsNumber(), 240);

  performanceManager.setTargetMode('144');
  assert.equal(performanceManager.getTargetFpsNumber(), 144);

  performanceManager.setTargetMode('60');
  assert.equal(performanceManager.getTargetFpsNumber(), 60);

  performanceManager.setTargetMode('native');
  assert.equal(performanceManager.getTargetFpsNumber(), 0); // Native/VRR is unthrottled

  performanceManager.setTargetMode('uncapped');
  assert.equal(performanceManager.getTargetFpsNumber(), 0);
});

test('2. shouldThrottleFrame: Accurately enforces target frametimes for 60, 144, and 360 FPS', () => {
  performanceManager.setTargetMode('60'); // 16.67ms min interval
  const t0 = 1000;

  // After 5ms (too early for 60 FPS) -> should throttle
  assert.equal(performanceManager.shouldThrottle(t0 + 5, t0), true);
  // After 17ms (ready for next 60 FPS frame) -> should NOT throttle
  assert.equal(performanceManager.shouldThrottle(t0 + 17, t0), false);

  // At 144 FPS (~6.94ms min interval)
  performanceManager.setTargetMode('144');
  assert.equal(performanceManager.shouldThrottle(t0 + 3, t0), true);
  assert.equal(performanceManager.shouldThrottle(t0 + 7, t0), false);

  // At 360 FPS (~2.78ms min interval)
  performanceManager.setTargetMode('360');
  assert.equal(performanceManager.shouldThrottle(t0 + 1.2, t0), true);
  assert.equal(performanceManager.shouldThrottle(t0 + 2.8, t0), false);

  // At Native/Uncapped -> never throttles
  performanceManager.setTargetMode('native');
  assert.equal(performanceManager.shouldThrottle(t0 + 0.5, t0), false);
});

test('3. Mathematical Frame-Rate Independence: Exponential Damping vs Linear Lerp Drift', () => {
  // Scenario: An object moves from pos = 0 towards target = 100 with lambda = 6.0 over 1.0 second.
  // Test 1: 60 FPS (60 discrete steps of dt = 1/60s)
  let pos60 = 0;
  const dt60 = 1 / 60;
  for (let i = 0; i < 60; i++) {
    const alpha = exponentialDamp(6.0, dt60);
    pos60 += (100 - pos60) * alpha;
  }

  // Test 2: 360 FPS (360 discrete steps of dt = 1/360s)
  let pos360 = 0;
  const dt360 = 1 / 360;
  for (let i = 0; i < 360; i++) {
    const alpha = exponentialDamp(6.0, dt360);
    pos360 += (100 - pos360) * alpha;
  }

  // Verify that final positions match almost identically (< 0.0001% divergence)
  const difference = Math.abs(pos60 - pos360);
  assert.ok(
    difference < 0.001,
    `Exponential damp must yield identical positions at 60fps (${pos60.toFixed(4)}) and 360fps (${pos360.toFixed(4)}) - diff: ${difference}`
  );

  // In contrast, naive linear lerp `pos += (100 - pos) * (speed * dt)` deviates drastically between 60fps and 360fps:
  let naive60 = 0;
  for (let i = 0; i < 60; i++) {
    naive60 += (100 - naive60) * (6.0 * dt60);
  }
  let naive360 = 0;
  for (let i = 0; i < 360; i++) {
    naive360 += (100 - naive360) * (6.0 * dt360);
  }
  const naiveDiff = Math.abs(naive60 - naive360);
  assert.ok(
    naiveDiff > 0.01,
    `Naive linear lerp causes noticeable drift between 60fps and 360fps: ${naiveDiff}`
  );
});

test('4. clampDeltaTime: Preserves 360Hz precision and prevents spiral of death', () => {
  // At 360Hz: dt ~ 0.00277s -> must preserve exact sub-millisecond precision
  const dt360 = 1 / 360;
  assert.equal(clampDeltaTime(dt360), dt360);

  // At 144Hz: dt ~ 0.00694s -> preserved
  const dt144 = 1 / 144;
  assert.equal(clampDeltaTime(dt144), dt144);

  // Huge stall (e.g. 1.2s when switching tabs) -> clamped to 0.05s (50ms)
  assert.equal(clampDeltaTime(1.2), 0.05);

  // Zero or negative delta -> clamped to positive epsilon
  assert.ok(clampDeltaTime(0) > 0);
  assert.ok(clampDeltaTime(-0.1) > 0);
});

test('5. Performance Metrics Recorder: Accurately reflects 360 FPS and 60 FPS rates', () => {
  performanceManager.setTargetMode('native');

  // Simulate 60 frames at 360 FPS (interval = 1000 / 360 = 2.777ms)
  let mockTime = 10000;
  for (let i = 0; i < 60; i++) {
    mockTime += 1000 / 360;
    performanceManager.recordFrame(mockTime);
  }

  const m360 = performanceManager.getCurrentMetrics();
  assert.ok(
    m360.currentFps >= 340 && m360.currentFps <= 380,
    `Smoothed FPS should be close to 360 (got ${m360.currentFps})`
  );
  assert.ok(
    m360.frameTimeMs >= 2.5 && m360.frameTimeMs <= 3.2,
    `Frame time should be ~2.78ms (got ${m360.frameTimeMs})`
  );
  assert.equal(m360.smoothnessRating, 'Ultra Smooth (360Hz)');

  // Now simulate 60 frames at 60 FPS (interval = 1000 / 60 = 16.666ms)
  for (let i = 0; i < 60; i++) {
    mockTime += 1000 / 60;
    performanceManager.recordFrame(mockTime);
  }

  const m60 = performanceManager.getCurrentMetrics();
  assert.ok(
    m60.currentFps >= 55 && m60.currentFps <= 65,
    `Smoothed FPS should be close to 60 (got ${m60.currentFps})`
  );
  assert.ok(
    m60.frameTimeMs >= 15.5 && m60.frameTimeMs <= 17.5,
    `Frame time should be ~16.67ms (got ${m60.frameTimeMs})`
  );
  assert.equal(m60.smoothnessRating, 'Smooth (60-120Hz)');
});
