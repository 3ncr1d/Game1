import test from 'node:test';
import assert from 'node:assert/strict';
import {
  DistrictId,
  InteriorId,
  TOWN_GRID_SIZE,
  GLOAMREST_DISTRICTS,
  GLOAMREST_INTERIORS,
  generateGloamrestExteriorGrid,
} from './gloamrestMapAndInteriors';
import {
  MAP_DISTRICT_METADATA,
  MAP_BUILDINGS,
  isDistrictDiscovered,
  isDistrictFullyExplored,
  getDistrictDiscoveryState,
  getDiscoveredDistrictsCount,
  getExploredInteriorsCount,
  getActiveQuestMapMarkers,
  getNpcMapMarkers,
  getServiceMapMarkers,
} from './gloamrestMapData';
import { createDefaultCharacterBuild } from './rules';
import { createInitialGloamrestState } from './gloamrestEngine';
import { GloamrestSaveState } from './gloamrestEngineTypes';
import { SavedAdventureSlot } from './saveAdventureSlots';

/**
 * GLOAMREST SETTLEMENT MAP TEST SUITE
 * Verifies cartographic layout, 9 districts, buildings, grid geometry,
 * player tracking, quest markers, district/interior discovery, and persistence.
 */

test('1. Settlement Districts: exactly 9 distinct districts with valid world bounds and center coordinates', () => {
  const districtKeys = Object.keys(MAP_DISTRICT_METADATA) as DistrictId[];
  assert.equal(districtKeys.length, 9, 'Must define exactly 9 districts');

  const expectedDistricts: DistrictId[] = [
    'hearth_square',
    'wandering_stag_tavern',
    'ironroot_forge',
    'green_vessel',
    'chapel_last_light',
    'watch_barracks',
    'timber_yard',
    'abandoned_manor',
    'whispering_gate',
  ];

  for (const id of expectedDistricts) {
    const meta = MAP_DISTRICT_METADATA[id];
    assert.ok(meta, `District ${id} must exist in map metadata`);
    assert.ok(meta.name.length > 0, `District ${id} must have a name`);
    assert.ok(meta.category.length > 0, `District ${id} must have a category`);
    assert.ok(meta.landmarks.length >= 2, `District ${id} must have at least 2 landmarks`);
    assert.ok(meta.services.length >= 1, `District ${id} must have available services`);
    assert.ok(meta.entryRoads.length >= 1, `District ${id} must have connecting entry roads`);

    // Verify bounds fit within the 50x50 world grid
    assert.ok(meta.bounds.minX >= 0 && meta.bounds.maxX < TOWN_GRID_SIZE);
    assert.ok(meta.bounds.minZ >= 0 && meta.bounds.maxZ < TOWN_GRID_SIZE);
    assert.ok(meta.bounds.minX <= meta.bounds.maxX);
    assert.ok(meta.bounds.minZ <= meta.bounds.maxZ);

    // Verify center is inside bounds
    assert.ok(meta.center.x >= meta.bounds.minX && meta.center.x <= meta.bounds.maxX);
    assert.ok(meta.center.z >= meta.bounds.minZ && meta.center.z <= meta.bounds.maxZ);
  }
});

test('2. Building Catalogue: all major buildings have real world footprints, door coordinates, and services', () => {
  assert.ok(MAP_BUILDINGS.length >= 10, 'Must have at least 10 major buildings');

  const buildingIds = new Set<string>();

  for (const bldg of MAP_BUILDINGS) {
    assert.ok(!buildingIds.has(bldg.id), `Duplicate building ID: ${bldg.id}`);
    buildingIds.add(bldg.id);

    assert.ok(bldg.name.length > 0);
    assert.ok(MAP_DISTRICT_METADATA[bldg.districtId], `Building ${bldg.id} has valid district`);
    assert.ok(bldg.footprint.minX <= bldg.footprint.maxX);
    assert.ok(bldg.footprint.minZ <= bldg.footprint.maxZ);
    assert.ok(bldg.footprint.minX >= 0 && bldg.footprint.maxX < TOWN_GRID_SIZE);
    assert.ok(bldg.footprint.minZ >= 0 && bldg.footprint.maxZ < TOWN_GRID_SIZE);

    if (bldg.doorTile) {
      assert.ok(bldg.doorTile.x >= 0 && bldg.doorTile.x < TOWN_GRID_SIZE);
      assert.ok(bldg.doorTile.z >= 0 && bldg.doorTile.z < TOWN_GRID_SIZE);
    }
  }
});

test('3. Connected Urban Geometry: River, 3 Bridges, Perimeter Walls, and Walkable Roads', () => {
  const grid = generateGloamrestExteriorGrid();
  assert.equal(grid.length, TOWN_GRID_SIZE);
  assert.equal(grid[0].length, TOWN_GRID_SIZE);

  // Silverbrook River at x = 31..32 is water and unwalkable
  assert.equal(grid[31][15].terrain, 'river_water');
  assert.equal(grid[31][15].walkable, false);

  // 3 Bridges cross the river and are walkable:
  // Bridge 1: Northern Gatehouse Stone Bridge (z=7, x=31)
  assert.equal(grid[31][7].terrain, 'stone_bridge');
  assert.equal(grid[31][7].walkable, true);

  // Bridge 2: Central Market Stone Bridge (z=24, x=31)
  assert.equal(grid[31][24].terrain, 'stone_bridge');
  assert.equal(grid[31][24].walkable, true);

  // Bridge 3: Southern Mill Wooden Bridge (z=36, x=31)
  assert.equal(grid[31][36].terrain, 'wooden_bridge');
  assert.equal(grid[31][36].walkable, true);

  // Ancient Stone Well at (24, 25) is solid rim surrounded by walkable cobble plaza at (24, 26)
  assert.equal(grid[24][25].terrain, 'cobble_plaza');
  assert.equal(grid[24][25].walkable, false);
  assert.equal(grid[24][26].walkable, true);
});

test('4. District Discovery & Exploration System: handles unknown, discovered, and fully explored tiers', () => {
  const build = createDefaultCharacterBuild();
  let state = createInitialGloamrestState(build);

  // Initially: only Hearth Square is discovered
  assert.equal(isDistrictDiscovered(state, 'hearth_square'), true);
  assert.equal(isDistrictDiscovered(state, 'ironroot_forge'), false);
  assert.equal(getDiscoveredDistrictsCount(state), 1);
  assert.equal(getDistrictDiscoveryState(state, 'ironroot_forge'), 'unknown');

  // Discover Ironroot Forge
  state = {
    ...state,
    discoveredDistricts: [...state.discoveredDistricts, 'ironroot_forge'],
  };
  assert.equal(isDistrictDiscovered(state, 'ironroot_forge'), true);
  assert.equal(getDiscoveredDistrictsCount(state), 2);
  // Interior not yet discovered: state is 'discovered', not 'fully_explored'
  assert.equal(isDistrictFullyExplored(state, 'ironroot_forge'), false);
  assert.equal(getDistrictDiscoveryState(state, 'ironroot_forge'), 'discovered');

  // Enter the Forge interior
  state = {
    ...state,
    discoveredInteriors: [...state.discoveredInteriors, 'forge'],
  };
  assert.equal(getExploredInteriorsCount(state), 1);
  assert.equal(isDistrictFullyExplored(state, 'ironroot_forge'), true);
  assert.equal(getDistrictDiscoveryState(state, 'ironroot_forge'), 'fully_explored');
});

test('5. Interior Discovery Independence: discovering an exterior district does not discover its interior', () => {
  const build = createDefaultCharacterBuild();
  let state = createInitialGloamrestState(build);

  // Add all districts to discovered
  state = {
    ...state,
    discoveredDistricts: [
      'hearth_square',
      'wandering_stag_tavern',
      'ironroot_forge',
      'green_vessel',
      'chapel_last_light',
      'watch_barracks',
      'timber_yard',
      'abandoned_manor',
      'whispering_gate',
    ],
  };

  assert.equal(getDiscoveredDistrictsCount(state), 9);
  // Interiors should still be 0 until explicitly visited!
  assert.equal(getExploredInteriorsCount(state), 0);
  assert.equal(state.discoveredInteriors.includes('tavern'), false);
  assert.equal(state.discoveredInteriors.includes('chapel'), false);
  assert.equal(state.discoveredInteriors.includes('manor_basement'), false);
});

test('6. Active Quest Objective Tracking: accurately derives diamond markers from current quest state', () => {
  const build = createDefaultCharacterBuild();
  const state = createInitialGloamrestState(build);

  // MQ01 is active in state by default
  const questMarkers = getActiveQuestMapMarkers(state);
  assert.ok(questMarkers.length >= 1, 'Should generate quest markers for active tracked quest');

  const firstMarker = questMarkers[0];
  assert.equal(firstMarker.type, 'quest');
  assert.equal(firstMarker.districtId, 'hearth_square');
  assert.equal(firstMarker.color, '#E2B05A');
  assert.ok(firstMarker.questCode?.includes('MAIN QUEST 01'));
});

test('7. NPC Markers: reflects named character waypoints based on current time of day', () => {
  const build = createDefaultCharacterBuild();
  const state = createInitialGloamrestState(build);

  // Test Morning schedule
  const morningState: GloamrestSaveState = { ...state, timeOfDay: 'morning' };
  const morningNpcMarkers = getNpcMapMarkers(morningState);
  assert.ok(morningNpcMarkers.length >= 4, 'Should map NPCs present on exterior during morning');

  const aldric = morningNpcMarkers.find((m) => m.title.includes('Aldric Veyne'));
  assert.ok(aldric, 'Elder Aldric Veyne must appear in morning markers');
  assert.equal(aldric.districtId, 'hearth_square');
});

test('8. Service & Travel Markers: provides standard icons for all settlement facilities', () => {
  const services = getServiceMapMarkers();
  assert.ok(services.length >= 8, 'Must provide markers for key services');

  const forge = services.find((s) => s.serviceTag === 'blacksmith');
  const tavern = services.find((s) => s.serviceTag === 'tavern');
  const alchemy = services.find((s) => s.serviceTag === 'alchemy');
  const exitNorth = services.find((s) => s.id === 'srv_exit_north');

  assert.ok(forge && forge.districtId === 'ironroot_forge');
  assert.ok(tavern && tavern.districtId === 'wandering_stag_tavern');
  assert.ok(alchemy && alchemy.districtId === 'green_vessel');
  assert.ok(exitNorth && exitNorth.districtId === 'whispering_gate');
});

test('9. Save/Load Persistence: SavedAdventureSlot preserves exploration data without regression', () => {
  const build = createDefaultCharacterBuild();
  const state = createInitialGloamrestState(build);

  state.discoveredDistricts = ['hearth_square', 'wandering_stag_tavern', 'green_vessel'];
  state.discoveredInteriors = ['tavern', 'herbalist'];

  const slot: SavedAdventureSlot = {
    id: 'slot-test-map',
    commanderName: 'Seraphina Vane',
    level: 3,
    raceId: 'half_elf',
    classId: 'paladin',
    subclassId: 'dawn_warden',
    originChoice: 'Mercy',
    stageId: 0,
    playtime: '02h 15m',
    saveDate: '2026-11-01 16:00',
    timestamp: Date.now(),
    gloamrestState: state,
  };

  const serialized = JSON.stringify(slot);
  const loadedSlot: SavedAdventureSlot = JSON.parse(serialized);

  assert.ok(loadedSlot.gloamrestState);
  assert.deepEqual(loadedSlot.gloamrestState.discoveredDistricts, [
    'hearth_square',
    'wandering_stag_tavern',
    'green_vessel',
  ]);
  assert.deepEqual(loadedSlot.gloamrestState.discoveredInteriors, ['tavern', 'herbalist']);
  assert.equal(getDiscoveredDistrictsCount(loadedSlot.gloamrestState), 3);
  assert.equal(getExploredInteriorsCount(loadedSlot.gloamrestState), 2);
});
