const fs = require('fs');
const path = require('path');

const ICONS_DIR = path.resolve(__dirname, '../public/assets/icons/progression-skills');

function makeIconSvg(id, palette, innerSvgContent, subjectComment) {
  const { bgDark, bgLight, border, stroke, glow, accent } = palette;
  return `<svg xmlns="http://www.w3.org/2000/svg" width="128" height="128" viewBox="0 0 128 128" fill="none">
  <defs>
    <radialGradient id="bg_${id}" cx="50%" cy="46%" r="62%">
      <stop offset="0%" stop-color="${bgLight}"/>
      <stop offset="100%" stop-color="${bgDark}"/>
    </radialGradient>
    <radialGradient id="aura_${id}" cx="50%" cy="50%" r="50%">
      <stop offset="0%" stop-color="${glow}" stop-opacity="0.25"/>
      <stop offset="100%" stop-color="${glow}" stop-opacity="0"/>
    </radialGradient>
  </defs>
  <!-- Background Plate -->
  <rect width="128" height="128" fill="url(#bg_${id})"/>
  <rect x="2" y="2" width="124" height="124" rx="4" fill="none" stroke="${border}" stroke-width="1.8" opacity="0.6"/>
  <!-- Corner Inset Flourishes -->
  <g opacity="0.45" stroke="${stroke}" stroke-width="1.2">
    <path d="M6 16L16 6M122 16L112 6M6 112L16 122M122 112L112 122"/>
    <circle cx="16" cy="16" r="2" fill="${accent}"/>
    <circle cx="112" cy="16" r="2" fill="${accent}"/>
    <circle cx="16" cy="112" r="2" fill="${accent}"/>
    <circle cx="112" cy="112" r="2" fill="${accent}"/>
  </g>
  <!-- Ambient Center Aura -->
  <circle cx="64" cy="64" r="50" fill="url(#aura_${id})"/>
  <!-- ${subjectComment} -->
  ${innerSvgContent.trim()}
</svg>`;
}

const P_DAWN = { bgLight: '#2D2314', bgDark: '#120E06', border: '#997A3D', stroke: '#F59E0B', glow: '#FDE047', accent: '#FEF08A' };
const P_VENGEANCE = { bgLight: '#2C1616', bgDark: '#120707', border: '#7F2626', stroke: '#DC2626', glow: '#EF4444', accent: '#F87171' };
const P_CRIMSON = { bgLight: '#26121D', bgDark: '#10060B', border: '#701A4B', stroke: '#BE185D', glow: '#E11D48', accent: '#FB7185' };
const P_CHRONO = { bgLight: '#14252E', bgDark: '#071016', border: '#265F7A', stroke: '#06B6D4', glow: '#38BDF8', accent: '#67E8F9' };
const P_BRIAR = { bgLight: '#17281A', bgDark: '#08120A', border: '#2D6635', stroke: '#16A34A', glow: '#22C55E', accent: '#4ADE80' };
const P_SENTINEL = { bgLight: '#24251B', bgDark: '#0E100A', border: '#5C6141', stroke: '#84CC16', glow: '#A3E635', accent: '#BEF264' };

const SPEC_ICONS = {};

// DAWN WARDEN (6)
SPEC_ICONS['solar_flare'] = {
  palette: P_DAWN,
  comment: 'Solar Flare: Blinding Solar Corona Flash with Radiating Light Beams',
  svg: `
  <circle cx="64" cy="64" r="24" fill="#FEF08A"/>
  <circle cx="64" cy="64" r="34" fill="none" stroke="#F59E0B" stroke-width="3" stroke-dasharray="8 6"/>
  <path d="M64 12V32M64 96V116M12 64H32M96 64H116M28 28L42 42M86 86L100 100M28 100L42 86M86 42L100 28" stroke="#FEF08A" stroke-width="2.5" stroke-linecap="round"/>
  `
};

SPEC_ICONS['aegis_of_the_dawn'] = {
  palette: P_DAWN,
  comment: 'Aegis of the Dawn: Crystalline Light Pavilion Dome with Sun Emblems',
  svg: `
  <path d="M30 84C30 48 44 28 64 24C84 28 98 48 98 84Z" fill="#241B0E" stroke="#F59E0B" stroke-width="2.5"/>
  <path d="M42 84C42 54 52 40 64 36C76 40 86 54 86 84Z" fill="#423014" stroke="#FDE047" stroke-width="1.8"/>
  <circle cx="64" cy="58" r="10" fill="#FEF08A"/>
  <line x1="64" y1="24" x2="64" y2="100" stroke="#F59E0B" stroke-width="2"/>
  `
};

SPEC_ICONS['daybreak_smite'] = {
  palette: P_DAWN,
  comment: 'Daybreak Smite: Ascending Dawn Fire Blade Uppercut with Solar Wings',
  svg: `
  <path d="M38 104L64 26L72 32L50 110Z" fill="#F59E0B" stroke="#FEF08A" stroke-width="2"/>
  <path d="M64 26L74 16L82 24L72 32Z" fill="#FEF08A"/>
  <path d="M36 68C22 58 26 42 42 42C44 52 40 62 36 68Z" fill="#FDE047"/>
  <path d="M72 82C86 92 82 108 66 108C64 98 68 88 72 82Z" fill="#FDE047"/>
  `
};

SPEC_ICONS['sunwell_aura'] = {
  palette: P_DAWN,
  comment: 'Sunwell Aura: Sacred Spring Well Head with Concentric Radiance Ripples',
  svg: `
  <ellipse cx="64" cy="74" rx="42" ry="20" fill="#1C150A" stroke="#F59E0B" stroke-width="2.5"/>
  <ellipse cx="64" cy="74" rx="28" ry="12" fill="#3D2E14" stroke="#FDE047" stroke-width="1.8"/>
  <ellipse cx="64" cy="74" rx="14" ry="6" fill="#FEF08A"/>
  <path d="M64 24L68 54H60Z" fill="#FEF08A"/>
  <circle cx="64" cy="22" r="5" fill="#FEF08A"/>
  `
};

SPEC_ICONS['radiant_bastion'] = {
  palette: P_DAWN,
  comment: 'Radiant Bastion: Quad-Pillar Sun Pavilion with Protective Solar Runes',
  svg: `
  <rect x="28" y="44" width="72" height="52" rx="4" fill="#20170A" stroke="#F59E0B" stroke-width="2.5"/>
  <path d="M22 44L64 20L106 44Z" fill="#382912" stroke="#FDE047" stroke-width="2"/>
  <line x1="42" y1="44" x2="42" y2="96" stroke="#F59E0B" stroke-width="2"/>
  <line x1="86" y1="44" x2="86" y2="96" stroke="#F59E0B" stroke-width="2"/>
  <circle cx="64" cy="68" r="10" fill="#FEF08A"/>
  `
};

SPEC_ICONS['avatar_of_the_sun'] = {
  palette: P_DAWN,
  comment: 'Avatar of the Sun: Incandescent Solar Being with Six Sun Wings',
  svg: `
  <circle cx="64" cy="46" r="14" fill="#FEF08A"/>
  <path d="M54 78C54 62 64 58 64 58C64 58 74 62 74 78L64 104Z" fill="#FDE047"/>
  <path d="M50 42C28 32 20 48 24 64C36 58 44 50 50 42Z" fill="#F59E0B"/>
  <path d="M78 42C100 32 108 48 104 64C92 58 84 50 78 42Z" fill="#F59E0B"/>
  <path d="M46 64C26 64 22 80 30 92C38 84 42 74 46 64Z" fill="#F59E0B"/>
  <path d="M82 64C102 64 106 80 98 92C90 84 86 74 82 64Z" fill="#F59E0B"/>
  `
};

// VENGEANCE KNIGHT (6)
SPEC_ICONS['retribution_strike'] = {
  palette: P_VENGEANCE,
  comment: 'Retribution Strike: Jagged Heavy Executioner Blade Dripping Crimson Vengeance',
  svg: `
  <path d="M26 102L96 32L106 42L36 112Z" fill="#7F1D1D" stroke="#EF4444" stroke-width="2"/>
  <polygon points="96,32 108,20 118,30 106,42" fill="#EF4444"/>
  <path d="M48 64L62 60L58 74Z" fill="#DC2626"/>
  <path d="M68 44L82 40L78 54Z" fill="#DC2626"/>
  <circle cx="64" cy="64" r="5" fill="#FCA5A5"/>
  `
};

SPEC_ICONS['spiteful_ward'] = {
  palette: P_VENGEANCE,
  comment: 'Spiteful Ward: Spiked Iron Coffin Shield with Impaling Barbs',
  svg: `
  <polygon points="64,22 96,44 86,104 64,114 42,104 32,44" fill="#180C0C" stroke="#DC2626" stroke-width="2.5"/>
  <polygon points="64,44 68,30 64,34 60,30" fill="#EF4444"/>
  <polygon points="80,58 94,54 90,62 86,66" fill="#EF4444"/>
  <polygon points="48,58 34,54 38,62 42,66" fill="#EF4444"/>
  <circle cx="64" cy="68" r="10" fill="#7F1D1D" stroke="#EF4444" stroke-width="2"/>
  `
};

SPEC_ICONS['dread_inscription'] = {
  palette: P_VENGEANCE,
  comment: 'Dread Inscription: Searing Blood Rune Inscribed in Mid-Air',
  svg: `
  <path d="M64 24L38 52H90L64 24Z" fill="none" stroke="#DC2626" stroke-width="3"/>
  <path d="M38 76L64 104L90 76H38Z" fill="none" stroke="#DC2626" stroke-width="3"/>
  <line x1="64" y1="20" x2="64" y2="108" stroke="#EF4444" stroke-width="2.5"/>
  <circle cx="64" cy="64" r="8" fill="#F87171"/>
  `
};

SPEC_ICONS['unrelenting_vengeance'] = {
  palette: P_VENGEANCE,
  comment: 'Unrelenting Vengeance: Demonic Horned War Skull with Burning Red Eyes',
  svg: `
  <path d="M42 50C42 36 52 28 64 28C76 28 86 36 86 50C86 64 78 72 74 78H54C50 72 42 64 42 50Z" fill="#1C0A0A" stroke="#DC2626" stroke-width="2.5"/>
  <!-- Curved Demonic Horns -->
  <path d="M46 36C34 26 26 36 22 50C30 46 38 42 46 40Z" fill="#7F1D1D" stroke="#EF4444" stroke-width="1.5"/>
  <path d="M82 36C94 26 102 36 106 50C98 46 90 42 82 40Z" fill="#7F1D1D" stroke="#EF4444" stroke-width="1.5"/>
  <circle cx="53" cy="52" r="5" fill="#EF4444"/>
  <circle cx="75" cy="52" r="5" fill="#EF4444"/>
  `
};

SPEC_ICONS['executioners_wrath'] = {
  palette: P_VENGEANCE,
  comment: 'Executioners Wrath: Heavy Crescent Executioner Axe Cleaving Downward',
  svg: `
  <line x1="42" y1="106" x2="86" y2="22" stroke="#521B1B" stroke-width="4" stroke-linecap="round"/>
  <path d="M72 34C88 20 106 32 104 56C96 66 84 66 74 54Z" fill="#7F1D1D" stroke="#EF4444" stroke-width="2.5"/>
  <path d="M68 42C56 50 48 44 46 38C52 32 62 34 68 42Z" fill="#DC2626"/>
  <line x1="90" y1="56" x2="114" y2="80" stroke="#F87171" stroke-width="2.5" stroke-linecap="round"/>
  `
};

SPEC_ICONS['oath_of_total_ruin'] = {
  palette: P_VENGEANCE,
  comment: 'Oath of Total Ruin: Cataclysmic Blood Nova Detonating All Armor Plates',
  svg: `
  <circle cx="64" cy="64" r="22" fill="#7F1D1D" stroke="#EF4444" stroke-width="3"/>
  <circle cx="64" cy="64" r="10" fill="#FCA5A5"/>
  <polygon points="64,16 70,36 90,40 74,54 78,74 64,62 50,74 54,54 38,40 58,36" fill="#DC2626" opacity="0.8"/>
  <line x1="24" y1="24" x2="44" y2="44" stroke="#EF4444" stroke-width="2.5"/>
  <line x1="104" y1="24" x2="84" y2="44" stroke="#EF4444" stroke-width="2.5"/>
  <line x1="24" y1="104" x2="44" y2="84" stroke="#EF4444" stroke-width="2.5"/>
  <line x1="104" y1="104" x2="84" y2="84" stroke="#EF4444" stroke-width="2.5"/>
  `
};

// CRIMSON SAVANT (6)
SPEC_ICONS['blood_siphon'] = {
  palette: P_CRIMSON,
  comment: 'Blood Siphon: Siphoning Arterial Conduits Flowing into Vampire Chalice',
  svg: `
  <path d="M48 40H80L74 72C74 82 66 88 64 88C62 88 54 82 54 72Z" fill="#3B0724" stroke="#BE185D" stroke-width="2.5"/>
  <path d="M60 88V106H68V88" stroke="#BE185D" stroke-width="3"/>
  <line x1="50" y1="106" x2="78" y2="106" stroke="#BE185D" stroke-width="3" stroke-linecap="round"/>
  <!-- Inflowing Siphon Droplets -->
  <circle cx="64" cy="22" r="5" fill="#FB7185"/>
  <circle cx="50" cy="30" r="4" fill="#E11D48"/>
  <circle cx="78" cy="30" r="4" fill="#E11D48"/>
  `
};

SPEC_ICONS['boiling_veins'] = {
  palette: P_CRIMSON,
  comment: 'Boiling Veins: Branching Blood Vessels Igniting with Sizzling Embers',
  svg: `
  <path d="M64 104V72M64 72L42 46M64 72L86 46M42 46L30 26M42 46L54 26M86 46L74 26M86 46L98 26" fill="none" stroke="#E11D48" stroke-width="3" stroke-linecap="round"/>
  <circle cx="30" cy="26" r="4" fill="#FB7185"/>
  <circle cx="54" cy="26" r="4" fill="#FB7185"/>
  <circle cx="74" cy="26" r="4" fill="#FB7185"/>
  <circle cx="98" cy="26" r="4" fill="#FB7185"/>
  <circle cx="64" cy="72" r="6" fill="#F43F5E"/>
  `
};

SPEC_ICONS['sanguine_transfusion'] = {
  palette: P_CRIMSON,
  comment: 'Sanguine Transfusion: Two Flowing Blood Droplets Intertwined in Harmony',
  svg: `
  <path d="M48 42C48 30 64 20 64 20C64 20 80 30 80 42C80 54 64 64 64 64C64 64 48 54 48 42Z" fill="#BE185D" stroke="#FB7185" stroke-width="2"/>
  <path d="M64 64C64 64 80 74 80 86C80 98 64 108 64 108C64 108 48 98 48 86C48 74 64 64 64 64Z" fill="#9D174D" stroke="#E11D48" stroke-width="2"/>
  <circle cx="64" cy="42" r="6" fill="#FECDD3"/>
  <circle cx="64" cy="86" r="6" fill="#FB7185"/>
  `
};

SPEC_ICONS['hemorrhage_curse'] = {
  palette: P_CRIMSON,
  comment: 'Hemorrhage Curse: Ornate Bleeding Eye of Malice with Crimson Teardrop',
  svg: `
  <path d="M26 60C44 40 84 40 102 60C84 80 44 80 26 60Z" fill="#2E0A1E" stroke="#BE185D" stroke-width="2.5"/>
  <circle cx="64" cy="60" r="16" fill="#831843" stroke="#FB7185" stroke-width="2"/>
  <circle cx="64" cy="60" r="6" fill="#0F0309"/>
  <!-- Bleeding Crimson Tear -->
  <path d="M64 76C64 76 72 86 72 94C72 102 64 108 64 108C64 108 56 102 56 94C56 86 64 76 64 76Z" fill="#E11D48"/>
  `
};

SPEC_ICONS['crimson_maelstrom'] = {
  palette: P_CRIMSON,
  comment: 'Crimson Maelstrom: Swirling Whirlpool Vortex of Boiling Dark Blood',
  svg: `
  <path d="M64 24C86 24 104 42 104 64C104 82 88 98 68 98C52 98 38 84 38 68C38 56 48 46 60 46C68 46 74 52 74 60" fill="none" stroke="#E11D48" stroke-width="3.5" stroke-linecap="round"/>
  <circle cx="74" cy="60" r="6" fill="#FB7185"/>
  <circle cx="34" cy="44" r="3.5" fill="#FB7185"/>
  <circle cx="94" cy="84" r="4.5" fill="#BE185D"/>
  `
};

SPEC_ICONS['heartstop_sovereign'] = {
  palette: P_CRIMSON,
  comment: 'Heartstop Sovereign: Squeezed Anatomical Heart with Crushing Necrotic Grip',
  svg: `
  <!-- Anatomical Heart Form -->
  <path d="M46 44C36 44 32 56 36 68C42 84 64 102 64 102C64 102 86 84 92 68C96 56 92 44 82 44C74 44 68 50 64 56C60 50 54 44 46 44Z" fill="#831843" stroke="#FB7185" stroke-width="2.5"/>
  <!-- Aorta & Vena Cava -->
  <path d="M54 44V26H62V48" stroke="#E11D48" stroke-width="3"/>
  <path d="M68 46V22H76V44" stroke="#BE185D" stroke-width="3"/>
  <!-- Gripping Talon Ring -->
  <circle cx="64" cy="68" r="14" fill="none" stroke="#FFFFFF" stroke-width="2.5" stroke-dasharray="6 4"/>
  `
};

// RIFT CHRONOMANCER (6)
SPEC_ICONS['time_slip'] = {
  palette: P_CHRONO,
  comment: 'Time Slip: Reversing Chronal Dial Rewinding Past Coordinates',
  svg: `
  <circle cx="64" cy="64" r="40" fill="#0C1B24" stroke="#06B6D4" stroke-width="2.5"/>
  <path d="M64 30C82 30 98 46 98 64C98 82 82 98 64 98C50 98 38 88 34 76" fill="none" stroke="#38BDF8" stroke-width="3" stroke-linecap="round"/>
  <polygon points="34,76 30,86 42,82" fill="#38BDF8"/>
  <line x1="64" y1="64" x2="52" y2="48" stroke="#67E8F9" stroke-width="3" stroke-linecap="round"/>
  <line x1="64" y1="64" x2="80" y2="64" stroke="#67E8F9" stroke-width="2.5" stroke-linecap="round"/>
  <circle cx="64" cy="64" r="4.5" fill="#FFFFFF"/>
  `
};

SPEC_ICONS['chronostasis'] = {
  palette: P_CHRONO,
  comment: 'Chronostasis: Crystalline Hourglass Encased in Frozen Temporal Sphere',
  svg: `
  <circle cx="64" cy="64" r="42" fill="#0B1A22" stroke="#38BDF8" stroke-width="2" stroke-dasharray="8 6"/>
  <!-- Hourglass Shape -->
  <polygon points="46,36 82,36 64,62" fill="#164E63" stroke="#06B6D4" stroke-width="2"/>
  <polygon points="46,92 82,92 64,66" fill="#164E63" stroke="#06B6D4" stroke-width="2"/>
  <circle cx="64" cy="64" r="4" fill="#67E8F9"/>
  <circle cx="64" cy="84" r="6" fill="#67E8F9"/>
  `
};

SPEC_ICONS['accelerate_flow'] = {
  palette: P_CHRONO,
  comment: 'Accelerate Flow: Forward Hastening Chronal Arrows with Clock Gears',
  svg: `
  <circle cx="64" cy="64" r="38" fill="none" stroke="#0891B2" stroke-width="2"/>
  <!-- Triple Forward Hastening Chevrons -->
  <path d="M42 44L60 64L42 84" fill="none" stroke="#06B6D4" stroke-width="3.5" stroke-linecap="round"/>
  <path d="M58 44L76 64L58 84" fill="none" stroke="#38BDF8" stroke-width="3.5" stroke-linecap="round"/>
  <path d="M74 44L92 64L74 84" fill="none" stroke="#67E8F9" stroke-width="3.5" stroke-linecap="round"/>
  `
};

SPEC_ICONS['echoes_of_eternity'] = {
  palette: P_CHRONO,
  comment: 'Echoes of Eternity: Cascading Temporal Ghost Silhouettes in Motion',
  svg: `
  <circle cx="48" cy="48" r="14" fill="#155E75" opacity="0.5"/>
  <circle cx="64" cy="56" r="14" fill="#0891B2" opacity="0.75"/>
  <circle cx="80" cy="64" r="14" fill="#06B6D4" stroke="#67E8F9" stroke-width="2"/>
  <path d="M38 78C38 68 48 68 48 68" stroke="#155E75" stroke-width="2" opacity="0.5"/>
  <path d="M54 86C54 76 64 76 64 76" stroke="#0891B2" stroke-width="2" opacity="0.75"/>
  <path d="M70 94C70 84 80 84 80 84" stroke="#38BDF8" stroke-width="2.5"/>
  `
};

SPEC_ICONS['paradox_nova'] = {
  palette: P_CHRONO,
  comment: 'Paradox Nova: Two Colliding Contradictory Timelines Exploding in Nova',
  svg: `
  <ellipse cx="64" cy="64" rx="44" ry="16" fill="none" stroke="#06B6D4" stroke-width="2.5" transform="rotate(-35 64 64)"/>
  <ellipse cx="64" cy="64" rx="44" ry="16" fill="none" stroke="#06B6D4" stroke-width="2.5" transform="rotate(35 64 64)"/>
  <circle cx="64" cy="64" r="16" fill="#155E75" stroke="#67E8F9" stroke-width="2.5"/>
  <circle cx="64" cy="64" r="8" fill="#FFFFFF"/>
  `
};

SPEC_ICONS['time_stop'] = {
  palette: P_CHRONO,
  comment: 'Time Stop: Grand Pendulum Clock Frozen at Dead Center in Absolute Zero',
  svg: `
  <rect x="42" y="24" width="44" height="40" rx="4" fill="#0F242F" stroke="#06B6D4" stroke-width="2.5"/>
  <circle cx="64" cy="44" r="12" fill="#164E63" stroke="#67E8F9" stroke-width="1.8"/>
  <line x1="64" y1="44" x2="64" y2="36" stroke="#FFFFFF" stroke-width="2" stroke-linecap="round"/>
  <line x1="64" y1="44" x2="72" y2="44" stroke="#FFFFFF" stroke-width="2" stroke-linecap="round"/>
  <line x1="64" y1="64" x2="64" y2="98" stroke="#38BDF8" stroke-width="3"/>
  <circle cx="64" cy="98" r="8" fill="#67E8F9"/>
  `
};

// BRIAR STALKER (6)
SPEC_ICONS['ambush_snare'] = {
  palette: P_BRIAR,
  comment: 'Ambush Snare: Living Root Snare Coiled with Thorn Barbs Ready to Spring',
  svg: `
  <path d="M34 64C34 44 54 36 68 46C82 56 82 78 66 84C52 90 40 76 44 60" fill="none" stroke="#16A34A" stroke-width="4" stroke-linecap="round"/>
  <polygon points="68,46 74,38 78,48" fill="#4ADE80"/>
  <polygon points="82,78 92,82 84,88" fill="#4ADE80"/>
  <polygon points="40,76 30,82 38,88" fill="#4ADE80"/>
  <circle cx="64" cy="64" r="6" fill="#FEF08A"/>
  `
};

SPEC_ICONS['shadow_thorn'] = {
  palette: P_BRIAR,
  comment: 'Shadow Thorn: Barbed Shadow Blowpipe Dart with Venomous Spine',
  svg: `
  <line x1="28" y1="100" x2="96" y2="32" stroke="#15803D" stroke-width="3" stroke-linecap="round"/>
  <polygon points="96,32 108,20 102,40" fill="#4ADE80"/>
  <polygon points="48,80 40,74 54,74" fill="#22C55E"/>
  <polygon points="64,64 56,58 70,58" fill="#22C55E"/>
  <polygon points="80,48 72,42 86,42" fill="#22C55E"/>
  `
};

SPEC_ICONS['bramble_stride'] = {
  palette: P_BRIAR,
  comment: 'Bramble Stride: Leaf-Veiled Agile Boot Gliding Effortlessly Across Thorns',
  svg: `
  <path d="M42 38L58 64L50 78L86 86L90 94H46L38 78L44 52Z" fill="#1B331F" stroke="#22C55E" stroke-width="2.5"/>
  <path d="M38 76C24 70 18 80 18 90C28 88 34 82 38 80Z" fill="#4ADE80"/>
  <path d="M20 98C40 92 60 104 80 96C100 88 112 102 112 98" fill="none" stroke="#15803D" stroke-width="2.5"/>
  `
};

SPEC_ICONS['venomous_bramble'] = {
  palette: P_BRIAR,
  comment: 'Venomous Bramble: Poisonous Briar Thicket with Dripping Emerald Thorns',
  svg: `
  <path d="M26 94L54 44L68 68L96 36L102 94" fill="none" stroke="#16A34A" stroke-width="3" stroke-linecap="round"/>
  <circle cx="54" cy="44" r="4.5" fill="#4ADE80"/>
  <circle cx="96" cy="36" r="4.5" fill="#4ADE80"/>
  <circle cx="68" cy="68" r="4.5" fill="#4ADE80"/>
  <circle cx="60" cy="80" r="3" fill="#86EFAC"/>
  `
};

SPEC_ICONS['lurker_in_the_foliage'] = {
  palette: P_BRIAR,
  comment: 'Lurker in the Foliage: Shrouded Stalker Face Concealed in Dense Fern Fronds',
  svg: `
  <path d="M28 88C38 60 52 42 78 32C66 52 64 74 60 92" fill="none" stroke="#15803D" stroke-width="3"/>
  <path d="M100 88C90 60 76 42 50 32C62 52 64 74 68 92" fill="none" stroke="#15803D" stroke-width="3"/>
  <circle cx="56" cy="64" r="3.5" fill="#4ADE80"/>
  <circle cx="72" cy="64" r="3.5" fill="#4ADE80"/>
  `
};

SPEC_ICONS['wrath_of_the_primordial_grove'] = {
  palette: P_BRIAR,
  comment: 'Wrath of the Primordial Grove: Colossal Subterranean Roots Clawing Bedrock',
  svg: `
  <path d="M64 24V64M64 64L36 98M64 64L92 98M64 64L50 106M64 64L78 106" stroke="#22C55E" stroke-width="4" stroke-linecap="round"/>
  <polygon points="36,98 28,110 40,104" fill="#86EFAC"/>
  <polygon points="92,98 100,110 88,104" fill="#86EFAC"/>
  <circle cx="64" cy="64" r="8" fill="#4ADE80"/>
  `
};

// IRONBOUGH SENTINEL (6)
SPEC_ICONS['ironwood_brace'] = {
  palette: P_SENTINEL,
  comment: 'Ironwood Brace: Gnarled Petrified Ironwood Trunk Armor with Steel Bands',
  svg: `
  <path d="M42 28C42 28 54 24 64 24C74 24 86 28 86 28L82 98C82 98 74 104 64 104C54 104 46 98 46 98Z" fill="#222417" stroke="#84CC16" stroke-width="2.8"/>
  <path d="M40 48H88M38 72H90" stroke="#A3E635" stroke-width="2.5"/>
  <circle cx="64" cy="60" r="6" fill="#BEF264"/>
  `
};

SPEC_ICONS['rooting_cleave'] = {
  palette: P_SENTINEL,
  comment: 'Rooting Cleave: Heavy Poleaxe Cleaving Ground with Tangling Vine Wraps',
  svg: `
  <line x1="32" y1="102" x2="94" y2="28" stroke="#4B3F2E" stroke-width="3.5" stroke-linecap="round"/>
  <path d="M82 36C96 26 106 38 102 54C94 62 84 58 76 48Z" fill="#36401E" stroke="#84CC16" stroke-width="2.5"/>
  <path d="M48 82C40 76 34 84 36 94C44 92 48 86 48 82Z" fill="#A3E635"/>
  <path d="M60 68C52 62 46 70 48 80" fill="none" stroke="#A3E635" stroke-width="2"/>
  `
};

SPEC_ICONS['grounded_bastion'] = {
  palette: P_SENTINEL,
  comment: 'Grounded Bastion: Massive Bedrock Anchor Plate with Forest Guardian Sigil',
  svg: `
  <polygon points="64,24 96,48 86,102 42,102 32,48" fill="#1C1E14" stroke="#84CC16" stroke-width="2.5"/>
  <circle cx="64" cy="64" r="14" fill="#313620" stroke="#A3E635" stroke-width="2"/>
  <line x1="64" y1="28" x2="64" y2="98" stroke="#BEF264" stroke-width="1.8"/>
  <line x1="36" y1="64" x2="92" y2="64" stroke="#BEF264" stroke-width="1.8"/>
  `
};

SPEC_ICONS['timberfall_slam'] = {
  palette: P_SENTINEL,
  comment: 'Timberfall Slam: Massive Fallen Petrified Timber Trunk Crashing Earth',
  svg: `
  <rect x="24" y="52" width="76" height="24" rx="5" transform="rotate(-25 64 64)" fill="#36291C" stroke="#84CC16" stroke-width="2.5"/>
  <line x1="20" y1="98" x2="108" y2="98" stroke="#5C6141" stroke-width="2.5"/>
  <polygon points="64,98 72,82 80,98" fill="#BEF264"/>
  <polygon points="44,98 52,86 58,98" fill="#BEF264"/>
  `
};

SPEC_ICONS['heart_of_the_ancient_bough'] = {
  palette: P_SENTINEL,
  comment: 'Heart of the Ancient Bough: Sacred Ancient Tree Heart Glowing with Sap',
  svg: `
  <circle cx="64" cy="64" r="34" fill="#1F2416" stroke="#84CC16" stroke-width="2.5"/>
  <circle cx="64" cy="64" r="20" fill="#3D4522" stroke="#A3E635" stroke-width="2"/>
  <circle cx="64" cy="64" r="8" fill="#BEF264"/>
  <path d="M64 30V18M64 98V110M30 64H18M98 64H110" stroke="#84CC16" stroke-width="2.5"/>
  `
};

SPEC_ICONS['colossus_of_the_vale'] = {
  palette: P_SENTINEL,
  comment: 'Colossus of the Vale: Titanic Ironwood Guardian Horned Monolith',
  svg: `
  <polygon points="64,18 90,44 82,106 46,106 38,44" fill="#202417" stroke="#84CC16" stroke-width="2.8"/>
  <!-- Ancient Antler Branches -->
  <path d="M48 38C34 26 26 38 22 46" fill="none" stroke="#A3E635" stroke-width="2.5"/>
  <path d="M80 38C94 26 102 38 106 46" fill="none" stroke="#A3E635" stroke-width="2.5"/>
  <circle cx="56" cy="56" r="4" fill="#BEF264"/>
  <circle cx="72" cy="56" r="4" fill="#BEF264"/>
  <polygon points="64,72 70,86 58,86" fill="#84CC16"/>
  `
};

let writtenCount = 0;
for (const [id, def] of Object.entries(SPEC_ICONS)) {
  const svg = makeIconSvg(id, def.palette, def.svg, def.comment);
  const filePath = path.join(ICONS_DIR, id + '.svg');
  fs.writeFileSync(filePath, svg, 'utf8');
  writtenCount++;
}

console.log('Successfully generated ' + writtenCount + ' distinct specialization skill icons in ' + ICONS_DIR);
